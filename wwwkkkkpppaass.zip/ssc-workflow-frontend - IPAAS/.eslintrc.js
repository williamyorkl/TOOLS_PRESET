// https://eslint.org/docs/user-guide/configuring

module.exports = {
  root: true,

  parserOptions: {
    parser: 'babel-eslint'
  },

  env: {
    // 可以使用浏览器中的一些全局变量(window)和node中的全局变量(process)
    browser: true,
    node: true
  },

  extends: [
    'plugin:vue/essential',
    '@vue/standard'
  ],

  // required to lint *.vue files
  plugins: [
    'vue'
  ],

  // add your custom rules here: 0-off-关闭, 1-warn-警告, 2-error-错误.调试中的代码允许有警告，打包与提交代码时请移除会触发警告的代码（如debugger）
  rules: {
    /**
     * js的一些规则说明，也可以直接查看eslint官方文档
     * https://segmentfault.com/a/1190000017461203
     */
    /** generator *周围是否允许有空格 */
    // 'generator-star-spacing': 0,

    /** 是否要求箭头函数的参数使用圆括号 */
    'arrow-parens': 0,

    /** 是否禁用不必要的转译字符 */
    'no-useless-escape': 0,

    /** 是否禁止使用console */
    'no-console': 0,

    /** 是否禁止出现未使用过的变量 */
    'no-unused-vars': [2, { "args": "after-used", "argsIgnorePattern": "^_" }],

    /** 是否必须使用全等 */
    'eqeqeq': 2,

    /** 是否要求在注释周围有空行 */
    'lines-around-comment': 0,

    /** 是否禁用行尾空白 */
    'no-trailing-spaces': 2,

    /** 是否指定return函数必须有返回值 */
    'consistent-return': 0,

    /** 是否要求function的左括号前必须有空格 */
    'space-before-function-paren': [2, 'never'],

    /** 是否禁止使用tab */
    'no-tabs': 2,

    /**
     * 是否可以直接使用prototype上的属性
     * 错误: const hasBarProperty = foo.hasOwnProperty("bar")
     * 正确: const hasBarProperty = Object.prototype.hasOwnProperty.call(foo, "bar")
     */
    'no-prototype-builtins': 0,

    /**
     * 是否可以debugger
     * 此处设置为warn，在提交代码或打包时请移除debugger
     */
    'no-debugger': 1,

    /** 禁止使用var声明变量 */
    'no-var': 2,

    /** 禁止对象字面量中出现重复的键 */
    'no-dupe-keys': 2,

    /** 禁止空块语句 */
    'no-empty': 2,

    /**
     * vue的一些规则配置
     * https://eslint.vuejs.org/rules/no-parsing-error.html
     */

    /**
     * template规则配置
     */
    'vue/no-parsing-error': [2],

    /** 不允许重复的属性 */
    'vue/no-duplicate-attributes': [2, {
      allowCoexistClass: true,
      allowCoexistStyle: true
    }],

    /** 是否允许重复的属性 */
    'vue/no-dupe-keys': [2],

    /** v-for */
    'vue/require-v-for-key': 2,
    'vue/valid-v-for': 2,

    /** prop类型与default值匹配检测 */
    'vue/require-valid-default-prop': 2,

    /** v-if和v-for不允许同时使用 */
    'vue/no-use-v-if-with-v-for': 2,

    /** 不允许未使用的components */
    'vue/no-unused-components': 2,

    /** computed必须有返回值 */
    'vue/return-in-computed-property': 0,

    /** template必须有根元素且根元素内容不能为空 */
    'vue/valid-template-root': 0,

    /** 组件名使用多个单词：这个规则暂不可用，开启后会报错 */
    // 'vue/multi-word-component-names': [2, {
    //   ignores: []
    // }],

    /** 组件名应该倾向于完整单词且使用大驼峰 */
    'vue/component-definition-name-casing': [2, 'PascalCase'],

    /** 标签自闭和 */
    'vue/html-self-closing': [2],

    /** 标签上的属性使用 驼峰 */
    'vue/attribute-hyphenation': ['error',  "never", { ignore: ["custom-prop"] }],

    // /** 从第一个属性开始换行：不支持 */
    // 'vue/first-attribute-linebreak': [2],

    /** > 是否换行 */
    'vue/html-closing-bracket-newline': [2, {
      'singleline': 'never',
      'multiline': 'always'
    }],

    /** >前面的空格 */
    'vue/html-closing-bracket-spacing': 2,

    /** html缩进 */
    'vue/html-indent': 2,

    /** 标签属性的引号 */
    'vue/html-quotes': 2,

    /** Require a line break before and after the contents of a multiline element */
    'vue/multiline-html-element-content-newline': [2],

    /** {{ 前后要有空格 }}  */
    'vue/mustache-interpolation-spacing': 2,

    /** 不允许有多个空格 */
    'vue/no-multi-spaces': 2,

    /** 标签中属性的 = 两边不允许有空格 */
    'vue/no-spaces-around-equal-signs-in-attribute': 2,

    /** props中属性名必须使用驼峰 */
    'vue/prop-name-casing': 2,

    /** 为每个未标记为required: true的prop设置默认值 */
    'vue/require-default-prop': 2,

    /** 必须指定prop属性的类型 */
    'vue/require-prop-types': 2,

    /** 必须使用简写: 关闭，因无法处理 v-bind="$attrs" */
    'vue/v-bind-style': 0,

    /** 必须使用简写: 关闭，因无法处理 v-on="$listeners" */
    'vue/v-on-style': 0,

    /** 必须使用简写 #defaule="data" => v-slot="data" ;   v-slot => #default  ;  v-slot:one => #one */
    'vue/v-slot-style': 2,

    /** 组件名不允许使用保留字 */
    'vue/no-reserved-component-names': 2,

    /** template标签上不要使用无意义的属性，如：class、普通prop属性、普通方法、ref等.因不支持，暂时关闭 */
    // 'vue/no-useless-template-attributes': 2,
  }
}
