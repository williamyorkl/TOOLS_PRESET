import './init'
import Vue from 'vue'
import 'utils/scroll'
import './components'
import './routerGuard'
import './registerPrototypeMethod'
import mountVueInstance from './mountVueInstance'
import installMixins from '@/mixins/modules'
import '@/base_components/common/register.js'
import '@/directives'
import JsonViewer from 'vue-json-viewer'

import '@/assets/svg-icon/index.js'

// 引入虚拟列表组件
import UmyUi from 'umy-ui'
import 'umy-ui/lib/theme-chalk/index.css'

Vue.use(UmyUi)
Vue.use(JsonViewer)

installMixins(Vue)

Vue.config.productionTip = false

// 根据环境挂载对应实例
mountVueInstance()
