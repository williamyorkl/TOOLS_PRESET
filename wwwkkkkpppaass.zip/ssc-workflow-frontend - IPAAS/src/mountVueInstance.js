import Vue from 'vue'
import store from 'store'
import App from './App'
import router from './router'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'

NProgress.start()

export default () => {
  if (process.env.VUE_APP_MODE === 'private') {
    // fetch环境配置信息
    store.dispatch('user/getLoginMethods').then(res => {
      NProgress.done()
      initVueInstance()
    }).catch(e => {
      NProgress.done()
    })
  } else if (process.env.VUE_APP_MODE === '__container__') {
    NProgress.done()
    initVueInstance()
  }

  function initVueInstance() {
    window.eventBus = new Vue({
      el: '#app',
      store,
      router,
      components: { App },
      template: '<App/>'
    })
  }
}
