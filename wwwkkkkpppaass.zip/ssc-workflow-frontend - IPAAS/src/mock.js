// 引入mockjs
const Mock = require('mockjs')
// 获取 mock.Random 对象
const Random = Mock.Random
// mock一组数据
const produceNewsData = function() {
  const articles = []
  for (let i = 0; i < 10; i++) {
    const newArticleObject = {
      bacthCode: Random.cname(),
      itemId: Random.cname(),
      itemName: Random.cname(),
      simplePriceLimit: Random.natural(1, 5),
      stackPriceLimit: Random.natural(1, 5),
      isTempPrice: Random.cname(),
      platformType: Random.cname(),
      beginTime: Random.date() + ' ' + Random.time(),
      endTime: Random.date() + ' ' + Random.time(),
      isDeleted: '否',
      shopId: Random.natural(1, 5),
      description: Random.csentence(5, 20),
      requestUrl: Random.csentence(5, 20),
      description: Random.csentence(5, 20),
      owner: Random.natural(1, 5)
    }
    articles.push(newArticleObject)
  }

  return {
    articles: articles
  }
}

// Mock.mock( url, post/get , 返回的数据)；
Mock.mock('/news/index', 'post', produceNewsData)
