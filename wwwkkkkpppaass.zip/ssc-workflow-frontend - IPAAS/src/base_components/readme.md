### 基础组件库
common中的组件在register中全局注册，只需引入register即可直接使用

# 新增组件
如果需要自动注入，组件文件夹必须以`mc-`开头，必须放在`common`目录下，组件文件必须为`index.vue`。 如`common/mc-btn-list/index.vue`
关于自动注入，查看`base_components/common/register.js`