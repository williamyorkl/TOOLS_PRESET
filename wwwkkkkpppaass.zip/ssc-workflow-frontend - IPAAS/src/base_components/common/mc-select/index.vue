<template>
  <el-select :value="value" v-bind="$attrs" v-on:change="valueChange">
    <el-option
      v-for="item in options"
      :key="item.value"
      :label="item[labelKey]"
      :value="item[valueKey]"
      :disabled="optionItemDisabled(item)"
    />
  </el-select>
</template>

<script>
export default {
  name: 'McSelect',
  model: {
    event: 'change'
  },
  props: {
    value: {
      type: [Number, String, Array],
      default: null
    },
    options: {
      type: Array,
      default: () => []
    },
    labelKey: {
      type: String,
      default: 'label'
    },
    valueKey: {
      type: String,
      default: 'value'
    },
    optionItemDisabled: {
      type: Function,
      default: () => false
    }
  },
  methods: {
    valueChange(v) {
      this.$emit('change', v)
    }
  }
}
</script>

<style>

</style>
