<template>
  <div class="btn-list">
    <el-button v-for="btn in btnList" :type="btn.type" :key="btn.eventType" @click="eventListener(btn.eventType)">{{btn.text}}</el-button>
  </div>
</template>

<script>
export default {
  name: 'McBtnList',
  props: {
    btnList: {
      type: Array,
      default: () => []
    }
  },
  methods: {
    eventListener(type) {
      this.$emit('eventListener', type)
    }
  }
}
</script>

<style>

</style>
