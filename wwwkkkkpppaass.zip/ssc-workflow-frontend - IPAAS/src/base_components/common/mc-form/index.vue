<template>
  <el-form
    ref="ruleForm"
    @submit.native.prevent
    :model="model"
    :rules="rules"
    :style="{ '--label-width': labelWidth }"
    v-bind="$attrs"
    :label-width="labelWidth"
    :class="{'form-wrap-top-border':showTopBorder,'form-wrap-bottom-border':showBottomBorder}"
    class="mc-form form-wrap"
    size="small"
    type="flex">
    <el-row>
      <slot />
    </el-row>
  </el-form>
</template>

<script>
export default {
  name: 'McForm',
  props: {
    model: {
      type: Object,
      default: () => ({})
    },
    rules: {
      type: Object,
      default: () => ({})
    },
    labelWidth: {
      type: String,
      default: '96px'
    },
    readonly: {
      type: Boolean,
      default: false
    },
    showTopBorder: {
      type: Boolean,
      default: false
    },
    showBottomBorder: {
      type: Boolean,
      default: true
    }
  },
  provide() {
    return {
      CcsForm: this
    }
  },
  data() {
    return {}
  },
  mounted() {

  },
  methods: {
    validate() {
      return new Promise((resolve, reject) => {
        this.$refs.ruleForm.validate((valid) => {
          resolve(valid)
        })
      })
    },
    clearValidate() {
      this.$refs.ruleForm.clearValidate()
    }
  }
}
</script>

<style lang="scss" scoped>
.form-wrap {
  padding-top: 16px;

  ::v-deep .el-form-item__content {
    // width: calc(100% - 19px - var(--label-width));
    margin-right: 19px;
  }

  &-top-border {
    border-top: 1px solid rgba(15, 29, 63, .1);
  }

  &-bottom-border {
    border-bottom: 1px solid rgba(15, 29, 63, .1);
  }
}
</style>
