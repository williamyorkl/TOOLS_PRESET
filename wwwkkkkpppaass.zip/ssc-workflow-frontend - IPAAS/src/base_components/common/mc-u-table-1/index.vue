<template>
  <el-form v-model="formData">
    <!-- NOTE - 必须指定 row-id 必须开启use-virtual-->
    <u-table
      v-bind="$attrs"
      ref="uTable"
      useVirtual
      :rowId="rowId"
      :treeConfig="cpTreeConfig"
      :height="height"
    >
      <McUTable1Column v-for="columnOption in columnOptions" :columnOption="columnOption" :key="columnOption.label" />
    </u-table>
    <el-button class="add-btn" @click="handleBottomAddRow" size="medium" type="dash" icon="el-icon-plus" v-if="isShowAddButton">添加</el-button>
  </el-form>
</template>

<script>
import McUTable1Column from './mc-u-table1-column'
export default {
  name: 'McUTable1',
  components: { McUTable1Column },
  props: {
    data: {
      type: Array,
      required: true
    },
    isShowAddButton: {
      type: Boolean,
      default: true
    },
    treeConfig: {
      type: Object,
      default: () => ({
        children: 'children',
        expandAll: false,
        hasChildren: 'hasChildren'
      })
    },
    // NOTE - 注意：不给height或者不给maxheight，又或者给的是0，use-virtual直接会关闭）。 树且不能用，不能展开
    height: {
      type: Number,
      default: 600
    },
    rowId: {
      type: String,
      default: 'id'
    }
  },
  computed: {
    formData() {
      return {
        tableData: this.data
      }
    },
    cpTreeConfig() {
      const defaultTreeConfig = {
        children: 'children',
        expandAll: false,
        hasChildren: 'hasChildren'
      }
      const cpTreeConfig = { ...defaultTreeConfig, ...this.treeConfig }
      return cpTreeConfig
    }
  },
  watch: {
    data: {
      handler(nV) {
        // data变化时重新reload
        if (this.$refs.uTable) {
          this.$refs.uTable.reloadData(nV)
        }
      }
    }
  },
  mounted() {
    // NOTE - this.datas 为引用赋值, 直接操作props传入的 data 数据
    this.datas = this.data
    this.$refs.uTable.reloadData(this.data)
  },
  methods: {
    // 删除节点
    delnode(row) {
      const rowId = 'id' // row-id="id"  如同你上面设置的
      this.datas = this.filterNode(this.datas, row, rowId)
      // 获取之前已经展开的
      const eExpand = this.$refs.uTable.getTreeExpandRecords()
      // 获取之前滚动的位置
      const scrollTop = this.$refs.uTable.tableExample().scrollTop
      // 删除完数据了，你可能需要重新载入数据
      this.$refs.uTable.reloadData(this.datas).then(() => {
        eExpand.forEach(row => {
          this.$refs.uTable.setTreeExpansion(row, true)
        })

        this.$refs.uTable.pagingScrollTopLeft(scrollTop)
      })
    },
    filterNode(data, row, rowId) {
      const newData = data.filter(x => x[rowId] !== row[rowId])
      newData.forEach(x => x.children && (x.children = this.filterNode(x.children, row, rowId)))
      return newData
    },
    // NOTE - 考虑到添加的对象可能不一样，所以emit到父组件添加
    handleBottomAddRow() {
      // this.$emit('handleBottomAddRow', this.formData)
      this.addnode(this.datas)
    },
    addnode(row, newRowItem) {
      const rowNode = null
      if (Array.isArray(row)) {
        row.push({
          id: Math.random(),
          ...newRowItem
        })
      } else {
        const children = [{
          id: Math.random(),
          ...newRowItem
        }]

        this.getTreeItem(this.datas, row, this.rowId, children)
      }

      // 获取之前已经展开的
      const eExpand = this.$refs.uTable.getTreeExpandRecords()
      // 获取之前滚动的位置
      const scrollTop = this.$refs.uTable.tableExample().scrollTop
      // 添加完数据了，你可能需要重新载入数据
      this.$refs.uTable.reloadData(this.datas).then(() => {
        eExpand.forEach(row => {
          this.$refs.uTable.setTreeExpansion(row, true)
        })
        this.$refs.uTable.setTreeExpansion(rowNode, true)

        this.$refs.uTable.pagingScrollTopLeft(scrollTop + 60)
      })
    },
    getTreeItem(data, row, rowId, children) {
      data.map(item => {
        if (item[rowId] === row[rowId]) {
          // 如果存在子节点children就直接push
          if (item[this.treeConfig.children]) {
            item[this.treeConfig.children].push(...children)
          } else {
            // 如果不存在子节点，就直接创建子节点
            item[this.treeConfig.children] = children
          }
        } else {
          if (item.children) {
            this.getTreeItem(item.children, row, rowId, children)
          }
        }
      })
    }

  }
}
</script>

<style scoped lang="scss">
.add-btn{
  width: 100%;
  margin-top: 5px;
}
</style>
