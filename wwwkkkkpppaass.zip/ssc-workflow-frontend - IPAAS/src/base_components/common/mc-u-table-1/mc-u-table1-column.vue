<template>
  <!-- 普通文本框 -->
  <u-table-column
    v-if="type === 'index'"
    type="index"
  />
</template>

<script>
export default {
  props: {
    columnOption: {
      type: Object,
      default: () => ({})
    }
  }
}
</script>

<style>

</style>
