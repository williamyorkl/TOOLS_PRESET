<template>
  <div class="mc-collapse-panel">
    <div class="collapse-header">
      <span>{{label}}</span>
      <div class="collpase-panel-visible-block" @click="toggleShow">
        <span class="toggle-switch">
          <i class="el-icon-arrow-down" v-if="isCollapse"></i>
          <i class="el-icon-arrow-up" v-else></i>
        </span>
      </div>
      <div class="desc">
        <slot name="desc"></slot>
      </div>
      <!-- <el-input class="desc-input" v-model="itemDesc" maxlength="128" :disabled="disabled"></el-input> -->
    </div>
    <div class="collapse-container" v-if="!isCollapse">
      <slot>
        content
      </slot>
    </div>
  </div>
</template>

<script>
export default {
  name: 'McCollapsePanel',
  props: {
    label: {
      type: String,
      default: '标题'
    },
    initState: { // 初始状态
      type: Boolean,
      default: true
    },
    description: { // 描述，可编辑
      type: String,
      default: ''
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      isCollapse: true
    }
  },
  created() {
    this.isCollapse = this.initState
  },
  computed: {
    itemDesc: {
      get() {
        return this.description
      },
      set(val) {
        this.$emit('update:description', val)
      }
    }
  },
  methods: {
    toggleShow() {
      this.isCollapse = !this.isCollapse
    }
  }
}
</script>

<style scoped lang="scss">
.mc-collapse-panel {
  background: rgba(0,0,0,0.02);
  .collapse-header{
    padding: 10px 0;
    margin-left:  5px;
    border-bottom: 1px solid #eee;
    .desc{
      width: 300px;
      float: right;
    }
  }
  .collpase-panel-visible-block {
    margin-left: 10px;
    background: #eee;
    display: inline-block;
    padding: 3px 5px;
    border-radius: 4px;
    box-sizing: border-box;
    cursor: pointer;
  }
  .collapse-container{
    padding: 10px
  }
}
</style>
