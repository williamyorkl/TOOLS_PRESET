
<script>
export default {
  name: 'McInput',
  props: {
    needPrefix: {
      default: true,
      type: Boolean
    },
    dataType: {
      default: 0,
      type: Number
    },
    placeholder: {
      default: '',
      type: String
    },
    disabled: {
      default: false,
      type: Boolean
    },
    // eslint-disable-next-line vue/require-prop-types
    value: {
      default: null,
      required: true
    },
    // eslint-disable-next-line vue/require-default-prop
    maxlength: {
      type: String,
      required: false
    },
    max: {
      default: 21474836473,
      type: Number
    },
    // 字符串和long型(6, 2)可以选择是否trim
    trim: {
      type: Boolean,
      default: true
    }
  },
  model: {
    prop: 'value',
    event: 'input'
  },
  computed: {
    inputType() {
      if ([10, 8, 11, 2, 6, 7].includes(this.dataType)) {
        return 'el-input'
      }
      if ([5, 4, 1, 12].includes(this.dataType)) {
        return 'el-input-number'
      }
      if ([3].includes(this.dataType)) {
        return 'el-input-boolean'
      }
      if ([9].includes(this.dataType)) {
        return 'el-date-picker'
      }
      return 'el-input'
    },
    computedMaxLength() {
      return this.getMaxLength(this.dataType)
    }
  },
  render() {
    return (
      this.renderComponent(this.inputType)
    )
  },
  methods: {
    handleInput(e) {
      // Long型检测一下数据格式
      if (this.dataType === 2) {
        // 正则表达式匹配整数
        const longExp = /^(-|\+)?\d+$/
        if (!longExp.test(e)) {
          e = ''
        }
      }
      this.$emit('input', this.trim ? e.trim() : e)
    },
    // 在blur时做转数字处理
    handleBlur(e) {
      let val = e.target.value
      if (this.inputType === 'el-input-number') {
        val = parseFloat(val)
        if (isNaN(val)) {
          val = null
        }
      }
      this.$emit('input', val)
    },
    handleChange(e) {
      this.$emit('input', e)
    },
    renderComponent(inputType) {
      const components = {
        'el-input': <el-input value={this.value} disabled={this.disabled} placeholder={(this.needPrefix ? '请输入' : '') + this.placeholder} maxlength={this.maxlength || this.computedMaxLength} onInput={e => this.handleInput(e)}></el-input>,
        'el-input-number': <el-input value={this.value} disabled={this.disabled} placeholder={(this.needPrefix ? '请输入' : '') + this.placeholder} onBlur={e => this.handleBlur(e)} onInput={e => this.handleInput(e)}></el-input>,
        'el-date-picker': <el-date-picker value={this.value} disabled={this.disabled} type="datetime" placeholder={(this.needPrefix ? '请选择' : '') + this.placeholder} value-format="yyyy-MM-dd HH:mm:ss" onInput={e => this.handleChange(e)}></el-date-picker>,
        'el-input-boolean': (
          <el-select value={this.value} disabled={this.disabled} placeholder={(this.needPrefix ? '请选择' : '') + this.placeholder} onChange={e => this.handleChange(e)} clearable>
            <el-option label="true" value={true}></el-option>
            <el-option label="false" value={false}></el-option>
          </el-select>)
      }
      return components[inputType]
    },
    getMaxLength(dataType) {
      switch (dataType) {
        // 对象、数组等类型使用字符串表单域，长度设置为128
        case 10:
        case 8:
        case 11:
        case 6:
        case 7:
          return '128'
          // long类型使用字符串表单，程度设置为32
        case 2:
          return '32'
        default:
          return '32'
      }
    }
  }
}
</script>

<style>

</style>
