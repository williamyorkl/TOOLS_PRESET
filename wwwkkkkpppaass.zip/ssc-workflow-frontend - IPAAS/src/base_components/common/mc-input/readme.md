# 根据不同类型渲染对应的input

# 使用示例
```html
<mc-input :dataType="1" v-model="value" :placeholder="名称" :needPrefix="true" :disabled="disabled" />
```