<template>
  <el-col :span="span" :offset="$attrs.offset" :push="$attrs.push" :pull="$attrs.pull">
    <el-form-item v-bind="$attrs" class="mc-form-item" :prop="$attrs.validProp || $attrs.prop">
      <!-- mc-form-item上传入desc时使用slot方式传入label -->
      <mc-form-item-label v-if="$attrs.desc" slot="label" :label="$attrs.label" :description="$attrs.desc" icon="el-icon-info" />
      <template>
        <!-- 使用slot -->
        <slot v-if="$slots.default" />
        <!-- input特殊处理 -->
        <component
          v-else-if="componentType === 'ElInput' || componentType === 'ElSwitch'"
          :is="componentType"
          v-model="model[$attrs.prop]"
          v-bind="cpEditProps"
          v-on="$listeners"
          :readonly="cpReadonly"
          :disabled="cpReadonly"
          @input="v => handleInput(v, $attrs.prop)"
        />
        <!-- input.number特殊处理 -->
        <component
          v-else-if="componentType === 'ElInputNumber'"
          :is="'ElInput'"
          v-model.number="model[$attrs.prop]"
          v-bind="cpEditProps"
          v-on="$listeners"
          :readonly="cpReadonly"
          :disabled="cpReadonly"
          @input="v => transNum(v, $attrs.prop)"
        />

        <el-select
          v-else-if="componentType === 'ElSelect'"
          v-model="model[$attrs.prop]"
          v-bind="cpEditProps"
          v-on="$listeners"
          :readonly="cpReadonly"
          :disabled="cpReadonly"
        >
          <el-option v-for="item in cpDict" :value="item[valueKey]" :label="item[labelKey]" :key="item[valueKey]" :disabled="item.disabled" v-on="$listeners" />
        </el-select>

        <el-radio-group
          v-else-if="componentType === 'ElRadioGroup'"
          v-model="model[$attrs.prop]"
          v-bind="cpEditProps"
          v-on="$listeners"
          :readonly="cpReadonly"
          :disabled="cpReadonly"
        >
          <el-radio v-for="item in cpDict" :key="item.type" :label="item.type">{{ item.desc }}</el-radio>
        </el-radio-group>

        <!-- 占位行 -->
        <div v-else-if="componentType === 'FormPlaceholder'" class="mc-form-item-placeholder" />

        <!-- 非Input的其他组件 -->
        <component
          v-else-if="componentType"
          :is="componentType"
          v-model="model[$attrs.prop]"
          v-bind="cpEditProps"
          v-on="$listeners"
          :disabled="cpReadonly"
        />
        <!-- 需要toolTip功能的组件，只支持input类型 -->
        <el-tooltip
          v-else-if="toolTip"
          :content="cpValue"
          placement="top"
          class="item"
          effect="dark"
        >
          <div>
            <el-input v-model="cpValue" v-bind="cpEditProps" :readonly="cpReadonly" :disabled="cpReadonly" />
          </div>
        </el-tooltip>
      </template>
      <!-- 不可编辑的组件，计算出要显示的value -->
      <!-- <el-input v-else :value="cpValue" disabled readonly></el-input> -->
    </el-form-item>
  </el-col>
</template>

<script>
export default {
  name: 'McFormItem',
  inject: ['CcsForm'],
  /**
   * props: el-form-item的属性会通过$attrs读取，不要在props中声明，新增的自定义属性才需要添加到props中
   */
  props: {
    span: {
      type: Number,
      default: 12
    },
    componentType: {
      type: String,
      default: ''
    },
    // 可接收字典key或字典列表数据，需要先获取dict列表数据再激活组件 [{type: 1, desc: '男'}]
    dict: {
      type: [String, Array],
      default: () => []
    },
    trim: {
      type: Boolean,
      default: true
    },
    editProps: {
      type: Object,
      default: () => ({})
    },
    toolTip: {
      type: Boolean,
      default: false
    },
    readonly: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    },
    valueKey: {
      type: String,
      default: 'type'
    },
    labelKey: {
      type: String,
      default: 'desc'
    }
  },
  watch: {
    // 父组件model属性指向对象发生变化时重新赋值给this.model
    'CcsForm.model': {
      handler(nV) {
        this.model = this.CcsForm.model
      },
      immediate: true
    }
  },
  computed: {
    cpReadonly() {
      return (this.CcsForm || {}).readonly || this.readonly || this.disabled
    },
    cpValue() {
      return this.model[this.$attrs.prop]
    },
    cpDict() {
      let cpDict = this.dict
      if (typeof this.dict === 'string') {
        if (!this.$store.state.new_dict) {
          console.log(new Error('数据字典获取失败'))
          cpDict = []
        } else {
          cpDict = this.$store.state.new_dict.dictMap[this.dict]
        }
      }
      return cpDict
    },
    // 填充一些默认值
    cpEditProps() {
      const defaultEditProps = { clearable: true }
      let cpEditProps = { ...this.editProps }
      if (this.componentType === 'ElInput') {
        let maxlength = 128
        if (this.editProps.type === 'textarea') {
          maxlength = 256
        }
        cpEditProps = {
          maxlength,
          placeholder: (this.disabled || this.readonly) ? '' : `请输入${this.$attrs.label || ''}`,
          ...this.editProps
        }
      } else if (this.componentType === 'ElInputNumber') {
        cpEditProps = {
          controlsPosition: 'right',
          precision: 2,
          placeholder: (this.disabled || this.readonly) ? '' : `请输入${this.$attrs.label || ''}`,
          ...this.editProps
        }
      } else if (this.componentType === 'ElSelect') {
        cpEditProps = {
          ...cpEditProps,
          placeholder: (this.disabled || this.readonly) ? '' : `请选择${this.$attrs.label || ''}`
        }
      } else if (this.componentType === 'McPopoverSelect') {
        cpEditProps = {
          ...cpEditProps,
          placeholder: (this.disabled || this.readonly) ? '' : `请选择${this.$attrs.label || ''}`
        }
      } else if (this.editProps.type === 'datetimerange' || this.editProps.type === 'daterange') {
        const pickerOptions = {
          shortcuts: [{
            text: '最近1周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近1个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setMonth(start.getMonth() - 1)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近3个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setMonth(start.getMonth() - 3)
              picker.$emit('pick', [start, end])
            }
          }]
        }
        cpEditProps = {
          pickerOptions,
          ...this.editProps
        }
      }
      return { ...defaultEditProps, ...cpEditProps }
    }
  },
  methods: {
    handleInput(target, key) {
      if (this.componentType !== 'ElInput' || !this.trim) {
        return
      }
      this.model[key] = target.trim()
    },
    // 转number
    transNum(target, key) {
      const res = parseFloat(target)
      this.model[key] = isNaN(res) ? null : res
    }
  }
}
</script>

<style scoped lang="scss">
.mc-form-item {
  ::v-deep .el-input-number--small {
    width: 100%;
  }

  ::v-deep .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100%;
  }

  ::v-deep .el-range-editor--small.el-input__inner {
    width: 100%;
  }
  .mc-form-item-placeholder{
    width: 100%;
    height: 32px !important;
  }
}
::v-deep .el-form-item--small .el-form-item__content {
  min-height: 33px; /* Moz */
} /* Moz */

</style>
