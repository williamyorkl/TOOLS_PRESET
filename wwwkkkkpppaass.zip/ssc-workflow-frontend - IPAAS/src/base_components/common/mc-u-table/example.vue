<template>
  <div>
    <mc-u-table :data="tableData" ref="McUtable">
      <mc-u-table-column
        type="text"
        :columnProps="{
          treeNode: true,
          prop: 'address',
          label: '地址1',
          minWidth: 100
        }"
      />
      <mc-u-table-column
        type="ElInput"
        :columnProps="{
          prop: 'address',
          label: '地址修改',
          minWidth: 200
        }"
        :formItemProps="{}"
      />
      <mc-u-table-column
        type="McSelect"
        :columnProps="{
          prop: 'sex',
          label: '性别',
          minWidth: 200
        }"
        :formProps="{
          placeholder: '请选择性别',
          options: [{value: 1, label: '男'}, {value: 2, label: '女'}]
        }"
        :formItemProps="{}"
      />
      <mc-u-table-column
        type="operate"
        :columnProps="{
          label: '操作',
          minWidth: 220,
          fixed: 'right'
        }"
        :btnList="btnList"
      />
    </mc-u-table>
  </div>
</template>

<script>
import { tableData } from './tableData'
export default {
  data() {
    return {
      a: null,
      tableData,
      btnList: [
        {
          title: '添加',
          type: 'text',
          event: (row) => {
            const newRowItem = {
              date: '7',
              name: '王小虎',
              address: ''
            }

            this.$refs.McUtable.addnode(row, newRowItem)
          }
        },
        {
          title: '编辑',
          type: 'text',
          event: (row) => {
            console.log('编辑', row)
          }
        },
        {
          title: '删除',
          type: 'text',
          popconfirm: true,
          confirmText: '确认删除该条数据？',
          event: (row) => {
            console.log('删除', row)
            this.$refs.McUtable.delnode(row)
          }
        },
        {
          title: '详情',
          type: 'text',
          event: (row) => {
            console.log('详情', row)
          }
        }

      ]
    }
  },
  methods: {
    aChange(v) {
      console.log('v', v)
    }
  }
}
</script>

<style scoped>

</style>
