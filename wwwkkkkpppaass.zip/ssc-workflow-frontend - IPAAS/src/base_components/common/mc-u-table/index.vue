<template>
  <el-form v-bind="formData">
    <!-- NOTE - 必须指定 row-id 必须开启use-virtual-->
    <u-table
      v-bind="$attrs"
      ref="uTable"
      useVirtual
      :rowId="rowId"
      :treeConfig="cpTreeConfig"
      :height="height"
    >
      <slot />
    </u-table>
    <el-button class="add-btn" @click="handleBottomAddRow" size="medium" type="dash" icon="el-icon-plus" v-if="isShowAddButton">添加</el-button>
  </el-form>
</template>

<script>
import cloneDeep from 'lodash/cloneDeep'

export default {
  name: 'McUTable',
  props: {
    data: {
      type: Array,
      required: true
    },
    isShowAddButton: {
      type: Boolean,
      default: true
    },
    treeConfig: {
      type: Object,
      default: () => ({
        children: 'children',
        expandAll: false,
        hasChildren: 'hasChildren'
      })
    },
    // NOTE - 注意：不给height或者不给maxheight，又或者给的是0，use-virtual直接会关闭）。 树且不能用，不能展开
    height: {
      type: Number,
      default: 600
    },
    rowId: {
      type: String,
      default: 'id'
    }
  },
  computed: {
    formData() {
      return {
        tableData: this.data
      }
    },
    cpTreeConfig() {
      const defaultTreeConfig = {
        children: 'children',
        expandAll: false,
        hasChildren: 'hasChildren'
      }
      const cpTreeConfig = { ...defaultTreeConfig, ...this.treeConfig }
      return cpTreeConfig
    }
  },
  watch: {
    data: {
      handler(nV) {
        // data变化时重新reload
        if (this.$refs.uTable) {
          this.$refs.uTable.reloadData(nV)
        }
      }
    }
  },
  mounted() {
    this.$refs.uTable.reloadData(this.data)
  },
  methods: {
    // 表格真实数据
    getTableData() {
      let treeData = this.$refs.uTable.getUTreeData()
      treeData = treeData.filter(row => !row.pl_table_level)
      return treeData
    },
    async addnode(row, newRowItem) {
      // FIXME - 表单数据需要提交时重新通过$refs获取
      const { treeData, eExpand, scrollTop } = this.recordTreeStatus()

      let rowNode = null

      // NOTE - 往最外层添加 rowNode
      if (Array.isArray(row)) {
        row.push({
          [this.rowId]: Math.random(),
          ...newRowItem
        })
        this.$refs.uTable.reloadData(row)
        // this.$emit('update:data', row)
      } else {
        // NOTE - 往childrendList里添加 rowNode
        const children = [{
          [this.rowId]: Math.random(),
          ...newRowItem
        }]
        rowNode = this.getTreeItem(treeData, row, this.rowId, children)
        this.$refs.uTable.reloadData(treeData)
        // this.$emit('update:data', treeData)
      }

      // 添加完数据了，你可能需要重新载入数据

      eExpand.forEach(row => {
        this.$refs.uTable.setTreeExpansion(row, true)
      })
      this.$refs.uTable.setTreeExpansion(rowNode, true)

      this.$refs.uTable.pagingScrollTopLeft(scrollTop)

      await this.$nextTick()
    },
    // 删除节点
    delnode(row) {
      const { treeData, eExpand, scrollTop } = this.recordTreeStatus()
      const rowIdKey = this.rowId // row-id="id"  如同你上面设置的
      const childrenKey = this.treeConfig.children
      // 在treeData里找到row并删除
      const newTreeData = this.filterNode(treeData, row, rowIdKey, childrenKey)

      // 删除完数据了，你可能需要重新载入数据
      this.$refs.uTable.reloadData(newTreeData).then(() => {
        eExpand.forEach(row => {
          this.$refs.uTable.setTreeExpansion(row, true)
        })

        this.$refs.uTable.pagingScrollTopLeft(scrollTop)
      })
    },
    // 在treeData里找到row并删除
    filterNode(treeData, row, rowIdKey, childrenKey) {
      const deleteRowKey = row[rowIdKey]
      const newTreeData = treeData.filter(treeRow => treeRow[rowIdKey] !== deleteRowKey)
      newTreeData.forEach(item => item[childrenKey] && (item[childrenKey] = this.filterNode(item[childrenKey], row, rowIdKey, childrenKey)))
      return newTreeData
    },
    // NOTE - 考虑到添加的对象可能不一样，所以emit到父组件添加
    handleBottomAddRow() {
      const { treeData } = this.recordTreeStatus()

      this.$emit('addRow', cloneDeep(treeData))
    },
    recordTreeStatus() {
      // 获取之前已经展开的
      const eExpand = this.$refs.uTable.getTreeExpandRecords()
      // 获取之前滚动的位置
      const scrollTop = this.$refs.uTable.tableExample().scrollTop
      // 手动收起，处理缩进异常的问题
      eExpand.forEach(row => {
        this.$refs.uTable.setTreeExpansion(row, false)
      })
      // this.$refs.uTable.clearTreeExpand() // 此操作会恢复到源数据
      const treeData = this.getTableData()
      return { treeData, eExpand, scrollTop }
    },
    getTreeItem(data, row, rowId, children) {
      let newRow = null
      data.map(item => {
        if (item[rowId] === row[rowId]) {
          // 如果存在子节点children就直接push
          if (item[this.treeConfig.children]) {
            item[this.treeConfig.children].push(...children)
            newRow = item
          } else {
            // 如果不存在子节点，就直接创建子节点
            item[this.treeConfig.children] = children
            newRow = item
          }
        } else {
          if (item[this.treeConfig.children]) {
            newRow = this.getTreeItem(item[this.treeConfig.children], row, rowId, children)
          }
        }
      })
      return newRow
    }

  }
}
</script>

<style scoped lang="scss">
.add-btn{
  width: 100%;
  margin-top: 5px;
}
</style>
