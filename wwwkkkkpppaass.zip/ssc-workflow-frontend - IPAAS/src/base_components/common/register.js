import Vue from 'vue'
import './style/index.scss'

const files = require.context('../common', true, /mc-.*index\.vue/)
files.keys().forEach(file => {
  const fileContext = files(file).default
  Vue.component(fileContext.name, fileContext)
})
