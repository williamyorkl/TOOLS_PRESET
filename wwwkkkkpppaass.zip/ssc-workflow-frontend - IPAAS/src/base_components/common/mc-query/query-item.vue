<template>
  <el-form-item class="query-item" :required="query.required" :prop="query.prop || query.key" :label="query.label" :key="query.prop || query.key" :style="{'--label-width': labelWidth, width: (100 / col)+'%'}" :rules="query.rules || []">
    <div class="label" slot="label">
      <span class="label">{{ query.label }}</span>
      <el-tooltip v-if="query.info" class="item" effect="dark" :content="query.info" placement="top-start">
        <i class="el-icon-info" />
      </el-tooltip>
    </div>
    <el-select v-if="query.queryType === 'select' || query.queryType === 'ElSelect'" v-model="formData[query.prop || query.key]" v-bind="cpEditProps" @change="queryItemChange">
      <el-option v-for="item in cpDict" :value="item[query.valueKey || 'id']" :key="item[query.valueKey || 'id']" :label="item[query.labelKey || 'label']" />
    </el-select>

    <el-select v-else-if="query.queryType === 'remoteSelect'" filterable remote :remoteMethod="remoteMethod" v-model="formData[query.prop || query.key]" v-bind="cpEditProps" @change="queryItemChange">
      <el-option v-for="item in remoteDict" :value="item[query.valueKey || 'id']" :key="item[query.valueKey || 'id']" :label="item[query.labelKey || 'label']" />
    </el-select>

    <mc-popover-select
      v-else-if="query.queryType === 'McPopoverSelect'"
      v-model="formData[query.prop || query.key]"
      v-bind="cpEditProps"
      v-on="query.listener"
      @changeRow="queryItemChange"
    />
    <el-date-picker
      v-else-if="query.queryType === 'elDateRange' || query.queryType === 'ElDateRange'"
      v-model="formData[query.prop || query.key]"
      v-bind="cpEditProps"
      @change="queryItemChange"
    />
    <el-input v-else v-model.trim="formData[query.prop || query.key]" v-bind="cpEditProps" @input="queryItemChange" />
  </el-form-item>
</template>

<script>
export default {
  name: 'QueryItem',
  props: {
    query: {
      type: Object,
      required: true
    },
    formData: {
      type: Object,
      require: true,
      default: () => ({})
    },
    labelWidth: {
      type: [String],
      default: '90px'
    },
    col: {
      type: Number,
      default: 3
    }
  },
  data() {
    return {
      remoteDict: [] // 远程返回数据
    }
  },
  created() {
    this.triggerRemoteMethod()
  },
  activated() {
    this.triggerRemoteMethod()
  },
  computed: {
    cpDict() {
      const dictKey = this.query.dict ? 'dict' : 'list'
      let cpDict = this.query[dictKey]
      if (typeof this.query[dictKey] === 'string') {
        if (!this.$store.state.new_dict) {
          console.log(new Error('数据字典获取失败'))
          cpDict = []
        } else {
          cpDict = this.$store.state.new_dict.dictMap[this.query[dictKey]]
        }
      }
      return cpDict
    },

    // 填充一些默认值
    cpEditProps() {
      const defaultEditProps = { clearable: true }
      const editProps = this.query.editProps || {}
      let cpEditProps = { clearable: true, ...editProps }
      if (this.query.queryType === 'ElInput' || this.query.queryType === 'input' || !this.query.queryType) {
        let maxlength = 50
        if (editProps.type === 'textarea') {
          maxlength = 100
        }
        cpEditProps = {
          maxlength,
          placeholder: `请输入${this.query.label || ''}`,
          ...editProps
        }
      } else if (this.query.queryType === 'ElSelect' || this.query.queryType === 'select') {
        cpEditProps = {
          placeholder: `请选择${this.query.label || ''}`
        }
      } else if (this.query.queryType === 'ElInputNumber') {
        cpEditProps = {
          controlsPosition: 'right',
          precision: 2,
          ...editProps
        }
      } else if (this.query.queryType === 'elDateRange' || this.query.queryType === 'ElDateRange') {
        const pickerOptions = {
          shortcuts: [{
            text: '最近1周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近1个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setMonth(start.getMonth() - 1)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近3个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setMonth(start.getMonth() - 3)
              picker.$emit('pick', [start, end])
            }
          }]
        }
        cpEditProps = {
          pickerOptions,
          valueFormat: this.query.valueFormat || 'yyyy-MM-dd HH:mm:ss',
          format: this.query.valueFormat || 'yyyy-MM-dd HH:mm:ss',
          type: this.query.type || 'datetimerange',
          rangeSeparator: '-',
          startPlaceholder: '开始日期',
          endPlaceholder: '结束日期',
          ...editProps
        }
      }
      return { ...defaultEditProps, ...cpEditProps }
    }
  },
  methods: {
    triggerRemoteMethod() {
      if (this.query.defaultText) {
        this.remoteMethod(this.query.defaultText)
      }
    },
    // 远程模糊搜索,数据返回由业务代码控制
    async remoteMethod(v) {
      if (!v) {
        this.remoteDict = []
      } else {
        const resp = await this.query.remoteMethod(v)
        this.remoteDict = resp
      }
    },
    queryItemChange(value) {
      // McPopoverSelect向上传递row数据，其他几种类型直接传值
      this.$emit('change', this.query.prop || this.query.key, value, this.formData)
    }
  }
}
</script>

<style scoped lang="scss">
.query-item{
  width: 33.3%;
  margin-right: 0;
  padding-right: 10px;
  ::v-deep .el-form-item__content{
    width: calc(100% - 20px - var(--label-width))
  }
  ::v-deep .el-input__inner{
    width: 100%;
  }
  .label{
    word-break: break-all;
  }
}
</style>
