<template>
  <div class="query-box" :class="{'query-box-top-border':showTopBorder,'query-box-bottom-border':showBottomBorder}" v-if="mcQueryList.length > 0">
    <el-form class="query-form-box" ref="form" :model="formData" :inline="true" :labelWidth="labelWidth" :size="size" @key-enter.native="query" @submit.native.prevent>
      <template v-for="query in mcQueryList.slice(0, showMore ? mcQueryList.length : limitLength)">
        <query-item :col="col" :formData="formData" :query="query" :key="query.prop || query.key" :labelWidth="labelWidth" v-on="$listeners" />
      </template>
    </el-form>
    <div class="query-btn-box">
      <template v-if="!hiddenBtnBox">
        <el-button @click="query" type="primary">筛选</el-button>
        <el-button @click="reset">重置</el-button>
      </template>
    </div>
    <div class="query-visible-block" v-if="mcQueryList && mcQueryList.length > limitLength">
      <span class="show-more-switch" @click="toggleShowMore">{{ showMore ? '隐藏' : '显示' }}
        <i class="el-icon-arrow-up" v-if="showMore" />
        <i class="el-icon-arrow-down" v-else /></span>
    </div>
  </div>
</template>

<script>
import QueryItem from './query-item'
export default {
  name: 'McQuery',
  components: { QueryItem },
  props: {
    queryList: {
      type: Array,
      required: true,
      default: () => []
    },
    labelWidth: {
      type: [String],
      default: '90px'
    },
    size: {
      type: String,
      default: 'small'
    },
    row: {
      type: Number,
      default: 2
    },
    col: {
      type: Number,
      default: 3
    },
    showTopBorder: {
      type: Boolean,
      default: true
    },
    showBottomBorder: {
      type: Boolean,
      default: true
    },
    hiddenBtnBox: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      showMore: false,
      formData: {},
      timeRangeMap: {} // 储存timeRange的key   key: [startKey, endKey]
    }
  },
  watch: {
    queryList: {
      handler(nV) {
        if (nV && nV.length > 0) {
          this.formData = this.geneFormData(nV)
        }
      },
      immediate: true
    }
  },
  computed: {
    limitLength() {
      return this.row * this.col
    },
    mcQueryList() {
      return this.queryList
    }
  },
  methods: {
    // 提供从外部修改formData的方法
    setQuery(key, value, original) {
      this.$set(this.formData, key, value)
      if (original) {
        return this.formData
      } else {
        return this.formatterFormData(this.formData)
      }
    },
    // 是否返回原始数据
    getQueryData(original) {
      if (original) {
        return this.formData
      } else {
        return this.formatterFormData(this.formData)
      }
    },
    resetForm() {
      this.$refs.form.resetFields()
      this.formData = {}
    },
    query() {
      const formData = this.formatterFormData(this.formData)
      this.$refs.form.validate(valid => {
        if (valid) {
          this.$emit('eventListener', '查询', formData)
          this.$emit('query', formData)
        }
      })
    },
    reset() {
      this.resetForm()
      this.$emit('eventListener', '重置')
      this.$emit('eventListener', '查询', this.formData)
      this.$emit('query', this.formData)
    },
    // 分解timeRangeMap中的值，并删除数组值
    formatterFormData(formData) {
      const data = { ...formData }
      Object.keys(this.timeRangeMap).forEach(item => {
        if (data[item]) {
          const timeRange = this.timeRangeMap[item];
          [data[timeRange[0]], data[timeRange[1]]] = data[item]
        }
        delete data[item]
      })
      return data
    },
    // 根据queryList生成formData: 对于时间范围组件，优先使用用户传入的key或prop，如果用户未传入，则使用query.startKey + _ + query.endKey拼接存入query.prop字段。并记录入timeRangeMap对象，用户后续反转
    geneFormData(queryList) {
      const formData = {}
      queryList.forEach(query => {
        if (query.queryType !== 'elDateRange' && query.queryType !== 'ElDateRange') {
          formData[query.prop || query.key] = query.defaultValue || null
        } else if (query.queryType === 'elDateRange' || query.queryType === 'ElDateRange') {
          query.prop = query.key || query.prop || `${query.startKey}_${query.endKey}`
          this.timeRangeMap[query.prop] = [query.startKey || 'startTime', query.endKey || 'endTime']
          // 增加时间选择器的自定义初始化时间，在配置时传入defaultValue数组接收处理
          formData[query.prop] = query.defaultValue || []
          formData[query.startKey || 'startTime'] = query.defaultValue ? query.defaultValue[0] : null
          formData[query.endKey || 'endTime'] = query.defaultValue ? query.defaultValue[1] : null
        }
      })
      return formData
    },
    toggleShowMore() {
      this.showMore = !this.showMore
    }
  }
}
</script>

<style scoped lang="scss">
.query-box{
  position: relative;
  display: flex;
  padding-top: 20px;
  padding-bottom: 10px;
  &-top-border{
    border-top: 1px solid rgba(15, 29, 63, 0.1);
  }
  &-bottom-border{
    border-bottom: 1px solid rgba(15, 29, 63, 0.1);
  }
  .query-form-box{
    flex-grow: 1;
  }
  .query-btn-box{
    width: 130px;
    min-height: 10px;
    flex-shrink: 0;
  }
  .query-visible-block{
    position: absolute;
    bottom: 0;
    display: flex;
    justify-content: center;
    width: 100%;
    .show-more-switch{
      display: inline-block;
      padding: 3px 10px 0 10px;
      background-color:#eee;
      border-top-left-radius: 5px;
      border-top-right-radius: 5px;
      cursor: pointer;
      line-height: 20px;
    }
  }
}
</style>
