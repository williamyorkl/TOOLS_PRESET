使用示例  
```html
<mc-svg-icon icon="async" iconClass="asdf" />
```
| prop | desc |
| ---- | ---- |
| icon | svg图标文件的名称 |
| iconClass | 样式类 |

注意：需要删除svg文件中的fill属性  

需要配合[`svg-sprite-loader`](https://www.npmjs.com/package/svg-sprite-loader)使用


相关配置：
1. webpack添加`svg-sprite-loader`
```js
module.exports = {
  chainWebpack: config => {
    config.module.rules.delete('svg')
    config.module
      .rule('svg-sprite-loader')
      .test(/\.svg$/)
      .include
      .add(resolve('src/icons')) //处理svg目录
      .end()
      .use('svg-sprite-loader')
      .loader('svg-sprite-loader')
      .options({
        symbolId: 'icon-[name]'
      })
  }
}
```
2. main.js引入全部字体图标

```js
// requires and returns all modules that match
const requireAll = requireContext => requireContext.keys().map(requireContext)

// import all svg
const req = require.context('./assets/svg-icon', false, /\.svg$/)
requireAll(req)
```