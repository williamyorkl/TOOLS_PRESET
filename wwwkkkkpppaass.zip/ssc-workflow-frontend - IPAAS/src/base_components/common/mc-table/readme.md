### 展示table组件，只用于展示信息，不包括table内表单编辑
1. 可以多选行，并将选中的行传递出去
2. 支持转换枚举数据
3. emit行内操作事件
4. 行内操作按钮禁用/启用 显示/隐藏


#### 使用

* 模板
```
<mc-table @selection-change="handleSelectionChange" :tableData="tableData" :tableColumn="tableColumn" @eventListener="eventListener" :header-row-class-name="headerClass">
  <div slot="age">slot渲染结果</div>
</mc-table>
```
绑定的prop和事件除了tableData、tableColumn、eventListener，其余会通过 v-bind="$attrs" 和 v-on="$listeners"传递给el-table

* tableColumn: 
```js
  [
    { label: '姓名', prop: 'name', type: 'link' },
    { label: '年龄', prop: 'age', type: 'slot' },
    { label: '请求方式', prop: 'type', dict: 'MethodTypeEnum' },
    {
      label: 'format方式',
      prop: 'sex',
      formatter(row, column, cellValue, index) {
        return cellValue + '嘿嘿1'
      }
    },
    {
      prop: 'operate',
      label: '操作',
      width: 200,
      btnList: [
        {
          text: '查看',
          eventType: 'view',
          hidden: (row) => false
        }
      ]
    }
  ]
```
- 参数说明：
  - type: 
    * link：链接
    * slot: 使用slot渲染，slot的name是prop字段值
    * dict: 有dict的会映射字典文本或枚举列表数据，如果之间传入枚举列表数据会直接解析；如果传入字典key需要在columns赋值前获取字典枚举数据存储到store中(this.$dispatch('new_dict/getDict', dictKey))
    * 缺省值：会将所有属性通过v-bind绑定到el-table-column上
  - eventType:
    * 事件类型，大多数列表事件会通过eventListener事件emit上来，eventListener函数的参数：eventType: 即事件类型，row: 行数据