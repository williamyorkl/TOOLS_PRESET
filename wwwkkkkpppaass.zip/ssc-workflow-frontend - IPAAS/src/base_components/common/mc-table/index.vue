<template>
  <el-table ref="table" size="mini" border fit stripe highlightCurrentRow class="main-table" v-on="$listeners" :data="tableData" v-bind="$attrs" :maxHeight="maxHeight" :height="height">
    <el-table-column type="selection" v-if="$listeners['selection-change'] && tableData && tableData.length > 0" fixed="left" />
    <el-table-column v-if="showIndex" type="index" label="序号" align="center" fixed="left" width="48" />
    <template v-for="(column, index) in currentTableColumn">
      <template v-if="column.prop !== 'operate'">
        <!-- 根据type分类型渲染 -->
        <!-- slot -->
        <template v-if="column.type === 'slot'">
          <el-table-column
            :key="index"
            :label="column.label"
            :width="column.width"
            :minWidth="column.minWidth"
            :showOverflowTooltip="column.showOverflowTooltip === false ? false : true"
          >
            <template slot-scope="scope">
              <slot :name="column.prop" v-bind="scope" />
            </template>
          </el-table-column>
        </template>

        <!-- link -->
        <template v-else-if="column.type === 'link'">
          <el-table-column :key="index" :label="column.label" :width="column.width" :minWidth="column.minWidth" :showOverflowTooltip="column.showOverflowTooltip === false ? false : true">
            <template slot-scope="scope">
              <el-link type="primary" :underline="false" @click="eventListener('link', scope.row, scope.$index)">{{ scope.row[column.prop] }}</el-link>
            </template>
          </el-table-column>
        </template>

        <!-- dict -->
        <template v-else-if="column.dict">
          <el-table-column :key="index" :label="column.label" :width="column.width" :minWidth="column.minWidth" :showOverflowTooltip="column.showOverflowTooltip === false ? false : true">
            <template slot-scope="scope">
              {{ code2Text(scope.row[column.prop], column.dict, column.labelKey, column.valueKey) }}
            </template>
          </el-table-column>
        </template>

        <!-- 普通类型直接将所有属性传入 -->
        <el-table-column v-else :key="index" v-bind="column" :width="column.width" :minWidth="column.minWidth" :showOverflowTooltip="column.showOverflowTooltip === false ? false : true" />
      </template>

      <!-- operate操作类型 -->
      <template v-else>
        <el-table-column v-if="operateColumn" :label="operateColumn.label" :width="operateColumn.width || 60" :key="index" fixed="right" :showOverflowTooltip="operateColumn.showOverflowTooltip === false ? false : true">
          <template slot-scope="scope">
            <!-- 处理 operate自定义操作 -->
            <slot v-if="operateColumn.type === 'slot'" :name="operateColumn.prop" v-bind="scope" />

            <!-- 处理 operate默认操作栏 -->
            <template v-else>
              <template v-for="btn in operateColumn.btnList">
                <el-button v-if="btnVisible(btn, scope.row)" type="text" :key="btn.text" @click="eventListener(btn.eventType, scope.row, scope.$index)">
                  {{ btn.text }}
                </el-button>
              </template>
              <template v-if="toCollapseBtnList">
                <el-dropdown class="more-btn" v-if="showExpand(scope.row)">
                  <el-button type="text" size="mini">
                    更多<i class="el-icon-arrow-down el-icon--right" />
                  </el-button>

                  <el-dropdown-menu slot="dropdown">
                    <template v-for="btn in toCollapseBtnList">
                      <el-dropdown-item v-if="btnVisible(btn, scope.row)" type="text" :key="btn.text" @click.native="eventListener(btn.eventType, scope.row, scope.$index)">
                        {{ btn.text }}
                      </el-dropdown-item>
                    </template>
                  </el-dropdown-menu>
                </el-dropdown>
              </template>
            </template>
          </template>
        </el-table-column>
      </template>
    </template>
  </el-table>
</template>

<script>

export default {
  name: 'McTable',
  components: {},
  provide() {
    // 可以通过provide传递一些事件在子组件中触发这些事件
    return {}
  },
  props: {
    height: {
      type: [String, Number],
      default: '500px'
    },
    maxHeight: {
      type: [String, Number],
      default: '800'
    },
    tableColumn: {
      type: Array,
      default: () => []
    },
    tableData: {
      type: Array,
      default: () => []
    },
    showIndex: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      toCollapseBtnList: null,
      operateColumn: null,
      defaultBtnLimit: 4,
      hiddenBtnList: [],
      hiddenBtnMap: new Map()
    }
  },
  watch: {
    tableData: {
      async handler(_nV) {
        await this.$nextTick()
        this.$refs.table.doLayout()
      },
      immediate: true
    },
    tableColumn: {
      handler(nV) {
        this.operateColumn = nV.find(i => i.prop === 'operate')
        if (!this.operateColumn || !this.operateColumn.btnList) return

        // NOTE - 按需切割btnList
        if (this.operateColumn.btnList.length > this.defaultBtnLimit) {
          this.toCollapseBtnList = this.operateColumn.btnList.splice(this.operateColumn.btnLimit || this.defaultBtnLimit)
        }
      },
      immediate: true
    }
  },
  methods: {
    eventListener(eventType, row, index) {
      this.$emit('eventListener', eventType, row, index)
    },
    code2Text(code, dictKey, labelKey = 'desc', valueKey = 'type') {
      let options = []
      if (Array.isArray(dictKey)) {
        options = dictKey
      } else {
        // 此处字典请求需要依赖项目的vuex
        if (!this.$store.state.new_dict) {
          console.log(new Error('字典对象new_dict不存在'))
          options = []
        } else {
          options = this.$store.state.new_dict.dictMap[dictKey] || []
        }
      }
      const obj = options.find(item => item[valueKey] === code) || { desc: code }
      return obj[labelKey]
    },
    btnVisible(btn, row) {
      if (!this.hiddenBtnMap.get(row.id)) {
        this.hiddenBtnMap.set(row.id, new Set())
      }
      if (!btn.hidden) { // hidden === false
        this.hiddenBtnMap.get(row.id).add(btn)
        return true
      } else if (btn.hidden) { // hidden有值 === true || func()
        if (typeof btn.hidden === 'function') {
          const bVal = btn.hidden(row)
          bVal && this.hiddenBtnMap.get(row.id).add(btn)
          return !bVal
        } else {
          return false
        }
      }
    },
    /**
     * 是否显示 “展示” 按钮
     */
    showExpand(row) {
      const hiddenBtnList = [...this.hiddenBtnMap.get(row.id)]
      const deltaList = this.toCollapseBtnList.filter(v => !hiddenBtnList.includes(v))
      return deltaList.length > 0
    }
  },
  computed: {
    currentTableColumn() {
      return this.tableColumn.filter((column) => !column.hidden)
    }

  }
}
</script>

<style scoped lang="scss">
.main-table{
  margin: 16px 0;
  width: 100%;
}
</style>
