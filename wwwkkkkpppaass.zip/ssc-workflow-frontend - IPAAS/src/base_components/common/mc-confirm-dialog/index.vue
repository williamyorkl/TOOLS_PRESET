<template>
  <el-dialog :title="dialogTitle" :visible.sync="visible" :beforeClose="handleCancel" width="500px">
    <div class="warning-text">
      <div>
        为防止意外，确认继续操作请输入以下内容：
      </div>
      <span class="confirm-text">
        {{ confirmText }}
      </span>
    </div>
    <div class="confirm-input">
      <el-input v-model="text" placeholder="请输入提示内容以确认继续操作" />
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">取 消</el-button>
      <el-button type="primary" @click="handleConfirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
export default {
  name: 'McConfirmDialog',
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    dialogTitle: {
      type: String,
      default: '二次确认'
    },
    confirmText: {
      type: String,
      require: true,
      default: 'delete'
    },
    failText: {
      type: String,
      default: '下线确认内容错误'
    }
  },
  data() {
    return {
      text: ''
    }
  },
  methods: {
    handleConfirm() {
      const text = this.text.toLowerCase()
      const confirmText = this.confirmText.toLowerCase()
      if (text === confirmText) {
        this.$emit('confirm')
        this.$emit('update:visible', false)
      } else {
        this.$message.error(this.failText)
      }
      this.text = null
    },
    handleCancel() {
      this.$emit('update:visible', false)
    }
  }
}
</script>

<style scoped lang="scss">
.warning-text {
  background-color: #ffe8e6;
  color: #db2828;
  padding: 20px;
  border: 2px solid #d87d7d;
}
.confirm-text {
  display: inline-block;
  padding: 10px 0 0 0;
  font-weight: 700;
  border-bottom: 2px dashed red;
  color: #000;
  word-break: break-all;
}
.confirm-input{
  margin-top: 20px;
}
</style>
