<template>
  <!-- 普通文本框 -->
  <u-table-column
    v-if="type === 'index'"
    v-bind="columnProps"
    type="index"
  />
  <!-- 普通文本框 -->
  <u-table-column
    v-else-if="type === 'text'"
    v-bind="columnProps"
  />
  <!-- 特定表单域 -->
  <u-table-column v-else-if="formItemProps && type !== 'operate'" v-bind="columnProps">
    <template slot-scope="scope">
      <el-form-item labelWidth="0" v-bind="formItemProps">
        <component :is="type" v-model="scope.row[columnProps.prop]" v-bind="{ ...defaultFormProps, ...formProps(scope) }" @input="fieldInput($event, scope)" @change="fieldChange($event, scope)" />
      </el-form-item>
    </template>
  </u-table-column>
  <!-- 自定义 -->
  <!-- 操作栏 -->
  <u-table-column v-else-if="type === 'operate'" v-bind="columnProps">
    <template slot-scope="scope">
      <!-- 1. 正常区域（不展开） -->
      <template v-for="(btn,idx) in btnList">
        <el-button v-if="!btn.confirmText" :type="btn.type" :key="btn.title" @click="btn.event(scope.row)" :size="btn.size || 'mini'" :disabled="btnDisabled(scope.row, btn)">
          {{ btn.title }}
        </el-button>

        <el-popconfirm class="popconfirm" v-else :title="btn.confirmText || '删除数据'" :key="btn.title + idx" @confirm="btn.event(scope.row)">
          <el-button slot="reference" :type="btn.type" :size="btn.size || 'mini'">
            {{ btn.title }}
          </el-button>
        </el-popconfirm>
      </template>

      <!-- 2. 展开区域（如大于若干个） -->
      <template v-if="toCollapseBtnList">
        <el-dropdown class="more-btn">
          <el-button type="text" size="mini">
            更多<i class="el-icon-arrow-down el-icon--right" />
          </el-button>

          <el-dropdown-menu slot="dropdown">
            <template>
              <el-dropdown-item v-for="(btn) in toCollapseBtnList" type="text" :key="btn.title" @click.native="btn.disabled ? null : handleClick(btn,scope)" :style="disabledStyle(btn)">
                {{ btn.title }}
              </el-dropdown-item>
            </template>
          </el-dropdown-menu>
        </el-dropdown>
      </template>
    </template>
  </u-table-column>
</template>

<script>
const formTypes = ['ElInput', 'McSelect', 'ElDatePicker', 'McPopSelect']
// checkbox, radio
export default {
  name: 'McUTableColumn',
  props: {
    columnProps: {
      type: Object,
      default: () => ({})
    },
    formItemProps: {
      type: Object,
      default: () => ({})
    },
    formProps: {
      type: Function,
      default: () => ({})
    },
    // 列类型
    type: {
      type: String,
      default: 'text'
    },
    btnList: {
      type: Array,
      default: () => []
    },
    formEvents: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      formTypes,
      defaultBtnLimit: 3,
      toCollapseBtnList: null
    }
  },
  watch: {
    btnList: {
      handler(val) {
        if (val.length > this.defaultBtnLimit) {
          this.toCollapseBtnList = val.splice(this.columnProps.btnLimit || this.defaultBtnLimit)
        }
      },
      immediate: true
    }
  },
  computed: {
    defaultFormProps() {
      const selectArr = ['McSelect', 'ElSelect', 'McPopoverSelect']
      const text = selectArr.includes(this.type) ? '请选择' : '请输入'

      const defaultFormProps = {
        clearable: true,
        placeholder: `${text}${this.formProps.placeholder === undefined ? this.columnProps.label : ''}`
      }
      return defaultFormProps
    }
  },
  methods: {
    fieldInput(v, scope) {
      this.triggerEvent('input', v, scope)
    },
    fieldChange(v, scope) {
      this.triggerEvent('change', v, scope)
    },
    triggerEvent(type, v, scope) {
      const event = this.formEvents[type]
      if (event) {
        event(v, scope)
      }
    },
    handleClick(btn, scope) {
      if (btn.confirmText) {
        this.$confirm(btn.confirmText, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          btn.event(scope.row)
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
      } else {
        btn.event(scope.row)
      }
    },
    btnDisabled(row, btn) {
      const btnDisabled = btn.disabled
      if (typeof btnDisabled !== 'function') {
        // 非函数，直接返回
        return btnDisabled
      } else {
        // 函数
        return btnDisabled(row)
      }
    },
    disabledStyle(btn, row) {
      const btnDisabled = this.btnDisabled(row, btn)
      return btnDisabled ? { color: '#C0C4CC', backgroundColor: '#fff', cursor: 'not-allowed' } : ''
    }
  }
}
</script>

<style scoped lang="scss">
.el-button {
  margin-left: 10px;
}

.popconfirm {
  margin-left: 5px;
}
</style>
