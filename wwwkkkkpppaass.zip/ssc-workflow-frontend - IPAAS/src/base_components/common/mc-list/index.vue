<template>
  <el-row>
    <el-row v-for="(item, index) in list" :key="index" type="flex">
      <el-col :span="23">
        <slot :item="item" :index="index">左侧item的内容</slot>
      </el-col>
      <el-col class="reduce-box" :span="1" v-if="!currentDisabled">
        <i class="el-icon-remove-outline remove-btn" @click="remove(index)" />
      </el-col>
    </el-row>
    <el-col :span="24" v-if="!currentDisabled">
      <el-button class="add-btn" @click="handleAdd" size="medium" type="dash" icon="el-icon-plus">添加</el-button>
    </el-col>
  </el-row>
</template>

<script>
export default {
  name: 'McList',
  props: {
    list: {
      type: Array,
      default: () => []
    },
    mode: {
      type: String,
      default: 'edit'
    },
    limit: {
      type: Number,
      default: 0
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    currentDisabled() {
      return this.mode === 'snapshot' || this.disabled
    }
  },
  methods: {
    remove(index) {
      if (!this.handleDelete) {
        if (this.list.length <= this.limit) {
          this.$message.error(`至少保留${this.limit}条数据`)
          return
        }
        this.list.splice(index, 1)
      } else {
        this.$emit('handleDelete', this.list, index)
      }
    },
    handleAdd() { // 考虑到添加的对象可能不一样，所以emit到父组件添加
      this.$emit('handleAdd', this.list)
    }
  }
}
</script>

<style scoped lang="scss">
.remove-btn{
  color: red;
  font-size: 22px;
  cursor: pointer;
}
.add-btn{
  width: 100%;
  margin-top: 6px;
}

.reduce-box{
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
