<template>
  <el-popover v-model="visible" placement="bottom-start" :width="width" trigger="click" :disabled="disabled">
    <PopContent ref="popContent" v-bind="$attrs" @handleRowClick="handleRowClick" v-if="visible" />
    <el-input slot="reference" v-model="inputValue" :placeholder="placeholder" :disabled="disabled" :readonly="readonly && selfReadonly" suffixIcon="el-icon-more" clearable size="small" @clear="handleClear" @focus="inputFocus" @blur="inputBlur" />
  </el-popover>
</template>

<script>
import PopContent from './pop-content'
export default {
  name: 'McPopoverSelect',
  components: { PopContent },
  props: {
    disabled: {
      type: Boolean,
      default: false
    },
    placeholder: {
      default: '请选择'
    },
    defaultValue: {
      type: String,
      default: ''
    },
    value: {},
    readonly: {
      type: Boolean,
      default: true
    },
    labelKey: {
      type: String,
      default: 'name'
    },
    valueKey: {
      type: String,
      default: 'id'
    },
    validateRowData: {
      type: Function
    },
    width: {
      default: 700
    }
  },
  model: {
    event: 'change'
  },
  data() {
    return {
      inputValue: this.defaultValue,
      btnSize: 'mini',
      visible: false,
      selfReadonly: false
    }
  },
  watch: {
    async visible(val) {
      if (val) {
        await this.$nextTick()
        this.$refs.popContent.handleFilter()
      }
    },
    defaultValue: {
      deep: true,
      immediate: true,
      handler(nV, oV) {
        if (nV) {
          this.inputValue = nV
        } else {
          this.inputValue = ''
        }
      }
    },
    value(nV) {
      if (!nV) {
        this.inputValue = ''
      }
    }
  },
  methods: {
    handleClear() {
      this.$emit('change', null)
      this.$emit('changeRow', {})
    },
    async handleRowClick(row, flag) {
      const oldRow = { [this.labelKey]: this.inputValue, [this.valueKey]: this.value }
      // 选值前加一层验证，如果有传入validateRowData需要查看函数的结果是否为RESOLVE，如果是继续执行，否则弹窗提示错误信息。使用例子可参照serverRegister/interfaceManage/components/edit-dialog.vue
      let status = 'RESOLVE'
      if (this.validateRowData && typeof this.validateRowData === 'function') {
        status = await this.validateRowData(row)
      }
      if (status === 'RESOLVE') {
        this.visible = flag
        this.inputValue = row[this.labelKey]
        this.$emit('change', row[this.valueKey])
        this.$emit('changeRow', row, oldRow) // 将整行值向上传递
      } else {
        this.$message.error(status)
      }
    },
    inputFocus() {
      this.selfReadonly = true
    },
    inputBlur() {
      this.selfReadonly = false
    }
  }
}
</script>

<style scoped lang="scss">
</style>
