<template>
  <div class="common-container popover-common-container">
    <div class="apply-content">
      <mc-query :query-list="queryList" @query="handleFilter" :col="col" :row="row"></mc-query>
      <div class="common-table-container" v-loading="listLoading">
        <mc-table :tableData="tableData" :tableColumn="tableColumn" @eventListener="eventListener" @row-click="handleRowClick" :max-height="maxHeight">
        </mc-table>
      </div>
      <div class="pagination-container">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :pager-count="5" :current-page.sync="pageIndex" :page-sizes="[5, 10, 20, 50, 100]" :page-size="pageSize" layout="total, sizes, prev, pager, next, jumper" :total="recordCount" background>
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import Constant from '@/config/constant'
export default {
  name: 'PopContent',
  props: {
    // 查列表的接口函数，返回promise
    apiFunc: {
      type: Function
    },
    maxHeight: {
      type: [String, Number],
      default: '271'
    },
    // 表格列配置
    tableColumn: {
      type: Array,
      default: () => [{}]
    },
    // 查询条配置
    queryList: {
      type: Array,
      default: () => []
    },
    // 默认的查询参数
    param: {
      type: Object,
      default: () => ({})
    },
    col: {
      type: Number,
      default: 2
    },
    row: {
      type: Number,
      default: 2
    }
  },
  data() {
    return {
      listLoading: false,
      recordCount: 0,
      pageIndex: 1,
      pageSize: 5,
      query: {}, // 列表查询条件
      tableData: []
    }
  },
  created() {
    // this.getList()
  },
  methods: {
    async getList() {
      this.listLoading = true
      const params = {
        ...this.param,
        size: this.pageSize,
        page: this.pageIndex,
        ...this.query
      }
      this.apiFunc(params)
        .then((res) => {
          this.tableData = res.records || []
          if (this.pageIndex === 1) {
            this.recordCount = res.total || 0
          }
        })
        .finally(() => {
          this.listLoading = false
        })
    },
    handleRowClick(row) {
      this.$emit('handleRowClick', row, false)
    },
    // 根据刷选条件过滤数据
    handleFilter(val) {
      this.pageIndex = 1
      this.query = val
      this.getList()
    },
    // 修改每页数量
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.pageIndex = val
      this.getList()
    },
    eventListener(eventType, row) {
      switch (eventType) {
        case Constant.EDIT:
          this.handleEdit(row)
          break
        case Constant.DELETE:
          this.handleDelete(row)
          break
        case Constant.COMMIT:
          this.handleCommit(row)
          break
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.popover-common-container{
  padding-left: 0;
  min-height: 400px;
}
</style>
