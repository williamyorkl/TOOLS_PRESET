# 专用于form-item的label插槽的组件，可快速配置提示信息

### 使用
```html
<mc-form-item-label label="姓名" description="这是姓名，默认是xxx" icon="el-icon-info" />
```