<template>
  <div class="label">
    {{label}}
    <el-tooltip effect="dark" :content="description" placement="right">
      <i :class="icon"></i>
      <slot slot="content"></slot>
    </el-tooltip>
  </div>
</template>

<script>
export default {
  name: 'McFormItemLabel',
  props: {
    label: {
      default: 'label',
      type: String
    },
    icon: {
      default: 'el-icon-info',
      type: String
    },
    description: {
      default: '描述',
      type: String
    }
  }
}
</script>

<style>

</style>
