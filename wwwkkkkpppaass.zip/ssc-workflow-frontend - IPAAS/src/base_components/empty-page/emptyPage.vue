<template>
    <div class="content">
      <i class="iconfont icon-jingqingqidai"></i>
    </div>
</template>

<script>
export default {}
</script>

<style scoped lang="scss">
.content{
  background: #fff;
  height: 90%;
  box-sizing: border-box;
  padding: 100px 20px;
  font-size: 50px;
  text-align: center;
  .iconfont{
    font-size: 100px;
  }
}
</style>
