/**
 * ux-grid: 找到源数据中对应的行，添加新的数据到行的childrenList中
 * @param {*} instance: 表格实例
 * @param {*} sourceData: 表格源数据
 * @param {*} parentRow: 父行（当前点击的这一行）
 * @param {*} newRow: 要添加的数据行
 * @param {*} rowId
 * @param {*} treeConfig
 */
export function addNode({ instance, sourceData, parentRow, newRow, rowId = 'id', treeConfig = { children: 'children' } }) {
  // 要添加的行
  const children = [newRow]
  // 操作源数据添加行，并记录row在源数据中对应的数据用于展开该行
  const rowNode = getTreeItem({ sourceData, parentRow, rowId, children, treeConfig })
  // 如果行为展开则展开行
  const isExpand = instance.isTreeExpandByRow(rowNode)
  if (!isExpand) {
    instance.toggleTreeExpand(rowNode)
  }
}

/**
 * 从源数据删除对应行
 * @param {*} instance: 表格实例
 * @param {*} sourceData: 表格源数据
 * @param {*} row: （当前点击的这一行）
 * @param {*} rowId
 * @param {*} treeConfig
 */
// eslint-disable-next-line no-unused-vars
export function delNode({ instance, row, sourceData, rowId = 'id', treeConfig = { children: 'children' } }) {
  // 从源数据中删除该行重新给源数据赋值
  sourceData = filterNode(sourceData, row, rowId, treeConfig)
}

// 递归遍历sourceData找到对应行，并添加数据,返回点击的这一行对应的源数据中的row
export function getTreeItem({ sourceData, parentRow, rowId, children, treeConfig }) {
  if (!parentRow) {
    sourceData.push(...children)
    return children[0]
  }
  let sourceCurrentRow = null
  const len = sourceData.length
  for (let i = 0; i < len; i++) {
    const rowData = sourceData[i]
    if (rowData[rowId] === parentRow[rowId]) {
      sourceCurrentRow = rowData
      if (!rowData[treeConfig.children]) rowData[treeConfig.children] = []
      rowData[treeConfig.children].push(...children)
    } else {
      if (rowData[treeConfig.children]) sourceCurrentRow = getTreeItem({ sourceData: rowData[treeConfig.children], parentRow, rowId, children, treeConfig })
      if (sourceCurrentRow) break
    }
  }
  return sourceCurrentRow
}

// 删除行
export function filterNode(data, row, rowId, treeConfig) {
  const len = data.length
  let flag = false
  for (let i = 0; i < len; i++) {
    const rowData = data[i]
    if (rowData[rowId] === row[rowId]) {
      data.splice(i, 1)
      flag = true
      break
    } else {
      flag = filterNode(data[i][treeConfig.children] || [], row, rowId, treeConfig)
    }
    if (flag) break
  }
  return flag
}

/**
 * 激活下一行，并返回下一行的下标
 * @param {*} data
 * @param {*} currentRow
 * @param {*} Instance
 * @returns activeRowIndex
 */
export function activeNextRow(data, currentRow, Instance, compareKey = 'id') {
  const index = data.findIndex(item => item[compareKey] === currentRow[compareKey])
  const len = data.length
  let nextRowIndex = index + 1
  if (nextRowIndex >= len) {
    nextRowIndex = index
  }
  Instance.setCurrentRow(data[nextRowIndex])
  return nextRowIndex
}

export function setCurrentRow(data, currentRow, Instance, compareKey = 'id', nodeKey = 'path') {
  const row = data.find(item => item[compareKey] === currentRow[nodeKey])
  Instance.setCurrentRow(row)
  return row
}
