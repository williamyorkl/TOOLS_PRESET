import Vue from 'vue'
import elementOptions from 'config/elementOptions'
import ElementUI from 'element-ui'
import 'styles/variables.scss'
import 'styles/vars.scss'
import { filterLoad } from 'filters'
// import hasPermission from 'directives/has-permission'
// import apiPermission from 'directives/api-permission'
// import hoverClipboard from 'directives/hover-clipboard'
import SimpleModalService from '@/components/common/modal/index.js'

import VueClipboard from 'vue-clipboard2'

filterLoad(Vue)

Vue.prototype.$simpleModalService = SimpleModalService

Vue.prototype.$EventBus = new Vue()

// 更改ElementUI默认Attribute区域

// 更改el-button默认size属性为small
ElementUI.Button.props.size = {
  type: String,
  default: elementOptions.button.size
}

// 更改el-select默认size属性为mini
ElementUI.Select.props.size = {
  type: String,
  default: elementOptions.select.size
}

// 更改el-select默认placeholder属性为请选择
ElementUI.Select.props.placeholder = {
  type: String,
  default: elementOptions.select.placeholder
}

// 更改el-input默认size属性为mini
ElementUI.Input.props.size = {
  type: String,
  default: elementOptions.input.size
}

// ----- 添加该配置后导致placeholder无法显示，暂时注释 -----
// // 更改el-input默认placeholder属性为请选择
// ElementUI.Input.props.placeholder = {
//   type: String,
//   default: elementOptions.input.placeholder
// }

// 更改el-datePiker默认size属性为mini
ElementUI.DatePicker.props.size = {
  type: String,
  default: elementOptions.datePiker.size
}

// 更改el-datePiker默认placeholder属性为请选择
ElementUI.DatePicker.props.placeholder = {
  type: String,
  default: elementOptions.datePiker.placeholder
}

// 更改el-table列的溢出隐藏属性showOverflowTooltip默认为true
ElementUI.TableColumn.props.showOverflowTooltip = {
  type: Boolean,
  default: elementOptions.table.showOverflowTooltip
}

// 更改el-table表格默认border属性为true
ElementUI.Table.props.border = {
  type: Boolean,
  default: elementOptions.table.border
}

// 更改el-table表格默认stripe属性为true
ElementUI.Table.props.stripe = {
  type: Boolean,
  default: elementOptions.table.stripe
}
// 更改el-table表格默认stripe属性为true
ElementUI.Table.props.size = {
  type: String,
  default: elementOptions.table.size
}

// 更改el-table表格默认pageSizes属性为true
ElementUI.Pagination.props.pageSizes = {
  type: Array,
  default() {
    return elementOptions.table.pageSizes
  }
}

ElementUI.Dialog.props.center = {
  default: elementOptions.dialog.center
}
ElementUI.Dialog.props.closeOnClickModal.default = false

// el-form文字对齐方式、错误提示布局
ElementUI.Form.props.labelPosition = {
  default: elementOptions.form.labelPosition
}
ElementUI.Form.props.inlineMessage = {
  default: elementOptions.form.inlineMessage
}

Vue.use(ElementUI)
// Vue.use(hasPermission)
// Vue.use(apiPermission)
// Vue.use(hoverClipboard)
Vue.use(VueClipboard)
