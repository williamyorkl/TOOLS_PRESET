const processEnv = process.env

export const PROCESS_ENV = {
  ENV: processEnv.NODE_ENV,
  MODE: processEnv.VUE_APP_MODE,
  PUBLIC_PATH: processEnv.VUE_APP_PUBLIC_PATH,
  SINGLESIGN_URL: processEnv.VUE_APP_SINGLESIGN_URL,
  BASE_URL: processEnv.VUE_APP_BASE_URL,
  TARGET: processEnv.VUE_APP_TARGET,
  BASE_URL_PATCH: processEnv.VUE_APP_BASE_URL_PATCH,
  AUTH_PREFIX: processEnv.VUE_APP_AUTH_PREFIX,
  PLATFORM: processEnv.VUE_APP_PLATFORM
}
