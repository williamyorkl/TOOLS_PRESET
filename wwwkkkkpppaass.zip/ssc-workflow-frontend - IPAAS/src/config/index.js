export const AUTH_REDIRECT_URL = process.env.AUTH_REDIRECT_URL

export const LOGIN_URL = process.env.LOGIN_URL
