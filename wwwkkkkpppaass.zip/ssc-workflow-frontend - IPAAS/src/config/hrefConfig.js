// #之前的内容
// http://120.31.129.156:34136/login?service=http://120.31.129.156:3100/si
const baseURL = location.href.match(/^[\w|\W]+(?=#)/)
export const hrefConfig = {
  default: {
    url: '',
    redirectBackUrl: baseURL,
    ticketKey: ''
  },
  iam: {
    url: 'http://120.31.129.156:34136/login',
    ticketKey: 'ticket'
  }
}
