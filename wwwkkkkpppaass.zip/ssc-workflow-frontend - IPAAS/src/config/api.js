export const TIMEOUT_MILLISECONDS = 50000

export const WHITE_LIST = ['login', 'signup']

// 不需要添加token的接口
export const NO_AUTH_API_LIST = ['auth/loginMethod', 'auth/login', 'auth/forward']
