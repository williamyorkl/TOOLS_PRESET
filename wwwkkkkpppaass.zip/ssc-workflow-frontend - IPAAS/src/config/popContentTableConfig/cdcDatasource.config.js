import { formatTime } from '@/utils'
export const getTableColumn = function() {
  const tableColumn = [
    { label: 'CDC名称', prop: 'name', minWidth: '180px' },
    { label: '服务类型', prop: 'type', dict: 'CdcTypeEnum', minWidth: '120px' },
    {
      label: '创建时间',
      prop: 'createTime',
      minWidth: '140px',
      formatter(row, column) {
        return formatTime(row.createTime)
      }
    },
    { label: '更新人', prop: 'updateByName' },
    {
      label: '更新时间',
      prop: 'updateTime',
      minWidth: '140px',
      formatter(row, column) {
        return formatTime(row.updateTime)
      }
    }
  ]

  return tableColumn
}

export const getQueryList = function({ CdcTypeEnum = [] }) {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'name',
      label: 'CDC名称',
      queryType: 'input'
    },
    {
      key: 'type',
      label: '服务类型',
      queryType: 'select',
      list: CdcTypeEnum,
      labelKey: 'desc',
      valueKey: 'type'
    }
  ]
  return queryList
}
