export const getTableColumn = function() {
  const tableColumn = [
    { label: 'MQ名称', prop: 'name' },
    { label: 'MQ Server地址', prop: 'mqServerUrl', width: '120' },
    { label: 'kafkaBrokers', prop: 'kafkaBrokers', width: '120' },
    { label: 'kafkaConnector', prop: 'kafkaConnector', width: '120' }
  ]

  return tableColumn
}

export const getQueryList = function() {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'name',
      label: 'MQ名称',
      queryType: 'input'
    }
  ]
  return queryList
}
