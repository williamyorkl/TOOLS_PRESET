export const getTableColumn = function() {
  const tableColumn = [
    { label: '数据库编码', prop: 'dataBaseCode', width: '150px' },
    { label: '数据库名称', prop: 'dataBaseName', width: '100px' },
    { label: '服务器地址', prop: 'dataBaseUrl', width: '200px' },
    { label: '用户名', prop: 'userName' }
  ]

  return tableColumn
}

export const getQueryList = function() {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'dataBaseCode',
      label: '数据库编码',
      queryType: 'input'
    },
    {
      key: 'dataBaseName',
      label: '数据库名称',
      queryType: 'input'
    }
  ]
  return queryList
}
