export const getTableColumn = function() {
  const tableColumn = [
    { label: '用户接口名称', prop: 'businessApiName', minWidth: '100px' },
    { label: '接口请求URL', prop: 'requestUrl', minWidth: '100px' },
    { label: '请求方式', prop: 'requestType', dict: 'MethodTypeEnum', minWidth: '100px' }
  ]

  return tableColumn
}

export const getQueryList = function(MethodTypeEnum) {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'businessApiName',
      label: '用户接口名称',
      queryType: 'input'
    },
    {
      key: 'requestType',
      label: '请求方式',
      queryType: 'select',
      list: MethodTypeEnum,
      labelKey: 'desc',
      valueKey: 'type'
    },
    {
      key: 'requestUrl',
      label: '接口请求URL',
      queryType: 'input'
    }
  ]
  return queryList
}
