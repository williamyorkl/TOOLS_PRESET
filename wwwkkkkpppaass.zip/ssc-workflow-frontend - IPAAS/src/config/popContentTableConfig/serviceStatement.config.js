import registryApi from '@/api/interface/registry'
import { getTableColumn as getRegistryTableColumn, getQueryList as getRegistryQueryList } from '@/config/popContentTableConfig/registry.config'

export const getTableColumn = function() {
  const tableColumn = [
    { label: '服务声明名称', prop: 'serviceName', minWidth: '180px' },
    { label: '应用名', prop: 'applicationName', minWidth: '80px' },
    { label: '服务类型', prop: 'serviceType', dict: 'ServiceTypeEnum', minWidth: '120px' },
    { label: '描述', prop: 'serviceDesc', minWidth: '170px' }
  ]

  return tableColumn
}

export const getQueryList = function(registryTypeList = [], serviceTypeList = []) {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'serviceName',
      label: '服务声明名称',
      queryType: 'input',
      editProps: {
        maxLength: 256
      }
    },
    {
      key: 'serviceType',
      label: '服务类型',
      queryType: 'select',
      list: serviceTypeList,
      labelKey: 'desc',
      valueKey: 'type'
    },
    {
      prop: 'registerId',
      label: '注册中心',
      queryType: 'McPopoverSelect',
      editProps: {
        defaultValue: null,
        apiFunc: registryApi.getRegistryList,
        tableColumn: getRegistryTableColumn(),
        queryList: getRegistryQueryList(),
        labelKey: 'name'
      }
    }
  ]
  return queryList
}
