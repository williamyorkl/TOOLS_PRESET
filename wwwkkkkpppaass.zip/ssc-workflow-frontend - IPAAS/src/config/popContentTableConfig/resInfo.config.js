import resStructApi from '@/api/platformConfig/resStruct'
import { getTableColumn as getResStructTableColumn, getQueryList as getResStructQueryList } from '@/config/popContentTableConfig/resStruct.config'
import { formatTime, expandJSONPath } from '@/utils'

export const getTableColumn = function() {
  const tableColumn = [
    { label: '响应码名称', prop: 'errorName', minWidth: '100px' },
    { label: '结构名称', prop: 'structName', minWidth: '100px' },
    {
      label: '展示结构',
      prop: 'structName',
      minWidth: '100px',
      formatter: (row, column) => {
        const { infoList = [] } = row
        const res = expandJSONPath(infoList)
        return JSON.stringify(res, null, 2)
      }
    },
    {
      label: '更新时间',
      prop: 'updateTime',
      minWidth: '140px',
      formatter(row, column) {
        return formatTime(row.updateTime)
      }
    }
  ]

  return tableColumn
}

export const getQueryList = function({ TrueFalseEnum }) {
  const queryList = [
    // 筛选条件初始化
    {
      prop: 'structHeadId',
      label: '响应码结构',
      queryType: 'McPopoverSelect',
      editProps: {
        defaultValue: null,
        apiFunc: resStructApi.listResStruct,
        tableColumn: getResStructTableColumn(),
        queryList: getResStructQueryList({ TrueFalseEnum }),
        labelKey: 'structName',
        valueKey: 'id'
      }
    }
  ]
  return queryList
}
