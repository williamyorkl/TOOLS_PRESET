import dbApi from '@/api/database'
import fieldModelApi from '@/api/model/field-model'

export const getTableColumn = function() {
  const tableColumn = [
    {
      label: '表名',
      prop: 'tableName',
      minWidth: '100px'
    }
  ]

  return tableColumn
}

export const getQueryList = function() {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'tableName',
      label: '表名',
      queryType: 'input'
    }
  ]
  return queryList
}

// 接口
export const apiFunc = dbApi.getTablesColumnsByDbIdPage
export const apiFunc1 = fieldModelApi.getTableListPage
export default {
  apiFunc,
  apiFunc1,
  getTableColumn,
  getQueryList
}
