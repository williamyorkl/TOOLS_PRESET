import arrangeApi from '@/api/arrange'

export const getTableColumn = function() {
  const tableColumn = [
    { label: '服务分组名称', prop: 'groupName', minWidth: '120px' },
    { label: 'BasePath', prop: 'baseUrl', minWidth: '120px' }
  ]

  return tableColumn
}

export const getQueryList = function() {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'groupName',
      label: '服务分组名称',
      queryType: 'input'
    }
  ]
  return queryList
}

// 接口
export const apiFunc = arrangeApi.listGroup

export default {
  apiFunc,
  getTableColumn,
  getQueryList
}
