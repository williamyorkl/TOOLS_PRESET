import cacheApi from '@/api/cached-database'
const getTableColumn = function() {
  const tableColumn = [
    { label: '数据库名称', prop: 'sourceName', minWidth: '100px' },
    { label: '服务器地址', prop: 'sourceUrl', minWidth: '200px' }
  ]

  return tableColumn
}

const getQueryList = function() {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'sourceName',
      label: '数据库名称',
      queryType: 'input'
    }
  ]
  return queryList
}

const apiFunc = cacheApi.getDatabaseList

const model = {
  apiFunc,
  getTableColumn,
  getQueryList
}

export default model
