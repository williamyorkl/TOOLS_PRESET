import authApi from '@/api/serviceStatement/auth'

export const getTableColumn = function() {
  const tableColumn = [
    { label: '后端认证名称', prop: 'authName', minWidth: '120px' },
    { label: '认证方式', prop: 'authType', dict: 'BackApiAuthTypeEnum', minWidth: '100px' }
  ]

  return tableColumn
}

export const getQueryList = function({ BackApiAuthTypeEnum = [] }) {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'authName',
      label: '后端认证名称',
      queryType: 'input'
    },
    {
      key: 'authType',
      label: '认证方式',
      queryType: 'select',
      list: BackApiAuthTypeEnum,
      valueKey: 'type',
      labelKey: 'desc'
    }
  ]
  return queryList
}

// 接口
export const apiFunc = authApi.listAuth

export default {
  apiFunc,
  getTableColumn,
  getQueryList
}
