export const getTableColumn = function() {
  const tableColumn = [
    { label: '用户接口名称', prop: 'businessApiName', minWidth: '120' },
    { label: '接口请求URL', prop: 'requestUrl', minWidth: '120' },
    { label: '开发者', prop: 'developer', minWidth: '120' }
  ]

  return tableColumn
}

export const getQueryList = function() {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'businessApiName',
      label: '用户接口名称',
      queryType: 'input'
    }
  ]
  return queryList
}
