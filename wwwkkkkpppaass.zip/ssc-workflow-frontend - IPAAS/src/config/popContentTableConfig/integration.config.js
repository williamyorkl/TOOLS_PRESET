export const getTableColumn = function() {
  const tableColumn = [
    { label: '集成应用名称', prop: 'appName' },
    { label: '描述', prop: 'remark' }
  ]

  return tableColumn
}

export const getQueryList = function() {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'appName',
      label: '集成应用名称',
      queryType: 'input'
    }
  ]
  return queryList
}
