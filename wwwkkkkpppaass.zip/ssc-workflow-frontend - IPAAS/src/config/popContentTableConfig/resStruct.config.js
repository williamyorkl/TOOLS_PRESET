export const getTableColumn = function() {
  const tableColumn = [
    { label: '结构名称', prop: 'structName', minWidth: '100px' },
    { label: '是否默认', prop: 'defaultFlag', dict: 'TrueFalseEnum', minWidth: '100px' },
    { label: '创建人', prop: 'createByName', minWidth: '100px' }
  ]

  return tableColumn
}

export const getQueryList = function({ TrueFalseEnum = [] }) {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'structName',
      label: '结构名称',
      queryType: 'input'
    },
    {
      key: 'defaultFlag',
      label: '是否默认',
      queryType: 'select',
      list: TrueFalseEnum,
      labelKey: 'desc',
      valueKey: 'type'
    }
  ]
  return queryList
}
