export const getTableColumn = function() {
  const tableColumn = [
    { label: '后端服务名称', prop: 'apiName', minWidth: '120' },
    { label: '服务类型', prop: 'serviceType', dict: 'ServiceTypeEnum', minWidth: '120' },
    { label: '接口请求URL', prop: 'apiRequestUrl', minWidth: '120' },
    { label: '方法名称', prop: 'methodName', minWidth: '120' },
    { label: '服务声明名称', prop: 'serviceName', minWidth: '120' }
  ]

  return tableColumn
}

export const getQueryList = function({ allType, ServiceTypeEnum }) {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'apiName',
      label: '后端服务名称',
      queryType: 'input'
    },
    {
      key: 'serviceName',
      label: '服务声明名称',
      queryType: 'input',
      editProps: {
        maxLength: 256
      }
    },
    {
      key: 'apiRequestUrl',
      label: '接口请求URL',
      queryType: 'input'
    }
  ]

  if (!allType) {
    return [...queryList,
      {
        key: 'serviceType',
        label: '服务类型',
        queryType: 'select',
        list: ServiceTypeEnum,
        labelKey: 'desc',
        valueKey: 'type'
      }
    ]
  } else {
    return [...queryList,
      {
        key: 'serviceType',
        label: '服务类型',
        queryType: 'select',
        list: ServiceTypeEnum,
        labelKey: 'desc',
        valueKey: 'type'
      }
    ]
  }
}
