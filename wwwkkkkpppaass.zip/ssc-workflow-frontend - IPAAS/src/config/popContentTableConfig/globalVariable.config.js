import globalVariableApi from '@/api/platformConfig/global-variable.js'

export const getTableColumn = function() {
  const tableColumn = [
    { label: '变量名', prop: 'keyName', minWidth: '150px' },
    { label: '变量类型', prop: 'keyType', dict: 'GlobalKeyValTypeEnum', minWidth: '100px' },
    { label: '数据类型', prop: 'dataType', dict: 'DataTypeEnum', minWidth: '100px' },
    { label: '变量值', prop: 'keyVal', minWidth: '150px' },
    { label: '描述', prop: 'description', minWidth: '150px' }
  ]

  return tableColumn
}

export const getQueryList = function({ GlobalKeyValTypeEnum = [] }) {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'keyName',
      label: '变量名',
      queryType: 'input'
    }, {
      key: 'keyType',
      label: '变量类型',
      queryType: 'select',
      list: GlobalKeyValTypeEnum,
      labelKey: 'desc',
      valueKey: 'type'
    }
  ]
  return queryList
}

// 接口
export const apiFunc = globalVariableApi.getVariableList

export default {
  apiFunc,
  getTableColumn,
  getQueryList
}
