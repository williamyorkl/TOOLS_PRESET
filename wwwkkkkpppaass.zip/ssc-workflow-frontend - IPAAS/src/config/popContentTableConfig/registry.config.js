export const getTableColumn = function() {
  const tableColumn = [
    { label: '注册中心名称', prop: 'name', minWidth: '120px' },
    { label: '注册中心类型', prop: 'type', dict: 'RegistryTypeEnum', width: '120' },
    { label: '命名空间', prop: 'namespace', minWidth: '120px' },
    { label: '注册中心地址', prop: 'addressList', minWidth: '120px' },
    { label: '描述', prop: 'remark', minWidth: '80px' }
  ]

  return tableColumn
}

export const getQueryList = function() {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'name',
      label: '注册中心名称',
      queryType: 'input'
    },
    {
      key: 'namespace',
      label: '命名空间',
      queryType: 'input'
    },
    {
      key: 'addressList',
      label: '注册中心地址',
      queryType: 'input'
    }
  ]
  return queryList
}
