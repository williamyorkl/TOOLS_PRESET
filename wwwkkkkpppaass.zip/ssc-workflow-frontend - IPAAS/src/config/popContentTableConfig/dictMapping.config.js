import mappingDictApi from '@/api/mappingDict'

export const getTableColumn = function() {
  const tableColumn = [
    { label: '映射名称', prop: 'name' },
    { label: '映射结果来源', prop: 'dictMapSrcType', dict: 'DictMapSrcTypeEnum', minWidth: '100px' },
    { label: '缓存时间(s)', prop: 'cacheTime', minWidth: '100px' }
  ]

  return tableColumn
}

export const getQueryList = function({ DictMapSrcTypeEnum = [] }) {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'name',
      label: '映射名称',
      queryType: 'input'
    },
    {
      key: 'dictMapSrcType',
      label: '映射结果来源',
      queryType: 'select',
      list: DictMapSrcTypeEnum,
      valueKey: 'type',
      labelKey: 'desc'
    }
  ]
  return queryList
}

// 接口
export const apiFunc = mappingDictApi.getMappingDictList

export default {
  apiFunc,
  getTableColumn,
  getQueryList
}
