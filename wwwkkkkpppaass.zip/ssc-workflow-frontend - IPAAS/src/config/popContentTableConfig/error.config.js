import errApi from '@/api/platformConfig/err'
export const getConfig = async function() {
  const resp = await errApi.getErrorStruct({})
  const tableColumn = []
  const queryList = []
  resp.forEach(item => {
    tableColumn.push({ label: item.fieldName, prop: item.fieldName, minWidth: '120px' })
    queryList.push({ key: item.fieldName, label: item.fieldName, queryType: 'input' })
  })

  return [tableColumn, queryList]
}
