export const LogStatusEnum = ['success', 'warning', 'error', 'timeout']

export const STATUS_ICON = {
  0: 'success',
  1: 'warning',
  2: 'error',
  3: 'error'
}

// const javaType = [
//   { type: 1, desc: 'Integer' },
//   { type: 2, desc: 'Long' },
//   { type: 3, desc: 'Boolean' },
//   { type: 4, desc: 'Float' },
//   { type: 5, desc: 'Double' },
//   { type: 6, desc: 'String' },
//   { type: 7, desc: 'Object' },
//   { type: 8, desc: 'Array' },
//   { type: 9, desc: 'Date' },
//   { type: 10, desc: 'BigDecimal' },
//   { type: 11, desc: 'Byte' },
//   { type: 12, desc: 'Short' }
// ]
export const JS_JAVA_TYPE_TRANSFORM = {
  string: 6,
  number: 4,
  object: 7,
  array: 8,
  boolean: 3,
  integer: 1,
  float: 4
}

export const TIME_ENUM = [
  { type: 's', desc: '秒' },
  { type: 'm', desc: '分' },
  { type: 'h', desc: '时' },
  { type: 'd', desc: '天' }
]

export const TIME_OPTIONS = {
  d: 30,
  m: 59,
  s: 59,
  h: 23
}

export const LOGIN_MODE = {
  TENANT_ADMIN: 1, // 租户管理
  WEB_ADMIN: 2 // 服务管理
}

export const TENANT_ADMIN_MODE = ['default', 'iam']

export const LogicWorkflowEnum = [{ type: 1, desc: '调度任务' }, { type: 2, desc: 'MQ驱动' }, { type: 3, desc: 'CDC驱动' }]

export const DbSqlSortEnum = [{ type: 'DESC', desc: 'DESC' }, { type: 'ASC', desc: 'ASC' }]

// 节点类型
export const NodeTypeEnum = {
  START: 1, // 开始
  PROCESS: 2, // 流程
  DB: 3, // 数据库
  MQ: 4, // MQ
  FORWARD: 6, // 转发
  ERROR: 7, // 错误
  RESPONSE: 8, // 响应
  VARIABLE: 9, // 变量
  FILTER: 10, // 过滤
  MAPPER: 11, // 映射
  GROUP: 12, // 组
  GROOVY: 13, // Groovy
  COMBINE: 14, // 合并
  END: 15, // 结束
  CHOICE: 16, // 选择
  FOREACH: 17, // forEach
  BREAK: 18,
  CONTINUE: 19,
  SORT: 20, // 排序节点
  SYNC: 21, // synchronized节点
  ASYNC: 22,
  CACHE: 23, // 缓存节点
  TRY: 24 // try节点
}

// 分组节点
export const GROUP_NODES = [NodeTypeEnum.SYNC, NodeTypeEnum.FOREACH, NodeTypeEnum.CHOICE, NodeTypeEnum.ASYNC, NodeTypeEnum.TRY]

export const ChoiceEnum = {
  IF: 1,
  ELSE_IF: 2,
  ELSE: 3
}

// 普通节点
export const NormalNode = ['START', 'PROCESS', 'DB', 'MQ', 'FORWARD', 'ERROR', 'RESPONSE', 'VARIABLE', 'FILTER', 'MAPPER', 'GROUP', 'GROOVY', 'COMBINE', 'END']

export const TemplateCategoryEnum = {
  ServiceArrangeList: 0, // 服务编排
  DispatchArrangeList: 1, // 定时集成
  MqArrangeList: 2, // 消息集成
  CdcArrangeList: 3 // 实时集成
}

// java数据类型
export const DataTypes = {
  Integer: 1,
  Array: 8,
  BigDecimal: 10,
  Boolean: 3,
  Byte: 11,
  Date: 9,
  Double: 5,
  Float: 4,
  Long: 2,
  Object: 7,
  Short: 12,
  String: 6
}

// 数据库数据类型转java类型
export const DbType2JavaType = {
  Array: ['array', 'arr'],
  Object: ['object', 'obj'],
  Integer: ['bit', 'number', 'int2', 'int4', 'int8', 'int', 'tinyint', 'integer'],
  BigDecimal: ['numeric', 'decimal', 'bigdecimal'],
  Boolean: ['bool', 'boolean'],
  Byte: ['binary', 'image', 'varbinary', 'udt', 'byte'],
  Date: ['date', 'datetime', 'timestamp', 'time', 'smalldatetime', 'datetime2'],
  Double: ['money', 'double'],
  Float: ['float4', 'float8', 'float', 'real'],
  Long: ['bigint', 'long'],
  Short: ['smallint', 'tinyint', 'short'],
  String: ['str', 'string', 'char', 'ntext', 'decimal', 'uniqueidentifier', 'xml', 'smallmoney', 'varchar2', 'path', 'point', 'polygon', 'varbit', 'bigserial', 'timestamp without time zone', 'text', 'blob', 'clob', 'nchar', 'nvarchar', 'box', 'bpchar', 'cidr', 'circle', 'inet', 'interval', 'line', 'lseg', 'macaddr']
}

export const ReverseTrueFalseEnum = [
  { type: 0, desc: '是' },
  { type: 1, desc: '否' }
]
