export default {
  VIEW: '查看',
  ADD: '新增',
  DELETE: '删除',
  QUERY: '查询',
  LIMIT: '流控',
  LINK: '链接',
  COMMIT: '提交',
  CANCEL: '返回',
  CONNECT: '连接',
  UPLOAD: '上传',
  ROWCLICK: '点击行',
  EDIT: '编辑',
  ARRANGE: '编排',
  ROWSELECT: '多选行',
  WX_UPDATE: '更新微信',
  DD_UPDATE: '更新钉钉',
  HANDLE: '处理',
  GENE_DOC: '文档生成',
  GENE_SDK: 'SDK生成',
  PERMISSION: '权限',
  START: '启动',
  PAUSE: '暂停',
  LOG: '日志',
  FORWARD: '路由转发',
  SYNC: '同步',
  GRANT: '授权',
  RETRY: '重试',
  DEGRADE: '熔断',
  RESET: '重置',
  ENABLE: '启用',
  DISABLE: '禁用',
  LAYOUT: '编排',
  CREATE_TPL: '生成模板',
  SAVE: '保存',
  THREAD_POOL: '线程池设置',
  PUBLISH: '发布',
  OPERATE_LOG: '操作日志',
  DISCARD: '作废'
}

// 数据状态：待发布-0；已上线-1；已下线-2  待发布 => 已上线 => 已下线 => 已上线
export const StatusEnum = {
  0: {
    statusLabel: '待发布',
    nextStatus: 1,
    operateBtn: '发布'
  },
  1: {
    statusLabel: '已上线',
    nextStatus: 2,
    operateBtn: '下线'
  },
  2: {
    statusLabel: '已下线',
    nextStatus: 1,
    operateBtn: '上线'
  }
}

export const INT_MAX = 2147483647
