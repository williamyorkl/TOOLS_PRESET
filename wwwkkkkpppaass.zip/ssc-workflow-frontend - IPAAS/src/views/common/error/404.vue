<template>
  <div class="error-container">
    
        <div class="error-title">
          404错误!
        </div>
        <div class="error-desc">
          {{ message }}
        </div>
        <div class="error-detail">
          对不起，您正在寻找的页面不存在。尝试检查URL的错误，然后按浏览器上的刷新按钮或尝试在我们的应用程序中找到其他内容。
        </div>
        <router-link to="/" class="error-btn el-tag el-tag--light">
          返回首页
        </router-link>
      </div>
</template>

<script>

export default {
  name: 'Page404',

  computed: {
    message() {
      return '找不到网页！'
    }
  }
}
</script>

<style lang="scss" scoped>
.error-container{
  display: flex;
    align-items: center;
    justify-content: center;
    min-height: 500px;
    flex-direction: column;
    line-height: 3;
  .error-title{
    font-size: 50px;
  }
  .error-btn{
    // line-height: auto;
  }

}

</style>
