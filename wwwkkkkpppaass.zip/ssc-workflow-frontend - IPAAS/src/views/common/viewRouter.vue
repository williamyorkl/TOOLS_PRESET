<template >
  <keep-alive :max="10" :include="keepAliveNames">
    <router-view :key="$route.fullPath" />
  </keep-alive>
</template>

<script>
import { mapState } from 'vuex'
export default {
  computed: {
    ...mapState({
      keepAliveNames: state => {
        // console.log(state.keepAliveNames)
        return state.keepAliveNames
      }
    })
  }
}
</script>
