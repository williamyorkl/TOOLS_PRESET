<template>
<div class="app-list" v-loading="!appList">
  <template v-if="appList">
    <el-row :gutter="10" v-if="appList.length > 0">
      <el-col :span="8" v-for="item in appList" :key="item.appId">
        <div class="app" @click="handleAppClick(item)">
          <el-image class="app-logo" :src="item.logo || defaultImg" fit="fill"></el-image>
          <div class="app-text">
            <div class="app-title">{{item.appName}}</div>
            <div class="app-subtitle">{{item.description || '暂时没有描述'}}</div>
          </div>
        </div>
      </el-col>
    </el-row>
    <el-empty v-if="appList.length === 0" description="您还没有已授权应用">
      <el-button type="primary" @click="logout">退出</el-button>
    </el-empty>
  </template>
</div>
</template>

<script>
import appApi from '@/api/app/app'
import defaultImg from '@/assets/LOGO-brand.png'
export default {
  data() {
    return {
      appList: null,
      defaultImg
    }
  },
  async created() {
    this.appList = await this.getAppList()
    // 如果只有一个应用，直接进入该应用
    if (this.appList && this.appList.length === 1) {
      this.handleAppClick(this.appList[0])
    }
  },
  methods: {
    async getAppList() {
      const userId = this.$store.state.user.userInfo.jwtInfo.userId
      const resp = await appApi.listAppByUserId({ userId })
      return resp
    },
    handleAppClick(app) {
      this.$store.commit('user/TOGGLE_APP', app)
      this.$router.push({ name: 'home' })
    },
    logout() {
      this.$store.dispatch('user/logout')
    }
  }
}
</script>

<style scoped lang="scss">
.app-list{
  min-height: 500px;
}
.app{
  display: flex;
  align-items: center;
  // height: 180px;
  // width: 300px;
  height: 180px;
  padding: 10px;
  box-sizing: border-box;
  margin: 50px 100px;
  // background: rgba(0, 0, 0, .1);
  background: #eee;
  border-radius: 25px;
  cursor: pointer;
  word-break: break-all;
  &:hover{
    box-shadow: 10px 10px 10px #aaa;
    margin-top: 49px;
    margin-bottom: 51px;
  }
  .app-logo{
    width: 120px;
    height: 120px;
    flex-shrink: 0;
  }
  .app-title{
    font-size: 28px;
  }
  .app-subtitle{
    font-size: 12px;
  }
}
</style>
