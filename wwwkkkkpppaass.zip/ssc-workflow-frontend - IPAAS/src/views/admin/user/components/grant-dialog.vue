<template>
  <el-dialog :title="title" :visible.sync="visible" :width="width" :before-close="handleClose" v-if="visible">
    <el-transfer v-model="grantedApp" :data="appList" :titles="['未授权', '已授权']" :props="{key: 'id', label: 'appName'}">

    </el-transfer>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" @click="confirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import Constant from '@/config/constant'
export default {
  name: 'EditDialog',
  props: {
    visible: {
      default: false,
      type: Boolean
    },
    title: {
      default: '新增',
      type: String
    },
    width: {
      default: '30%',
      type: String
    },
    grantedApp: {
      type: Array,
      default: () => []
    },
    appList: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
    }
  },
  watch: {
    visible(nV) {
      if (nV && this.$refs.form) {
        this.$refs.form.clearValidate()
      }
    }
  },
  methods: {
    handleClose(done) {
      this.$emit('update:visible', false)
    },
    confirm() {
      this.$emit('commit', this.grantedApp)
    }
  }
}
</script>
