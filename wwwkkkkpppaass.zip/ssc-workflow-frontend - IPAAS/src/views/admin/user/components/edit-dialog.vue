<template>
  <el-dialog :title="title" :visible.sync="visible" :width="width" :before-close="handleClose" v-if="visible">
    <mc-form ref="form" :model="formData" :rules="rules">
      <mc-form-item componentType="ElInput" prop="userName" label="账号" :span="24"></mc-form-item>
      <mc-form-item componentType="ElInput" prop="showName" label="名称" :span="24"></mc-form-item>
      <mc-form-item componentType="ElInput" prop="passWord" label="密码" :editProps="{type: 'password'}" :span="24" @input="passWordChange"></mc-form-item>
    </mc-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" @click="confirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { deepClone } from '@/utils'
import { regExpRules } from '@/utils/validator'
import { enRsa } from '@/utils/decode'
import Constant from '@/config/constant'
export default {
  name: 'EditDialog',
  props: {
    visible: {
      default: false,
      type: Boolean
    },
    title: {
      default: '新增',
      type: String
    },
    width: {
      default: '30%',
      type: String
    },
    formData: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      rules: {
        userName: [
          { required: true, message: '请输入账号', trigger: 'blur' },
          { pattern: regExpRules.account, message: '长度在2~16之间', trigger: 'blur' }
        ],
        showName: [
          { required: true, message: '请输入名称', trigger: 'blur' },
          { pattern: regExpRules.account, message: '长度在2~16之间', trigger: 'blur' }
        ],
        passWord: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { pattern: regExpRules.passWord, message: '长度在4~16之间', trigger: 'blur' }
        ]
      },
      isPassWordChanged: false
    }
  },
  watch: {
    visible(nV) {
      if (nV && this.$refs.form) {
        this.$refs.form.clearValidate()
      }
    }
  },
  methods: {
    passWordChange(v) {
      if (!this.isPassWordChanged) {
        this.isPassWordChanged = true
      }
    },
    handleClose(done) {
      this.$emit('update:visible', false)
    },
    confirm() {
      this.$refs.form.validate()
        .then(valid => {
          if (valid) {
            // 如果未编辑，不传密码；如果修改，转base64
            const formData = deepClone(this.formData)
            if (this.isPassWordChanged) {
              console.log(formData)
              formData.passWord = enRsa(formData.passWord)
            } else {
              delete formData.passWord
            }
            this.$emit('eventListener', Constant.COMMIT, formData)
          } else {
            this.$message.error('请按照提示完善表单数据')
          }
        })
    }
  }
}
</script>
