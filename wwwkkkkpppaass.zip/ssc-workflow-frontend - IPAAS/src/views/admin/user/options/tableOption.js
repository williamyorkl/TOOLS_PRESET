import Constant from '@/config/constant'
import { formatTime } from '@/utils'

export function getTableColumn() {
  const tableColumn = [
    { label: '账号', prop: 'userName', minWidth: '200px' },
    { label: '名称', prop: 'showName', minWidth: '200px' },
    { label: '来源', prop: 'channelFlag', minWidth: '200px' },
    { label: '关联ID', prop: 'relateId', minWidth: '200px' },
    { label: '创建人', prop: 'createByName' },
    {
      label: '创建时间',
      prop: 'createTime',
      minWidth: '140px',
      formatter(row, column) {
        return formatTime(row.createTime)
      }
    },
    { label: '更新人', prop: 'updateByName' },
    {
      label: '更新时间',
      prop: 'updateTime',
      minWidth: '140px',
      formatter(row, column) {
        return formatTime(row.updateTime)
      }
    },
    {
      prop: 'operate',
      label: '操作',
      width: 140,
      btnList: [
        {
          text: '编辑',
          eventType: Constant.EDIT,
          hidden: (row) => !!row.channelFlag
        },
        {
          text: '授权应用',
          eventType: Constant.GRANT,
          hidden: (row) => !!row.channelFlag
        },
        {
          text: '删除',
          eventType: Constant.DELETE,
          hidden: (row) => !!row.channelFlag
        }
      ]
    }
  ]

  return tableColumn
}
