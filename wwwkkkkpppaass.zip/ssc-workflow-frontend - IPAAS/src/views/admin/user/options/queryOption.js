export function getQueryList() {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'userName',
      label: '账号',
      queryType: 'input'
    },
    {
      key: 'showName',
      label: '名称',
      queryType: 'input'
    }
    // {
    //   key: 'migrateType',
    //   label: '状态',
    //   queryType: 'select',
    //   list: MigrateTypeEnum,
    //   valueKey: 'type',
    //   labelKey: 'desc'
    // }
  ]

  return queryList
}
