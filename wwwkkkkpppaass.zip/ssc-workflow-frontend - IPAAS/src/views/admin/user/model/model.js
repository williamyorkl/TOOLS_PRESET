export class FormData {
  constructor() {
    this.userName = null // 用户名
    this.passWord = null // 密码
    this.showName = null // 名称
  }
}
