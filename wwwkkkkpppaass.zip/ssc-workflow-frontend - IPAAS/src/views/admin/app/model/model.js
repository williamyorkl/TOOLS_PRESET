export class FormData {
  constructor() {
    this.appName = null // 应用名称
    this.id = null
  }
}
