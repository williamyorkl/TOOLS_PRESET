export function getQueryList() {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'appName',
      label: '应用名称',
      queryType: 'input'
    },
    {
      key: 'relateId',
      label: '应用编码',
      queryType: 'input'
    }
    // {
    //   key: 'migrateType',
    //   label: '状态',
    //   queryType: 'select',
    //   list: MigrateTypeEnum,
    //   valueKey: 'type',
    //   labelKey: 'desc'
    // }
  ]

  return queryList
}
