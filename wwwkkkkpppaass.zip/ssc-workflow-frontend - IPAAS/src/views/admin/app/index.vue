<template>
  <div class="common-container">
    <div class="apply-content">
      <mc-query :query-list="queryList" @query="handleFilter"></mc-query>
      <div class="common-btns-container">
        <el-button type="primary" @click="handleAdd">新增</el-button>
      </div>
      <div class="common-table-container" v-loading="listLoading">
        <mc-table :tableData="tableData" :tableColumn="tableColumn" @eventListener="eventListener">
        </mc-table>
      </div>
      <div class="pagination-container">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page.sync="pageIndex" :page-sizes="[10, 20, 50, 100]" :page-size="10" layout="total, sizes, prev, pager, next, jumper" :total="recordCount" background>
        </el-pagination>
      </div>
    </div>

    <edit-dialog :formData.sync="formData" :visible.sync="editDialogVisible" :title="editDialogTitle" @eventListener="eventListener" width="800px" :props="{}"></edit-dialog>

  </div>
</template>

<script>
import { mapActions } from 'vuex'
import Constant from '@/config/constant'

import EditDialog from './components/edit-dialog'
import appApi from '@/api/admin/app'
import { getQueryList } from './options/queryOption'
import { getTableColumn } from './options/tableOption'
import { FormData } from './model/model'
export default {
  name: 'User',
  components: { EditDialog },
  data() {
    return {
      listLoading: false,
      recordCount: 0,
      pageIndex: 1,
      pageSize: 10,
      queryList: [],
      query: {}, // 列表查询条件
      tableColumn: [],
      tableData: [],
      editDialogVisible: false,
      editDialogTitle: '新增用户',
      formData: {}
    }
  },
  async created() {
    const [MigrateTaskStatusEnum, MigrateTaskTypeEnum, MigrateTypeEnum] = await this.getDicts(['MigrateTaskStatusEnum', 'MigrateTaskTypeEnum', 'MigrateTypeEnum'])
    this.tableColumn = getTableColumn()
    this.queryList = getQueryList({ MigrateTaskStatusEnum, MigrateTaskTypeEnum, MigrateTypeEnum })
    this.getList() // 如果有字典数据必须放在获取字典数据后
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    handleEdit(row) {
      this.editDialogTitle = '编辑用户'
      this.editDialogVisible = true
      this.formData = { ...row }
    },
    handleAdd() {
      this.editDialogTitle = '新增用户'
      this.editDialogVisible = true
      this.formData = new FormData()
    },
    async handleCommit(formData) {
      let msg = '新增成功'
      if (formData.id) {
        await appApi.updateApp(formData)
        msg = '成功'
      } else {
        const resp = await appApi.saveApp(formData)
      }
      this.$message.success(msg)
      this.editDialogVisible = false
      this.getList()
    },
    async handleDelete(row) {
      this.$confirm('是否确认删除该条数据?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(async() => {
        await appApi.deleteApp({ id: row.id })
        this.$message.success('删除成功')
        this.getList()
      }).catch(() => {
        this.$message.info('已取消删除')
      })
    },
    async getList() {
      this.listLoading = true
      const params = {
        size: this.pageSize,
        page: this.pageIndex,
        ...this.query
      }
      appApi
        .listApp(params)
        .then((response) => {
          this.listLoading = false
          this.tableData = response.records || []
          if (this.pageIndex === 1) {
            this.recordCount = response.total || 0
          }
        })
        .catch(() => {
          this.listLoading = false
          this.tableData = []
          this.recordCount = 0
        })
    },
    eventListener(eventType, row) {
      switch (eventType) {
        case Constant.EDIT:
          this.handleEdit(row)
          break
        case Constant.COMMIT:
          this.handleCommit(row)
          break
        case Constant.DELETE:
          this.handleDelete(row)
          break
      }
    },
    // 根据刷选条件过滤数据
    handleFilter(val) {
      this.pageIndex = 1
      this.query = val
      this.getList()
    },
    // 修改每页数量
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.pageIndex = val
      this.getList()
    }
  }
}
</script>

<style>
</style>
