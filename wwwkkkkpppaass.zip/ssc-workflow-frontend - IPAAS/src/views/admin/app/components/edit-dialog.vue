<template>
  <el-dialog :title="title" :visible.sync="visible" :width="width" :before-close="handleClose" v-if="visible">
    <mc-form ref="form" :model="formData" :rules="rules">
      <mc-form-item componentType="ElInput" prop="appName" label="应用名称" :span="24"></mc-form-item>
      <template v-if="formData.id">
        <mc-form-item componentType="ElInput" prop="channelFlag" label="来源" :editProps="{placeholder: ''}" :disabled="true" :span="24"></mc-form-item>
        <mc-form-item componentType="ElInput" prop="relateId" label="关联ID" :editProps="{placeholder: ''}" :disabled="true" :span="24"></mc-form-item>
      </template>
    </mc-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" @click="confirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { regExpRules } from '@/utils/validator'
import Constant from '@/config/constant'
export default {
  name: 'EditDialog',
  props: {
    visible: {
      default: false,
      type: Boolean
    },
    title: {
      default: '新增',
      type: String
    },
    width: {
      default: '30%',
      type: String
    },
    formData: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      rules: {
        appName: [
          { required: true, message: '请输入应用名称', trigger: 'blur' }
        ]
      }
    }
  },
  watch: {
    visible(nV) {
      if (nV && this.$refs.form) {
        this.$refs.form.clearValidate()
      }
    }
  },
  methods: {
    handleClose(done) {
      this.$emit('update:visible', false)
    },
    confirm() {
      this.$refs.form.validate()
        .then(valid => {
          if (valid) {
            this.$emit('eventListener', Constant.COMMIT, this.formData)
          } else {
            this.$message.error('请按照提示完善表单数据')
          }
        })
    },
    connectServer() {
      this.$emit('eventListener', Constant.CONNECT, this.formData)
    }
  }
}
</script>
