<template>
  <div class="common-container">
    <div class="apply-content">
      <mc-query :queryList="queryList" @query="handleFilter" />
      <div class="common-table-container" v-loading="listLoading">
        <mc-table :tableData="tableData" :tableColumn="tableColumn" @eventListener="eventListener" />
      </div>
      <div class="pagination-container">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :currentPage.sync="pageIndex" :pageSizes="[10, 20, 50, 100]" :pageSize="10" layout="total, sizes, prev, pager, next, jumper" :total="recordCount" background />
      </div>
    </div>

    <retry-log :id="logId" :visible.sync="logDialogVisible" v-if="logDialogVisible" />
    <edit-dialog :formData.sync="formData" :visible.sync="editDialogVisible" :title="editDialogTitle" @eventListener="eventListener" width="800px" />
  </div>
</template>

<script>
import { mapActions } from 'vuex'
import Constant from '@/config/constant'
import logApi from '@/api/gateway/log'

import EditDialog from './components/edit-dialog'
import RetryLog from './components/retryLog/retryLog'
import breakPointApi from '@/api/arrange/breakPoint'
import { getQueryList } from './options/queryOption'
import { getTableColumn } from './options/tableOption'
import { prettierJson } from '@/utils'
export default {
  name: 'BreakPoint',
  components: { EditDialog, RetryLog },
  data() {
    return {
      listLoading: false,
      recordCount: 0,
      pageIndex: 1,
      pageSize: 10,
      queryList: [],
      query: {}, // 列表查询条件
      tableColumn: [],
      tableData: [],
      editDialogVisible: false,
      editDialogTitle: '断点续跑',
      formData: {},
      logId: null,
      logDialogVisible: false
    }
  },
  async created() {
    this.tableColumn = getTableColumn()

    const [TrueFalseEnum, ConsistencyTaskStatusEnum] = await this.getDicts(['TrueFalseEnum', 'ConsistencyTaskStatusEnum', 'ConsistencyPolicyFrontEnum'])
    this.getList()
    this.queryList = getQueryList({ TrueFalseEnum, ConsistencyTaskStatusEnum, remoteQuery: this.remoteQuery })
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    handleView(row) {
      this.editDialogTitle = '断点续跑详情'
      this.editDialogVisible = true
      row.result = prettierJson(row.result)
      this.formData = { ...row }
    },
    handleLog(row) {
      this.logId = row.id
      this.logDialogVisible = true
    },
    handleLink(row) {
      console.log('link')
      this.$router.push({
        name: 'GatewayLog',
        query: {
          id: row.traceId
        }
      })
    },
    async handleRetry(row) {
      await breakPointApi.retryBreakPoint({ id: row.id })
      this.$message.success('操作成功')
      this.editDialogVisible = false
      this.getList()
    },
    async handleDiscard(row) {
      await breakPointApi.discardBreakPoint({ id: row.id })
      this.$message.success('操作成功')
      this.editDialogVisible = false
      this.getList()
    },
    async getList() {
      this.listLoading = true
      const params = {
        size: this.pageSize,
        page: this.pageIndex,
        ...this.query
      }
      breakPointApi
        .listbreakPoint(params)
        .then((response) => {
          this.listLoading = false
          this.tableData = response.records || []
          if (this.pageIndex === 1) {
            this.recordCount = response.total || 0
          }
        })
        .catch(() => {
          this.listLoading = false
          this.tableData = []
          this.recordCount = 0
        })
    },
    eventListener(eventType, row) {
      switch (eventType) {
        case Constant.VIEW:
          this.handleView(row)
          break
        case Constant.RETRY:
          this.handleRetry(row)
          break
        case Constant.DISCARD:
          this.handleDiscard(row)
          break
        case Constant.LOG:
          this.handleLog(row)
          break
        case 'link':
          this.handleLink(row)
          break
      }
    },
    remoteQuery(v) {
      return new Promise((resolve, reject) => {
        logApi.getUserLists({ businessApiName: v })
          .then(res => {
            resolve(res.records)
          }).catch((err) => reject(err))
      })
    },
    // 根据刷选条件过滤数据
    handleFilter(val) {
      this.pageIndex = 1
      this.query = val
      this.getList()
    },
    // 修改每页数量
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.pageIndex = val
      this.getList()
    }
  }
}
</script>

<style>
</style>
