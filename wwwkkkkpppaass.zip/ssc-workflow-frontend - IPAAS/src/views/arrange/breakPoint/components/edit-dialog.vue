<template>
  <el-dialog :title="title" :visible.sync="visible" :width="width" :beforeClose="handleClose" v-if="visible">
    <mc-form ref="form" :model="formData" :rules="rules">
      <mc-form-item componentType="ElInput" prop="taskId" label="任务ID" :disabled="true" />
      <mc-form-item componentType="ElInput" prop="definitionName" label="集成流名称" :disabled="true" />
      <mc-form-item componentType="ElInput" prop="stageRetryTimes" label="重试次数" :disabled="true" />
      <mc-form-item componentType="ElInput" prop="retryPolicy" label="重试策略" :disabled="true" />
      <mc-form-item componentType="ElInput" prop="retryStage" label="重试阶段" :disabled="true" />
      <mc-form-item componentType="ElInput" prop="result" label="响应结果" :editProps="{type: 'textarea', rows: 5}" :span="24" :disabled="true" />
    </mc-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" @click="confirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import Constant from '@/config/constant'
export default {
  name: 'EditDialog',
  props: {
    visible: {
      default: false,
      type: Boolean
    },
    title: {
      default: '新增',
      type: String
    },
    width: {
      default: '30%',
      type: String
    },
    formData: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      rules: {}
    }
  },
  watch: {
    visible(nV) {
      if (nV && this.$refs.form) {
        this.$refs.form.clearValidate()
      }
    }
  },
  computed: {
    oracle_schemaRules() {
      if (this.formData.dataBaseType === 2) {
        return { required: true, message: '请填写schema', trigger: 'blur' }
      } else {
        return {}
      }
    }
  },
  methods: {
    handleClose() {
      this.$emit('update:visible', false)
    },
    confirm() {
      this.$refs.form.validate().then((valid) => {
        if (valid) {
          this.$emit('eventListener', Constant.COMMIT, this.formData)
          this.$emit('update:visible', false)
        } else {
          this.$message.error('请按照提示完善表单数据')
        }
      })
    }
  }
}
</script>
