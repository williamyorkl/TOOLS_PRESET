import { formatTime } from '@/utils'

export function getTableColumn() {
  const tableColumn = [
    { label: '业务类型', prop: 'bizType', dict: 'OperateBizTypeEnum' },
    { label: '日志内容', prop: 'logContent' },
    {
      label: '创建时间',
      prop: 'createTime',
      formatter(row, _column) {
        return formatTime(row.createTime)
      }
    },
    { label: '操作人', prop: 'operatorName' }
    // {
    //   prop: 'operate',
    //   label: '操作',
    //   width: 50,
    //   btnList: [
    //     {
    //       text: '详情',
    //       eventType: Constant.VIEW,
    //       hidden: (row) => false
    //     }
    //     // {
    //     //   text: '删除',
    //     //   eventType: Constant.DELETE,
    //     //   hidden: (row) => false
    //     // }
    //   ]
    // }
  ]

  return tableColumn
}
