<template>
  <el-dialog title="操作日志" :visible.sync="visible" :beforeClose="handleCancel" width="60%" v-if="visible" :modalAppendToBody="false">
    <div class="common-container">
      <div class="apply-content">
        <!-- <mc-query :queryList="queryList" @query="handleFilter" :col="2" /> -->
        <div class="common-btns-container">
          <!-- <el-button type="primary" @click="handleAdd">新增</el-button> -->
        </div>
        <div class="common-table-container" v-loading="listLoading">
          <mc-table :tableData="tableData" :tableColumn="tableColumn" @eventListener="eventListener" />
        </div>
        <div class="pagination-container">
          <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :currentPage.sync="pageIndex" :pageSizes="[10, 20, 50, 100]" :pageSize="10" layout="total, sizes, prev, pager, next, jumper" :total="recordCount" background />
        </div>
      </div>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">关 闭</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { mapActions } from 'vuex'
import Constant from '@/config/constant'

import retryApi from '@/api/arrange/breakPoint'
// import { getQueryList } from './options/queryOption'
import { getTableColumn } from './options/tableOption'
export default {
  name: 'ArrangeLog',
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    dialogTitle: {
      type: String,
      default: '新增'
    },
    // eslint-disable-next-line vue/require-default-prop
    id: {
      type: Number
    }
  },
  data() {
    return {
      listLoading: false,
      recordCount: 0,
      pageIndex: 1,
      pageSize: 10,
      // queryList: [],
      query: {}, // 列表查询条件
      tableColumn: [],
      tableData: [],
      formData: {}
    }
  },
  async created() {
    this.tableColumn = getTableColumn()
    const [OperateBizTypeEnum] = await this.getDicts([
      'OperateBizTypeEnum'
    ])
    console.log('🚀 ~ file: arrangeLog.vue ~ line 63 ~ created ~ OperateBizTypeEnum', OperateBizTypeEnum)
    this.getList()
    // this.queryList = getQueryList({ OperateBizTypeEnum })
    // console.log(this.queryList)
  },
  watch: {
    id(_nV) {
      this.getList()
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    async handleView(row) {
      this.$emit('handleViewLog')
      this.$router.push(`/arrange/arrangeSnapshot?type=log&id=${row.id}&categoryType=${this.$route.name}`)
    },
    async getList() {
      this.listLoading = true
      const params = {
        size: this.pageSize,
        page: this.pageIndex,
        // ...this.query,
        bizType: 1, // 固定为重试任务
        bizId: this.id
      }
      retryApi
        .logsBreakPoint(params)
        .then((response) => {
          this.listLoading = false
          this.tableData = response.records || []
          if (this.pageIndex === 1) {
            this.recordCount = response.total || 0
          }
        })
        .catch(() => {
          this.listLoading = false
          this.tableData = []
          this.recordCount = 0
        })
    },
    eventListener(eventType, row) {
      switch (eventType) {
        case Constant.VIEW:
          this.handleView(row)
          break
      }
    },
    // 根据刷选条件过滤数据
    handleFilter(val) {
      this.pageIndex = 1
      this.query = val
      this.getList()
    },
    // 修改每页数量
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.pageIndex = val
      this.getList()
    },
    handleCancel() {
      this.$emit('update:visible', false)
    }
  }
}
</script>

<style scoped lang="scss">
.common-container{
  padding-left: 0;
}
</style>
