import Constant from '@/config/constant'
import { formatTime } from '@/utils'

export function getTableColumn() {
  const tableColumn = [
    { label: '任务ID', prop: 'taskId', minWidth: '120px' },
    { label: '跟踪ID', prop: 'traceId', minWidth: '120px', type: 'link' },
    { label: '集成流名称', prop: 'definitionName', minWidth: '120px' },
    { label: '一致性策略', prop: 'policy', dict: 'ConsistencyPolicyFrontEnum', minWidth: '100px' },
    { label: '重试状态', prop: 'retryStatus', dict: 'ConsistencyTaskStatusEnum', minWidth: '100px' },
    { label: '重试次数', prop: 'stageRetryTimes', minWidth: '80px' },
    { label: '重试策略', prop: 'retryPolicy', minWidth: '180px' },
    { label: '重试阶段', prop: 'retryStage', minWidth: '120px' },
    { label: '最近重试时间', prop: 'latestRetryTime', minWidth: '140px' },
    { label: '下次重试时间', prop: 'nextRetryTime', minWidth: '140px' },
    { label: '更新人', prop: 'updateByName', minWidth: '140px' },
    {
      label: '更新时间',
      prop: 'updateTime',
      minWidth: '140px'
    },
    {
      label: '创建时间',
      prop: 'createTime',
      minWidth: '140px',
      formatter(row) {
        return formatTime(row.createTime)
      }
    },
    {
      prop: 'operate',
      label: '操作',
      width: 180,
      btnList: [
        {
          text: Constant.VIEW,
          eventType: Constant.VIEW,
          hidden: (_row) => false
        },
        {
          text: '立即重试',
          eventType: Constant.RETRY,
          hidden: (row) => ![0, 1].includes(row.retryStatus) // 重试中和重试最终失败的可操作重试
        },
        {
          text: Constant.DISCARD,
          eventType: Constant.DISCARD,
          hidden: (row) => row.retryStatus !== 1 // 重试中的可操作作废
        },
        {
          text: Constant.LOG,
          eventType: Constant.LOG,
          hidden: (_row) => false // 重试中的可操作作废
        }
      ]
    }
  ]

  return tableColumn
}
