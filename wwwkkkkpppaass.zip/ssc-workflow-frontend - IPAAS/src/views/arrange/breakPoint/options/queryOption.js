export function getQueryList({ ConsistencyTaskStatusEnum = [], remoteQuery }) {
  const queryList = [
    // 筛选条件初始化
    // {
    //   key: 'definitionName',
    //   label: '集成流名称',
    //   queryType: 'input'
    // },
    {
      key: 'definitionId',
      label: '集成流名称',
      queryType: 'remoteSelect',
      remoteMethod: remoteQuery,
      valueKey: 'id',
      labelKey: 'businessApiName'
    },
    {
      key: 'retryStatus',
      label: '重试状态',
      queryType: 'select',
      list: ConsistencyTaskStatusEnum,
      valueKey: 'type',
      labelKey: 'desc'
    },
    {
      key: 'traceId',
      label: '跟踪ID',
      queryType: 'input'
    }
  ]

  return queryList
}
