<template>
  <flow :formData="formData" v-if="formData" :baseDetail="baseDetail" @commit="commitForm" />
</template>

<script>
import flow from '@/components/flow-node'
import { geneDefaultData } from '@/components/flow-node/model/data_default'
import arrangeApi from '@/api/arrange'
import { mapActions } from 'vuex'
import { getArrangeDetail } from '@/views/platformConfig/arrange-tpl-set/utils/getArrangeDetail'

export default {
  name: 'ServiceArrangeDetail',
  components: { flow },
  props: {
    mode: {
      type: String,
      default: 'edit'
    },
    arrangeData: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      formData: null,
      baseDetail: null
    }
  },
  provide() {
    return {
      formDisabled: this.formDisabled,
      getFormData: () => { return this.formData }
    }
  },
  computed: {
    formDisabled() {
      return this.mode === 'snapshot'
    }
  },
  async created() {
    if (!this.formDisabled) {
      this.id = this.$route.query.id
      const templateCategory = Number(this.$route.query.templateCategory);
      [this.DataTypeEnum] = await this.getDicts(['DataTypeEnum'])
      if (this.id) {
        // const formData = await this.getArrangeData()
        const [baseDetail, formData] = await getArrangeDetail(templateCategory, this.id)
        this.formData = this.formatterData(formData)
        this.baseDetail = baseDetail
      }
    } else {
      this.formData = this.arrangeData
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    async getArrangeData() {
      const resp = await arrangeApi.detailArrange({ definitionId: this.id })
      return resp
    },
    formatterData(formData) {
      if (!formData.nodeList || formData.nodeList.length === 0) {
        const [nodeList, lineList] = geneDefaultData({})
        formData.nodeList = nodeList
        formData.lineList = lineList
      }
      return formData
    },
    async commitForm(formData) {
      // 缺少提交前清空空行的处理
      await arrangeApi.updateArrange(formData)
      this.$message.success('提交成功')
    }
  }
}
</script>

<style>

</style>
