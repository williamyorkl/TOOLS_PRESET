import Constant from '@/config/constant'
import { formatTime } from '@/utils'

export function getTableColumn() {
  const tableColumn = [
    { label: '服务编排名称', prop: 'definitionName', minWidth: '120px' },
    { label: '接口类型', prop: 'type', dict: 'ApiTypeEnum' },
    { label: '服务声明名称', prop: 'serviceName', minWidth: '120px' },
    { label: '接口名称', prop: 'serviceApiName' },
    { label: '修改内容', prop: 'changContext' },
    { label: '状态', prop: 'status', dict: 'ChangeNotificationStatusEnum' },
    {
      label: '创建时间',
      prop: 'createTime',
      minWidth: '180px',
      formatter(row, column) {
        return formatTime(row.createTime)
      }
    },
    {
      prop: 'operate',
      label: '操作',
      width: 50,
      btnList: [
        {
          text: '处理',
          eventType: Constant.HANDLE,
          hidden: row => row.status === 1
        }
        // {
        //   text: '删除',
        //   eventType: Constant.DELETE,
        //   hidden: (row) => false
        // }
      ]
    }
  ]

  return tableColumn
}
