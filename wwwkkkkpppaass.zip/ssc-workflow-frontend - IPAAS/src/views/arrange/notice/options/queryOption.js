export function getQueryList({ ApiTypeEnum = [], ChangeNotificationStatusEnum = [] }) {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'definitionName',
      label: '服务编排名称',
      queryType: 'input'
    },
    {
      key: 'type',
      label: '接口类型',
      queryType: 'select',
      list: ApiTypeEnum,
      valueKey: 'type',
      labelKey: 'desc'
    },
    {
      key: 'status',
      label: '状态',
      queryType: 'select',
      list: ChangeNotificationStatusEnum,
      valueKey: 'type',
      labelKey: 'desc'
    },
    {
      endKey: 'endTime',
      startKey: 'startTime',
      label: '创建时间',
      queryType: 'elDateRange',
      valueFormat: 'yyyy-MM-dd HH:mm:ss'
    }
  ]

  return queryList
}
