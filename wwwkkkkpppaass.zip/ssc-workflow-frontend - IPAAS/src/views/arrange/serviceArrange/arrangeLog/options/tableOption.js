import Constant from '@/config/constant'
import { formatTime } from '@/utils'

export function getTableColumn() {
  const tableColumn = [
    { label: '操作类型', prop: 'operatitonType', dict: 'OperatitonType' },
    {
      label: '创建时间',
      prop: 'createTime',
      formatter(row) {
        return formatTime(row.createTime)
      }
    },
    { label: '操作人', prop: 'createByName' },
    {
      prop: 'operate',
      label: '操作',
      width: 50,
      btnList: [
        {
          text: '详情',
          eventType: Constant.VIEW,
          hidden: (_row) => false
        }
        // {
        //   text: '删除',
        //   eventType: Constant.DELETE,
        //   hidden: (row) => false
        // }
      ]
    }
  ]

  return tableColumn
}
