<template>
  <el-dialog title="操作日志" :visible.sync="visible" :beforeClose="handleCancel" width="60%" v-if="visible" :modalAppendToBody="false">
    <div class="common-container">
      <div class="apply-content">
        <div class="common-btns-container">
          <!-- <el-button type="primary" @click="handleAdd">新增</el-button> -->
        </div>
        <div class="common-table-container" v-loading="listLoading">
          <mc-table :tableData="tableData" :tableColumn="tableColumn" @eventListener="eventListener" />
        </div>
        <div class="pagination-container">
          <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :currentPage.sync="pageIndex" :pageSizes="[10, 20, 50, 100]" :pageSize="10" layout="total, sizes, prev, pager, next, jumper" :total="recordCount" background />
        </div>
      </div>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">关 闭</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { mapActions } from 'vuex'
import Constant from '@/config/constant'

import arrangeLogApi from '@/api/arrange/arrangeLog'
import { getQueryList } from './options/queryOption'
import { getTableColumn } from './options/tableOption'
export default {
  name: 'ArrangeLog',
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    dialogTitle: {
      type: String,
      default: '新增'
    },
    // eslint-disable-next-line vue/require-default-prop
    definitionId: {
      type: Number
    }
  },
  data() {
    return {
      listLoading: false,
      recordCount: 0,
      pageIndex: 1,
      pageSize: 10,
      queryList: [],
      query: {}, // 列表查询条件
      tableColumn: [],
      tableData: [],
      formData: {}
    }
  },
  async created() {
    this.tableColumn = getTableColumn()
    const [OperatitonType] = await this.getDicts([
      'OperatitonType'
    ])
    console.log('🚀 ~ file: arrangeLog.vue ~ line 63 ~ created ~ OperatitonType', OperatitonType)
    this.getList()
    this.queryList = getQueryList()
  },
  watch: {
    definitionId(_nV) {
      this.getList()
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    async handleView(row) {
      this.$emit('handleViewLog')
      this.$router.push(`/arrange/arrangeSnapshot?type=log&id=${row.id}&categoryType=${this.$route.name}`)
    },
    async getList() {
      this.listLoading = true
      const params = {
        size: this.pageSize,
        page: this.pageIndex,
        ...this.query,
        definitionId: this.definitionId
      }
      arrangeLogApi
        .listArrangeLog(params)
        .then((response) => {
          this.listLoading = false
          this.tableData = response.records || []
          if (this.pageIndex === 1) {
            this.recordCount = response.total || 0
          }
        })
        .catch(() => {
          this.listLoading = false
          this.tableData = []
          this.recordCount = 0
        })
    },
    eventListener(eventType, row) {
      switch (eventType) {
        case Constant.VIEW:
          this.handleView(row)
          break
      }
    },
    // 根据刷选条件过滤数据
    handleFilter(val) {
      this.pageIndex = 1
      this.query = val
      this.getList()
    },
    // 修改每页数量
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.pageIndex = val
      this.getList()
    },
    handleCancel() {
      this.$emit('update:visible', false)
    }
  }
}
</script>

<style scoped lang="scss">
.common-container{
  padding-left: 0;
}
</style>
