<template>
  <el-form class="table-form" ref="form" :model="formData" labelWidth="0px" size="mini">
    <ux-grid :data="tableData" ref="uTable" border stripe :rowId="'rowKey'" fixedColumnsRoll headerDragStyle height="300" :treeConfig="treeConfig" showOverflow="tooltip" useVirtual :editConfig="{trigger: 'click', mode: 'row'}" :expandConfig="{expandAll: true}">
      <ux-table-column resizable showOverflow="tooltip" :treeNode="true" type="index" width="90" />

      <ux-table-column resizable field="paramName" title="参数名" width="120">
        <template slot-scope="scope">
          <el-form-item>
            <el-input v-model.trim="scope.row.paramName" :disabled="disabled" />
          </el-form-item>
        </template>
      </ux-table-column>

      <ux-table-column resizable field="dataType" title="参数类型" align="left" width="170px">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.dataType" clearable placeholder="请选择参数类型" @change="dataTypeChange($event, scope.row)" :disabled="dataTypeDisabled">
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </ux-table-column>

      <ux-table-column resizable field="dataPosition" v-if="type === 'inParams'" title="参数位置" align="left" width="170px">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.dataPosition" clearable placeholder="请选择参数位置" :disabled="scope.row.dataPosition === 1 || mode === 'snapshot'">
              <!-- 禁止用户手动设置path参数；如果是get·，禁止设置body参数 -->
              <el-option v-for="item in DataPosEnum" :key="item.type" :label="item.desc" :value="item.type" :disabled="item.type === 1 || (item.type === 4 && !allowBody)" />
            </el-select>
          </el-form-item>
        </template>
      </ux-table-column>

      <ux-table-column resizable field="isRequired" v-if="type === 'inParams'" title="是否必填" align="left" width="80px">
        <template #default="scope">
          <el-form-item>
            <el-switch v-model="scope.row.isRequired" :disabled="disabled" />
          </el-form-item>
        </template>
      </ux-table-column>

      <ux-table-column resizable field="value" title="默认值" align="left" width="200px">
        <template slot-scope="scope">
          <el-form-item>
            <mc-input :dataType="scope.row.dataType" :trim="false" v-model="scope.row.value" placeholder="默认值" :disabled="disabled" />
          </el-form-item>
        </template>
      </ux-table-column>

      <!-- 只有array类型的需要设置元素泛型 -->
      <ux-table-column resizable field="generic" title="数组元素泛型" align="left" :showOverflowTooltip="false" width="200px">
        <template slot-scope="scope">
          <el-form-item>
            <el-select :disabled="scope.row.dataType !== 8 || disabled" v-model="scope.row.generic" clearable placeholder="请选择数组元素泛型" @change="genericChange($event, scope.$index, scope.row)">
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </ux-table-column>

      <ux-table-column resizable field="description" title="描述" align="left" :showOverflowTooltip="false" minWidth="130px">
        <template slot-scope="scope">
          <el-form-item>
            <el-input v-model="scope.row.description" placeholder="请输入描述" :disabled="disabled" />
          </el-form-item>
        </template>
      </ux-table-column>

      <ux-table-column resizable field="operate" title="操作" width="140" fixed="right">
        <template #default="{row}">
          <!-- 当前行类型不是数组或对象时禁止添加行   7:Object 8：Array    generic ：3  -->
          <el-button v-if="type === 'inParams'" type="text" @click="paramCheck(row)" :disabled="disabled">校验</el-button>

          <el-button
            type="text"
            @click="addRow(row)"
            :disabled="!(row.dataType === 7 || (row.dataType === 8 && row.generic === 7)) || disabled"
          >
            添加
          </el-button>

          <el-button type="text" @click="deleteRow(row)" :disabled="row.dataPosition === 1 || disabled">删除</el-button>
        </template>
      </ux-table-column>
    </ux-grid>
    <el-button class="table-add-btn" size="medium" type="dash" icon="el-icon-plus" :disabled="disabled" @click="addRow()">
      添加
    </el-button>
    <ParamCheckDialog :rowData="currentRow" :formData.sync="currentRowParamCheck" :visible.sync="paramCheckDialogVisible" v-bind="$attrs" dialogTitle="参数校验设置" @confirm="paramCheckConfirm" />
  </el-form>
</template>

<script>
import ParamCheckDialog from '@/components/paramValidator'
import { Param, ParamCheck } from '../options/model'
import { mapActions } from 'vuex'
import { addNode, delNode } from '@/base_components/utils/uTableUtils'
import { code2Text, deepClone } from '@/utils'

let currentRow = {}
export default {
  components: { ParamCheckDialog },
  props: {
    type: {
      default: 'inParams',
      type: String
    },
    tableData: {
      default: () => [],
      type: Array
    },
    autoGenByServerApiId: {
      default: null,
      type: Number
    },
    mode: {
      type: String,
      default: 'add'
    },
    requestType: {
      type: Number,
      default: null
    }
  },
  data() {
    return {
      code2Text,
      formData: {},
      DataTypeEnum: [],
      DataPosEnum: [],
      treeConfig: { children: 'childrenList', expandAll: true },
      currentRowParamCheck: {},
      paramCheckDialogVisible: false,
      currentRow: {}
    }
  },
  async created() {
    [this.DataTypeEnum, this.DataPosEnum] = await this.getDicts([
      'DataTypeEnum',
      'DataPosEnum'
    ])
  },
  mounted() {
    this.$refs.uTable.reloadData(this.tableData)
  },
  computed: {
    // 通过接口直连生成的数据不允许修改参数
    disabled() {
      return !!this.autoGenByServerApiId || this.mode === 'snapshot'
    },
    // 是否允许设置body参数
    allowBody() {
      return this.requestType && this.requestType !== 1
    },
    dataTypeDisabled(_row) {
      // 默认为long，可编辑
      return this.mode === 'snapshot'
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    addnode(row) {
      const newRow = new Param()
      addNode({
        instance: this.$refs.uTable,
        sourceData: this.tableData,
        parentRow: row,
        newRow,
        rowId: 'rowKey',
        treeConfig: this.treeConfig
      })
    },
    delnode(row) {
      delNode({
        instance: this.$refs.uTable,
        row,
        sourceData: this.tableData,
        rowId: 'rowKey',
        treeConfig: this.treeConfig
      })
    },
    paramCheck(row) {
      currentRow = row
      this.currentRowParamCheck = deepClone(row.paramCheck) || new ParamCheck()
      this.currentRow = { ...row }
      this.paramCheckDialogVisible = true
    },
    paramCheckConfirm(row) {
      currentRow.paramCheck = row
      this.paramCheckDialogVisible = false
    },
    addRow(row) {
      const newRow = new Param()
      addNode({
        instance: this.$refs.uTable,
        sourceData: this.tableData,
        parentRow: row,
        newRow,
        rowId: 'rowKey',
        treeConfig: this.treeConfig
      })
    },
    deleteRow(row) {
      // const { parentList, idx } = this.findParentRow(this.formData.data, row)
      // parentList.splice(idx, 1)
      delNode({
        instance: this.$refs.uTable,
        row,
        sourceData: this.tableData,
        rowId: 'rowKey',
        treeConfig: this.treeConfig
      })
    },
    // 参数类型改变时，清空数组元素泛型和row.childrenList
    dataTypeChange(v, row) {
      row.generic = null
      row.value = null
      row.childrenList = []
    },
    genericChange(_v, _index, _row) {
      _row.childrenList = []
    },
    // 深度优先递归
    findParentRow(list, row) {
      let parentList = []
      let idx = null
      const length = list.length
      for (let i = 0; i < length; i++) {
        if (list[i] === row) {
          return { parentList: list, idx: i }
        }
        if (list[i].childrenList) {
          const res = this.findParentRow(list[i].childrenList, row)
          if (res) {
            parentList = res.parentList
            idx = res.idx
            return { parentList, idx }
          }
        }
      }
    }
  }
}
</script>

<style scoped lang="scss">
</style>
