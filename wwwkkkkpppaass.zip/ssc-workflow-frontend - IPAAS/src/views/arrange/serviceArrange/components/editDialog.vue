<template>
  <el-dialog :title="dialogTitle + 'API接口'" :visible.sync="visible" :beforeClose="handleCancel" width="90%">
    <EditForm :formData="formData" ref="editform" :rules="rules" />
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">取 消</el-button>
      <el-button type="primary" @click="handleConfirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { regExpRules, validateFn, validateTableTreeData } from '@/utils/validator'
import EditForm from './editForm'
export default {
  components: { EditForm },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    formData: {
      type: Object,
      default: () => ({})
    },
    dialogTitle: {
      type: String,
      default: '新增'
    },
    mode: {
      type: String,
      default: null
    }
  },
  watch: {
    visible(nV) {
      if (nV && this.$refs.editform) {
        this.$refs.editform.$refs.form.clearValidate()
      }
    }
  },
  data() {
    return {
      requestTypes: [],
      groupList: [],
      rules: {
        businessApiName: [
          { required: true, message: '请输入API接口名称', trigger: 'blur' },
          { max: 50, message: 'API接口名称长度不能超过50个字符', trigger: 'blur' }
        ],
        crossFlag: [
          { required: true, message: '请选择是否允许跨域', trigger: 'change' }
        ],
        webServiceFlag: [
          {
            required: true,
            validator: (rule, value, callback) => {
              if (value !== 2 && this.formData.httpFlag !== 2) callback(new Error('请选择协议类型'))
              callback()
            },
            message: '请选择协议类型',
            trigger: 'change'
          }
        ],
        httpFlag: [
          { required: true, message: '请选择协议类型', trigger: 'change' }
        ],
        requestType: [
          { required: true, message: '请选择请求方式', trigger: 'change' }
        ],
        requestUrl: [
          { required: true, message: '请输入请求URL', trigger: 'blur' },
          {
            pattern: regExpRules.startWithSlash,
            message: '必须以/开头',
            trigger: 'blur'
          }
        ],
        logLevel: [
          { required: true, message: '请选择日志等级', trigger: 'change' }
        ],
        groupId: [
          { required: true, message: '请选择服务分组', trigger: 'change' }
        ],
        apiAuthType: [
          { required: true, message: '请选择认证方式', trigger: 'change' }
        ],
        apiCacheTime: [
          { validator: validateFn.checkNum({ min: 0, max: 9999999, notNull: false }) }
        ],
        requestTimeout: [
          { required: true, message: '请设置超时时间', trigger: 'blur' },
          { validator: validateFn.checkNum({ min: 0, max: 999999, notNull: false }) }
        ],
        authId: [
          { required: true, message: '请设置前端自定义认证', trigger: 'change' }
        ]
      }
    }
  },
  methods: {
    validateOutparamRow(row, _isTop) {
      if (!row.paramName) {
        return [false, '参数名不能为空']
      }
      if (!row.dataType) {
        return [false, '参数类型不能为空']
      }
      if (row.dataType === 8 && !row.generic) {
        return [false, '参数类型为Array时，必须设置数组元素泛型']
      }
      return [true]
    },
    validateInparamRow(row, isTop) {
      if (!row.paramName) {
        return [false, '参数名不能为空']
      }
      if (!row.dataType) {
        return [false, '参数类型不能为空']
      }
      if (isTop && !row.dataPosition) {
        return [false, '参数位置不能为空']
      }
      if (row.dataType === 8 && !row.generic) {
        return [false, '参数类型为Array时，必须设置数组元素泛型']
      }
      return [true]
    },
    validateTreeTable(formData) {
      const [valid1, msg1, rowIndex1] = validateTableTreeData(formData.apiInParamList, this.validateInparamRow)
      if (!valid1) { this.$message.error(`请求参数-第${rowIndex1}行：${msg1}`) }
      const [valid2, msg2, rowIndex2] = validateTableTreeData(formData.apiOutParamList, this.validateOutparamRow)
      if (!valid2) { this.$message.error(`响应参数-第${rowIndex2}行：${msg2}`) }
      if (valid1 && valid2) { return true }
    },
    handleConfirm() {
      this.$refs.editform.handleConfirm().then(formData => {
        console.log('🚀 ~ file: editDialog.vue ~ line 137 ~ this.$refs.editform.handleConfirm ~ formData', formData)

        const resTableData = this.$refs.editform.$refs.paramlistRef.getMcUTableData()

        formData.apiInParamList = resTableData

        const valid = this.validateTreeTable(formData)

        if (!valid) return
        this.$emit('confirm', formData)
      })
    },
    handleCancel() {
      this.$emit('update:visible', false)
    }
  }
}
</script>

<style scoped lang="scss">
// .param-list{
//   max-height: 200px;
//   overflow: auto;
// }
</style>
