<template>
  <el-dialog :title="title" :visible.sync="visible" :width="width" :before-close="handleClose" append-to-body v-if="visible">
    <mc-form ref="form" :model="formData" :rules="rules">
      <mc-form-item componentType="ElSelect" prop="type" label="导入类型" dict="WorkflowShiftTypeEnum" :span="24"></mc-form-item>
      <mc-form-item componentType="ElInput" prop="file" label="文件" :span="24">
        <el-upload ref="upload" class="upload-demo" :auto-upload="false" drag action="#" :limit="1" accept=".json" :on-change="fileChange" :on-remove="onRemoveFile">
          <i class="el-icon-upload"></i>
          <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
          <div class="el-upload__tip" slot="tip">只能上传json文件</div>
        </el-upload>
      </mc-form-item>

    </mc-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" @click="confirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { mapActions } from 'vuex'
import Constant from '@/config/constant'
export default {
  props: {
    props: {
      default: () => ({}),
      type: Object
    },
    visible: {
      default: false,
      type: Boolean
    },
    title: {
      default: '导入业务接口',
      type: String
    },
    width: {
      default: '30%',
      type: String
    },
    formData: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      rules: {
        type: [
          { required: true, message: '请选择导入类型', trigger: 'change' }
        ],
        file: [
          { required: true, message: '请选择文件', trigger: 'change' }
        ]
      }
    }
  },
  watch: {
    visible(nV) {
      if (nV && this.$refs.form) {
        this.$refs.form.clearValidate()
        this.$refs.upload.clearFiles()
      }
    }
  },
  created() {
    this.getDicts(['WorkflowShiftTypeEnum'])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    fileChange(file, fileList) {
      this.formData.file = file.raw
    },
    onRemoveFile(file, fileList) {
      this.formData.file = null
    },
    handleClose(done) {
      this.$emit('update:visible', false)
    },
    submitUpload(file) {
      console.log('file', file)
    },
    confirm() {
      this.$refs.form.validate().then((valid) => {
        if (valid) {
          this.$emit('confirm', this.formData)
        } else {
          this.$message.error('请按照提示完善表单数据')
        }
      })
    }
  }
}
</script>

<style>
</style>
