<template>
  <el-dialog :title="dialogTitle" :visible.sync="visible" :beforeClose="handleCancel" width="500px">
    <div>
      <el-form ref="form" :model="formData" :rules="rules" labelWidth="120px">
        <el-form-item :label="apiNameName" prop="businessApiName">
          <el-input v-model="formData.businessApiName" :disabled="true" />
        </el-form-item>
        <el-row :gutter="10">
          <el-col :span="18">
            <el-form-item label="时长" prop="timeLen" disabled>
              <el-input v-model.number="formData.timeLen" type="number" />
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="" labelWidth="0" prop="timeType">
              <el-select v-model="formData.timeType" clearable>
                <el-option v-for="item in timeTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="接口流量限制" prop="count" disabled>
          <el-input v-model.number="formData.count" type="number" />
        </el-form-item>
      </el-form>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">取 消</el-button>
      <el-button type="primary" @click="handleConfirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { mapActions } from 'vuex'
import { validateFn } from '@/utils/validator'
export default {
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    formData: {
      type: Object,
      default: () => ({})
    },
    dialogTitle: {
      type: String,
      default: '新增'
    },
    apiNameName: {
      type: String,
      default: 'API接口名称'
    }
  },
  data() {
    return {
      timeTypeEnum: [],
      rules: {
        timeLen: [
          {
            validator: (rule, value, callback) => {
              if ((this.formData.timeType || this.formData.count) && !value) {
                callback(new Error('请填写时长'))
              }
              callback()
            },
            trigger: 'blur'
          },
          { validator: validateFn.checkNum({ max: 10000, notNull: false }), trigger: 'blur' }
        ],
        count: [
          {
            validator: (rule, value, callback) => {
              if ((this.formData.timeLen || this.formData.timeType) && !value) {
                callback(new Error('请填写接口流量限制'))
              }
              callback()
            },
            trigger: 'blur'
          },
          { validator: validateFn.checkNum({ max: 100000, notNull: false }), trigger: 'blur' }
        ],
        timeType: [
          {
            validator: (rule, value, callback) => {
              if ((this.formData.timeLen || this.formData.count) && !value) {
                callback(new Error('请选择时间类型'))
              }
              callback()
            },
            trigger: 'blur'
          }
        ]
      }
    }
  },
  async created() {
    this.timeTypeEnum = await this.getDicts('TimeTypeEnum')
  },
  watch: {},
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    handleConfirm() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          // this.visible = false
          this.$emit('confirm', this.formData)
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    handleCancel() {
      this.$emit('update:visible', false)
    }
  }
}
</script>

<style scoped lang="scss">
</style>
