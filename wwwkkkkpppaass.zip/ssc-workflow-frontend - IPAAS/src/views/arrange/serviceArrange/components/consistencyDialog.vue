<template>
  <el-dialog title="事务控制设置" :visible.sync="visible" :beforeClose="handleCancel" width="500px">
    <mc-form ref="form" :model="formData" :rules="rules">
      <mc-form-item componentType="ElSwitch" prop="isEnable" label="策略开关" :span="24" :editProps="{
        activeValue: 1,
        inactiveValue: 0,
        activeColor: '#13ce66',
        inactiveColor: '#ff4949'
      }"
      />
      <template v-if="formData.isEnable">
        <mc-form-item componentType="ElRadioGroup" prop="policy" label="策略" dict="ConsistencyPolicyEnum" :span="24" />
        <!-- 策略为3时不显示策略表达式 -->
        <mc-form-item label="阶梯表达式" :span="24" prop="ladderExpression" v-if="formData.policy === 1 || formData.policy === 2">
          <ladder-expression ref="ladderExpression" :data.sync="formData.ladderExpression" :uniqe="true" />
        </mc-form-item>
      </template>
    </mc-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">取 消</el-button>
      <el-button type="primary" @click="handleConfirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import LadderExpression from '@/components/ladder-expression'
import { regExpRules } from '@/utils/validator'
export default {
  components: { LadderExpression },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    formData: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      rules: {
        isEnable: [
          { required: true, message: '请选择策略开关', trigger: 'change' }
        ],
        policy: [
          { required: true, message: '请选择策略', trigger: 'change' }
        ],
        ladderExpression: [
          { required: true, message: '请输入阶梯表达式', trigger: 'blur' },
          { pattern: regExpRules.noChinese, message: '阶梯表达式不能包含中文', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    handleConfirm() {
      this.$refs.form.validate().then(async valid => {
        const ladderExpressionValid = await this.$refs.ladderExpression.validateForm()
        if (valid && ladderExpressionValid) {
          this.$emit('confirm', this.formData)
        } else {
          this.$message.error('请按照提示完善表单数据')
        }
      })
    },

    handleCancel() {
      this.$emit('update:visible', false)
    }
  }
}
</script>

<style scoped lang="scss">
.condition-box ::v-deep .el-form-item__content {
  display: flex;
  .text1 {
    display: block;
    min-width: 135px;
  }
  .text2 {
    display: block;
    min-width: 90px;
  }
}
</style>
