<template>
  <el-dialog title="熔断策略设置" :visible.sync="visible" :before-close="handleCancel" width="1200px">
    <el-form ref="form" :model="formData" :rules="rules" label-width="120px">
      <el-form-item label="启用熔断" prop="isEnable">
        <el-switch v-model="formData.isEnable" active-color="#13ce66" inactive-color="#ff4949" :active-value="1" :inactive-value="0"></el-switch>
      </el-form-item>
      <template v-if="formData.isEnable">
        <el-form-item label="熔断触发条件" class="condition-box">
          <el-form-item label="" label-width="0" prop="statIntervalMs">
            <el-input v-model.number="formData.statIntervalMs" :disabled="!formData.isEnable" type="number" placeholder="统计时长"></el-input><span class="text1">毫秒内接口请求次数超过</span>
          </el-form-item>
          <el-form-item label="" label-width="0" prop="minRequestAmount">
            <el-input v-model.number="formData.minRequestAmount" type="number" :disabled="!formData.isEnable" placeholder="最大请求数"></el-input><span class="text2">次且错误率大于</span>
          </el-form-item>
          <el-form-item label="" label-width="0" prop="count">
            <el-input v-model.number="formData.count" :disabled="!formData.isEnable" type="number" placeholder="异常比例0.0~1.0"></el-input>
          </el-form-item>
        </el-form-item>
        <el-form-item label="降级响应内容" prop="degradeResponseContext">
          <el-input v-model="formData.degradeResponseContext" type="textarea" :disabled="!formData.isEnable" :placeholder="placeholder.degradeResponseContext" :rows="5"></el-input>
        </el-form-item>
      </template>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">取 消</el-button>
      <el-button type="primary" @click="handleConfirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { mapActions } from 'vuex'
import { degrateDialogRules } from '../options/validator'
// import { regExpRules } from '@/utils'
export default {
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    formData: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      rules: degrateDialogRules(this)
    }
  },
  computed: {
    placeholder() {
      return {
        degradeResponseContext: `{
   "msg" : "接口熔断降级",
    "code" : 501
}`
      }
    }
  },
  async created() {
  },
  watch: {},
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    handleConfirm() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          // this.visible = false
          this.$emit('confirm', this.formData)
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    handleCancel() {
      this.$emit('update:visible', false)
    }
  }
}
</script>

<style scoped lang="scss">
.condition-box ::v-deep .el-form-item__content{
  display: flex;
  .text1{
    display: block;
    min-width: 135px;
  }
  .text2{
    display: block;
    min-width: 90px;
  }
}
</style>
