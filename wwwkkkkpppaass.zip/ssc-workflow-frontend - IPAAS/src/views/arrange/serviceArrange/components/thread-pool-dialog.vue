<template>
  <el-dialog :title="title" :visible.sync="visible" :width="width" :beforeClose="handleClose">
    <el-form :model="formData" labelWidth="80px" :rules="rules" ref="threadPoolForm">
      <el-form-item label="线程池名字">
        <el-select v-model="formData.poolName" placeholder="请选择线程池名字" @change="handleSelectChange">
          <el-option :label="item.poolName" :value="item.id" v-for="item in threadPoolSelectOpts" :key="item.id" />
        </el-select>
      </el-form-item>
      <el-form-item label="线程池名字" prop="poolName">
        <el-input v-model="formData.poolName" :disabled="isDisable" />
      </el-form-item>
      <el-form-item label="核心线程数" prop="corePoolSize">
        <el-input v-model="formData.corePoolSize" :disabled="isDisable" />
      </el-form-item>
      <el-form-item label="最大线程数" prop="maxPoolSize">
        <el-input v-model="formData.maxPoolSize" :disabled="isDisable" />
      </el-form-item>
      <el-form-item label="队列长度" prop="workQueueSize">
        <el-input v-model="formData.workQueueSize" :disabled="isDisable" />
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">关闭</el-button>
      <el-button type="primary" @click="handleSave">保存</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { isInteger } from '@/utils'
export default {
  name: 'ThreadPoolDialog',
  components: {
  },
  props: {
    visible: {
      default: false,
      type: Boolean
    },
    title: {
      default: '线程池设置',
      type: String
    },
    width: {
      default: '30%',
      type: String
    },
    threadPoolSelectOpts: {
      type: Array,
      default: () => []
    },
    threadPoolFormData: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      selectOpts: null,
      formData: {},
      isDisable: true,
      rules: {
        poolName: [
          { required: true, message: '请输入线程池名称', trigger: 'blur' },
          { min: 1, max: 8, message: '长度在 1 到 8 个字符', trigger: 'blur' }
        ],
        corePoolSize: [
          { required: true, message: '请选择核心线程数', trigger: 'blur' },
          { validator: isInteger, message: '请输入正整数', trigger: 'blur' }
        ],
        maxPoolSize: [
          { required: true, message: '请选择最大线程数', trigger: 'blur' },
          { validator: isInteger, message: '请输入正整数', trigger: 'blur' }
        ],
        workQueueSize: [
          { required: true, message: '请选择队列长度', trigger: 'blur' },
          { validator: isInteger, message: '请输入正整数', trigger: 'blur' }
        ]
      }
    }
  },
  mounted() {
    this.formData = this.threadPoolFormData
  },
  methods: {
    handleClose(done) {
      console.log('done', done)
      this.$emit('update:visible', false)
    },
    handleSave() {
      this.$refs.threadPoolForm.validate((valid) => {
        if (valid) {
          // this.visible = false
          this.$emit('confirm', this.formData)
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    handleSelectChange(value) {
      const selectedData = this.threadPoolSelectOpts.find(item => item.id === value)
      this.formData = { ...this.formData, ...selectedData }

      // 自定义设置允许填入
      value === -3 ? (this.isDisable = false) : (this.isDisable = true)
    }
  }
}
</script>

<style lang="scss" scoped>
.code-container {
  font-size: 12px;
  box-shadow: 4px 4px 4px #efefef;
  line-height: 20px;
  max-height: 150px;
  overflow: auto;

  ::v-deep .CodeMirror{
    height: 150px;
  }
}
.form-item-content {
  background: #fafafa;
  max-height: 200px;
  overflow: auto;
}
</style>
