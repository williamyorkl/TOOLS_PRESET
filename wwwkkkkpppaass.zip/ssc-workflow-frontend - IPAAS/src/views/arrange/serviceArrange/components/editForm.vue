<template>
  <el-form ref="form" :model="formData" :rules="rules" labelWidth="120px">
    <el-row :gutter="10">
      <el-col :span="12">
        <el-form-item label="API接口名称" prop="businessApiName">
          <el-input v-model.trim="formData.businessApiName" :disabled="isView" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="是否允许跨域 " prop="crossFlag">
          <el-radio-group v-model="formData.crossFlag" :disabled="isView">
            <el-radio :label="1">是</el-radio>
            <el-radio :label="0">否</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-col>
    </el-row>
    <el-row :gutter="10">
      <el-col :span="12">
        <el-form-item label="协议" prop="webServiceFlag">
          <el-checkbox v-model="formData.httpFlag" :trueLabel="2" :falseLabel="1" :disabled="isView" @change="httpFlagChange">Http</el-checkbox>
          <el-checkbox v-model="formData.webServiceFlag" :trueLabel="2" :falseLabel="1" :disabled="isView">
            WebService
          </el-checkbox>
          <template v-if="formData.webServiceFlag === 2">
            &nbsp;
            <el-tooltip class="item" effect="dark" :content="splicingWebServiceUrl" placement="top-start">
              <i class="el-icon-info" />
            </el-tooltip>
          </template>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="请求方式" prop="requestType" v-if="formData.httpFlag === 2">
          <el-select v-model="formData.requestType" placeholder="请求方式" @change="requestChange" :disabled="isView">
            <el-option v-for="item in requestTypes" :key="item.type" :label="item.desc" :value="item.type" />
          </el-select>
        </el-form-item>
      </el-col>
    </el-row>
    <el-row :gutter="10">
      <el-col :span="12">
        <el-form-item label="服务分组" prop="groupId">
          <el-select v-model="formData.groupId" placeholder="服务分组" @change="groupChange" clearable :disabled="isView">
            <el-option v-for="item in groupList" :key="item.id" :label="item.groupName" :value="item.id" />
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="集成应用" prop="integrationAppId">
          <mc-popover-select v-model="formData.integrationAppId" :defaultValue="formData.integrationAppName" :apiFunc="listIntergrationApp" :tableColumn="integrationColumn" :queryList="intergationQueryList" valueKey="id" labelKey="appName" @changeRow="changeRow" :disabled="isView" width="730" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-row :gutter="10">
      <el-col :span="12">
        <el-form-item label="BasePath" prop="baseUrl">
          <el-input v-model="formData.baseUrl" readonly :disabled="true" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="接口请求URL" prop="requestUrl">
          <el-input v-model.trim="formData.requestUrl" :disabled="isView" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="超时时间(ms)" prop="requestTimeout">
          <el-input type="number" v-model.number="formData.requestTimeout" :disabled="isView" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="缓存时间(s)" prop="apiCacheTime">
          <el-input type="number" v-model.number="formData.apiCacheTime" :disabled="isView" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="安全认证" prop="apiAuthType">
          <el-select v-model="formData.apiAuthType" placeholder="安全认证" clearable :disabled="isView">
            <el-option v-for="item in ApiAuthTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
          </el-select>
        </el-form-item>
        <el-form-item label="前端自定义认证" prop="authId" v-if="formData.apiAuthType == 3">
          <el-select v-model="formData.authId" placeholder="请选择">
            <el-option v-for="item in FrontEndAuthEnum" :key="item.id" :label="item.authName" :value="item.id" />
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="开发人员" prop="developer">
          <el-input v-model="formData.developer" :disabled="isView" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="日志等级" prop="logLevel">
          <el-radio-group v-model="formData.logLevel" :disabled="isView">
            <el-radio :label="1">info</el-radio>
            <el-radio :label="2">debug</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-col>
    </el-row>
    <el-form-item label="描述">
      <el-input type="textarea" v-model="formData.remark" :disabled="isView" />
    </el-form-item>
    <el-divider>请求参数</el-divider>
    <el-form-item>
      <el-tabs v-model="activeName" type="border-card">
        <el-tab-pane label="请求参数" name="params" :disabled="isView">
          <span slot="label">请求参数 <i class="el-icon-edit" @click="showJsonVisible('apiInParamList')" /></span>
          <ParamList class="param-list" type="inParams" :requestType="formData.requestType" :autoGenByServerApiId="formData.autoGenByServerApiId" :tableData="formData.apiInParamList" :mode="mode" :validateRowData="validateParamValidatorRowData" ref="paramlistRef" />
        </el-tab-pane>
      </el-tabs>
    </el-form-item>
    <el-divider>响应参数</el-divider>
    <el-form-item>
      <el-form-item>
        <el-tabs v-model="activeName" type="border-card">
          <el-tab-pane label="响应参数" name="params" :disabled="isView">
            <span slot="label">响应参数 <i class="el-icon-edit" @click="showJsonVisible('apiOutParamList')" /></span>
            <!-- <ParamList class="param-list" type="outParams" :autoGenByServerApiId="formData.autoGenByServerApiId" :tableData="formData.apiOutParamList" :mode="mode" /> -->
          </el-tab-pane>
        </el-tabs>
      </el-form-item>
    </el-form-item>
    <el-row :gutter="10">
      <el-col :span="12">
        <el-form-item prop="responseStructHeadId" label="响应码结构">
          <mc-popover-select v-model="formData.responseStructHeadId" :disabled="isView" :defaultValue="formData.responseStructHeadName" :apiFunc="apiFunc" :tableColumn="tableColumn" :queryList="queryList" labelKey="structName" valueKey="id" placeholder="不选择则为默认结构" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item prop="convertStructHeadId" label="转换结构">
          <mc-popover-select v-model="formData.convertStructHeadId" :disabled="isView" :defaultValue="formData.convertStructHeadName" :apiFunc="apiFunc" :tableColumn="tableColumn" :queryList="queryList" labelKey="structName" valueKey="id" placeholder="不选择则为默认结构" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <!-- <el-form-item prop="convertMsgFlag" label="是否翻译信息">
          <el-switch v-model="formData.convertMsgFlag" :disabled="isView" :activeValue="1" :inactiveValue="0" activeColor="#13ce66" inactiveColor="#ff4949" />
        </el-form-item> -->
      </el-col>
    </el-row>
    <jsonAutoResolveDialog :visible.sync="jsonDialogVisible" :originalParamList="originalParamList" :requestType="formData.requestType" :type="currentJsonKey" @confirm="confirmJsonData" width="70%" v-if="jsonDialogVisible" />
  </el-form>
</template>

<script>
import groupApi from '@/api/arrange'
import ParamList from './paramList'
import { mapActions } from 'vuex'
import { matchPathParams, recursionList, formatterUrlToWebService } from '@/utils'
import { Param } from '../options/model'
import integrationApi from '@/api/arrange/integration'
import { getTableColumn, getQueryList } from '@/config/popContentTableConfig/integration.config'
import jsonAutoResolveDialog from '@/components/jsonAutoResolveDialog'

import resStructApi from '@/api/platformConfig/resStruct'
import { getTableColumn as getResStructTableColumn, getQueryList as getResStructQueryList } from '@/config/popContentTableConfig/resStruct.config'

import authApi from '@/api/serviceStatement/auth'

export default {
  components: { ParamList, jsonAutoResolveDialog },
  props: {
    formData: {
      type: Object,
      default: () => ({})
    },
    rules: {
      type: Object,
      default: () => ({})
    },
    mode: {
      type: String,
      default: 'edit'
    }
  },
  data() {
    return {
      groupList: [],
      requestTypes: [],
      ApiAuthTypeEnum: [],
      FrontEndAuthEnum: [],
      listIntergrationApp: integrationApi.listIntergrationApp,
      integrationColumn: getTableColumn(),
      intergationQueryList: getQueryList(),
      apiFunc: resStructApi.listResStruct,
      tableColumn: getResStructTableColumn(),
      queryList: [],
      jsonDialogVisible: false,
      activeName: 'params',
      currentJsonKey: null,
      originalParamList: [],
      lazyRender: false
    }
  },
  watch: {
    'formData.requestUrl': {
      handler: function(nV) {
        const apiInParamList = this.formData.apiInParamList.filter(item => item.dataPosition !== 1)
        const pathParamList = this.reloadRequestUrlParam(nV)
        this.formData.apiInParamList = [...pathParamList, ...apiInParamList]
      }
    }
  },
  computed: {
    isView() {
      return this.mode === 'snapshot'
    },
    splicingWebServiceUrl() {
      if (this.formData.webServiceFlag !== 2) {
        return null
      } else {
        console.log('🚀 ~ file: editForm.vue ~ line 204 ~ splicingWebServiceUrl ~ this.formData', this.formData)

        let baseUrl = this.formData.baseUrl || ''
        let requestUrl = this.formData.requestUrl || ''
        if (baseUrl) {
          baseUrl = formatterUrlToWebService(baseUrl)
        }
        if (requestUrl) {
          requestUrl = formatterUrlToWebService(requestUrl)
        }
        return `${baseUrl}${requestUrl}?wsdl`
      }
    }
  },
  async created() {
    [this.requestTypes, this.ApiAuthTypeEnum, this.ApiAuthGroupEnum] = await this.getDicts(['MethodTypeEnum', 'ApiAuthTypeEnum', 'ApiAuthGroupEnum'])
    const [TrueFalseEnum] = await this.getDicts(['TrueFalseEnum'])

    this.getFrontEndAuthEnum()

    this.queryList = getResStructQueryList({ TrueFalseEnum })
    this.groupList = await this.getGroupList()
  },
  mounted() {
    setTimeout(() => {
      this.lazyRender = true
    }, 300)
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    validateParamValidatorRowData(row) {
      // 检测参数校验选中的接口是否是原接口
      if (row.id === this.formData.id) {
        return '不能选择原接口'
      } else {
        return 'RESOLVE'
      }
    },
    changeRow(row) {
      this.formData.integrationAppName = row.appName
    },
    httpFlagChange(v) {
      if (v === 1) {
        this.formData.requestType = 1
      }
    },
    async getGroupList() {
      return await groupApi.listGroupCtrl()
    },
    // requestUrl变化时，重刷inParamList中参数位置是path的行
    reloadRequestUrlParam(url) {
      const paramList = []
      const res = matchPathParams(url)
      if (res) {
        res.forEach((item, index) => {
          paramList.push({ ...new Param(), dataPosition: 1, paramName: item, dataType: 2, rowKey: Date.now() + index })
        })
      }
      return paramList
    },
    groupChange(v) {
      if (!v) {
        this.formData.baseUrl = null
      } else {
        const group = this.groupList.find((item) => item.id === v) || {}
        this.formData.baseUrl = group.baseUrl
      }
    },
    setNull(row) {
      if (row && row.dataPosition === 4) {
        this.$set(row, 'dataPosition', null)
      }
    },
    requestChange(v) {
      if (v === 1) {
        recursionList(this.formData.apiInParamList, this.setNull)
      }
    },

    handleConfirm() {
      return new Promise((resolve) => {
        this.$refs.form.validate((valid) => {
          if (valid) {
            resolve(this.formData)
          } else {
            this.$message.error('请按照提示完善表单数据')
            console.log('error submit!!')
            return false
          }
        })
      })
    },
    confirmJsonData(data) {
      this.formData[this.currentJsonKey] = data
      this.jsonDialogVisible = false
    },
    showJsonVisible(key) {
      if (this.isView) return
      this.currentJsonKey = key
      this.originalParamList = this.formData[key]
      this.jsonDialogVisible = true
    },
    async getFrontEndAuthEnum() {
      this.listLoading = true
      // TODO - 待实际接口确定
      const params = {
        // 类型: 前端
        authGroup: 1,
        // 认证方式: 自定义认证
        authType: 2
      }
      authApi
        .listAuth(params)
        .then((response) => {
          this.FrontEndAuthEnum = response.records || []
        })
        .catch(() => {
          this.FrontEndAuthEnum = []
        })
    }
  }
}
</script>

<style scoped>
.lazy-render-wrap{
  min-height: 300px;
}
</style>
