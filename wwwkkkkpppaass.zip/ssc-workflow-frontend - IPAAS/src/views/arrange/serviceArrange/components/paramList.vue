<template>
  <mc-u-table :data.sync="tableData" ref="McUTable" size="mini" rowId="rowKey" :height="300" :treeConfig="{children: 'childrenList'}" @addRow="addRow">
    <mc-u-table-column
      type="index"
      :tableData="tableData"
      :columnProps="{
        treeNode: true,
        label: '序号',
        width: 100
      }"
    /><mc-u-table-column
      type="ElInput"
      :tableData="tableData"
      :columnProps="{
        prop: 'paramName',
        label: '参数名称',
        minWidth: 100
      }"
      :formProps="({row}) => ({
        disabled: disabled
      })"
    />
    <mc-u-table-column
      type="McSelect"
      :tableData="tableData"
      :columnProps="{
        prop: 'dataType',
        label: '参数类型',
        minWidth: 120
      }"
      :formItemProps="{}"
      :formProps="({row}) => ({
        options: DataTypeEnum,
        labelKey: 'desc',
        valueKey: 'type',
        disabled: disabled
      })"
      :formEvents="{
        change: dataTypeChange
      }"
    />
    <mc-u-table-column
      v-if="type === 'inParams'"
      :tableData="tableData"
      type="McSelect"
      :columnProps="{
        prop: 'dataPosition',
        label: '参数位置',
        minWidth: 120
      }"
      :formItemProps="{}"
      :formProps="({row}) => ({
        options: DataPosEnum,
        optionItemDisabled: item => item.type === 1 || (item.type === 4 && !allowBody),
        labelKey: 'desc',
        valueKey: 'type',
        disabled: row.dataPosition === 1 || mode === 'snapshot'
      })"
    />
    <mc-u-table-column
      v-if="type === 'inParams'"
      type="ElSwitch"
      :tableData="tableData"
      :columnProps="{
        prop: 'isRequired',
        label: '是否必填',
        minWidth: 120,
      }"
      :formItemProps="{}"
      :formProps="({row}) => ({
        disabled: disabled
      })"
    />
    <mc-u-table-column
      type="McInput"
      :tableData="tableData"
      :columnProps="{
        prop: 'value',
        label: '默认值',
        minWidth: 120,
      }"
      :formItemProps="{
        prop: 'value',
        rules:[{ required: true, message: '选择填写字段', trigger: 'blur' }]
      }"
      :formProps="({row}) => ({
        dataType: row.dataType,
        disabled: disabled,
        trim: false
      })"
    />
    <mc-u-table-column
      type="McSelect"
      :tableData="tableData"
      :columnProps="{
        prop: 'generic',
        label: '数组元素泛型',
        minWidth: 120
      }"
      :formItemProps="{}"
      :formProps="({row}) => ({
        options: DataTypeEnum,
        labelKey: 'desc',
        valueKey: 'type',
        disabled: row.dataType !== 8 || disabled,
      })"
      :formEvents="{
        change: genericChange
      }"
    />
    <mc-u-table-column
      type="ElInput"
      :tableData="tableData"
      :columnProps="{
        prop: 'description',
        label: '描述',
        minWidth: 200
      }"
      :formItemProps="{}"
      :formProps="({row}) => ({
        disabled: disabled
      })"
    />
    <mc-u-table-column
      type="operate"
      :tableData="tableData"
      :columnProps="{
        label: '操作',
        minWidth: 220,
        fixed: 'right'
      }"
      :btnList="btnList"
    />
    <ParamCheckDialog :rowData="currentRow" :formData.sync="currentRowParamCheck" :visible.sync="paramCheckDialogVisible" v-bind="$attrs" dialogTitle="参数校验设置" @confirm="paramCheckConfirm" />
  </mc-u-table>
</template>

<script>
import ParamCheckDialog from '@/components/paramValidator'
import { Param, ParamCheck } from '../options/model'
import { mapActions } from 'vuex'
import { addNode, delNode } from '@/base_components/utils/uTableUtils'
import { code2Text, deepClone } from '@/utils'

let currentRow = {}
export default {
  components: { ParamCheckDialog },
  props: {
    type: {
      default: 'inParams',
      type: String
    },
    tableData: {
      default: () => [],
      type: Array
    },
    autoGenByServerApiId: {
      default: null,
      type: Number
    },
    mode: {
      type: String,
      default: 'add'
    },
    requestType: {
      type: Number,
      default: null
    }
  },
  data() {
    return {
      code2Text,
      formData: {},
      DataTypeEnum: [],
      DataPosEnum: [],
      treeConfig: { children: 'childrenList', expandAll: true },
      currentRowParamCheck: {},
      paramCheckDialogVisible: false,
      currentRow: {},
      btnList: [
        {
          title: '添加',
          type: 'text',
          event: (row) => {
            const newRow = new Param()
            this.$refs.McUTable.addnode(row, newRow)
          },
          disabled: (row) => {
            console.log('row', row)
            return !(row.dataType === 7 || (row.dataType === 8 && row.generic === 7)) || this.disabled
          }
        },
        {
          title: '校验',
          type: 'text',
          event: (row) => this.paramCheck(row),
          disabled: this.disabled
        },
        {
          title: '删除',
          type: 'text',
          event: (row) => {
            this.$refs.McUTable.delnode(row)
          }
        }
      ]
    }
  },
  async created() {
    [this.DataTypeEnum, this.DataPosEnum] = await this.getDicts([
      'DataTypeEnum',
      'DataPosEnum'
    ])
  },
  mounted() {
    // this.$refs.uTable.reloadData(this.tableData)
  },
  computed: {
    // 通过接口直连生成的数据不允许修改参数
    disabled() {
      return !!this.autoGenByServerApiId || this.mode === 'snapshot'
    },
    // 是否允许设置body参数
    allowBody() {
      return this.requestType && this.requestType !== 1
    },
    dataTypeDisabled(_row) {
      // 默认为long，可编辑
      return this.mode === 'snapshot'
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    getMcUTableData() {
      return this.$refs.McUTable.getTableData()
    },
    addRow(list) {
      const newRow = new Param()
      this.$refs.McUTable.addnode(list, newRow)
    },
    addnode(row) {
      const newRow = new Param()
      addNode({
        instance: this.$refs.uTable,
        sourceData: this.tableData,
        parentRow: row,
        newRow,
        rowId: 'rowKey',
        treeConfig: this.treeConfig
      })
    },
    delnode(row) {
      delNode({
        instance: this.$refs.uTable,
        row,
        sourceData: this.tableData,
        rowId: 'rowKey',
        treeConfig: this.treeConfig
      })
    },
    paramCheck(row) {
      console.log('🚀 ~ file: paramList.vue ~ line 258 ~ paramCheck ~ row', row)

      currentRow = row
      this.currentRowParamCheck = deepClone(row.paramCheck) || new ParamCheck()
      this.currentRow = { ...row }
      this.paramCheckDialogVisible = true
    },
    paramCheckConfirm(row) {
      currentRow.paramCheck = row
      this.paramCheckDialogVisible = false
    },
    deleteRow(row) {
      // const { parentList, idx } = this.findParentRow(this.formData.data, row)
      // parentList.splice(idx, 1)
      delNode({
        instance: this.$refs.uTable,
        row,
        sourceData: this.tableData,
        rowId: 'rowKey',
        treeConfig: this.treeConfig
      })
    },
    // 参数类型改变时，清空数组元素泛型和row.childrenList
    dataTypeChange(v, { row }) {
      row.generic = null
      row.value = null
      row.childrenList = []
    },
    genericChange(_v, { row }) {
      row.childrenList = []
      console.log(row)
      console.log(this.tableData)
      // this.$refs.McUTable.reloadData()
    },
    // 深度优先递归
    findParentRow(list, row) {
      let parentList = []
      let idx = null
      const length = list.length
      for (let i = 0; i < length; i++) {
        if (list[i] === row) {
          return { parentList: list, idx: i }
        }
        if (list[i].childrenList) {
          const res = this.findParentRow(list[i].childrenList, row)
          if (res) {
            parentList = res.parentList
            idx = res.idx
            return { parentList, idx }
          }
        }
      }
    }
  }
}
</script>

<style scoped lang="scss">
</style>
