<template>
  <el-dialog title="同步用户接口" :visible.sync="visible" :before-close="handleCancel" width="200" v-if="visible">
    <mc-form ref="form" :model="formData" :rules="rules">
      <mc-form-item componentType="McPopoverSelect" prop="registerId" label="注册中心" @changeRow="registerIdChange" :span="24" :editProps="{
        defaultValue: formData.registryName,
        apiFunc: registryListApiFunc,
        tableColumn: registryTableColumn,
        queryList: registryQueryList,
        labelKey: 'name',
      }"></mc-form-item>
      <mc-form-item componentType="ElSelect" prop="applicationName" label="应用名称" :dict="srvList" :editProps="{allowCreate: true,filterable: true, placeholder: '请选择或直接输入应用名称', clearable: true}" :span="24"></mc-form-item>
      <mc-form-item componentType="ElInput" prop="packagePath" label="包名" :span="24"></mc-form-item>
      <mc-form-item :display="true" label="协议" :span="24" :defaultValue="'dubbo'" :editProps="{value: 'dubbo'}">
        <el-input value="dubbo" disabled></el-input>
      </mc-form-item>
    </mc-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">取 消</el-button>
      <el-button type="primary" @click="handleConfirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { mapActions } from 'vuex'
import arrangeApi from '@/api/arrange'
import registryApi from '@/api/interface/registry'
import { getTableColumn as getRegistryTableColumn, getQueryList as getRegistryQueryList } from '@/config/popContentTableConfig/registry.config'

const resetFormData = {
  applicationName: null,
  namespace: null,
  registryAddress: null,
  registryType: null
}
export default {
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    dialogTitle: {
      type: String,
      default: '新增'
    }
  },
  watch: {
    'formData.registerId': {
      async handler(nV) {
        if (!nV) {
          this.srvList = []
        } else {
          this.srvList = await this.getSrvList(nV)
        }
      },
      immediate: true
    }
  },
  data() {
    return {
      srvList: [],
      registryTableColumn: getRegistryTableColumn(),
      registryQueryList: getRegistryQueryList(),
      registryListApiFunc: registryApi.getRegistryList,
      rules: {
        applicationName: [
          { required: true, message: '请选择应用名称', trigger: 'change' }
        ],
        registerId: [
          { required: true, message: '请选择注册中心', trigger: 'change' }
        ]
      },
      formData: {}
    }
  },
  async created() {
    this.formData = { ...resetFormData }
    await this.getDicts('RegistryTypeEnum')
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    registerIdChange(row) {
      this.formData.applicationName = ''
    },
    async getSrvList(id) {
      const resp = await registryApi.serviceList({ id }) || []
      return resp.map(item => ({ desc: item, type: item }))
    },
    handleConfirm() {
      this.$refs.form.validate().then(async valid => {
        if (valid) {
          await arrangeApi.syncController(this.formData)
          this.$message.success('同步成功')
          this.formData = resetFormData
          this.$emit('update:visible', false)
        } else {
          this.$message.error('请按照提示完善表单数据')
        }
      })
    },
    handleCancel() {
      this.$emit('update:visible', false)
    }
  }
}
</script>

<style scoped lang="scss">
// .param-list{
//   max-height: 200px;
//   overflow: auto;
// }
</style>
