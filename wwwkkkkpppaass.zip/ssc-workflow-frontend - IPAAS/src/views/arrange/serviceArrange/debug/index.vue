<template>
  <div class="common-container">
    <div class="apply-content">
      <ApiForm :formData="formData" ref="apiform" :rules="rules" @send="sendApi" @mockData="mockData" style="padding-top: 16px" />
      <el-divider>响应数据</el-divider>
      <div class="response">
        <div v-if="!isEmptyObj(response)">
          <p style="line-height: 32px; font-size: 14px">
            响应码:<span>{{ response.status }}</span>
            <span style="margin-left: 16px">耗时:</span><span>{{ response.duration }}</span> ms
          </p>
          <p class="api-detail-text" style="line-height: 32px; font-size: 14px">
            接口请求URL: {{ response.request.responseURL || '' }}
          </p>
        </div>

        <el-tabs v-model="activeName" type="border-card">
          <div class="flex-between">
            <el-radio-group v-model="radio">
              <el-radio label="text">text</el-radio>
              <el-radio label="json">json</el-radio>
            </el-radio-group>
            <el-button type="text" @click="linkLog" v-if="response.headers && response.headers.traceid">查看运行日志</el-button>
          </div>
          <el-tab-pane label="响应体" name="responseBody">
            <json-viewer
              v-if="radio == 'json'"
              :value="jsonData"
              :expandDepth="5"
              copyable
              boxed
              sort
            />
            <el-input
              v-else
              type="textarea"
              :rows="5"
              placeholder=""
              v-model="textData"
            />
          </el-tab-pane>
          <el-tab-pane label="响应头" name="responseHeader">
            <json-viewer
              v-if="radio == 'json'"
              :value="jsonHeader"
              :expandDepth="5"
              copyable
              boxed
              sort
            />
            <el-input
              v-else
              type="textarea"
              :rows="5"
              placeholder=""
              v-model="textHeader"
            />
          </el-tab-pane>
        </el-tabs>
      </div>
    </div>
  </div>
</template>

<script>
import { Param } from '../options/model'
import arrangeApi from '@/api/arrange'
import { mapActions } from 'vuex'
import fetch from 'api/fetch.js'
import { isNull } from '@/utils'
import { regExpRules, validateTableTreeData } from '@/utils/validator'
import ApiForm from './apiForm'
export default {
  name: 'Debug',
  components: { ApiForm },
  data() {
    return {
      requestTypes: [],
      groupList: [],
      rules: {
        businessApiName: [
          { required: true, message: '请输入API接口名称', trigger: 'blur' }
        ],
        requestType: [
          { required: true, message: '请选择请求方式', trigger: 'change' }
        ],
        // baseUrl: [
        //   { pattern: regExpRules.startWithSlash, message: '必须以/开头', trigger: 'blur' }
        // ],
        requestUrl: [
          { required: true, message: '请输入接口请求URL', trigger: 'blur' },
          {
            pattern: regExpRules.startWithSlash,
            message: '必须以/开头',
            trigger: 'blur'
          }
        ],
        groupId: [
          { required: true, message: '请选择服务分组', trigger: 'change' }
        ],
        apiAuthType: [
          { required: true, message: '请选择认证方式', trigger: 'change' }
        ]
      },
      formData: {},
      radio: 'json',
      response: {},
      activeName: 'responseBody'
    }
  },
  async created() {
    this.id = this.$route.query.id;
    [this.requestTypes] = await this.getDicts(['MethodTypeEnum'])
    const formData = await arrangeApi.detailArrange({ definitionId: this.id })
    // 初始化一下每一行的对象，双向绑定
    const apiInParamList = formData.apiInParamList.map(item => ({ ...new Param(), ...item }))
    const apiOutParamList = formData.apiOutParamList.map(item => ({ ...new Param(), ...item }))
    this.formData = { ...formData, apiInParamList, apiOutParamList }
  },
  computed: {
    jsonData() {
      return this.response.data ? this.response.data : ''
    },
    textData() {
      return this.response.data ? JSON.stringify(this.response.data) : ''
    },
    jsonHeader() {
      return this.response.headers ? this.response.headers : ''
    },
    textHeader() {
      return this.response.headers ? JSON.stringify(this.response.headers) : ''
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    /* validateOutparamRow(row, isTop) {
      if (!row.paramName) {
        return [false, '参数名不能为空']
      }
      if (!row.dataType) {
        return [false, '参数类型不能为空']
      }
      if (row.dataType == 8 && !row.generic) {
        return [false, '参数类型为Array时，必须设置数组元素泛型']
      }
      return [true]
    }, */
    validateInparamRow(row, isTop) {
      if (!row.paramName) {
        return [false, '参数名不能为空']
      }
      if (!row.dataType) {
        return [false, '参数类型不能为空']
      }
      if (isTop && !row.dataPosition) {
        return [false, '参数位置不能为空']
      }
      // 非对象或数组  &&  必填   && row.value !== undefined
      if (![7, 8].includes(row.dataType) && row.isRequired && isNull(row.value)) {
        return [false, '参数值不能为空']
      }
      if (row.dataType === 8 && !row.generic) {
        return [false, '参数类型为Array时，必须设置数组元素泛型']
      }
      return [true]
    },
    validateTreeTable(formData) {
      const [valid1, msg1, rowIndex1] = validateTableTreeData(formData.apiInParamList, this.validateInparamRow)
      if (!valid1) { this.$message.error(`请求参数-第${rowIndex1}行：${msg1}`) }
      // const [valid2, msg2, rowIndex2] = validateTableTreeData(formData.apiOutParamList, this.validateOutparamRow)
      // if (!valid2) { this.$message.error(`响应参数-第${rowIndex2}行：${msg2}`) }
      if (valid1) { return true }
    },
    async mockData() {
      const apiList = await arrangeApi.mockDebuggerData({ definitionId: this.formData.id })
      this.formData.apiInParamList = apiList
    },
    sendApi() {
      const valid = this.validateTreeTable(this.formData)
      if (!valid) return
      const obj = this.requestTypes.find(item => {
        return item.type === this.formData.requestType
      })
      let url = (this.formData.baseUrl === '/' ? '' : this.formData.baseUrl) + this.formData.requestUrl
      const method = obj.desc
      const query = {}
      const postData = {}
      const headers = {}
      this.formData.apiInParamList.forEach(item => {
        console.log(item)
        switch (item.dataPosition) {
          case 1:
            // 需要将requestUrl中的{a}替换为对应的值
            // url = url + 'item.value'
            url = url.replace(`{${item.paramName}}`, item.value)
            break
          case 2:
            this.resolveReqData(item, query)
            // query[item.paramName] = item.value
            break
          case 3:
            // headers[item.paramName] = item.value
            this.resolveReqData(item, headers)
            break
          case 4:
            // postData[item.paramName] = item.value
            this.resolveReqData(item, postData)
            break
        }
      })
      const fetchOptions = { url, headers, method, data: postData, params: query, apiDebug: true, timeout: 120000 }
      fetch(fetchOptions).then(res => {
        this.response = res
      }).catch(err => {
        if (!err.response) {
          // 请求超时
          this.response = {
            request: { responseURL: fetchOptions.url }, status: '请求超时', duration: '--'
          }
        } else {
          this.response = err.response
          this.$message.error(`请求出错，状态码:${this.response.status}`)
        }
      })
    },
    linkLog() {
      const isEmpty = this.isEmptyObj(this.response)
      if (!isEmpty) {
        this.$router.push({
          name: 'GatewayLog',
          query: {
            id: this.response.headers.traceid
          }
        })
      }
    },
    // 解析树形列表的数据
    resolveReqData(row, reqObj) {
      reqObj[row.paramName] = row.value
      // 对数组和对象，
      if ((row.dataType === 8 && row.generic === 7)) {
        const subRow = {}
        reqObj[row.paramName] = [subRow];
        (row.childrenList || []).forEach(item => {
          this.resolveReqData(item, subRow)
        })
      } else if (row.dataType === 7) {
        const subRow = {}
        reqObj[row.paramName] = subRow;
        (row.childrenList || []).forEach(item => {
          this.resolveReqData(item, subRow)
        })
      }
    },
    isEmptyObj(obj) {
      if (obj && typeof obj === 'object') {
        return Object.keys(obj).length === 0
      }
      return true
    }
  }
}
</script>

<style scoped lang="scss">
.response {
  margin-left: 120px;
}
.flex-between {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.api-detail-text{
  word-wrap: break-word;
  word-break: break-all;
}
</style>
