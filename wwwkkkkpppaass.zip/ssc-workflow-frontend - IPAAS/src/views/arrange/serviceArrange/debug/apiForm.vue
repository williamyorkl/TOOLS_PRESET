<template>
  <el-form ref="form" :model="formData" :rules="rules" labelWidth="120px">
    <el-form-item label="API接口名称" prop="businessApiName">
      <el-input v-model="formData.businessApiName" disabled />
    </el-form-item>
    <el-form-item label="请求方式" prop="requestType">
      <el-select v-model="formData.requestType" placeholder="请求方式" disabled>
        <el-option v-for="item in requestTypes" :key="item.type" :label="item.desc" :value="item.type" />
      </el-select>
    </el-form-item>
    <el-form-item label="路径" prop="baseUrl">
      <el-row>
        <el-col :span="18">
          <el-input v-model="fullPath" readonly :disabled="true" />
        </el-col>
        <el-col :span="6" style="padding-left: 16px">
          <el-button type="primary" @click="mockData">构造数据</el-button>
          <el-button type="primary" @click="send">发送</el-button>
        </el-col>
      </el-row>
    </el-form-item>
    <el-divider>请求参数</el-divider>
    <el-form-item>
      <ApiParamList class="param-list" type="inParams" :requestType="formData.requestType" :autoGenByServerApiId="formData.autoGenByServerApiId" :tableData="formData.apiInParamList" :mode="mode" />
    </el-form-item>
    <!-- <el-divider>请求头</el-divider>
      <el-form-item>
        <ParamList class="param-list" type="outParams" :autoGenByServerApiId="formData.autoGenByServerApiId" :tableData="formData.apiOutParamList" :mode="mode" />
      </el-form-item> -->
  </el-form>
</template>

<script>
import groupApi from '@/api/arrange'
import ApiParamList from './apiParamList'
import { mapActions } from 'vuex'
export default {
  components: { ApiParamList },
  props: {
    formData: {
      type: Object,
      default: () => ({})
    },
    rules: {
      type: Object,
      default: () => ({})
    },
    mode: {
      type: String,
      default: 'edit'
    }
  },
  data() {
    return {
      groupList: [],
      requestTypes: [],
      ApiAuthTypeEnum: []
    }
  },
  watch: {
    // 'formData.requestUrl': {
    // handler: function(nV) {
    // const apiInParamList = this.formData.apiInParamList.filter(item => item.dataPosition !== 1)
    // const pathParamList = this.reloadRequestUrlParam(nV)
    // this.formData.apiInParamList = [...pathParamList, ...apiInParamList]
    // console.log(JSON.stringify(this.formData.apiInParamList, null, 2))
    // }
    // }
  },
  computed: {
    isView() {
      return this.mode === 'snapshot'
    },
    fullPath() {
      return (this.formData.baseUrl === '/' ? '' : this.formData.baseUrl) + this.formData.requestUrl
    }
  },
  async created() {
    [this.requestTypes, this.ApiAuthTypeEnum] = await this.getDicts(['MethodTypeEnum', 'ApiAuthTypeEnum'])
    this.groupList = await this.getGroupList()
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    async getGroupList() {
      return await groupApi.listGroupCtrl()
    },
    // requestUrl变化时，重刷inParamList中参数位置是path的行
    // reloadRequestUrlParam(url) {
    //   const paramList = []
    //   const res = matchPathParams(url)
    //   if (res) {
    //     res.forEach((item, index) => {
    //       paramList.push({ ...new Param(), dataPosition: 1, paramName: item, rowKey: Date.now() + index })
    //     })
    //   }
    //   return paramList
    // },
    groupChange(v) {
      if (!v) {
        this.formData.baseUrl = null
      } else {
        const group = this.groupList.find((item) => item.id === v) || {}
        this.formData.baseUrl = group.baseUrl
      }
    },
    handleConfirm() {
      return new Promise((resolve) => {
        this.$refs.form.validate((valid) => {
          if (valid) {
            resolve(this.formData)
          } else {
            this.$message.error('请按照提示完善表单数据')
            console.log('error submit!!')
            return false
          }
        })
      })
    },
    mockData() {
      this.$emit('mockData')
    },
    send() {
      this.$emit('send')
    }
  }
}
</script>

<style>

</style>
