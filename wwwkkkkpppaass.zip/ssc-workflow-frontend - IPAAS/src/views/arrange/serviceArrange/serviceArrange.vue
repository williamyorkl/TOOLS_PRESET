<template>
  <div class="common-container">
    <div class="apply-content">
      <mc-query ref="querybar" :queryList="queryList" @query="handleFilter" />
      <div class="common-btns-container">
        <el-button type="primary" @click="add">新增</el-button>
        <el-button @click="syncApi">同步API接口</el-button>
        <el-button @click="handleImportSw">导入swagger</el-button>
      </div>
      <div class="common-table-container" v-loading="listLoading">
        <mc-table :tableData="tableData" :tableColumn="tableColumn">
          <template #operate="scope">
            <div>
              <el-button type="text" size="mini" @click="edit(scope.row)">编辑</el-button>
              <el-button type="text" size="mini" @click="limit(scope.row)">限流</el-button>
              <el-button type="text" size="mini" @click="arrange(scope.row)">编排</el-button>
              <el-dropdown class="more-btn" @command="handleCommand($event, scope.row)">
                <el-button type="text" size="mini">更多<i class="el-icon-arrow-down el-icon--right" /></el-button>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item command="VIEW">详情</el-dropdown-item>
                  <!-- 已上线才可调试 -->
                  <el-dropdown-item command="DEBUG" v-if="scope.row.status === 1">调试</el-dropdown-item>
                  <el-dropdown-item command="DEGRADE">熔断策略</el-dropdown-item>
                  <el-dropdown-item command="THREAD_POOL">线程池设置</el-dropdown-item>
                  <el-dropdown-item command="OFFLINE">{{ (StatusEnum[scope.row.status] || {operateBtn: '发布'}).operateBtn }}</el-dropdown-item>
                  <!-- 已上线才可授权 -->
                  <el-dropdown-item command="GRANT" v-if="scope.row.status === 1">授权</el-dropdown-item>
                  <el-dropdown-item command="CONSISTENCY">事务控制</el-dropdown-item>
                  <el-dropdown-item command="OPERATE_LOG">操作日志</el-dropdown-item>
                  <el-dropdown-item command="CREATE_TPL">生成模板</el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </div>
          </template>
        </mc-table>
      </div>
      <div class="pagination-container">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :currentPage.sync="pageIndex" :pageSizes="[10, 20, 50, 100]" :pageSize="10" layout="total, sizes, prev, pager, next, jumper" :total="recordCount" background />
      </div>
    </div>
    <!-- 编排日志 -->
    <ArrangeLog :definitionId="currentDefinetionId" :visible.sync="logDialogVisible" v-if="logDialogVisible" :dialogTitle="dialogTitle" @handleViewLog="handleViewLog" />
    <EditDialog :formData.sync="formData" :visible.sync="editDialogVisible" v-if="editDialogVisible" :dialogTitle="dialogTitle" @confirm="submitForm" />
    <LimitDialog :formData.sync="formData" :visible.sync="limitDialogVisible" v-if="limitDialogVisible" :dialogTitle="dialogTitle" @confirm="submitLimitForm" />
    <DegradeDialog :formData.sync="formData" :visible.sync="degradeDialogVisible" @confirm="submitDegrateForm" />

    <ThreadPoolDialog :formData.sync="formData" :visible.sync="threadPoolDialogVisible" @confirm="submitThreadPoolForm" :threadPoolFormData="threadPoolFormData" v-if="threadPoolDialogVisible" :threadPoolSelectOpts="threadPoolSelectOpts" />

    <ConsistencyDialog :formData.sync="formData" :visible.sync="consistencyDialogVisible" v-if="consistencyDialogVisible" @confirm="submitConsistencyForm" />
    <SyncDialog :visible.sync="syncDialogVisible" v-if="syncDialogVisible" />
    <ImportDialog :formData.sync="formData" :visible.sync="importDialogVisible" v-if="importDialogVisible" :dialogTitle="dialogTitle" @confirm="submitImportForm" width="50%" />
    <ImportySwDialog :formData.sync="formData" :visible.sync="importSwDialogVisible" :dialogTitle="dialogTitle" @confirm="submitImportSwForm" width="50%" />
    <McConfirmDialog :visible.sync="confirmDialogVisible" v-if="confirmDialogVisible" dialogTitle="确认下线" confirmText="DOWN" @confirm="confirmOffline" />
    <GrantDialog :formData.sync="formData" :visible.sync="grantDialogVisible" v-if="grantDialogVisible" title="接口授权" @confirm="apiGrant" />
    <TplDialog :formData="templateInfo" :visible.sync="tplDialogVisible" v-if="tplDialogVisible" @confirm="geneTpl" />
  </div>
</template>

<script>
import arrangeApi from '@/api/arrange'
import serviceApi from '@/api/service'
import resStructApi from '@/api/platformConfig/resStruct'
import grantApi from '@/api/serviceStatement/grant'
import EditDialog from './components/editDialog.vue'
import GrantDialog from '@/components/grantDialog'
import LimitDialog from './components/limitDialog.vue'
import DegradeDialog from './components/degradeDialog.vue'
import ThreadPoolDialog from './components/thread-pool-dialog.vue'
import TplDialog from '@/components/tpl-dialog/index.vue'
import TplDialogMixin from '@/components/tpl-dialog/mixins'
import ConsistencyDialog from './components/consistencyDialog.vue'
import SyncDialog from './components/syncDialog.vue'
import { FormData, Param, Degrade, Consistency } from './options/model'
import { getQueryList } from './options/queryOption'
import { getTableColumn } from './options/tableOption'
import { code2Text } from '@/utils'
import { mapActions } from 'vuex'
import ImportDialog from './components/importDialog.vue'
import ImportySwDialog from './components/importSwDialog.vue'
import { StatusEnum } from '@/config/constant'
import ArrangeLog from './arrangeLog/arrangeLog'
import { TemplateCategoryEnum } from '@/config/enum'

export default {
  name: 'ServiceArrangeList',
  components: {
    EditDialog,
    GrantDialog,
    SyncDialog,
    LimitDialog,
    DegradeDialog,
    ConsistencyDialog,
    ImportDialog,
    ArrangeLog,
    ImportySwDialog,
    TplDialog,
    ThreadPoolDialog
  },
  mixins: [TplDialogMixin],
  data() {
    return {
      recordCount: 0,
      pageIndex: 1,
      pageSize: 10,
      tableData: [], // 列表数据
      listLoading: false,
      query: {}, // 列表查询条件
      queryList: [],
      tableColumn: [],
      // 弹窗数据
      formData: new FormData(),
      dialogTitle: '新增',
      editDialogVisible: false,
      code2Text,
      syncDialogVisible: false,
      limitDialogVisible: false,
      degradeDialogVisible: false,
      threadPoolDialogVisible: false,
      consistencyDialogVisible: false,
      // selectedRows: [],
      importDialogVisible: false,
      StatusEnum,
      confirmDialogVisible: false,
      logDialogVisible: false,
      currentDefinetionId: null,
      currentRow: {},
      importSwDialogVisible: false,
      grantDialogVisible: false,
      isLogDialogActive: false,
      logRow: {},
      threadPoolId: null,
      threadPoolSelectOpts: null,
      threadPoolFormData: {}
    }
  },
  async created() {
    const [DefinitionStatusEnum] = await this.getDicts([
      'DefinitionStatusEnum',
      'MethodTypeEnum',
      'ConsistencyPolicyEnum' // 数据一致性策略：重试 | 回滚
    ])
    this.queryList = getQueryList({ DefinitionStatusEnum })
    this.getList()
    this.tableColumn = getTableColumn()
  },
  async activated() {
    // 透传接口操作需要在actived中触发
    const apiId = this.$route.params.apiId
    if (apiId) {
      this.genDefinitionDocByApiId(apiId)
    }
    if (this.isLogDialogActive) {
      this.handleOperateLog(this.logRow)
    }
    this.isLogDialogActive = false
  },
  deactivated() {
    this.logDialogVisible = false
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    async getDetail(row) {
      const data = await arrangeApi.detailArrange({ definitionId: row.id })
      return data
    },
    async getLimitDetail(row) {
      const data = await arrangeApi.limitArrangeDetail(row)
      return data
    },
    async apiGrant() {
      await grantApi.apiGrant(this.formData)
      this.$message.success('授权成功')
      this.grantDialogVisible = false
    },
    async submitForm(formData) {
      await arrangeApi.updateArrangeHead(formData)
      this.$message.success(`${this.dialogTitle}成功`)
      this.editDialogVisible = false
      this.getList()
    },
    async submitLimitForm(formData) {
      await arrangeApi.limitArrange(formData)
      this.$message.success(`${this.dialogTitle}成功`)
      this.limitDialogVisible = false
      this.getList()
    },
    async submitDegrateForm(formData) {
      await arrangeApi.updateDegrade(formData)
      this.$message.success('熔断设置成功')
      this.degradeDialogVisible = false
      this.getList()
    },
    async submitThreadPoolForm(formData) {
      try {
        await arrangeApi.saveThreadPoolSetting(formData)
        this.$message.success('线程池设置成功')
        this.threadPoolDialogVisible = false
        this.getList()
      } catch (e) {
        console.log('error:', e)
      }
    },
    async submitConsistencyForm(formData) {
      await arrangeApi.updateConsistency(formData)
      this.$message.success('策略设置成功')
      this.consistencyDialogVisible = false
      this.getList()
    },
    async submitImportForm(formData) {
      await arrangeApi.importArrange(formData)
      this.$message.success('导入完成')
      this.importDialogVisible = false
    },
    // 从接口页跳转进入需要生成业务接口的基础信息，展示弹窗
    async genDefinitionDocByApiId(apiId) {
      const resp = await serviceApi.genDefinitionDocByApiId({
        serverApiId: apiId
      })
      this.formData = resp || new FormData()
      this.dialogTitle = '新增'
      this.editDialogVisible = true
    },
    // 获取列表
    getList() {
      this.listLoading = true
      const params = {
        size: this.pageSize,
        page: this.pageIndex,
        ...this.query
      }
      arrangeApi
        .listArrange(params)
        .then((response) => {
          this.listLoading = false

          this.tableData = response.records || []
          if (this.pageIndex === 1) {
            this.recordCount = response.total || 0
          }
        })
        .catch((_res) => {
          this.listLoading = false
          this.tableData = []
          this.recordCount = 0
        })
    },
    // 修改每页数量
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.pageIndex = val
      this.getList()
    },
    // 根据刷选条件过滤数据
    handleFilter(val) {
      this.pageIndex = 1
      this.query = val
      this.getList()
    },
    async add() {
      this.dialogTitle = '新增'
      this.editDialogVisible = true
      this.formData = new FormData()
      const resp = await resStructApi.getDefaultStruct()
      if (resp && resp.importFlag) {
        this.formData.apiOutParamList = resp.apiParamList
      }
    },
    // 编辑信息
    async edit(row) {
      const formData = await this.getDetail(row)
      // 初始化一下每一行的对象，双向绑定
      const apiInParamList = formData.apiInParamList.map((item) => ({
        ...new Param(),
        ...item
      }))
      const apiOutParamList = formData.apiOutParamList.map((item) => ({
        ...new Param(),
        ...item
      }))
      this.formData = { ...formData, apiInParamList, apiOutParamList }

      this.dialogTitle = '编辑'
      this.editDialogVisible = true
    },
    async limit(row) {
      this.formData = await this.getLimitDetail({ defineId: row.id })
      if (!this.formData) {
        this.formData = {
          businessApiName: row.businessApiName,
          defineId: row.id,
          timeLen: null,
          timeType: null,
          count: null
        }
      } else if (!this.formData.businessApiName) {
        this.formData.businessApiName = row.businessApiName
      }
      this.dialogTitle = '限流设置'
      this.limitDialogVisible = true
    },
    async handleDegrade(row) {
      this.formData = await arrangeApi.detailDegrade({ definitionId: row.id })
      if (!this.formData) {
        this.formData = { ...new Degrade(), definitionId: row.id }
      } else {
        this.formData = { ...new Degrade(), ...this.formData, definitionId: row.id }
      }
      this.degradeDialogVisible = true
    },
    async handleConsistency(row) {
      this.formData = await arrangeApi.detailConsistency({ definitionId: row.id })
      if (!this.formData) {
        this.formData = { ...new Consistency(), definitionId: row.id }
      } else {
        this.formData = { ...new Consistency(), ...this.formData, definitionId: row.id }
      }
      this.consistencyDialogVisible = true
    },
    arrange(row) {
      this.$router.push(`/arrange/serviceArrangeDetail?type=edit&id=${row.id}&templateCategory=${TemplateCategoryEnum.ServiceArrangeList}`)
    },
    async handleGrant(row) {
      if (row.status === 1) {
        const resp = await grantApi.listApp({ beGrantId: row.id, beGrantType: 1 })
        this.formData = { frontList: resp.frontList || [], beGrantId: row.id, apiName: row.businessApiName, beGrantType: 1, backList: [] }
        this.grantDialogVisible = true
      } else {
        this.$message.warning('该api未上线，暂无法授权')
      }
    },
    // 待发布-0；已上线-1；已下线-2  待发布 => 已上线 => 已下线 => 已上线
    async handleOffline(row) {
      this.currentRow = { ...row }
      const status = row.status
      if (status === 1) {
        this.confirmDialogVisible = true
      } else {
        this.confirmOffline()
      }
    },
    async confirmOffline() {
      const status = StatusEnum[this.currentRow.status].nextStatus
      const btnText = StatusEnum[this.currentRow.status].operateBtn
      await arrangeApi.publishArrange({
        id: this.currentRow.id,
        status
      })
      this.$message.success(`${btnText}成功`)
      this.getList()
      this.confirmDialogVisible = false
    },
    handleConfirm(formData) {
      console.log(formData)
      this.submitForm(formData)
    },
    // handleSelectionChange(v) {
    //   this.selectedRows = v
    //   console.log(this.selectedRows)
    // },
    handleViewLog() {
      this.isLogDialogActive = true
    },
    handleOperateLog(row) {
      this.logRow = row
      this.currentDefinetionId = row.id
      this.logDialogVisible = true
      // this.$router.push({ name: 'ArrangeLog', query: { id: row.id } })
    },
    handlView(row) {
      this.$router.push({ name: 'ArrangeDetail', query: { id: row.id, categoryType: 'ServiceArrangeList' } })
    },
    syncApi() {
      console.log('同步用户接口')
      this.syncDialogVisible = true
    },
    handleImport() {
      this.importDialogVisible = true
      this.formData = {
        file: null,
        type: null
      }
    },

    // async handleExport() {
    //   if (!this.selectedRows || this.selectedRows.length < 1) {
    //     return this.$message.error('请先选择要导出的数据')
    //   }
    //   const params = {
    //     ...this.$refs.querybar.formData,
    //     ids: this.selectedRows.map((row) => row.id)
    //   }
    //   const resp = await arrangeApi.exportArrange(params)
    //   downloadBlob(resp)
    // },
    handleCommand(command, row) {
      switch (command) {
        case 'VIEW':
          this.handlView(row)
          break
        case 'DEBUG':
          this.handleDebug(row)
          break
        case 'DEGRADE':
          this.handleDegrade(row)
          break
        case 'OPERATE_LOG':
          this.handleOperateLog(row)
          break
        case 'OFFLINE':
          this.handleOffline(row)
          break
        case 'CONSISTENCY':
          this.handleConsistency(row)
          break
        case 'GRANT':
          this.handleGrant(row)
          break
        case 'CREATE_TPL':
          this.createTpl(row)
          break
        case 'THREAD_POOL':
          this.handleThreadPool(row)
          break
      }
    },
    handleImportSw() {
      this.importSwDialogVisible = true
      this.formData = {
        file: null,
        type: null
      }
    },
    async submitImportSwForm(formData) {
      await arrangeApi.importSwArrange(formData)
      this.$message.success('导入swagger完成')
      this.importSwDialogVisible = false
    },
    async handleDebug(row) {
      this.$router.push({ name: 'Debug', query: { id: row.id } })
    },
    async handleThreadPool(row) {
      await this.getSelectOptions()
      this.threadPoolDialogVisible = true

      // 设置线程池表单默认值
      const selectedThreadData = this.threadPoolSelectOpts.find(item => item.id === row.threadPoolId)

      this.threadPoolFormData = {
        definitionId: row.id,
        ...selectedThreadData
      }
    },
    async getSelectOptions() {
      try {
        const res = await arrangeApi.getThreadPoolSetting({}) // NOTE - 后面可能有其它筛选条件，入参目前是空对象
        this.threadPoolSelectOpts = res
      } catch (error) {
        console.log('error: ', error)
      }
    }
  }
}
</script>

<style scoped lang="scss">
</style>
