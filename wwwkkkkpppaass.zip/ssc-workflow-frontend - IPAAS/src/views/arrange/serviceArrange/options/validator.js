import { validateFn } from '@/utils/validator'

export const degrateDialogRules = function(vm) {
  return {
    isEnable: [
      { required: true, message: '请选择是否启用熔断', trigger: 'change' }
    ],
    count: [
      { required: true, message: '请填写异常比例', trigger: 'blur' },
      { validator: validateFn.checkNum({ min: 0, max: 1, notNull: true, isInt: false }), trigger: 'change' }
    ],
    degradeResponseContext: [
      { required: true, message: '请填写降级响应内容', trigger: 'blur' }
    ],
    minRequestAmount: [
      { required: true, message: '请填写最大请求数', trigger: 'blur' },
      { validator: validateFn.checkNum({ min: 0, max: 2147483647, notNull: true, isPositiveNumber: true }), trigger: 'change' }
    ],
    statIntervalMs: [
      { required: true, message: '请填写统计时长', trigger: 'blur' },
      { validator: validateFn.checkNum({ min: 0, max: 2147483647, notNull: true, isPositiveNumber: true }), trigger: 'change' }
    ]
  }
}

function validateCount(rule, value, callback) {

}
