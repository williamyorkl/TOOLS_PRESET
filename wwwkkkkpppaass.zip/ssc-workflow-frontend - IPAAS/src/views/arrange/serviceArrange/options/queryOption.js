import { validateFn } from '@/utils/validator'
import groupConfig from '@/config/popContentTableConfig/group.config'
import integrationApi from '@/api/arrange/integration'
import { getTableColumn as getIntegrationTableColumn, getQueryList as getIntegrationQueryList } from '@/config/popContentTableConfig/integration.config'

export function getQueryList({ DefinitionStatusEnum }) {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'definitionId',
      label: 'ID',
      queryType: 'input',
      rules: [{ validator: validateFn.checkNum({ max: 2147483647, notNull: false, isPositiveNumber: true }), trigger: 'blur' }]
    },
    {
      key: 'businessApiName',
      label: 'API接口名称',
      queryType: 'input'
    },
    {
      key: 'requestUrl',
      label: '接口请求URL',
      queryType: 'input'
    },
    {
      key: 'status',
      label: '状态',
      queryType: 'select',
      list: DefinitionStatusEnum,
      valueKey: 'type',
      labelKey: 'desc'
    },
    {
      prop: 'groupId',
      label: '服务分组',
      queryType: 'McPopoverSelect',
      editProps: {
        defaultValue: null,
        apiFunc: groupConfig.apiFunc,
        tableColumn: groupConfig.getTableColumn(),
        queryList: groupConfig.getQueryList(),
        labelKey: 'groupName',
        valueKey: 'id',
        width: 730
      }
    },
    {
      prop: 'integrationAppId',
      label: '集成应用',
      queryType: 'McPopoverSelect',
      editProps: {
        defaultValue: null,
        apiFunc: integrationApi.listIntergrationApp,
        tableColumn: getIntegrationTableColumn(),
        queryList: getIntegrationQueryList(),
        labelKey: 'appName',
        valueKey: 'id',
        width: 730
      }
    },
    {
      endKey: 'endTime',
      startKey: 'startTime',
      label: '更新时间',
      queryType: 'elDateRange',
      valueFormat: 'yyyy-MM-dd HH:mm:ss'
    }
  ]

  return queryList
}
