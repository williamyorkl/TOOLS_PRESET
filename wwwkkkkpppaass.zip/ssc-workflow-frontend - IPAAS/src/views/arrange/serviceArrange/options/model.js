export class Param {
  constructor() {
    this.rowKey = Date.now() + ''
    this.childrenList = []
    this.dataType = null // 参数类型
    this.description = null // 描述
    this.isRequired = null // 是否必填
    this.paramName = null // 参数key
    this.generic = null
    this.dataPosition = null
    this.value = null
    this.paramCheck = new ParamCheck()
    // this.newBool = true
  }
}

export class Param1 {
  constructor() {
    this.rowKey = Date.now() + ''
    this.childrenList = []
    this.dataType = null // 参数类型
    this.description = null // 描述
    this.isRequired = null // 是否必填
    this.paramName = null // 参数key
    this.generic = null
    this.dataPosition = null
    this.value = null
    this.paramCheck = new ParamCheck()
    this.newBool = true
  }
}

export class FormData {
  constructor() {
    this.businessApiName = null // 用户接口名称
    this.developer = null // 开发人员
    this.logLevel = 1 // 日志等级
    this.id = null // id
    this.webServiceFlag = 1
    this.httpFlag = 2
    this.crossFlag = 0
    this.integrationAppId = null // 集成应用id
    this.remark = null // 描述
    this.requestTimeout = 5000 // 超时时间
    this.apiCacheTime = null // 缓存时间
    this.requestType = 1 // 请求方式
    this.requestUrl = null // 请求接口url
    this.apiInParamList = [] // 参数描述
    this.apiOutParamList = []
    this.packagePath = null
    this.apiAuthType = 1 // 安全认证类型  网关app认证和无认证
    this.authId = null
    this.convertMsgFlag = 0 // 是否转换消息格式
    this.convertStructHeadId = null // 转换结构
    this.responseStructHeadId = null // 响应结构
  }
}

export class PolicyData {
  constructor({ unit = 's', frequency = null, time = null }) {
    this.unit = unit
    this.frequency = frequency
    this.time = time
  }
}

// API校验类
export class FlowFieldApiCheck {
  constructor() {
    this.apiCacheTime = null
    this.definitionReqList = []

    this.definitionId = null // 用户接口id
    // 自动带出
    this.requestType = null // 认证api请求方式
    this.businessApiName = null // 业务接口名称
    this.requestUrl = null // 认证api请求连接
    this.resultScript = null // 脚本
  }
}

// 函数校验类
export class FlowFieldFunCheck {
  constructor() {
    this.express = null // 表达式
    this.parameters = [] // 参数
  }
}

// 参数校验类
export class ParamCheck {
  constructor() {
    this.formatType = null
    this.maxLen = null
    this.minLen = null
    this.regEx = null
    this.apiCheckFlag = 0
    this.funCheckFlag = 0
    this.flowFieldApiCheck = new FlowFieldApiCheck()
    this.flowFieldFunCheck = new FlowFieldFunCheck()
  }
}

// 熔断
export class Degrade {
  constructor() {
    this.id = null
    this.definitionId = null // 编排接口id
    this.count = null // 异常比例 1表示100%
    this.degradeResponseContext = null // 降级响应内容
    this.isEnable = 0
    this.minRequestAmount = null // 最小请求数
    this.statIntervalMs = null // 统计时长ms
  }
}

// 数据一致性
export class Consistency {
  constructor() {
    this.id = null
    this.definitionId = null
    this.isEnable = null
    this.ladderExpression = null
    this.policy = 1
  }
}
