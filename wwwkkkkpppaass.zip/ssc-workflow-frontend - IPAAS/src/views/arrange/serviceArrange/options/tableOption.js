export function getTableColumn() {
  const tableColumn = [
    { label: 'ID', prop: 'id', minWidth: '50px' },
    { label: 'API接口名称', prop: 'businessApiName', minWidth: '200px' },
    { label: '请求方式', prop: 'requestType', dict: 'MethodTypeEnum', minWidth: '100px' },
    { label: '状态', prop: 'status', dict: 'DefinitionStatusEnum', minWidth: '100px' },
    { label: '服务分组', prop: 'groupName', minWidth: '100px' },
    { label: 'BasePath', prop: 'baseUrl', minWidth: '80px' },
    { label: '接口请求URL', prop: 'requestUrl', minWidth: '140px' },
    { label: '创建人', prop: 'createByName', minWidth: '100px' },
    { label: '创建时间', prop: 'createTime', minWidth: '140px' },
    { label: '更新人', prop: 'updateByName', minWidth: '100px' },
    { label: '更新时间', prop: 'updateTime', minWidth: '140px' },
    {
      prop: 'operate',
      label: '操作',
      width: '170px',
      type: 'slot',
      showOverflowTooltip: false,
      btnList: []
    }
  ]

  return tableColumn
}
