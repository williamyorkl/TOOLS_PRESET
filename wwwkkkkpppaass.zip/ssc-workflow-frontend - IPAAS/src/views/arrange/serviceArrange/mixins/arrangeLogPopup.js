
export default {
  data() {
    return {
      currentDefinetionId: null,
      logDialogVisible: false,
      logRow: {}
    }
  },
  methods: {
    handleViewLog() {
      this.isLogDialogActive = true
    },
    // NOTE - 注意以下方法需要在页面的handleCommand中添加
    handleOperateLog(row) {
      this.logRow = row
      this.currentDefinetionId = row.id
      this.logDialogVisible = true
      // this.$router.push({ name: 'ArrangeLog', query: { id: row.id } })
    }
  },
  // NOTE - 处理keep-alive的弹窗保持逻辑
  async activated() {
    // 透传接口操作需要在actived中触发
    const apiId = this.$route.params.apiId
    if (apiId) {
      this.genDefinitionDocByApiId(apiId)
    }
    if (this.isLogDialogActive) {
      this.handleOperateLog(this.logRow)
    }
    this.isLogDialogActive = false
  },
  deactivated() {
    this.logDialogVisible = false
  }
}
