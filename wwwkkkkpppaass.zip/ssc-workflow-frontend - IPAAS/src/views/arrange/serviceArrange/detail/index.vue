<template>
  <div>
    <flow-panel v-if="arrangeData" :arrangeData="arrangeData" @commitForm="commitForm"></flow-panel>
  </div>
</template>

<script>
// 在本页面根据ID调接口获取数据后通过prop传入flowPanel。、修改后emit出来
import { mapActions } from 'vuex'
import arrangeApi from '@/api/arrange'
import '@/components/easy-flow/index.css'
import FlowPanel from '@/components/easy-flow/panel.vue'
import { getDataDefault } from '@/components/easy-flow/utils/data_default.js'
import { PolicyData } from '../options/model'
export default {
  name: 'ServiceArrangeDetail',
  components: {
    FlowPanel
  },
  data() {
    return {
      arrangeData: null,
      // arrangeData: getDataDefault(),
      arrangeDataDoc: {},
      id: null,
      DataTypeEnum: []
    }
  },
  async created() {
    this.id = this.$route.query.id;
    [this.DataTypeEnum] = await this.getDicts(['DataTypeEnum'])
    if (this.id) {
      const arrangeData = await this.getArrangeData()
      this.arrangeData = this.formatterData(arrangeData)
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    async getArrangeData() {
      const resp = await arrangeApi.detailArrange({ definitionId: this.id })
      return resp
    },
    async commitForm(formData) {
      const arrangeData = this.reverseFormatterData(formData)
      const resp = await arrangeApi.updateArrange(arrangeData)
      this.$message.success('提交成功')
    },
    reverseFormatterData(arrangeData) {
      const nodeList = arrangeData.nodeList
      return arrangeData
    },
    formatterData(arrangeData) {
      const defaultData = getDataDefault()
      if (!arrangeData.nodeList || arrangeData.nodeList.length === 0) {
        arrangeData.nodeList = defaultData.nodeList
        arrangeData.lineList = defaultData.lineList
      }
      arrangeData.nodeList.forEach(node => {
        if (node.type === 'start') {
          node.nodeParams.outputParamList = arrangeData.apiInParamList
        } else if (node.type === 'end') {
          node.nodeParams.outputParamList = arrangeData.apiOutParamList
        }
      })
      return arrangeData
    }
  }
}
</script>

<style>

</style>
