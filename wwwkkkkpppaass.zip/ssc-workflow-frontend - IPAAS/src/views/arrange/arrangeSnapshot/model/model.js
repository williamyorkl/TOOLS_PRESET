export class ArrangeSnapshot {
  constructor() {
    this.basicDetail = {}
    this.nodeDetail = {}
    this.id = null
    this.definitionId = null
    this.operatitionType = null
  }
}
