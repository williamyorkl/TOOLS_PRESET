<template>
  <div>
    <el-tabs v-model="activeName" type="border-card">
      <el-tab-pane label="基础配置" name="basicDetail" />
      <el-tab-pane label="服务编排" name="nodeDetail" />
      <keep-alive>
        <flow-panel :arrangeData="arrangeSnapshot.nodeDetail" mode="snapshot" v-if="activeName === 'nodeDetail'" />
        <component :is="editFormCptName" v-else :formData="unionFormData" ref="editform" mode="snapshot" />
      </keep-alive>
    </el-tabs>
  </div>
</template>

<script>
// 在本页面根据ID调接口获取数据后通过prop传入flowPanel。、修改后emit出来
import arrangeLogApi from '@/api/arrange/arrangeLog'
import arrangeApi from '@/api/arrange'
import '@/components/easy-flow/index.css'
// import FlowPanel from '@/components/easy-flow/panel.vue'
import FlowPanel from '@/views/arrange/arrangeDetail'
import ServiceArrangeListEditForm from '@/views/arrange/serviceArrange/components/editForm'
import DispatchArrangeListEditForm from '@/views/logicArrange/dispatchArrangeList/components/editForm.vue'
import CdcArrangeListEditForm from '@/views/logicArrange/cdcArrangeList/components/editForm.vue'
import MqArrangeListEditForm from '@/views/logicArrange/mqArrangeList/components/editForm.vue'
import { getDataDefault } from '@/components/easy-flow/utils/data_default.js'
import { ArrangeSnapshot } from './model/model'

export default {
  name: 'ArrangeSnapshot',
  components: {
    FlowPanel, ServiceArrangeListEditForm, DispatchArrangeListEditForm, CdcArrangeListEditForm, MqArrangeListEditForm
  },
  data() {
    return {
      arrangeData: getDataDefault(),
      arrangeDataDoc: {},
      id: null,
      activeName: 'basicDetail',
      arrangeSnapshot: new ArrangeSnapshot(),
      editFormCptName: null,
      unionFormData: null,
      resDataArrangeSnapshot: null,
      categoryType: null
    }
  },
  async created() {
    this.categoryType = this.$route.query.categoryType // 页面类型：定时集成、实时集成、消息集成、服务编排
    this.id = this.$route.query.id // 从日志列表进入
    const type = this.$route.query.type // 类型： log,标识是从日志列表进入还是编排列表进入
    let nodeDetail = {}
    let basicDetail = {}
    if (type === 'log') {
      const resp = await this.getArrangeSnapshot()
      this.resDataArrangeSnapshot = resp

      nodeDetail = resp.nodeDetail
      basicDetail = resp.basicDetail
    } else {
      nodeDetail = await this.getArrangeData()
      basicDetail = await this.getArrangeDocData()
    }
    this.arrangeSnapshot = this.mergeData({ nodeDetail, basicDetail })

    this.switchComponentType()
  },
  methods: {
    async getArrangeSnapshot() {
      const resp = await arrangeLogApi.detailArrangeSnapshot({ id: this.id })
      return resp
    },
    async getArrangeData() {
      const resp = await arrangeApi.detailArrange({ definitionId: this.id })
      return resp
    },
    // 需要将apiInParamList和apiOutParamList填充给开始节点和结束节点的入参和出参
    async getArrangeDocData() {
      const resp = await arrangeApi.detailArrange({ definitionId: this.id })
      return resp
    },
    mergeData({ basicDetail, nodeDetail }) {
      const defaultData = getDataDefault()
      if (!nodeDetail.nodeList || nodeDetail.nodeList.length === 0) {
        nodeDetail.nodeList = defaultData.nodeList
        nodeDetail.lineList = defaultData.lineList
      }
      nodeDetail.nodeList.forEach(item => {
        // 因入参其实不涉及参数映射，所以可以理解成入参源数据和目标数据是一致的接口输入数据
        if (item.type === 'start') {
          item.nodeParams.outputParamList = nodeDetail.apiInParamList
        }
        if (item.type === 'end') {
          item.nodeParams.outputParamList = nodeDetail.apiOutParamList
        }
      })
      return { nodeDetail, basicDetail }
    },
    goBack() {
      this.$router.go(-1)
    },
    switchComponentType() {
      switch (this.categoryType) {
        case 'ServiceArrangeList':
          this.editFormCptName = 'ServiceArrangeListEditForm'
          this.unionFormData = this.arrangeSnapshot.basicDetail
          break
        case 'DispatchArrangeList':
          this.editFormCptName = 'DispatchArrangeListEditForm'
          this.unionFormData = this.resDataArrangeSnapshot.logicBasicDetail
          break
        case 'CdcArrangeList':
          this.editFormCptName = 'CdcArrangeListEditForm'
          this.unionFormData = this.resDataArrangeSnapshot.logicBasicDetail
          break
        case 'MqArrangeList':
          this.editFormCptName = 'MqArrangeListEditForm'
          this.unionFormData = this.resDataArrangeSnapshot.logicBasicDetail
          break
      }
    }
  }
}
</script>

<style scoped lang="scss">
::v-deep .el-page-header{
  padding: 12px
}
</style>
