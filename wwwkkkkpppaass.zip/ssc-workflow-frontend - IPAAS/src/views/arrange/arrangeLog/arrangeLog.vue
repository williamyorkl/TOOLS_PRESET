<template>
  <div class="common-container">
    <div class="apply-content">
      <mc-query :query-list="queryList" @query="handleFilter"></mc-query>
      <div class="common-btns-container">
        <!-- <el-button type="primary" @click="handleAdd">新增</el-button> -->
      </div>
      <div class="common-table-container" v-loading="listLoading">
        <mc-table @selection-change="handleSelectionChange" :tableData="tableData" :tableColumn="tableColumn" @eventListener="eventListener">
        </mc-table>
      </div>
      <div class="pagination-container">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page.sync="pageIndex" :page-sizes="[10, 20, 50, 100]" :page-size="10" layout="total, sizes, prev, pager, next, jumper" :total="recordCount" background>
        </el-pagination>
      </div>
    </div>

  </div>
</template>

<script>
import { mapActions } from 'vuex'
import Constant from '@/config/constant'
import arrangeLogApi from '@/api/arrange/arrangeLog'
import { getQueryList } from './options/queryOption'
import { getTableColumn } from './options/tableOption'
export default {
  name: 'ArrangeLog',
  data() {
    return {
      listLoading: false,
      recordCount: 0,
      pageIndex: 1,
      pageSize: 10,
      queryList: [],
      query: {}, // 列表查询条件
      tableColumn: [],
      tableData: [],
      formData: {}
    }
  },
  async created() {
    this.tableColumn = getTableColumn()
    const [OperatitonType] = await this.getDicts([
      'OperatitonType'
    ])
    this.getList()
    this.queryList = getQueryList()
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    async handleView(row) {
      this.$router.push(`/arrange/arrangeSnapshot?type=log&id=${row.id}`)
    },
    async getList() {
      this.listLoading = true
      const definitionId = this.$route.query.id // 编排id
      const params = {
        size: this.pageSize,
        page: this.pageIndex,
        ...this.query,
        definitionId
      }
      arrangeLogApi
        .listArrangeLog(params)
        .then((response) => {
          this.listLoading = false
          this.tableData = response.records || []
          if (this.pageIndex === 1) {
            this.recordCount = response.total || 0
          }
        })
        .catch(() => {
          this.listLoading = false
          this.tableData = []
          this.recordCount = 0
        })
    },
    handleSelectionChange(rows) {
      console.log(rows)
    },
    eventListener(eventType, row) {
      switch (eventType) {
        case Constant.VIEW:
          this.handleView(row)
          break
      }
    },
    // 根据刷选条件过滤数据
    handleFilter(val) {
      this.pageIndex = 1
      this.query = val
      this.getList()
    },
    // 编辑每页数量
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.pageIndex = val
      this.getList()
    }
  }
}
</script>

<style>
</style>
