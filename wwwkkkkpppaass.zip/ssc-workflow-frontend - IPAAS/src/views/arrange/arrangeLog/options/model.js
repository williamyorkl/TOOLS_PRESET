import { FormData as BasicDetail } from '@/views/arrange/serviceArrange/options/model'
export class FormData {
  constructor() {
    this.basicDetail = new BasicDetail() // 基础详情
    this.createByName = null
    this.createTime = null
    this.definitionId = null // 定义id
    this.id = null
    this.nodeDetail = null // 节点详情
    this.operatitonType = null // 操作类型 0-新增 1-修改
    this.tenantId = null
    this.updateByName = null
    this.updateTime = null
  }
}
