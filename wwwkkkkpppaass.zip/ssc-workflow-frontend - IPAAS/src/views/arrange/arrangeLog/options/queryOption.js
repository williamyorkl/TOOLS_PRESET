export function getQueryList() {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'createByName',
      label: '创建人',
      queryType: 'input'
    },
    {
      endKey: 'endTime',
      startKey: 'startTime',
      label: '创建时间',
      queryType: 'elDateRange',
      valueFormat: 'yyyy-MM-dd HH:mm:ss'
    }
  ]

  return queryList
}
