export class FormData {
  constructor() {
    this.baseUrl = '' // BasePath
    this.groupDesc = '' // 分组描述
    this.groupName = '' // 分组名称
    this.id = null
    this.mark = '' // 描述
  }
}
