export function getQueryList() {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'groupName',
      label: '服务分组名称',
      queryType: 'input'
    }, {
      key: 'baseUrl',
      label: 'BasePath',
      queryType: 'input'
    }
  ]

  return queryList
}
