<template>
  <div class="common-container">
    <div class="apply-content">
      <mc-query :queryList="queryList" @query="handleFilter" />
      <div class="common-btns-container">
        <el-button type="primary" @click="handleAdd">新增</el-button>
      </div>
      <div class="common-table-container" v-loading="listLoading">
        <mc-table :tableData="tableData" :tableColumn="tableColumn" @eventListener="eventListener" />
      </div>
      <div class="pagination-container">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :currentPage.sync="pageIndex" :pageSizes="[10, 20, 50, 100]" :pageSize="10" layout="total, sizes, prev, pager, next, jumper" :total="recordCount" background />
      </div>
    </div>

    <edit-dialog :formData.sync="formData" :visible.sync="editDialogVisible" :title="editDialogTitle" @eventListener="eventListener" width="800px" />

    <McConfirmDialog :visible.sync="confirmDialogVisible" dialogTitle="删除确认" failText="删除确认内容错误" confirmText="DELETE" @confirm="confirmDelete" />
  </div>
</template>

<script>
import { mapActions } from 'vuex'
import Constant from '@/config/constant'

import EditDialog from './components/edit-dialog'
import groupApi from '@/api/arrange'
import { getQueryList } from './options/queryOption'
import { getTableColumn } from './options/tableOption'
import { FormData } from './options/model'
import { deepClone } from '@/utils'
export default {
  name: 'ServiceGroup',
  components: { EditDialog },
  data() {
    return {
      listLoading: false,
      recordCount: 0,
      pageIndex: 1,
      pageSize: 10,
      queryList: [],
      query: {}, // 列表查询条件
      tableColumn: [],
      tableData: [],
      editDialogVisible: false,
      editDialogTitle: '新增服务分组',
      confirmDialogVisible: false,
      formData: {},
      currentRow: {}
    }
  },
  async created() {
    this.tableColumn = getTableColumn()
    this.getList()
    this.queryList = getQueryList()
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    handleEdit(row) {
      this.editDialogTitle = '编辑服务分组'
      this.editDialogVisible = true
      this.formData = deepClone(row)
    },
    async confirmDelete() {
      console.log(groupApi.deleteGroup)
      await groupApi.deleteGroup({
        id: this.currentRow.id
      })
      this.$message.success('删除成功')
      this.getList()
    },
    async handleDelete(row) {
      this.confirmDialogVisible = true
      this.currentRow = { ...row }
      // this.$confirm('是否确认删除该条数据?', '提示', {
      //   confirmButtonText: '确定',
      //   cancelButtonText: '取消',
      //   type: 'warning'
      // }).then(async() => {
      //   console.log(groupApi.deleteGroup)
      //   await groupApi.deleteGroup({ id: row.id })
      //   this.$message.success('删除成功')
      //   this.getList()
      // }).catch(() => {
      //   this.$message({
      //     type: 'info',
      //     message: '已取消删除'
      //   })
      // })
    },
    handleAdd() {
      this.editDialogTitle = '新增服务分组'
      this.editDialogVisible = true
      this.formData = new FormData()
    },
    async handleCommit(formData) {
      await groupApi.updateGroup(formData)
      let msg = '新增成功'
      if (formData.id) {
        msg = '编辑成功'
      }
      this.$message.success(msg)
      this.editDialogVisible = false
      this.getList()
    },
    async getList() {
      this.listLoading = true
      const params = {
        size: this.pageSize,
        page: this.pageIndex,
        ...this.query
      }
      groupApi
        .listGroup(params)
        .then((response) => {
          this.listLoading = false
          this.tableData = response.records || []
          if (this.pageIndex === 1) {
            this.recordCount = response.total || 0
          }
        })
        .catch(() => {
          this.listLoading = false
          this.tableData = []
          this.recordCount = 0
        })
    },
    eventListener(eventType, row) {
      switch (eventType) {
        case Constant.EDIT:
          this.handleEdit(row)
          break
        case Constant.DELETE:
          this.handleDelete(row)
          break
        case Constant.COMMIT:
          this.handleCommit(row)
          break
      }
    },
    // 根据刷选条件过滤数据
    handleFilter(val) {
      this.pageIndex = 1
      this.query = val
      this.getList()
    },
    // 编辑每页数量
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.pageIndex = val
      this.getList()
    }
  }
}
</script>

<style>
</style>
