<template>
  <el-dialog :title="title" :visible.sync="visible" :width="width" :beforeClose="handleClose" appendToBody>
    <mc-form ref="form" :model="formData" :rules="rules" labelWidth="120px">
      <mc-form-item componentType="ElInput" prop="appCode" label="网关应用编码" :readonly="true" />
      <mc-form-item componentType="ElInput" prop="appName" label="网关应用名称" />
      <mc-form-item componentType="ElSelect" prop="authMethod" label="认证方式" dict="AuthTypeEnum" @change="authMethodChange" />
      <mc-form-item componentType="FormPlaceholder" prop="placeholder" label="" labelWidth="0" v-if="formData.authMethod === 6">
        <div>
          <el-popover placement="bottom" width="800" trigger="click">
            <pre class="pre">
            {{ jwtExa }}
            <i class="el-icon-copy-document" v-clipboard:copy="jwtExa" v-clipboard:success="onCopy" v-clipboard:error="onError" />
          </pre>
            <el-button type="text" slot="reference">JWT生成示例</el-button>
          </el-popover>
        </div>
      </mc-form-item>
      <mc-form-item componentType="ElInput" prop="authSign" label="密钥" :readonly="true" v-if="whiteAuthTypes.includes(formData.authMethod)" />
      <!-- 自定义认证 -->
      <CustomAuth :formData="formData" :rules="rules" v-if="formData.authMethod === 5" />
      <!-- jwt认证 -->
      <JwtAuth :formData="formData" :rules="rules" v-if="formData.authMethod === 6" />
      <mc-form-item componentType="ElSwitch" prop="whiteFlag" label="启用白名单" :editProps="{activeValue: 2, inactiveValue: 1}" :span="24" @change="whiteFlagChange" />
      <mc-form-item componentType="ElInput" prop="whiteList" label="IP白名单" v-if="formData.whiteFlag === 2" :editProps="{type: 'textarea', placeholder: '请输入IP白名单（10.74.1.1），以“,”分割'}" :span="24" />
      <mc-form-item labelWidth="0">
        <el-button type="primary" @click="eventListener('新增')">{{ btnText }}</el-button>
      </mc-form-item>
      <div class="common-table-container" v-loading="listLoading">
        <mc-table :tableData="formData.relationList" :tableColumn="tableColumn" @eventListener="eventListener" height="300px" />
      </div>
    </mc-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" @click="confirm">确 定</el-button>
    </span>
    <api-dialog :formData.sync="formData" :visible.sync="apiDialogVisible" v-if="apiDialogVisible" :title="apiDialogTitle" @eventListener="eventListener" width="800px" :props="{}" />
    <LimitDialog :formData.sync="currentRowData" :visible.sync="limitDialogVisible" :dialogTitle="limitDialogTitle" @confirm="submitLimitForm" />
    <PermissionDialog :defineId="currentRowData.defineId" :list.sync="currentApiFieldList" :visible.sync="permissionDialogVisible" :dialogTitle="permissionDialogTitle" @confirm="submitPermissionForm" />
  </el-dialog>
</template>

<script>
import { mapActions } from 'vuex'
import Constant from '@/config/constant'
import { getTableColumn } from './options/tableOption'
import ApiDialog from './components/apiDialog'
import LimitDialog from './components/limitDialog'
import PermissionDialog from './components/permissionDialog'
import { deepClone } from '@/utils'
import { regExpRules } from '@/utils/validator'
import CustomAuth from './components/customAuth'
import JwtAuth from './components/jwtAuth'
import jwtExa from './options/jwtExa'

export default {
  name: 'EditDialog',
  components: { ApiDialog, LimitDialog, PermissionDialog, CustomAuth, JwtAuth },
  props: {
    props: {
      default: () => ({}),
      type: Object
    },
    visible: {
      default: false,
      type: Boolean
    },
    title: {
      default: '新增',
      type: String
    },
    width: {
      default: '30%',
      type: String
    },
    formData: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      jwtExa,
      listLoading: false,
      tableData: [],
      tableColumn: [],
      selectedRows: [],
      apiDialogVisible: false,
      apiDialogTitle: '业务接口',
      limitDialogVisible: false,
      limitDialogTitle: '接口流控',
      permissionDialogVisible: false,
      permissionDialogTitle: '出参字段权限',
      currentApiFieldList: [],
      currentRowData: {},
      currentIndex: null,
      whiteAuthTypes: [1, 2, 3, 4],
      rules: {
        appName: [
          { required: true, message: '请填写网关应用名称', trigger: 'blur' },
          { max: 32, message: '网关应用名称长度不能超过32个字符', trigger: 'blur' }
        ],
        querySql: [
          { required: true, message: '请填写查询SQL', trigger: 'blur' }
        ],
        /* whiteFlag: [
          { required: true, message: '请选择是否启用白名单', trigger: 'change' }
        ], */
        authMethod: [
          { required: true, message: '请选择认证方式', trigger: 'change' }
        ],
        whiteList: [
          { required: true, message: '请填写IP白名单', trigger: 'blur' },
          { pattern: regExpRules.ipSplitWithComma, message: '格式有误', trigger: 'change' }
        ],
        definitionId: [
          { required: true, message: '请选择认证接口', trigger: 'change' }
        ],
        authResultField: [
          { required: true, message: '请选择认证结果字段', trigger: 'blur,change' }
        ],
        jwtName: [
          { required: true, message: '请输入JWT参数名', trigger: 'blur' }
        ],
        jwtPos: [
          { required: true, message: '请输入JWT取值位置', trigger: 'blur' }
        ],
        jwtKey: [
          { required: true, message: '请输入公钥', trigger: 'blur' }
        ]
      }
    }
  },
  async created() {
    this.tableColumn = getTableColumn()
    await this.getDicts(['MethodTypeEnum'])
  },
  watch: {
    visible(nV) {
      console.log(this.formData)
      if (nV) {
        this.getList() // 如果有字典数据必须放在获取字典数据后
      }
      if (nV && this.$refs.form) {
        this.$refs.form.clearValidate()
      }
    }
  },
  computed: {
    // btnText: '新增授权接口',
    btnText() {
      const limitApis = [4, 5] // JWT 改成 ‘添加授权接口’  AuthTypeEnum
      if (limitApis.includes(this.formData.authMethod)) {
        return '添加流控接口'
      } else {
        return '添加授权接口'
      }
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    async getList() {
      // 新增时为空数组
      if (!this.formData.id) {
        this.formData.relationList = []
      } else {
        // 修改时从接口获取
        // const resp = await appApi.getBusinessApiList({ appId: this.formData.id })
        // this.$set(this.formData, 'relationList', resp || [])
        // console.log(this.formData.relationList)
      }
    },
    authMethodChange(v) {
      // 1,2,3,4和5（自定义）不一样
      if ([1, 2, 3, 4].includes(v)) {
        this.formData.definitionId = null
        this.formData.businessApiName = null
        this.formData.requestUrl = null
        this.formData.requestType = null
        this.formData.businessApiName = null
        this.formData.definitionReqList = []
        this.formData.definitionRespList = []
      } else {
        this.formData.authSign = null
      }
    },
    whiteFlagChange(v) {
      console.log(v)
    },
    handleAdd() {
      this.apiDialogVisible = true
    },
    handleDelete(row, index) {
      this.formData.relationList.splice(index, 1)
    },
    handleLimit(row, index) {
      this.limitDialogVisible = true
      this.currentRowData = deepClone(row)
      this.currentIndex = index
    },
    // 弹窗打开参数列表，勾选有权限的列表
    handlePermission(row, index) {
      this.permissionDialogVisible = true
      this.currentRowData = row
      this.currentApiFieldList = deepClone(row.fieldList)
      this.currentIndex = index
    },
    submitLimitForm(formData) {
      this.formData.relationList.splice(this.currentIndex, 1, formData)
      this.limitDialogVisible = false
    },
    submitPermissionForm(fieldList) {
      this.currentRowData.fieldList = fieldList
      this.permissionDialogVisible = false
    },
    handleRowClick(row, isMul) {
      row = { ...row }
      row.defineId = row.id
      row.appName = this.formData.appName
      delete row.id
      const hasCurrentRow = this.formData.relationList.find(item => item.defineId === row.defineId)
      if (hasCurrentRow) {
        if (!isMul) {
          return this.$message.error('该接口已存在')
        } else {
          return false
        }
      }
      this.apiDialogVisible = false
      this.formData.relationList.unshift(row)
      return true
    },
    handleRowSelect(rows) {
      const total = rows.length
      const successRows = rows.filter(row => this.handleRowClick(row, true))
      const successCount = successRows.length
      this.apiDialogVisible = false
      this.$message.success(`成功${successCount}条，失败${total - successCount}条`)
    },
    handleClose(_done) {
      this.$emit('update:visible', false)
    },
    handleSelectionChange(rows) {
      this.selectedRows = rows
    },
    eventListener(eventType, row, index) {
      switch (eventType) {
        case Constant.ADD:
          this.handleAdd(row)
          break
        case Constant.LIMIT:
          this.handleLimit(row, index)
          break
        case Constant.PERMISSION:
          this.handlePermission(row, index)
          break
        case Constant.COMMIT:
          this.handleCommit(row)
          break
        case Constant.ROWCLICK:
          this.handleRowClick(row)
          break
        case Constant.ROWSELECT:
          this.handleRowSelect(row)
          break
        case Constant.DELETE:
          this.handleDelete(row, index)
          break
      }
    },
    onCopy() {
      this.$message.success('已复制到剪切板')
    },
    onError() {
      this.$message.error('复制失败')
    },
    confirm() {
      this.$refs.form.validate()
        .then(valid => {
          if (valid) {
            this.$emit('eventListener', Constant.COMMIT, this.formData)
            // this.$emit('update:visible', false)
          } else {
            this.$message.error('请按照提示完善表单数据')
          }
        })
    }
  }
}
</script>
