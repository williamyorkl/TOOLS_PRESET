<template>
  <el-dialog :title="title" :visible.sync="visible" :width="width" :beforeClose="handleClose" v-if="visible" appendToBody>
    <div class="apply-content">
      <mc-query :queryList="queryList" @query="handleFilter" :showTopBorder="false" :col="2" />
      <div class="common-table-container" v-loading="listLoading">
        <mc-table @selection-change="handleSelectionChange" :tableData="tableData" :tableColumn="tableColumn" @row-click="rowClick" maxHeight="397" />
      </div>
      <div class="pagination-container">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :currentPage.sync="pageIndex" :pageSizes="[10, 20, 50, 100]" :pageSize="10" layout="total, sizes, prev, pager, next, jumper" :total="recordCount" background />
      </div>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" @click="confirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { getTableColumn } from '../options/tableOption'
import Constant from '@/config/constant'
import arrangeApi from '@/api/arrange'
export default {
  name: 'ApiDialog',
  props: {
    props: {
      default: () => ({}),
      type: Object
    },
    visible: {
      default: false,
      type: Boolean
    },
    title: {
      default: '新增',
      type: String
    },
    width: {
      default: '30%',
      type: String
    }
  },
  data() {
    return {
      listLoading: false,
      recordCount: 0,
      pageIndex: 1,
      pageSize: 10,
      queryList: [],
      query: {}, // 列表查询条件
      tableColumn: [],
      tableData: [],
      selectRows: []
    }
  },
  async created() {
    this.tableColumn = getTableColumn(false)
    this.getList() // 如果有字典数据必须放在获取字典数据后
    this.queryList = [{
      key: 'businessApiName',
      label: 'API接口名称',
      queryType: 'input'
    },
    {
      key: 'requestUrl',
      label: '接口请求URL',
      queryType: 'input'
    }]
  },
  watch: {
    visible(nV) {
      if (nV && this.$refs.form) {
        this.$refs.form.clearValidate()
      }
    }
  },
  methods: {
    rowClick(row) {
      // row.defineId = row.id
      // delete row.id
      this.$emit('eventListener', Constant.ROWCLICK, row)
    },
    confirm() {
      this.$emit('eventListener', Constant.ROWSELECT, this.selectRows)
    },
    handleClose() {
      this.$emit('update:visible', false)
    },
    async getList() {
      this.listLoading = true
      const params = {
        size: this.pageSize,
        page: this.pageIndex,
        ...this.query,
        status: 1
      }
      arrangeApi
        .listArrange(params)
        .then((response) => {
          this.listLoading = false
          this.tableData = response.records || []
          if (this.pageIndex === 1) {
            this.recordCount = response.total || 0
          }
        })
        .catch(() => {
          this.listLoading = false
          this.tableData = []
          this.recordCount = 0
        })
    },
    handleSelectionChange(rows) {
      this.selectRows = rows
    },
    // 根据刷选条件过滤数据
    handleFilter(val) {
      this.pageIndex = 1
      this.query = val
      this.getList()
    },
    // 修改每页数量
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.pageIndex = val
      this.getList()
    }
  }
}
</script>

<style lang="scss" scoped>
.apply-content{
  padding-bottom: 20px;
  border-bottom: 1px solid rgba(15, 29, 63, .1);
}
</style>
