// 字段映射列表
<template>
  <div class="table-form" ref="mappingForm" :model="formData" :rules="rules" label-width="0px" size="mini">
    <el-table ref="mappingTable" :data="formData.tableList" highlight-current-row @current-change="handleCurrentChange" style="width: 100%" max-height="300px">
      <el-table-column label="序号" type="index" align="left" width="60" />

      <el-table-column label="请求参数名称" width="200px">
        <template slot-scope="scope">
          <el-form-item label-width="0px" :rules="rules.destName" :prop="'definitionReqList.' + scope.$index + '.destName'">
            <el-input v-model.trim="scope.row.destName" placeholder="请输入内容" :disabled="!scope.row.isUserAdd" />
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="请求参数类型" width="160px">
        <template slot-scope="scope">
          <el-form-item label-width="0px" :rules="rules.dataType" :prop="'definitionReqList.' + scope.$index + '.dataType'">
            <el-select v-model="scope.row.dataType" placeholder="请选择属性数据类型" :disabled="!scope.row.isUserAdd">
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="赋值类型" align="left" width="150px">
        <template slot-scope="scope">
          <el-form-item label-width="0px" :rules="rules.referenceType" :prop="'definitionReqList.' + scope.$index + '.referenceType'">
            <el-select v-model="scope.row.referenceType" placeholder="请选择类型" @change="referenceTypeChange(scope.row.referenceType, scope.row)">
              <el-option v-for="item in ParamReferenceTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="取值参数位置" align="left" width="150px">
        <template slot-scope="scope">
          <el-form-item label-width="0px">
            <!-- 只有引用值才要选择参数位置 -->
            <el-select v-model="scope.row.sourcePos" placeholder="请选择" :disabled="scope.row.referenceType === 0">
              <el-option v-for="item in DataPosEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="取值参数名" width="200px">
        <template slot-scope="scope">
          <el-form-item label-width="0px" :rules="rules.sourceName" :prop="'definitionReqList.' + scope.$index + '.sourceName'">
            <el-input v-model.trim="scope.row.sourceName" placeholder="请输入内容">
              <!-- <el-button v-if="scope.row.type === 1" slot="append" icon="el-icon-setting" @click="showJsonTree(scope.row)"></el-button> -->
            </el-input>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="函数设置" width="120px" align="left">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="editFunction(scope.row,scope.$index)">函数{{ scope.row.functionList&&scope.row.functionList.length ? '('+scope.row.functionList.length+')':'' }}</el-button>
          <el-button type="text" size="mini" @click="editScript(scope.row,scope.$index)">脚本{{ scope.row.scriptData?'(1)':'' }}</el-button>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="80px" fixed="right" align="left">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="deleteRow(scope.$index)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="mt-10 mb-10">
      <el-button class="table-add-btn" @click="addRow" icon="el-icon-plus">添加</el-button>
    </div>
    <FunctionSettingDialog ref="functionRfc" v-show="functionDialogVisible" :dialog-data="selectRow" :visible.sync="functionDialogVisible" @finish="(val)=>updateRow(val)" />
    <ScriptSetting :dialog-form="selectRow" v-show="scriptDialogVisible" :visible.sync="scriptDialogVisible" @finish="(val)=>updateRow(val)" />
  </div>
</template>

<script>
import ScriptSetting from './dialog/scriptSetting'
import FunctionSettingDialog from '@/components/functionSetting/functionSettingDialog'
import { mapActions } from 'vuex'
export default {
  components: { FunctionSettingDialog, ScriptSetting },
  props: {
    tableList: {
      default: () => [],
      type: Array
    },
    title: {
      default: 'inParamTable',
      type: String
    }
  },
  data() {
    return {
      formData: {
        tableList: this.tableList
      },
      rules: {
        referenceType: [
          { required: true, message: '请选择赋值类型', trigger: 'change' }
        ],
        sourceName: [
          { required: true, message: '请输入取值参数名', trigger: 'blur' }
        ],
        destName: [
          { required: true, message: '请输入输出参数名', trigger: 'blur' }
        ],
        dataType: [
          { required: true, message: '请选择属性数据类型', trigger: 'change' }
        ]
      },
      DataTypeEnum: [],
      ParamReferenceTypeEnum: [],
      // MappingDictEnum: [],
      DataPosEnum: [],
      selectRow: {},
      selectIndex: null,
      functionDialogVisible: false,
      scriptDialogVisible: false
    }
  },
  watch: {
    tableList: {
      handler(nV) {
        if (nV) {
          this.formData.tableList = nV
          console.log(this.formData.tableList)
        }
      },
      immediate: true
    }
  },
  async created() {
    // this.getMappingDictEnum();
    [this.DataTypeEnum, this.ParamReferenceTypeEnum, this.DataPosEnum] = await this.getDicts([
      'DataTypeEnum',
      'ParamReferenceTypeEnum',
      'DataPosEnum'
    ])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    // async getMappingDictEnum() {
    //   const res = await mappingDictApi.getMappingDictAll()
    //   this.MappingDictEnum = res
    // },
    handleCurrentChange(row) {
      this.$emit('eventLinstener', {
        type: 'currentChange',
        row: row,
        list: this.tableList,
        title: this.title
      })
    },
    addRow() {
      this.$emit('eventLinstener', {
        type: 'add',
        title: this.title,
        list: this.tableList
      })
    },
    editFunction(row, index) {
      this.functionDialogVisible = true
      if (!row.functionList) row.functionList = []
      this.selectRow = row
      this.selectIndex = index
    },
    // 编辑脚本
    editScript(row, index) {
      this.scriptDialogVisible = true
      this.selectRow = row
      this.selectIndex = index
    },
    updateRow(formData) {
      this.$set(this.formData.tableList, this.selectIndex, formData)
      this.scriptDialogVisible = false
      this.functionDialogVisible = false
    },
    deleteRow(index) {
      this.$confirm(
        '确定删除此行吗? 删除不会提交数据，请点击【保存】提交',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      ).then(() => {
        this.formData.tableList.splice(index, 1)
      })
    },
    referenceTypeChange(v, row) {
      // 固定值不需要参数位置
      if (v === 0) {
        row.sourcePos = null
      }
    }
  }
}
</script>

<style scoped lang="scss">
table-add-btn {
  width: 100%;
}
</style>
