<template>
  <el-dialog :title="dialogTitle" :visible.sync="visible" :before-close="handleCancel" width="500px" append-to-body>
    <el-alert title="tips:响应结果不包含勾选字段" type="warning">
    </el-alert>
    <u-table class="table" :data="paramList" size="mini" ref="permissionTable" use-virtual height="400px" border show-body-overflow="tooltip">
      <u-table-column type="selection" width="50" />
      <u-table-column label="参数名" width="180" prop="paramName"></u-table-column>
      <u-table-column label="参数类型" width="100" prop="dataType">
        <template slot-scope="scope">
          {{code2Text(scope.row.dataType, DataTypeEnum)}}
        </template>
      </u-table-column>
      <u-table-column label="数组元素泛型" width="100" prop="generic">
        <template slot-scope="scope">
          {{code2Text(scope.row.generic, DataTypeEnum)}}
        </template>
      </u-table-column>
    </u-table>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">取 消</el-button>
      <el-button type="primary" @click="handleConfirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { mapActions } from 'vuex'
import arrangeApi from '@/api/arrange'
import { code2Text } from '@/utils'

export default {
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    list: {
      type: Array,
      default: () => []
    },
    dialogTitle: {
      type: String,
      default: '新增'
    },
    defineId: {
      type: Number
    }
  },
  data() {
    return {
      paramList: [],
      DataTypeEnum: [],
      code2Text
    }
  },
  async created() {},
  watch: {
    visible: {
      async handler(nV) {
        if (nV) {
          [this.DataTypeEnum] = await this.getDicts(['DataTypeEnum'])
          const resp = await this.getAllParams()
          this.paramList = resp.apiOutParamPathList
          this.setPermissionRows(this.paramList, this.list)
        }
      },
      immediate: true
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    async getAllParams() {
      return await arrangeApi.detailArrangeHead({
        definitionId: this.defineId
      })
    },
    async setPermissionRows(paramList, permissionList) {
      const selectionRows = []
      const permissionMap = new Map()
      permissionList.forEach((row, index) => {
        permissionMap.set(row.paramName, row)
      })
      paramList.forEach((row) => {
        if (permissionMap.has(row.paramName)) {
          selectionRows.push({ row, selected: true })
        }
      })
      await this.$nextTick()
      this.$refs.permissionTable.toggleRowSelection(selectionRows)
    },
    handleConfirm() {
      const selectionRows = this.$refs.permissionTable.getCheckboxRecords()
      this.$emit('confirm', selectionRows)
    },
    handleCancel() {
      this.$emit('update:visible', false)
    }
  }
}
</script>

<style scoped lang="scss">
.table{
  padding-bottom: 15px;
  border-bottom: 1px solid rgba(15, 29, 63, .1);
}
</style>
