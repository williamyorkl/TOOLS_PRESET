<template>
  <Fragment>
    <mc-form-item componentType="ElSelect" prop="jwtPos" label="JWT取值位置" dict="DataPosEnum" />
    <mc-form-item componentType="ElInput" prop="jwtName" label="JWT取值参数名" />
    <mc-form-item componentType="ElInput" prop="jwtKey" label="公钥" :span="24" :editProps="{type: 'textarea', rows: '5', maxlength: 2000}" />

    <el-col :span="24">
      <el-divider contentPosition="center">请求参数</el-divider>
      <JwtReqParamList :tableList="formData.definitionReqList" @eventLinstener="eventLinstener" />
    </el-col>
  </Fragment>
</template>

<script>
import { Fragment } from 'vue-fragment'
import { mapActions } from 'vuex'
import JwtReqParamList from './paramList/jwtReq'
import { RowParam } from '../../model/model'
import jwtExa from '../options/jwtExa'

export default {
  components: { JwtReqParamList, Fragment },
  props: {
    formData: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      sourceParamList: [],
      jwtExa
    }
  },
  async created() {
    await this.getDicts(['DataPosEnum'])
    console.log(this.formData)
  },
  mounted() {

  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    addRow(list, title) {
      list.push(new RowParam({}))
    },
    eventLinstener({ type, title, list }) {
      switch (type) {
        case 'add':
          this.addRow(list, title)
      }
    },
    onCopy() {
      this.$message.success('已复制到剪切板')
    },
    onError() {
      this.$message.error('复制失败')
    }
  }
}
</script>

<style scoped lang="scss">
.pre{
  padding: 10px;
  background: #f0f0f0;
  overflow: auto;
  position: relative;
  .el-icon-copy-document{
    position: absolute;
    right: 10px;
    top: 10px;
    cursor: pointer;
  }
}
</style>
