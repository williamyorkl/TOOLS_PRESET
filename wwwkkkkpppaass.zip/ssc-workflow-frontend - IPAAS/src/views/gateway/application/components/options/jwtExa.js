const jwtExa = String.raw`
String keyId = "uniq_key";
String privateKeyJson = "{\n" +
        "    \"p\": \"7YHGb9Hz7SpMRlJd9oaf7JEHE9_3X-ouiauQVjDePbzvBlrivOK1Kuz5Izk5KeeUAiHnwFak89E0dYVj3d-WO6LGXDZmx8AOHPQEHPihr8vQTueSkahce8tHBu8L-krUzZzn1HgJfECJKbw0dzcNi08uNrQmoQDnJzzqPnzaqgE\",\n" +
        "    \"kty\": \"RSA\",\n" +
        "    \"q\": \"jV-0O5t3L1STq_xHpLWMMmrvPM565vP-r7-SsMNbXTH4TGAFBFp24o-AFq8H3sSaCVbhc0g1ruizymsfz3Vyn6lg-3Dn8-THGOjkih_ndA2P957ACZmmlUim9RoRoZiTsAXnw1BEYZmZP7bfRf01Wrgc7Nms4ZPc0477Titb-ys\",\n" +
        "    \"d\": \"SxHlsXET-O_zujYovchXOCUhT_WmMA3w6QEe3FX8I9zSVqdwdZP-1FcpmThrRfu8AGXxXo8TYcGmWVRNZXKRrz1qlm_QZ5zQwtzLGHczktqiWcsdFcdwCR8ZZVHCie3cqPkk7NkJCFqNyQbdSZcvPBHOe12sMROCh7trS62EiIN1SqDoUC-bXQDp25-dcTkQBLU81ijP7Uy9HgIDCdpKxpf6SkbbciXMt1-xsfzVyE8NpqQzFkCkwbyFJ_NXWx5qWF3ryc6Dar0ws7XJYuiYmDC8oGPHEViXLLO8ctoVs-TMjaiboejrcT9JmbYKh6O0dSCVtNq_y4vcuCvbskxYAQ\",\n" +
        "    \"e\": \"AQAB\",\n" +
        "    \"kid\": \"uniq_key\",\n" +
        "    \"qi\": \"kjNa23aOHrSnoVp9od6pgtdM6YW7ZNzTOFhfhUb4eoEd0J5yDHanJBCLe4VWEz6UOGlStqelrwbjbUtqr5mV--qHV6jMfTuWFEzuF9t0L_tkT3aZ_rbDKoPrzxdmc7chOFp5P4r-5uHkbxjBk6YjuPJDF3oD-vKpdp7AvGmiwzw\",\n" +
        "    \"dp\": \"mA9ZY-gw2uwUz4UWoaqJo2Uq-d-PurntN7k-_N_mufJHunLf7fzb7vKvg4y0e47HpSHeBbezfmK3ynIvgTMQNXg-tXUjEsp0frcAFyhcJHhCEvKSVW1MYPnBrL_JlGLqogXOK6r6r7GF39GeaaE2q7VzKhTnEnfIhseqVX2MZgE\",\n" +
        "    \"alg\": \"RS256\",\n" +
        "    \"dq\": \"D2OhnPN5b9-HC6u0qMtSbZKSZE4dttJMoRj7gN5jLavo2XeCVEz8sADq8o0vECLambWpaQEtRtLx71Dl75FbXuHzOqu5tCTtP1rqtdZvPYTUbSIMyX6-UXXNJtUloi-XtAuQhQRRzUYJFpRzjYzYp_1uuKGhXhTYbvcbiBDUPG0\",\n" +
        "    \"n\": \"gylEqsbNxOxxzHG_2JZKOvgUWHFjlg1NJ46Y8OxAjGFIYXiPyvXcbmKQY5oYQhzCglAwu5q7hnFgBMSn9TBv1KR2x1RHaUnVcCSRNsq5u1Rue8kQ5AkMaVCsWAjmDMBlfb1ZDPCMOBjwXkTrYOAGPxiSvgE5t0y45ME-58AC_VEVbFbABMQCOV9YUKZZyl1ZrSTNi3I5Cp_l8Su-KMWSzdXmBpLIml32PDMu6sTqZ8X3My9lIYxLFYhd4-DN4E0FAKw1pnobPcEnul1g9G6hAi8g5nJTHP3epquIMdYaG1yXXmgVGpMbadDqVjSfchUXQUVX7I7lwwWi8oB_9sSJKw\"\n" +
        "}";
JwtClaims claims = new JwtClaims();
claims.setGeneratedJwtId();
claims.setIssuedAtToNow();
NumericDate date = NumericDate.now();
date.addSeconds(120*60);
claims.setExpirationTime(date);
claims.setNotBeforeMinutesInThePast(1);
claims.setSubject("YOUR_SUBJECT");
claims.setClaim("userId", "1213234");
claims.setClaim("name", "candy");
JsonWebSignature jws = new JsonWebSignature();
jws.setAlgorithmHeaderValue(AlgorithmIdentifiers.RSA_USING_SHA256);
jws.setKeyIdHeaderValue(keyId);
jws.setPayload(claims.toJson());
PrivateKey privateKey = new RsaJsonWebKey(JsonUtil.parseJson(privateKeyJson)).getPrivateKey();
jws.setKey(privateKey);
String jwtResult = jws.getCompactSerialization();
System.out.println("Generate Json Web token , result is " + jwtResult);`

export default jwtExa
