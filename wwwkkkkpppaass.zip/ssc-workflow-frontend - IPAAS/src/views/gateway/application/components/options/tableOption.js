import Constant from '@/config/constant'

export function getTableColumn(showOperate = true) {
  const tableColumn = [
    { label: 'API接口名称', prop: 'businessApiName', minWidth: '120px' },
    { label: '请求方式', prop: 'requestType', dict: 'MethodTypeEnum', minWidth: '120px' },
    { label: '接口请求URL', prop: 'requestUrl', minWidth: '120px' }
  ]
  if (showOperate) {
    tableColumn.push({
      prop: 'operate',
      label: '操作',
      width: '120px',
      btnList: [
        {
          text: '权限',
          eventType: Constant.PERMISSION
        },
        {
          text: '流控',
          eventType: Constant.LIMIT,
          hidden: (_row) => false
        },
        {
          text: '删除',
          eventType: Constant.DELETE,
          hidden: (_row) => false
        }
      ]
    })
  }

  return tableColumn
}
