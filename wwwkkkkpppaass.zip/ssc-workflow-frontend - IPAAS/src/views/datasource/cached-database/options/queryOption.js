export function getQueryList({ UsableEnum = [], CacheSourceTypeEnum = [] }) {
  const queryList = [
    // 筛选条件初始化
    // {
    //   key: 'dataBaseCode',
    //   label: '数据库编码',
    //   queryType: 'input'
    // },
    {
      key: 'sourceName',
      label: '数据源名称',
      queryType: 'input'
    },
    {
      key: 'usable',
      label: '状态',
      queryType: 'select',
      list: UsableEnum,
      valueKey: 'type',
      labelKey: 'desc'
    },
    {
      key: 'sourceType',
      label: '数据源类型',
      queryType: 'select',
      list: CacheSourceTypeEnum,
      valueKey: 'type',
      labelKey: 'desc'
    }
  ]

  return queryList
}
