import Constant from '@/config/constant'
import { formatTime } from '@/utils'

export function getTableColumn() {
  const tableColumn = [
    // { label: '数据库编码', prop: 'dataBaseCode', minWidth: '120px' },  // NOTE - 按业务需要暂时干掉
    { label: '数据源名称', prop: 'sourceName', minWidth: '120px' },
    { label: '用户名', prop: 'userName', minWidth: '80px' },
    { label: '服务器地址', prop: 'sourceUrl', minWidth: '180px' },
    { label: '数据源类型', prop: 'sourceType', dict: 'CacheSourceTypeEnum', minWidth: '100px' },
    { label: '状态', prop: 'usable', dict: 'UsableEnum', minWidth: '80px' },
    // { label: 'IP', prop: 'host', minWidth: '120px' },      // NOTE - 按业务需要暂时干掉
    // { label: '端口号', prop: 'port', minWidth: '120px' },   // NOTE - 按业务需要暂时干掉
    { label: '创建人', prop: 'createByName', minWidth: '120px' },
    {
      label: '创建时间',
      prop: 'createTime',
      minWidth: '140px',
      formatter(row, _column) {
        return formatTime(row.createTime)
      }
    },
    { label: '更新人', prop: 'updateByName' },
    {
      label: '更新时间',
      prop: 'updateTime',
      minWidth: '140px',
      formatter(row, _column) {
        return formatTime(row.updateTime)
      }
    },
    {
      prop: 'operate',
      label: '操作',
      width: 50,
      btnList: [
        {
          text: '编辑',
          eventType: Constant.EDIT,
          hidden: (_row) => false
        }
        // {
        //   text: '删除',
        //   eventType: Constant.DELETE,
        //   hidden: (row) => false
        // }
      ]
    }
  ]

  return tableColumn
}
