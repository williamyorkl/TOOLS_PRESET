export class FormData {
  constructor() {
    this.sourceName = ''
    this.sourceType = null
    this.sourceUrl = ''
    this.id = null
    this.password = ''
    this.remark = ''
    this.usable = null
    this.timeout = null
    this.userName = ''
    // this.oracleSchema = null
    this.paramList = []
  }
}

export class ObjData {
  constructor() {
    this.key = ''
    this.value = ''
  }
}
