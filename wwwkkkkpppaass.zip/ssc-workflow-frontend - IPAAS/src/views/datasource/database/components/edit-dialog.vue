<template>
  <el-dialog class="common-dialog" :title="title" :visible.sync="visible" :width="width" :before-close="handleClose" v-if="visible">
    <mc-form ref="form" :model="formData" :rules="rules">
      <mc-form-item componentType="ElInput" prop="dataBaseCode" label="数据库编码" :disabled="true" :editProps="{placeholder: '自动生成'}"></mc-form-item>
      <mc-form-item componentType="ElInput" validProp="dataBaseName" prop="dataBaseName" label="数据库名称"></mc-form-item>
      <mc-form-item componentType="ElSelect" prop="dataBaseType" label="数据库类型" dict="DbTypeEnum"></mc-form-item>
      <mc-form-item componentType="ElInput" prop="dataBaseUrl" label="服务器地址" :editProps="{maxlength: 255, placeholder: '例：jdbc:mysql://192.168.101.167:3306/lcdp_demo'}"></mc-form-item>
      <mc-form-item componentType="ElInput" prop="userName" label="用户名"></mc-form-item>
      <mc-form-item componentType="ElInput" prop="passWord" label="密码" :editProps="{type: 'password'}"></mc-form-item>
      <mc-form-item componentType="ElSelect" prop="usable" label="状态" dict="UsableEnum"></mc-form-item>
      <mc-form-item componentType="ElInputNumber" prop="timeOut" label="超时时间(ms)"></mc-form-item>
      <mc-form-item componentType="ElInput" prop="oracleSchema" label="schema" :rules="oracle_schemaRules" v-if="formData.dataBaseType === 2 || formData.dataBaseType === 3" :editProps="{
        placeholder: formData.dataBaseType === 2 ? '请输入schema' : '默认dbo'
      }"></mc-form-item>
      <mc-form-item componentType="ElInput" prop="remark" label="描述" :editProps="{type: 'textarea'}" :span="24"></mc-form-item>
      <mc-form-item label="更多连接配置" :span="24" :editProps="{a: 1}">
        <mc-list :list="formData.paramList" @handleAdd="handleAdd">
          <template slot-scope="scope">
            <mc-form-item label="key" :span="12" :validProp="'paramList.' + scope.index + '.key'" :rules="rules.key">
              <el-select v-model.trim="scope.item.key" filterable allow-create placeholder="请选择或直接输入值" @change="keyChange($event, scope.item)">
                <el-option v-for="item in DsConfigEnum" :key="item.type" :label="item.desc" :value="item.desc"></el-option>
              </el-select>
            </mc-form-item>
            <mc-form-item label="value" :span="12" :validProp="'paramList.' + scope.index + '.value'" :rules="rules.value">
              <el-input v-model.trim="scope.item.value" maxlength="32" />
            </mc-form-item>
          </template>
        </mc-list>
      </mc-form-item>

    </mc-form>
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="connectServer">测试连接</el-button>
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" @click="confirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { mapActions } from 'vuex'
import Constant from '@/config/constant'
import { regExpRules, validateFn } from '@/utils/validator'
import { ObjData } from '../model/model'
export default {
  name: 'EditDialog',
  props: {
    visible: {
      default: false,
      type: Boolean
    },
    title: {
      default: '新增',
      type: String
    },
    width: {
      default: '30%',
      type: String
    },
    formData: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      DsConfigEnum: [],
      rules: {
        dataBaseName: [
          { required: true, message: '请填写数据库名称', trigger: 'blur' }
        ],
        dataBaseType: [
          { required: true, message: '请选择数据库类型', trigger: 'change' }
        ],
        dataBaseUrl: [
          { required: true, message: '请填写服务器地址', trigger: 'blur' }
        ],
        userName: [
          { required: true, message: '请填写用户名', trigger: 'blur' }
        ],
        passWord: [{ required: true, message: '请填写密码', trigger: 'blur' }],
        usable: [{ required: true, message: '请选择状态', trigger: 'change' }],
        timeOut: [
          { required: true, message: '请填写超时时间', trigger: 'blur' }, { type: 'number', message: '请填写数字', trigger: 'blur' },
          { validator: validateFn.checkNum({ min: 0, max: 2147483647, notNull: true, isPositiveNumber: true }), trigger: 'change' }
        ],
        key: [
          { required: true, message: '请选择或输入key', trigger: 'blur' },
          { validator: validateFn.checkLength({ minlength: 1, maxlength: 128 }), trigger: 'change' }
        ],
        value: [
          { required: true, message: '请填写value', trigger: 'blur' }

        ]
        // oracleSchema: [
        //   { required: true, message: '请填写schema', trigger: 'blur' }
        // ]
      }
    }
  },
  watch: {
    visible(nV) {
      if (nV && this.$refs.form) {
        this.$refs.form.clearValidate()
      }
    }
  },
  async created() {
    [this.DsConfigEnum] = await this.getDicts(['DsConfigEnum'])
  },
  computed: {
    oracle_schemaRules() {
      if (this.formData.dataBaseType === 2) {
        return { required: true, message: '请填写schema', trigger: 'blur' }
      } else {
        return {}
      }
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    keyChange(v, row) {
      if (v) {
        row.key = v.trim()
      }
    },
    handleClose(done) {
      this.$emit('update:visible', false)
    },
    confirm() {
      this.$refs.form.validate().then((valid) => {
        if (valid) {
          this.$emit('eventListener', Constant.COMMIT, this.formData)
        } else {
          this.$message.error('请按照提示完善表单数据')
        }
      })
    },
    connectServer() {
      this.$refs.form.validate().then((valid) => {
        if (valid) {
          this.$emit('eventListener', Constant.CONNECT, this.formData)
        } else {
          this.$message.error('请按照提示完善表单数据')
        }
      })
    },
    handleAdd() {
      this.formData.paramList.push(new ObjData())
    }
  }
}
</script>

<style scoped lang="scss">
.common-dialog {
  ::v-deep .reduce-box{
    line-height: 40px;
    display: block;
  }
}
</style>
