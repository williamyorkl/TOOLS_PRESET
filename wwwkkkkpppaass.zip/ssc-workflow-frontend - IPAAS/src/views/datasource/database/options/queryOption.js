export function getQueryList({ UsableEnum = [], DbTypeEnum = [] }) {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'dataBaseCode',
      label: '数据库编码',
      queryType: 'input'
    },
    {
      key: 'dataBaseName',
      label: '数据库名称',
      queryType: 'input'
    },
    {
      key: 'usable',
      label: '状态',
      queryType: 'select',
      list: UsableEnum,
      valueKey: 'type',
      labelKey: 'desc'
    },
    {
      key: 'dataBaseType',
      label: '数据库类型',
      queryType: 'select',
      list: DbTypeEnum,
      valueKey: 'type',
      labelKey: 'desc'
    }
  ]

  return queryList
}
