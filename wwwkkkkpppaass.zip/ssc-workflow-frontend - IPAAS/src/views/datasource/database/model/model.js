export class FormData {
  constructor() {
    this.dataBaseCode = ''
    this.dataBaseName = ''
    this.dataBaseType = null
    this.dataBaseUrl = ''
    this.id = null
    this.passWord = ''
    this.remark = ''
    this.usable = null
    this.timeOut = null
    this.userName = ''
    this.oracleSchema = null
    this.paramList = []
  }
}

export class ObjData {
  constructor() {
    this.key = ''
    this.value = ''
  }
}
