export class FormData {
  constructor() {
    this.id = null
    this.mqServerUrl = ''
    this.mqType = null
    this.name = ''
    this.kafkaBrokers = null
    this.kafkaConnector = null
  }
}
