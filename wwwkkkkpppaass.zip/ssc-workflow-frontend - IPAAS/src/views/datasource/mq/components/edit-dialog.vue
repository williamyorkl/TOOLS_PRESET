<template>
  <el-dialog :title="title" :visible.sync="visible" :width="width" :before-close="handleClose">
    <mc-form ref="form" :model="formData" :rules="rules" label-width="110px">
      <mc-form-item componentType="ElInput" prop="name" label="MQ名称"></mc-form-item>
      <mc-form-item componentType="ElSelect" prop="mqType" label="MQ类型" dict="MqTypeEnum"></mc-form-item>
      <mc-form-item v-if="formData.mqType === 1 || formData.mqType === 3" componentType="ElInput" prop="mqServerUrl" label="MQ Server地址"></mc-form-item>
      <mc-form-item v-if="formData.mqType === 2" componentType="ElInput" prop="kafkaBrokers" label="kafkaBrokers" :editProps="{maxlength: 512, type: 'textarea'}" :span="24"></mc-form-item>
      <mc-form-item v-if="formData.mqType === 2" componentType="ElInput" prop="kafkaConnector" label="kafkaConnector"></mc-form-item>
      <mc-form-item v-if="formData.mqType === 3" componentType="ElInput" prop="userName" label="账号"></mc-form-item>
      <mc-form-item v-if="formData.mqType === 3" componentType="ElInput" prop="passWord" label="密码"></mc-form-item>
    </mc-form>
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="connectServer">测试连接</el-button>
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" @click="confirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import Constant from '@/config/constant'
export default {
  name: 'EditDialog',
  props: {
    visible: {
      default: false,
      type: Boolean
    },
    title: {
      default: '新增',
      type: String
    },
    width: {
      default: '30%',
      type: String
    },
    formData: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请填写MQ名称', trigger: 'blur' }
        ],
        mqServerUrl: [
          { required: true, message: '请填写MQ Server 地址', trigger: 'blur' }
        ],
        mqType: [
          { required: true, message: '请选择MQ类型', trigger: 'change' }
        ],
        kafkaBrokers: [
          { required: true, message: '请填写kafkaBrokers', trigger: 'blur' }
        ],
        kafkaConnector: [
          { required: true, message: '请填写kafkaConnector', trigger: 'blur' }
        ],
        userName: [
          { required: true, message: '请填写账号', trigger: 'blur' }
        ],
        passWord: [
          { required: true, message: '请填写密码', trigger: 'blur' }
        ]
      }
    }
  },
  watch: {
    visible(nV) {
      if (nV && this.$refs.form) {
        this.$refs.form.clearValidate()
      }
    }
  },
  methods: {
    handleClose(done) {
      this.$emit('update:visible', false)
    },
    connectServer() {
      this.$refs.form.validate().then((valid) => {
        if (valid) {
          this.$emit('eventListener', Constant.CONNECT, this.formData)
        } else {
          this.$message.error('请按照提示完善表单数据')
        }
      })
    },
    confirm() {
      this.$refs.form.validate()
        .then(valid => {
          if (valid) {
            this.$emit('eventListener', Constant.COMMIT, this.formData)
          } else {
            this.$message.error('请按照提示完善表单数据')
          }
        })
    }
  }
}
</script>
