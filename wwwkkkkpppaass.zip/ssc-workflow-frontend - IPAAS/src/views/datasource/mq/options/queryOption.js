export function getQueryList({ MqTypeEnum = [] }) {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'name',
      label: 'MQ名称',
      queryType: 'input'
    },
    {
      key: 'mqType',
      label: 'MQ类型',
      queryType: 'select',
      list: MqTypeEnum,
      valueKey: 'type',
      labelKey: 'desc'
    },
    {
      endKey: 'endTime',
      startKey: 'startTime',
      label: '创建时间',
      queryType: 'elDateRange',
      valueFormat: 'yyyy-MM-dd HH:mm:ss'
    }
  ]

  return queryList
}
