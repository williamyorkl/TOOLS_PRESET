import Constant from '@/config/constant'
import { formatTime } from '@/utils'
export function getTableColumn() {
  const tableColumn = [
    { label: 'MQ名称', prop: 'name' },
    { label: 'MQ类型', prop: 'mqType', dict: 'MqTypeEnum' },
    { label: 'MQ Server地址', prop: 'mqServerUrl', width: '120' },
    { label: 'kafkaBrokers', prop: 'kafkaBrokers', width: '120' },
    { label: 'kafkaConnector', prop: 'kafkaConnector', width: '120' },
    { label: '创建人', prop: 'createByName' },
    {
      label: '创建时间',
      prop: 'createTime',
      minWidth: '140px',
      formatter(row, column) {
        return formatTime(row.createTime)
      }
    },
    { label: '更新人', prop: 'updateByName' },
    {
      label: '更新时间',
      prop: 'updateTime',
      minWidth: '140px',
      formatter(row, column) {
        return formatTime(row.updateTime)
      }
    },
    {
      prop: 'operate',
      label: '操作',
      width: 50,
      btnList: [
        {
          text: '编辑',
          eventType: Constant.EDIT,
          hidden: (row) => false
        }
        // {
        //   text: '删除',
        //   eventType: Constant.DELETE,
        //   hidden: (row) => false
        // }
      ]
    }
  ]

  return tableColumn
}
