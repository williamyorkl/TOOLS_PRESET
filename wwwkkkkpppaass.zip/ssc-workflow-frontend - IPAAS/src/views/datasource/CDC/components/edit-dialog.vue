<template>
  <el-dialog :title="title" :visible.sync="visible" :width="width" :beforeClose="handleClose" v-if="visible">
    <mc-form ref="form" :model="formData" :rules="rules">
      <mc-form-item componentType="ElInput" prop="name" label="CDC名称" />
      <mc-form-item componentType="ElSelect" prop="type" label="类型" dict="CdcTypeEnum" />
      <mc-form-item componentType="McPopoverSelect" prop="mqId" label="MQ数据源" :editProps="{
        defaultValue: (formData.mqConfigDto || {}).name,
        apiFunc: mqListApiFunc,
        tableColumn: mqTableColumn,
        queryList: mqQueryList,
        labelKey: 'name',
        param: {
          mqType: 2
        }
      }"
      >
        <mc-form-item-label slot="label" label="MQ数据源" icon="el-icon-info">
          kafka必须要配置Connector连接地址
        </mc-form-item-label>
      </mc-form-item>
      <mc-form-item componentType="McPopoverSelect" prop="dbId" label="DB数据源" @change="dbIdChange" :editProps="{
        defaultValue: (formData.flowDataBase || {}).dataBaseName,
        apiFunc: dbListApiFunc,
        tableColumn: dbTableColumn,
        queryList: dbQueryList,
        labelKey: 'dataBaseName',
        param: {usable: true}
      }"
      >
        <mc-form-item-label slot="label" label="DB数据源" icon="el-icon-info">
          目前只支持MySQL（必须开启binlog、binlog_format是行模式ROW）和Oracle（日志模式必须是 ARCHIVELOG）
        </mc-form-item-label>
      </mc-form-item>
      <mc-form-item componentType="McPopoverSelect" prop="includeTable" label="数据库表" :disabled="!formData.dbId" :editProps="{
        defaultValue: formData.includeTable,
        apiFunc: tableApiFunc,
        tableColumn: tableTableColumn,
        queryList: tableQueryList,
        labelKey: 'tableName',
        valueKey: 'tableName',
        param: {
          id: formData.dbId
        }
      }"
      />
    </mc-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" @click="confirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import Constant from '@/config/constant'
import mqApi from '@/api/mq'
import dbApi from '@/api/database'
import { FormData } from '../model/model'
import { getTableColumn as getMqTableColumn, getQueryList as getMqQueryList } from '@/config/popContentTableConfig/mq.config'
import { getTableColumn as getDbTableColumn, getQueryList as getDbQueryList } from '@/config/popContentTableConfig/db.config'
import tablesOption from '@/config/popContentTableConfig/table.config.js'
export default {
  name: 'EditDialog',
  props: {
    visible: {
      default: false,
      type: Boolean
    },
    title: {
      default: '新增',
      type: String
    },
    width: {
      default: '30%',
      type: String
    },
    formData: {
      type: Object,
      default: () => new FormData()
    }
  },
  data() {
    return {
      mqListApiFunc: mqApi.getMqList,
      mqTableColumn: getMqTableColumn(),
      mqQueryList: getMqQueryList(),
      dbListApiFunc: dbApi.getDatabaseList,
      dbTableColumn: getDbTableColumn(),
      dbQueryList: getDbQueryList(),
      tableApiFunc: tablesOption.apiFunc,
      tableTableColumn: tablesOption.getTableColumn(),
      tableQueryList: tablesOption.getQueryList(),
      rules: {
        name: [
          { required: true, message: '请输入CDC名称', trigger: 'blur' },
          { min: 1, max: 50, message: '长度在50个字符', trigger: 'blur' }
        ],
        type: [
          { required: true, message: '请选择类型', trigger: 'change' }
        ],
        mqId: [
          { required: true, message: '请选择MQ数据源', trigger: 'change' }
        ],
        dbId: [
          { required: true, message: '请选择DB数据源', trigger: 'change' }
        ],
        includeTable: [
          { required: true, message: '请选择数据表', trigger: 'change' }
        ]
      }
    }
  },
  watch: {
    visible(nV) {
      if (nV && this.$refs.form) {
        this.$refs.form.clearValidate()
      }
    }
  },
  methods: {
    dbIdChange(_row) {
      console.log('dbidchange')
      this.formData.includeTable = ''
    },
    handleClose(_done) {
      this.$emit('update:visible', false)
    },
    confirm() {
      this.$refs.form.validate()
        .then(valid => {
          if (valid) {
            this.$emit('eventListener', Constant.COMMIT, this.formData)
          } else {
            this.$message.error('请按照提示完善表单数据')
          }
        })
    }
  }
}
</script>
