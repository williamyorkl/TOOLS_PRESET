export class FormData {
  constructor() {
    this.dbId = null
    this.id = null
    this.includeTable = null
    this.mqId = null
    this.name = null
    this.type = null
    this.flowDataBase = { dataBaseName: null }
    this.mqConfigDto = { name: null }
  }
}
