export function getQueryList({ CdcTypeEnum = [] }) {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'name',
      label: 'CDC名称',
      queryType: 'input'
    },
    {
      key: 'type',
      label: '类型',
      queryType: 'select',
      list: CdcTypeEnum,
      valueKey: 'type',
      labelKey: 'desc'
    }
  ]

  return queryList
}
