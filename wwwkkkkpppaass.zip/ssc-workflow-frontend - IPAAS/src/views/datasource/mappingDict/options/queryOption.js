export function getQueryList({ DictMapSrcTypeEnum = [], DataBaseEnum = [] }) {
  const queryList = [
    // 筛选条件初始化
    {
      key: 'name',
      label: '映射名称',
      queryType: 'input'
    },
    {
      key: 'dictMapSrcType',
      label: '映射结果来源',
      queryType: 'select',
      list: DictMapSrcTypeEnum,
      valueKey: 'type',
      labelKey: 'desc'
    }
  ]

  return queryList
}
