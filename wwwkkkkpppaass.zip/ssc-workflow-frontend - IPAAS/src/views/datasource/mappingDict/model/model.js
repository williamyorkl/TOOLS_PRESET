import { getUUID } from '@/utils'

export class FormData {
  constructor({ dictMapSrcType }) {
    this.id = null
    this.name = null
    this.dictMapSrcType = dictMapSrcType // 映射结果来源
    this.cacheTime = null // 缓存时间
    if (this.dictMapSrcType === 1) {
      this.sqlDto = new SqlDto()
    }
    if (this.dictMapSrcType === 2) {
      this.apiDto = new ApiDto()
    }
  }
}

export class ApiDto {
  constructor() {
    this.businessApiName = null
    this.requestType = null
    this.requestUrl = null
    this.defineId = null // ?
    this.varList = []
    this.dictMappingReqList = []
    this.dictMappingRespList = []
  }
}

export class SqlDto {
  constructor() {
    this.dbId = null
    this.dataBaseName = null
    this.timeOut = null
    this.isInputSql = null
    this.textSql = null
    this.sqlMethod = 'select'
    this.tableName = null

    this.varList = []
    this.referenceFieldList = []
    this.selectFieldList = []
    this.updateFieldList = []
    this.whereFieldList = []
    this.sortFieldList = []
    this.pageFieldList = []
  }
}

export class RowParam {
  constructor() {
    this.dataType = null // 数据类型
    this.destName = null // 目标字段
    this.destPos = null// 目标位置
    this.funcData = [] // 函数
    this.referenceType = null // 赋值类型
    this.scriptData = null // 脚本
    this.sourceName = null // 取值参数路径名
    this.sourcePos = null // 取值位置
  }
}

export class DictMappingReq {
  constructor() {
    this.sourceName = null
    this.referenceType = 0
    this.scriptData = null
    this.functionList = []
    this.dataType = null
    this.destName = null
    this.destPos = null
    // this.sourceVal = {}
  }
}

export class DictMappingResp {
  constructor() {
    this.sourceName = null
    this.dataType = null
    this.functionList = []
    this.scriptData = null
    this.referenceType = null
    this.destName = null
  }
}

// func
export class Func {
  constructor() {
    this.express = null
    this.parameters = []
    this.scope = null
  }
}

export class Variable {
  constructor() {
    this.dataType = null
    this.varName = null
    this.desc = null
  }
}

// DB:where字段
export class WhereField {
  constructor() {
    this.dataType = null
    this.fieldName = ''
    this.logicalOperator = ''
    this.isGroup = 1
    this.nodeKey = ''
    this.nodeKey1 = ''
    this.operator = null
    this.type = null
    this.type1 = null
    this.value = ''
    this.value1 = ''
    this.rowKey = getUUID()
    this.groups = []
  }
}

// DB: 查询字段
export class SelectField {
  constructor({ fieldName, dataType }) {
    this.dataType = dataType
    this.fieldName = fieldName
  }
}

// DB:排序字段
export class SortField {
  constructor() {
    this.direction = null
    this.field = null
  }
}
