<template>
  <div class="table-form" ref="mappingForm" :model="formData" :rules="rules" label-width="0px" size="mini">
    <el-table ref="mappingTable" :data="formData.tableList" highlight-current-row style="width: 100%" max-height="250">

      <el-table-column label="序号" type="index" align="left" width="60"></el-table-column>

      <el-table-column label="表字段" align="left">
        <template slot-scope="scope">
          <el-form-item>
            <el-input v-model.trim="scope.row.fieldName" placeholder="请输入表字段" :disabled="true"></el-input>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="属性数据类型"  min-width="200">
        <template slot-scope="scope">
          <el-form-item :rules="rules.dataType" :prop="'selectFieldList.' + scope.$index + '.dataType'">
            <el-select v-model="scope.row.dataType" placeholder="请选择属性数据类型"  :disabled="formDisabled">
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type">
              </el-option>
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import { mapActions } from 'vuex'
export default {
  props: {
    tableList: {
      default: () => [],
      type: Array
    },
    title: {
      default: 'inParamTable',
      type: String
    },
    formDisabled: {
      default: false,
      type: Boolean
    }
  },
  data() {
    return {
      formData: {
        tableList: []
      },
      rules: {
        dataType: [
          { required: true, message: '请选择属性数据类型', trigger: 'change' }
        ]
      },
      DataTypeEnum: []
    }
  },
  watch: {
    tableList: {
      handler(nV) {
        if (nV) {
          this.formData.tableList = nV
          console.log(this.formData)
        }
      },
      immediate: true
    }
  },
  async created() {
    [this.DataTypeEnum] = await this.getDicts([
      'DataTypeEnum'
    ])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    addRow() {
      this.$emit('eventLinstener', {
        type: 'add',
        title: this.title,
        list: this.tableList
      })
    },
    deleteRow(index) {
      this.$confirm(
        '确定删除此行吗? 删除不会提交数据，请点击【保存】提交',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      ).then(() => {
        this.formData.tableList.splice(index, 1)
      })
    }
  }
}
</script>

<style scoped lang="scss">
table-add-btn {
  width: 100%;
}
</style>
