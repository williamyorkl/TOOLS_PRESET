// 参数列表
<template>
  <div class="table-form" ref="mappingForm" :model="formData" :rules="rules" label-width="0px" size="mini">
    <el-table ref="mappingTable" :data="formData.tableList" highlight-current-row @current-change="handleCurrentChange" style="width: 100%" max-height="300px">

      <el-table-column label="序号" type="index" align="left" width="60"></el-table-column>

      <el-table-column label="变量名称" min-width="200px">
        <template slot-scope="scope">
          <el-form-item :rules="rules.varName" :prop="'varList.' + scope.$index + '.varName'">
            <el-input v-model.trim="scope.row.varName" placeholder="请输入内容"></el-input>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="数据类型" min-width="160px">
        <template slot-scope="scope">
          <el-form-item :rules="rules.dataType" :prop="'varList.' + scope.$index + '.dataType'">
            <el-select v-model="scope.row.dataType" placeholder="请选择属性数据类型">
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type" :disabled="[7,8].includes(item.type)">
              </el-option>
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="描述" min-width="200px">
        <template slot-scope="scope">
          <el-form-item>
            <el-input v-model.trim="scope.row.desc" placeholder="请输入描述"></el-input>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="操作" min-width="80px" align="left" v-if="!formDisabled" fixed="right">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="deleteRow(scope.$index)">删除</el-button>

        </template>
      </el-table-column>
    </el-table>
    <div class="mt-10 mb-10">
      <el-button class="table-add-btn" @click="addRow" icon="el-icon-plus">添加</el-button>
    </div>
  </div>
</template>

<script>
import { mapActions } from 'vuex'
export default {
  props: {
    tableList: {
      default: () => [],
      type: Array
    },
    title: {
      default: 'inParamTable',
      type: String
    },
    varList: {
      default: () => [],
      type: Array
    },
    formDisabled: {
      default: false,
      type: Boolean
    }
  },
  data() {
    return {
      formData: {
        tableList: this.tableList
      },
      rules: {
        varName: [
          { required: true, message: '请输入变量名称', trigger: 'blur' }
        ],
        dataType: [
          { required: true, message: '请选择数据类型', trigger: 'change' }
        ]
      },
      DataTypeEnum: []
    }
  },
  watch: {
    tableList: {
      handler(nV) {
        if (nV) {
          this.formData.tableList = nV
          console.log(this.formData.tableList)
        }
      },
      immediate: true
    }
  },
  async created() {
    [this.DataTypeEnum] = await this.getDicts(['DataTypeEnum'])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    handleCurrentChange(row) {
      this.$emit('eventLinstener', {
        type: 'currentChange',
        row: row,
        list: this.tableList,
        title: this.title
      })
    },
    addRow() {
      this.$emit('eventLinstener', {
        type: 'add',
        title: this.title,
        list: this.tableList
      })
    },
    deleteRow(index) {
      this.$confirm(
        '确定删除此行吗? 删除不会提交数据，请点击【保存】提交',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      ).then(() => {
        this.formData.tableList.splice(index, 1)
      })
    }
  }
}
</script>

<style scoped lang="scss">
table-add-btn {
  width: 100%;
}
</style>
