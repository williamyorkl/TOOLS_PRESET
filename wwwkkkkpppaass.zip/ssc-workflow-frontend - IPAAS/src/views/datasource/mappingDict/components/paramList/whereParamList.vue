<template>
  <div class="table-form" ref="mappingForm" :model="formData" :rules="rules" label-width="0px" size="mini" :disabled="formDisabled">
    <el-table ref="mappingTable" row-key="rowKey" :data="formData.tableList" default-expand-all :tree-props="{children: 'groups'}" highlight-current-row style="width: 100%" max-height="250" :indent='8'>

      <el-table-column label="序号" prop="paramName" width="60">
        <template slot-scope="scope">
          {{scope.$index + 1}}
        </template>
      </el-table-column>

      <el-table-column label="逻辑符号" align="left" min-width="130">
        <template slot-scope="scope">
          <el-form-item :rules="rules.logicalOperator" :prop="'whereFieldList.' + scope.$index + '.logicalOperator'">
            <el-select v-model="scope.row.logicalOperator">
              <el-option v-for="item in DbSqlLogicalEnum" :key="item.desc" :label="item.desc" :value="item.desc"></el-option>
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="是否分组" align="left" min-width="130">
        <template slot-scope="scope">
          <el-form-item :rules="rules.isGroup" :prop="'whereFieldList.' + scope.$index + '.isGroup'">
            <el-select v-model="scope.row.isGroup" @change="isGroupChange($event,  scope.row)">
              <el-option v-for="item in YesNoEnum" :key="item.desc" :label="item.desc" :value="item.type"></el-option>
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="表字段" align="left" min-width="200">
        <template slot-scope="scope">
          <el-form-item :rules="rules.fieldName(scope.row)" :prop="'whereFieldList.' + scope.$index + '.fieldName'">
            <el-select v-model="scope.row.fieldName" :disabled="scope.row.isGroup === 2" @change="fieldChange($event, scope.row)" :filterable="true">
              <el-option v-for="item in columnList" :key="item.name" :label="item.name" :value="item.name"></el-option>
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="属性数据类型" min-width="200">
        <template slot-scope="scope">
          <el-form-item :rules="rules.dataType(scope.row)" :prop="'whereFieldList.' + scope.$index + '.dataType'">
            <el-select v-model="scope.row.dataType" placeholder="请选择属性数据类型" :disabled="true" @change="dataTypeChange(scope.row)">
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type">
              </el-option>
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="条件符" align="left" min-width="160">
        <template slot-scope="scope">
          <el-form-item :rules="rules.operator(scope.row)" :prop="'whereFieldList.' + scope.$index + '.operator'">
            <el-select v-model="scope.row.operator" @change="operaChange(scope.row)" :disabled="scope.row.isGroup === 2">
              <el-option v-for="item in DbOperatorEnum" :key="item.type" :label="item.desc" :value="item.type"></el-option>
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="值" min-width="200">
        <template slot-scope="scope">
          <el-form-item :rules="rules.value(scope.row)" :prop="'whereFieldList.' + scope.$index + '.value'">
            <el-select v-model="scope.row.value" :disabled="scope.row.isGroup === 2">
              <el-option v-for="item in varList" :key="item.varName" :label="item.varName" :value="item.varName"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item v-if="scope.row.operator === 11" :rules="rules.value1(scope.row)" :prop="'whereFieldList.' + scope.$index + '.value1'">
            <el-select v-model="scope.row.value1" :disabled="scope.row.isGroup === 2">
              <el-option v-for="item in varList" :key="item.varName" :label="item.varName" :value="item.varName"></el-option>
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="操作" width="150px" align="left" v-if="!formDisabled" fixed="right">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="addChildRow(scope.row)" :disabled="scope.row.isGroup !== 2">添加</el-button>
          <el-button type="text" size="mini" @click="deleteRow(scope.row, scope.$index)">删除</el-button>

        </template>
      </el-table-column>
    </el-table>
    <div class="mt-10 mb-10" v-if="!formDisabled">
      <el-button class="table-add-btn" @click="addRow" icon="el-icon-plus">添加</el-button>
    </div>
  </div>
</template>

<script>
import { mapActions } from 'vuex'

let currentIndex = null // 针对between情况，标识当前修改的是0还是1的数据
export default {
  props: {
    tableList: {
      default: () => [],
      type: Array
    },
    title: {
      default: 'inParamTable',
      type: String
    },
    columnList: {
      default: () => [],
      type: Array
    },
    columnMap: {
      default: () => new Map(),
      type: Map
    },
    sqlMethod: {
      type: String,
      default: 'insert'
    },
    nodeId: {
    },
    formDisabled: {
      default: false,
      type: Boolean
    },
    varList: {
      default: () => [],
      type: Array
    }
  },
  data() {
    return {
      formData: {
        tableList: []
      },
      rules: {
        logicalOperator: [
          { required: true, message: '请选择逻辑运算符', trigger: 'change' }
        ],
        isGroup: [
          { required: true, message: '请选择是否分组', trigger: 'change' }
        ],
        fieldName: (row) => {
          if (row.isGroup === 1) {
            return [
              { required: true, message: '请选择表字段', trigger: 'change' }
            ]
          } else {
            return []
          }
        },
        dataType: (row) => {
          if (row.isGroup === 1) {
            return [
              { required: true, message: '请选择属性数据类型', trigger: 'change' }
            ]
          } else {
            return []
          }
        },
        operator: (row) => {
          if (row.isGroup === 1) {
            return [
              { required: true, message: '请选择条件符', trigger: 'change' }
            ]
          } else {
            return []
          }
        },
        value: (row) => {
          if (row.isGroup === 1) {
            return [
              { required: true, message: '请选择值', trigger: 'change' }
            ]
          } else {
            return []
          }
        },
        value1: (row) => {
          if (row.isGroup === 1) {
            return [
              { required: true, message: '请选择值', trigger: 'change' }
            ]
          } else {
            return []
          }
        }
      },
      DataTypeEnum: [],
      DbSqlLogicalEnum: [],
      YesNoEnum: [],
      DbOperatorEnum: [],
      ParamReferenceTypeEnum: []
    }
  },
  watch: {
    tableList: {
      handler(nV) {
        if (nV) {
          this.formData.tableList = nV
        }
      },
      immediate: true
    }
  },
  async created() {
    [this.YesNoEnum, this.DataTypeEnum, this.DbSqlLogicalEnum, this.DbOperatorEnum, this.ParamReferenceTypeEnum] = await this.getDicts([
      'YesNoEnum',
      'DataTypeEnum',
      'DbSqlLogicalEnum',
      'DbOperatorEnum',
      'ParamReferenceTypeEnum'
    ])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    fieldChange(v, row) {
      row.dataType = this.columnMap.get(v).type
      row.value = null
    },
    dataTypeChange(row) {
      row.value = null
      row.value1 = null
    },
    isGroupChange(v, row) {
      row.value = null
      row.nodeKey = null
      row.groups = []
      row.value2 = null
      row.fieldName = null
      row.operator = null
      row.value1 = null
      row.nodeKey1 = null
      row.dataType = null
      row.type = null
    },
    typeChange(row, idx) {
      if (idx === 0) {
        row.value = null
        row.nodeKey = null
        row.groups = []
      } else if (idx === 1) {
        row.value1 = null
        row.nodeKey1 = null
      }
    },
    operaChange(row) {
      row.value = null
    },
    showJsonTree(row, idx) {
      this.jsonTreeDialogVisible = true
      this.currentRow = row
      currentIndex = idx
    },
    addRow() {
      this.$emit('eventLinstener', {
        type: 'add',
        title: this.title,
        list: this.tableList
      })
    },
    addChildRow(row) {
      if (!row.groups || row.groups === '' || row.groups === undefined || row.groups.length === 0) {
        this.$set(row, 'groups', [])
      }
      this.$emit('eventLinstener', {
        type: 'add',
        title: this.title,
        list: row.groups
      })
    },
    deleteRow(row, index) {
      this.$confirm(
        '确定删除此行吗? 删除不会提交数据，请点击【保存】提交',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      ).then(() => {
        const { parentList, idx } = this.findParentRow(this.formData.tableList, row)
        parentList.splice(idx, 1)
      })
    },
    // 深度优先递归
    findParentRow(list, row) {
      let parentList = []
      let idx = null
      const length = list.length
      for (let i = 0; i < length; i++) {
        if (list[i] === row) {
          return { parentList: list, idx: i }
        }
        if (list[i].groups) {
          const res = this.findParentRow(list[i].groups, row)
          if (res) {
            parentList = res.parentList
            idx = res.idx
            return { parentList, idx }
          }
        }
      }
    }
  }
}
</script>

<style scoped lang="scss">
table-add-btn {
  width: 100%;
}
.placeholder {
  min-height: 40px;
  min-width: 100px;
  line-height: 40px;
}
</style>
