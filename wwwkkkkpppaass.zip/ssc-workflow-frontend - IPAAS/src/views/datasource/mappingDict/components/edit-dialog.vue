<template>
  <el-dialog :title="title" :visible.sync="visible" :width="width" :beforeClose="handleClose" v-if="visible">
    <mc-form ref="form" :model="formData" :rules="rules">
      <mc-form-item componentType="ElInput" prop="name" label="映射名称" :editProps="{maxlength: 100}" />
      <mc-form-item componentType="ElSelect" prop="dictMapSrcType" label="映射结果来源" dict="DictMapSrcTypeEnum" @change="dictMapSrcTypeChange" />
      <mc-form-item componentType="ElInputNumber" prop="cacheTime" label="缓存时间(s)" />
      <mc-form-item labelWidth="0" :span="24" v-if="formData.dictMapSrcType === 1">
        <Sql ref="sql" :formData="formData.sqlDto" :DataBaseEnum="DataBaseEnum" />
      </mc-form-item>
      <mc-form-item labelWidth="0" :span="24" v-if="formData.dictMapSrcType === 2">
        <Api ref="api" :formData="formData.apiDto" />
      </mc-form-item>
    </mc-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" @click="confirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import Constant from '@/config/constant'
import { validateTableTreeData, validateFn } from '@/utils/validator'
import { isNull } from '@/utils'
import Sql from './sql'
import Api from './api'
import { SqlDto, ApiDto } from '../model/model'

export default {
  name: 'EditDialog',
  components: { Api, Sql },
  props: {
    // eslint-disable-next-line vue/prop-name-casing
    DataBaseEnum: {
      default: () => ([]),
      type: Array
    },
    visible: {
      default: false,
      type: Boolean
    },
    title: {
      default: '新增',
      type: String
    },
    width: {
      default: '30%',
      type: String
    },
    formData: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请填写映射名称', trigger: 'blur' }
        ],
        dictMapSrcType: [
          { required: true, message: '请选择映射结果来源', trigger: 'change' }
        ],
        cacheTime: [
          { required: true, validator: validateFn.checkNum({ min: 0, max: 9999999 }) }
        ]
      }
    }
  },
  watch: {
    visible(nV) {
      if (nV && this.$refs.form) {
        this.$refs.form.clearValidate()
      }
    }
  },
  methods: {
    dictMapSrcTypeChange(v) {
      console.log(this.formData)
      if (v === 1) {
        delete this.formData.apiDto
        this.$set(this.formData, 'sqlDto', new SqlDto())
      } else if (v === 2) {
        delete this.formData.sqlDto
        this.$set(this.formData, 'apiDto', new ApiDto())
      }
    },
    recursionList(list, fn, children = 'childrenList') {
      list.forEach(item => {
        if (item[children]) {
          this.recursionList(item[children], fn)
        }
        fn(item)
      })
    },
    validateResRow(row, _isTop) {
      if (isNull(row.referenceType)) {
        return [false, '赋值类型不能为空']
      }
      if (!row.destName) {
        return [false, '包装参数名称不能为空']
      }
      if (!row.sourceName) {
        return [false, '源字段值不能为空']
      }
      return [true]
    },
    validateReqRow(row, _isTop) {
      if (isNull(row.referenceType)) {
        return [false, '赋值类型不能为空']
      }
      if (!row.sourceName) {
        return [false, '取值参数名不能为空']
      }
      return [true]
    },
    validateTreeTable(formData) {
      let valid1 = 0
      formData.dictMappingReqList.forEach(item => {
        if (item.referenceType === 1) {
          valid1 = 1
        }
      })
      if (!valid1) {
        setTimeout(() => {
          this.$message.error('请求参数-至少有一行选择引用值')
        })
      }
      const [valid2, msg2, rowIndex2] = validateTableTreeData(formData.dictMappingRespList, this.validateResRow)
      if (!valid2) {
        setTimeout(() => {
          this.$message.error(`响应参数-第${rowIndex2}行：${msg2}`)
        })
      }
      const [valid3, msg3, rowIndex3] = validateTableTreeData(formData.dictMappingReqList, this.validateReqRow)
      if (!valid3) {
        this.$message.error(`请求参数-第${rowIndex3}行：${msg3}`)
      }
      if (valid1 && valid2 && valid3) { return true }
    },
    handleClose() {
      this.$emit('update:visible', false)
    },
    confirm() {
      this.$refs.form.validate()
        .then(valid => {
          if (valid) {
            if (this.formData.dictMapSrcType === 1) {
              this.$refs.sql.validate().then(sqlValid => {
                if (sqlValid) {
                  this.$emit('eventListener', Constant.COMMIT, this.formData)
                } else {
                  this.$message.error('请按照提示完善表单数据')
                }
              })
            } else if (this.formData.dictMapSrcType === 2) {
              this.$refs.api.validate().then(sqlValid => {
                if (sqlValid) {
                  this.$emit('eventListener', Constant.COMMIT, this.formData)
                } else {
                  this.$message.error('请按照提示完善表单数据')
                }
              })
            }
          } else {
            this.$message.error('请按照提示完善表单数据')
          }
        })
    },
    connectServer() {
      this.$emit('eventListener', Constant.CONNECT, this.formData)
    }
  }
}
</script>
