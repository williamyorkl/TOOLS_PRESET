<template>
  <mc-form ref="form-sql" :model="formData" :showBottomBorder="false" :rules="rules">
    <mc-form-item componentType="ElSwitch" prop="isInputSql" label="输入SQL" :editProps="{activeValue: 1, inactiveValue: 0}" @change="isInputSqlChange" />
    <mc-form-item componentType="ElInputNumber" prop="timeOut" label="超时时间(s)" />
    <mc-form-item componentType="ElSelect" prop="dbId" label="SQL数据源" :dict="DataBaseEnum" valueKey="id" labelKey="dataBaseName" />

    <template v-if="formData.isInputSql === 0">
      <mc-form-item componentType="McPopoverSelect" prop="tableName" label="数据表" @changeRow="tableNameChange" :editProps="{
        defaultValue: formData.tableName,
        apiFunc: tableApiFunc,
        tableColumn: tablesTableColumn,
        queryList: tablesQueryList,
        labelKey: 'tableName',
        valueKey: 'tableName',
        param: {id: formData.dbId}
      }"
      />
      <mc-form-item :span="24" labelWidth="0">
        <el-divider>参数列表</el-divider>
        <VarList title="varList" :tableList="formData.varList" @eventLinstener="eventLinstener" />
      </mc-form-item>
      <mc-form-item :span="24" labelWidth="0">
        <el-divider>选择表字段</el-divider>
        <SelectParamList :tableList="formData.selectFieldList" :varList="formData.varList" :columnList="columnList" :columnMap="columnMap" title="select" @eventLinstener="eventLinstener" />
      </mc-form-item>
      <mc-form-item :span="24" labelWidth="0">
        <el-divider>where条件</el-divider>
        <WhereParamList :tableList="formData.whereFieldList" :varList="formData.varList" :columnList="columnList" :columnMap="columnMap" title="where" @eventLinstener="eventLinstener" />
      </mc-form-item>
      <mc-form-item :span="24" labelWidth="0">
        <el-divider>排序</el-divider>
        <SortParamList :tableList="formData.sortFieldList" :columnList="columnList" :columnMap="columnMap" title="select" @eventLinstener="eventLinstener" />
      </mc-form-item>
    </template>
    <template v-if="formData.isInputSql === 1">
      <mc-form-item :span="24" labelWidth="0">
        <el-divider>参数列表</el-divider>
        <VarList title="varList" :tableList="formData.varList" @eventLinstener="eventLinstener" />
      </mc-form-item>
      <mc-form-item :span="24" label="SQL语句" prop="textSql">
        <codemirror v-model.trim="formData.textSql" @blur="textareaBlur" :options="options" class="code-container" />
      </mc-form-item>
      <mc-form-item :span="24" labelWidth="0">
        <el-divider>结果映射</el-divider>
        <ResultParamList :tableList="formData.selectFieldList" :columnList="columnList" :columnMap="columnMap" title="select" @eventLinstener="eventLinstener" />
      </mc-form-item>
    </template>
  </mc-form>
</template>

<script>
import { mapActions } from 'vuex'
import tablesOption from '@/config/popContentTableConfig/table.config.js'
import dbApi from '@/api/database'
import { validateFn } from '@/utils/validator'
import VarList from './paramList/variable'
import { Variable, SelectField, SortField, WhereField } from '../model/model'
import SelectParamList from './paramList/selectParamList'
import WhereParamList from './paramList/whereParamList'
import SortParamList from './paramList/sortParamList'
import ResultParamList from './paramList/resultParamList'
import arrangeApi from '@/api/arrange'

import { codemirror } from 'vue-codemirror'
import 'codemirror/lib/codemirror.css'
import 'codemirror/theme/base16-dark.css'
import 'codemirror/mode/sql/sql.js'
import 'codemirror/addon/display/placeholder.js'
export default {
  components: { codemirror, VarList, SelectParamList, WhereParamList, SortParamList, ResultParamList },
  props: {
    formData: {
      type: Object,
      default: () => ({})
    },
    // eslint-disable-next-line vue/prop-name-casing
    DataBaseEnum: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      tableApiFunc: tablesOption.apiFunc,
      tablesTableColumn: tablesOption.getTableColumn(),
      tablesQueryList: tablesOption.getQueryList(),
      DbSqlMethodEnum: [],
      columnList: [],
      options: {
        mode: { name: 'sql', json: true },
        theme: 'base16-dark',
        lineNumbers: true
      },
      rules: {
        timeOut: [
          { required: true, message: '请输入超时时间', trigger: 'blur' },
          // { type: 'number', min: 0, max: 3600, message: '超时时间范围为0-3600', trigger: 'blur' },
          { required: true, validator: validateFn.checkNum({ min: 0, max: 9999999 }) }
        ],
        dbId: [
          { required: true, message: '请选择数据源', trigger: 'change' }
        ],
        tableName: [
          { required: true, message: '请选择数据表', trigger: 'change' }
        ],
        textSql: [
          { required: true, message: '请输入SQL语句', trigger: 'blur' }
        ]
      },
      sqlTips: '示例：select id,app_code,app_name  from flow_app where id in ($id) and app_name like concat("%",$name,"%") and app_code = $code;'
    }
  },
  provide() {
    return {
      formDisabled: false
    }
  },
  watch: {
    'formData.tableName': {
      handler(nV) {
        this.getCurrentTableColumnDtos(nV)
      },
      immediate: true
    }
  },
  async created() {
    this.DbSqlMethodEnum = await this.getDicts('DbSqlMethodEnum')
  },
  computed: {
    columnMap() {
      const map = new Map()
      this.columnList.forEach((item) => {
        map.set(item.name, item)
      })
      return map
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),

    isInputSqlChange() {
      this.formData.selectFieldList = []
    },
    // blur解析sql语句
    async textareaBlur() {
      const oldList = this.formData.selectFieldList
      const newList = []
      const oldMap = new Map()
      const resp = await arrangeApi.parseSql({ sql: this.formData.textSql })
      oldList.forEach(item => { oldMap.set(item.fieldName, item) })
      resp.forEach(item => {
        let param = oldMap.get(item)
        if (!param) {
          param = new SelectField({ fieldName: item })
        }
        newList.push(param)
      })
      this.formData.selectFieldList = newList
    },
    tableNameChange(row) {
    //   this.getCurrentTableColumnDtos()
    },
    async getCurrentTableColumnDtos() {
      if (!this.formData.dbId || !this.formData.tableName) {
        this.columnList = []
        return
      }
      const resp = await dbApi.getFields({ id: this.formData.dbId, tableName: this.formData.tableName })
      this.columnList = resp.columnDtos || []
    },
    addRow(list, title) {
      if (title === 'varList') {
        list.push(new Variable())
      } else if (title === 'select') {
        list.push(new SelectField({}))
      } else if (title === 'where') {
        list.push(new WhereField({}))
      } else if (title === 'sort') {
        list.push(new SortField({}))
      } else if (title === 'addChildRow') {
        list.push(new WhereField())
      }
    },
    eventLinstener({ type, title, list }) {
      switch (type) {
        case 'add':
          this.addRow(list, title)
          break
      }
    },
    validate() {
      return this.$refs['form-sql'].validate()
    }
  }
}
</script>

<style>

</style>
