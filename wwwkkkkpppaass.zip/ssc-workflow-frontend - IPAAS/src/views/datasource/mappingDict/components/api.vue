<template>
  <mc-form ref="form-api" :model="formData" :show-bottom-border="false"  :rules="rules">
    <mc-form-item componentType="McPopoverSelect" prop="defineId" label="映射接口" :editProps="{
      defaultValue: formData.businessApiName,
      apiFunc: frontendApiListApiFunc,
      tableColumn: frontendApiTableColumn,
      queryList: frontendApiQueryList,
      labelKey: 'businessApiName',
      param: {status: 1}
    }" @changeRow="changeRow"></mc-form-item>
    <mc-form-item componentType="ElSelect" prop="requestType" label="接口请求方式" dict="MethodTypeEnum" :readonly="true"></mc-form-item>
    <mc-form-item componentType="ElInput" prop="requestUrl" label="映射接口URL" :readonly="true"></mc-form-item>
    <!-- <mc-form-item componentType="ElInputNumber" prop="cacheTime" label="缓存时间(s)"></mc-form-item> -->
    <mc-form-item :span="24" label-width="0">
      <el-divider>参数列表</el-divider>
      <VarList title="varList" :tableList="formData.varList" @eventLinstener="eventLinstener" />
    </mc-form-item>
    <mc-form-item :span="24" label-width="0">
      <el-divider>请求参数</el-divider>
      <ReqParamList :tableList="formData.dictMappingReqList" @eventLinstener="eventLinstener" :varList="formData.varList" />
    </mc-form-item>
    <mc-form-item :span="24" label-width="0">
      <el-divider>响应参数</el-divider>
      <ResParamList :tableList="formData.dictMappingRespList" @eventLinstener="eventLinstener" />
    </mc-form-item>
  </mc-form>
</template>

<script>
import arrangeApi from '@/api/arrange'
import { mapActions } from 'vuex'
import ReqParamList from './paramList/req'
import ResParamList from './paramList/res'
import VarList from './paramList/variable'
import { RowParam, Variable } from '../model/model'
import {
  getTableColumn,
  getQueryList
} from '@/config/popContentTableConfig/frontendApi.config'
export default {
  components: { ReqParamList, ResParamList, VarList },
  props: {
    formData: {
      type: Object
    }
  },
  data() {
    return {
      frontendApiTableColumn: [],
      frontendApiQueryList: [],
      frontendApiListApiFunc: arrangeApi.listArrange,
      sourceParamList: [],
      rules: {
        defineId: [
          { required: true, message: '请选择映射接口', trigger: 'change' }
        ]
      }
    }
  },
  async created() {
    const [
      MethodTypeEnum
    ] = await this.getDicts([
      'MethodTypeEnum'
    ])
    this.frontendApiQueryList = getQueryList(MethodTypeEnum)
    this.frontendApiTableColumn = getTableColumn()
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    changeRow(row) {
      this.formData.businessApiName = row.businessApiName
      this.formData.requestUrl = row.requestUrl
      this.formData.requestType = row.requestType
      this.formData.dictMappingReqList = this.formatterRowParam(row.apiInParamPathList, 'destName') || []
      this.formData.dictMappingRespList = this.formatterRowParam(row.apiOutParamPathList, 'sourceName') || []
    },
    addRow(list, title) {
      if (title === 'varList') {
        list.push(new Variable())
      } else {
        list.push(new RowParam())
      }
    },
    eventLinstener({ type, title, list }) {
      switch (type) {
        case 'add':
          this.addRow(list, title)
      }
    },
    formatterRowParam(list, key) {
      list = list || []
      return list.map(item => ({
        ...new RowParam(), [key]: item.paramName, dataType: item.dataType, isRequired: item.isRequired, destPos: item.dataPosition
      }))
    },
    validate() {
      return this.$refs['form-api'].validate()
    }
  }
}
</script>

<style>

</style>
