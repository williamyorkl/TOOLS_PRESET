import area from 'api/area'

const actions = {
  /**
   *
   * @param {*} param0
   * @param {*} param1 type: 数据类型 province city area  parentCode传递的参数
   */
  async getProvince ({ commit }, { type, parentCode }) {
    const { content } = await area.getList({
      parentCode
    })
    if (type === 'province') {
      commit('SET_PROVINCE', content)
    } else if (type === 'city') {
      commit('SET_CITY', content)
    } else if (type === 'area') {
      commit('SET_AREA', content)
    }
  }

}

export default actions
