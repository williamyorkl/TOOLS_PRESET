import Vue from 'vue'
import mod from '@/api/common/directory'
import { arrayToMap } from '@/utils/modules'

export const SET = 'SET_DICT'
export const GET = 'GET_DICT'
export const DELETE = 'DELETE_DICT'

const INT_RE = /^-?\d+$/

function transformDictValue(dicts) {
  dicts.forEach(dict => {
    const value = dict.value

    if (INT_RE.test(value)) {
      dict.value = parseInt(value)
    } else if (value === 'true') {
      dict.value = true
    } else if (value === 'false') {
      dict.value = false
    }
  })
}

// 状态
const state = {
  dict: {}
}

let caches = Object.create(null)

// 操作
const mutations = {
  [SET](state, data) {
    Object.keys(data).forEach(key => {
      Vue.set(state.dict, key, data[key])
    })
  },

  [DELETE](state) {
    state.dict = {}
    caches = Object.create(null)
  }
}
// 方法
const actions = {
  /**
   * @returns {Promise}
   * @description 获取单个数据字典，只获取一次
   */
  [GET]({ commit }, key) {
    const cache = caches[key]

    if (cache) {
      return cache
    }

    caches[key] = mod.getDDValueListByKey(key)
      .then(res => {
        const data = {}
        const dicts = res.content

        transformDictValue(dicts)

        data[key] = dicts
        data[`${key}Map`] = arrayToMap(dicts)

        commit(SET, data)
      }).catch(e => {
        delete caches[key]
        return Promise.reject(e)
      })

    return caches[key]
  }
}

export default {
  // 开启命名空间
  namespaced: true,
  state,
  mutations,
  actions
}
