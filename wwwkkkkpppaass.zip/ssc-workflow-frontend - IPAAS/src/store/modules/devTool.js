const state = {
  databaseInfo: {}  
}

// 操作
const mutations = {
  SET_DATABASE_INFO(state, obj) {
    state.databaseInfo = obj
  }  
}

const actions = {
 
}

// getters
const getters = {
  databaseInfo: state => {
    return state.databaseInfo || []
  }
  
}

export default {
  namespaced: true,
  getters,
  state,
  mutations,
  actions
}
