const state = {
  breadListState: [{
    name: '首页',
    path: '/'
  }]
}

// 操作
const mutations = {
  breadListMutations (state, list) {
    state.breadListState = list
    sessionStorage.setItem('breadListStorage', JSON.stringify(list))
  }
}

const actions = {

}

// getters
const getters = {
  breadListState: state => {
    return JSON.parse(sessionStorage.getItem('breadListStorage')) || state.breadListState
  }
}

export default {
  namespaced: true,
  getters,
  state,
  mutations,
  actions
}
