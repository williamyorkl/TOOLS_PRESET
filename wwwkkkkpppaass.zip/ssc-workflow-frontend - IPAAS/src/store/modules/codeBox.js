import { Message } from 'element-ui'

const state = {
  codeBox: {}
}

// 操作
const mutations = {
  SAVE_CODE(state, { msg, code }) {
    code = String(code)
    if (!state.codeBox[code]) {
      state.codeBox[code] = true
      Message.error(msg || '操作失败')
    }
  },
  REMOVE_CODE(state, code) {
    code = String(code)
    state.codeBox[code] = false
  }
}

const actions = {

}

// getters
const getters = {
}

export default {
  namespaced: true,
  getters,
  state,
  mutations,
  actions
}
