import exportModal from '@/api/common/export'

const state = {
  exportData: [],
  addExportAnimation: false,
  showExportList: false,
  loadingExportCount: 0
}

// 操作
const mutations = {
  showExportList (state) { // 显示导出队列
    state.showExportList = true
  },
  hideExportList (state) { // 隐藏导出队列
    state.showExportList = false
  },
  setExportList (state, list) { // 设置导出队列数据
    state.exportData = list
  },
  setExportData (state, obj) { // 设置index导出数据状态
    state.exportData[obj.index].status = obj.data.status
    state.exportData[obj.index].fileUrl = obj.data.fileUrl
  },
  addExport (state, obj) { // 导出队列添加数据
    state.exportData.unshift(obj)
  },
  addExportCount (state) { // 增加头部显示的导出数量
    state.loadingExportCount++
  },
  startAnimation (state) { // 开始增加导出数据动画
    state.addExportAnimation = true
  },
  endAnimation (state) { // 结束增加导出数据动画
    state.addExportAnimation = false
  },
  setLoadingExportCount (state, count) { // 设置头部显示的导出数量
    state.loadingExportCount = count
  }
}

const actions = {
  addExport (context, obj) {
    context.commit('startAnimation')
    exportModal.exportDetail(obj.id).then(res => {
      context.commit('addExport', res.data)
    })
  },
  getExportList (context) {
    exportModal.getList().then(res => {
      res.data && context.commit('setExportList', res.data.list)
    })
  }
}

// getters
const getters = {
  exportData: state => {
    return state.exportData.concat()
  },
  addExportAnimation: state => {
    return state.addExportAnimation
  },
  showExportList: state => {
    return state.showExportList
  },
  loadingExportCount: state => {
    return state.loadingExportCount
  }
}

export default {
  namespaced: true,
  getters,
  state,
  mutations,
  actions
}
