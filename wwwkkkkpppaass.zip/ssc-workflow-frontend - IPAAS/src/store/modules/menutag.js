import { setLocal, getLocal } from '@/utils/cache'

const FIEXD_TAG = {
  label: 'iPaaS平台',
  name: 'home',
  path: '/',
  fullPath: '/',
  meta: {
    keepAlive: false
  },
  params: {},
  query: {}
}

const state = {
  breadListState: [{
    name: 'iPaaS平台',
    path: '/',
    fullPath: '/',
    label: 'iPaaS平台'
  }],
  tabList: [FIEXD_TAG],
  breadListState: [],
  tabList: []
}

// 从 localStorage 中获取 tabList
const tabListFromStorage = getLocal('ipaasTabList')
if (tabListFromStorage) {
  const tabListArray = tabListFromStorage
  if (tabListArray.length > state.tabList.length) {
    const filterArr = tabListArray.filter((item) => {
      const existItem = state.tabList.find((item2) => {
        return item.fullPath === item2.fullPath
      })
      return Boolean(existItem) === false
    })
    state.tabList = [...state.tabList, ...filterArr]
  }
}

// 操作
const mutations = {
  setTabList(state, list) {
    state.tabList = list
    setLocal('ipaasTabList', state.tabList)
    return state.tabList
  },
  unshiftTab(state, tab) {
    state.tabList.unshift(tab)
    setLocal('ipaasTabList', state.tabList)
    return state.tabList
  },
  pushTab(state, tab) {
    state.tabList.push(tab)
    setLocal('ipaasTabList', state.tabList)
    return state.tabList
  },
  spliceAddTab(state, obj) {
    state.tabList.splice(obj.tabSourceIndex, obj.num, obj.tab)
    setLocal('ipaasTabList', state.tabList)
    return state.tabList
  },
  spliceTab(state, obj) {
    state.tabList.splice(obj.tabIndex, obj.num)
    setLocal('ipaasTabList', state.tabList)
    return state.tabList
  },
  breadListMutations (getters, list) {
    getters.breadListState = list
    sessionStorage.setItem('breadListStorage', list)
  },

  delOthersViews(state, obj) {
    state.tabList = obj.name === 'home' ? [FIEXD_TAG] : [FIEXD_TAG].concat(obj)
    setLocal('ipaasTabList', state.tabList)
  },
  delAllViews(state) {
    state.tabList = [FIEXD_TAG]
    setLocal('ipaasTabList', state.tabList)
  },

  // 删除当前页面tab页签
  delCurView: (state, path) => {
    for (const [i, v] of state.tabList.entries()) {
      if (v.path === path) {
        state.tabList.splice(i, 1)
        break
      }
    }
  },

  // 拖拽
  dragDrop: (state, obj) => {
    const dragItem = state.tabList[obj.sIndex]
    state.tabList.splice(obj.eIndex, 0, dragItem)// index:元素需要放置的位置索引，从0开始
    if (obj.sIndex > obj.eIndex) {
      state.tabList.splice(obj.sIndex + 1, 1)// 移除原来位置上的该元素
    } else {
      state.tabList.splice(obj.sIndex, 1)// 移除原来位置上的该元素
    }
  }

}

const actions = {

}

// getters
const getters = {
  breadListState: state => {
    return JSON.parse(sessionStorage.getItem('breadListStorage')) || state.breadListState.concat()
  }
}

export default {
  namespaced: true,
  getters,
  state,
  mutations,
  actions
}
