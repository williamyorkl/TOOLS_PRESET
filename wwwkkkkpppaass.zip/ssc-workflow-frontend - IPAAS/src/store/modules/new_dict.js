import Vue from 'vue'
import dictApi from '@/api/common/dict'
import { unique } from '@/utils'
// 每次get字典时，先查询是否已在dictMap中，如果已在dictMap中直接返回，否则调接口存储到dictMap中之后返回,支持传数组，返回对应的键值对对象，当然也会存到dictMap中，不想用这个返回值的话可以自己重新用GET_DICT取，不过只能取单个
const state = {
  dictMap: {}
}

// 操作
const mutations = {
  SET_DICT(state, payload) {
    // 响应式添加新属性
    Vue.set(state.dictMap, payload.dictName, payload.dict)
  }
}

const actions = {
  // 获取字典数据，仅支持字符串
  async getDict({ commit, state, getters }, payload) {
    if (!payload) return []
    let dict = getters.dict(payload)
    if (dict && dict.length > 0) return dict
    try {
      const resp = await dictApi.getDict(payload)
      commit('SET_DICT', { dictName: payload, dict: resp })
      dict = getters.dict(payload)
      return dict
    } catch (e) {
      return []
    }
  },
  // 获取字典数据，支持传数组和字符串.传数组时按照顺序返回n组枚举列表
  async getDicts({ dispatch }, payload) {
    if (!payload) return []
    const isArray = Array.isArray(payload)
    if (!isArray) {
      return dispatch('getDict', payload)
    } else {
      payload = unique(payload)
      const arr = payload.map(dictName => dispatch('getDict', dictName))
      return Promise.all(arr)
    }
  }
}

// getters
const getters = {
  // 可通过this.$store.getters['new_dict/dict']('code')获取或使用mapGetters
  dict: state => dictName => {
    return state.dictMap[dictName]
  }
}

export default {
  namespaced: true,
  getters,
  state,
  mutations,
  actions
}
