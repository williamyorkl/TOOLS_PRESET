const state = {
  salonShop: {}
}

const mutations = {
  SET_SALON_TOP (state, shop) {
    state.salonShop = shop
  }
}

const actions = {}

const getters = {}

export default {
  namespaced: true,
  state,
  mutations,
  actions,
  getters
}
