import cookiejs from '../../utils/cookie'
import model from 'api/es'
import { encode } from 'js-base64'
import router from '../../router'
import authApi from '@/api/auth/auth'
import { Message } from 'element-ui'
import { LOGIN_MODE } from '@/config/enum'

const state = {
  envMap: [], // 环境信息
  userInfo: {},
  app: {}, // 当前应用
  backEndType: null // 当前模式，[admin | app]  admin使用routes.admin，app使用routes.total
}

// 操作
const mutations = {
  SET_ENV(state, val) {
    state.envMap = val
  },
  SAVE_USER_INFO(state, userInfo) {
    state.userInfo = userInfo
  },
  TOGGLE_APP(state, app) {
    state.app = app
  },
  SET_MODE(state, backEndType) {
    state.backEndType = backEndType
  }
}

const actions = {

  async getLoginMethods({ commit, dispatch }) {
    return authApi.loginMethod().then(res => {
      // 将环境配置在commit中处理
      commit('SET_ENV', res)
    })
  },

  fetchToken({
    commit,
    dispatch
  }, payload) {
    return new Promise((resolve, reject) => {
      if (process.env.VUE_APP_MODE === '__paas__') {
        model.fetchToken(payload).then(res => {
          cookiejs.setStoreCookie('IDaaSAuthToken', res.token || '')
          resolve(res)
        })
      } else if (process.env.VUE_APP_MODE === '__container__') {
        model.fetchToken(payload).then(res => {
          if (res.token) {
            const token = encode(JSON.stringify(res))
            cookiejs.setStoreCookie('X-IDaas-Resource', token || '')
            resolve(res)
          }
        })
      }
    })
  },
  // 登录并保存用户信息
  async login({ commit, state, dispatch }, payload) {
    const resp = await authApi.login(payload)
    if (resp) {
      commit('codeBox/REMOVE_CODE', 403, { root: true })
      commit('SAVE_USER_INFO', resp)
      commit('SET_MODE', payload.backEndType)
      return Promise.resolve()
    }
  },
  // 清空用户信息并执行跳转
  async clearUserInfo({ commit, state, dispatch }, payload) {
    if (process.env.VUE_APP_MODE === '__container__') {
      dispatch('logout', payload)
    } else {
      commit('SAVE_USER_INFO', {}) // 清空用户信息
      commit('TOGGLE_APP', {}) // 清空所选App
      commit('SET_MODE', null)
      if (payload && payload.data && payload.data.url) { // 重定向到指定链接或回登录页
        location.href = payload.data.url
      } else {
        router.push({ name: 'login' })
      }
    }
  },
  async logout ({ commit, state, dispatch }, payload) { // 退出登录
    if (process.env.VUE_APP_MODE === '__paas__' || process.env.VUE_APP_MODE === '__container__') {
      cookiejs.remove('X-IDaas-Resource')
      const signUrl = process.env.VUE_APP_SINGLESIGN_URL
      const redirectUrl = window.location.origin + process.env.VUE_APP_PUBLIC_PATH

      window.location.href = `${signUrl}?service=${redirectUrl}`
    } else if (process.env.VUE_APP_MODE === 'private') { // private删除userInfo并重定向到后端返回的地址
      const redirectUrl = location.origin + location.pathname
      await authApi.logout({ handlerName: state.userInfo.handlerName, redirectUrl })
      Message.success('已登出')
      setTimeout(() => {
        dispatch('clearUserInfo', payload)
      }, 800)
    }
  }
}

// getters
const getters = {
  // mainMenuList: state => {
  //   return state.mainMenus || []
  // },
  // operationAuth: state => {
  //   return state.operationAuth || []
  // }
}

export default {
  namespaced: true,
  getters,
  state,
  mutations,
  actions
}
