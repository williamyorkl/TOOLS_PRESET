const mutations = {
  SET_SALONSHOPID (state, shop) {
    console.log(shop, 'shop')
    state.salonShop = shop
  },
  SET_PROVINCE (state, list) {
    state.province = list
  },
  SET_CITY (state, list) {
    state.city = list
  },

  SET_AREA (state, list) {
    state.area = list
  },

  SET_PLATFORM_CATEGORY (state, category) { // 获取平台类目
    state.platformCategory = category || []
  },
  SET_SHOP_CATEGORY (state, category) { // 获取平台类目
    state.shopCategory = category || []
  },
  SET_PLATFROM (state, list) {
    state.platformList = list || []
  },

  PUSH_KEEP_ALIVE_NAME(state, payLoad) {
    if (state.keepAliveNames.includes(payLoad.name) === false && payLoad.keepAlive === true) {
      state.keepAliveNames.push(payLoad.name)
    }
  },
  SPLICE_KEEP_ALIVE_NAME(state, payLoad) {
    const index = state.keepAliveNames.indexOf(payLoad.name)
    if (index !== -1) {
      state.keepAliveNames.splice(index, 1)
    }
  }
}

export default mutations
