const state = {
  salonShop: {}, // 当前选中店铺ID
  platformCategory: [], // 平台类目 cateKind=1
  secondPlatformCategory: [],
  thirdPlatformCategory: [],
  shopCategory: [], // 店铺类目 cateKind=2shopCategoryList
  secondShopCategory: [],
  thirdShopCategory: [],
  province: [],
  platformList: [], // 平台列表  isInnerPlatform: true
  keepAliveNames: [], // 需要缓存的页面 router name
  curPlatformId: '' // 当前平台 Id
}
export default state
