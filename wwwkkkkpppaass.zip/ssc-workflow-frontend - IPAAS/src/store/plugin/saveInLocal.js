export default (store) => {
  // 缓存数据, localStorage.state存在 就替换本地保存的最新值
  localStorage.state && store.replaceState(JSON.parse(localStorage.state))
  store.subscribe((mutations, state) => {
    localStorage.state = JSON.stringify(state)
  })
}
