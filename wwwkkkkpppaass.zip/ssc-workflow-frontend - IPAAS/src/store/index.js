import Vue from 'vue'
import Vuex from 'vuex'
import user from './modules/user'
import DICT from './modules/dict'
// eslint-disable-next-line camelcase
import new_dict from './modules/new_dict'
import codeBox from './modules/codeBox'
// import breadCrumb from './modules/breadCrumb'
import menutag from './modules/menutag'
import exportList from './modules/exportList'

import common from './modules/common'
import devTool from './modules/devTool'
// import globleConfig from './modules/globleConfig'
import saveInLocal from './plugin/saveInLocal'
import actions from './actions'
import mutations from './mutations'
import state from './state'
import getters from './getters'

Vue.use(Vuex)

const store = new Vuex.Store({
  // strict: process.env.NODE_ENV !== 'production',
  modules: {
    user,
    // breadCrumb,
    menutag,
    exportList,
    DICT,
    new_dict,
    common,
    devTool,
    codeBox

    // globleConfig,
  },
  actions,
  mutations,
  getters,
  state,
  plugins: [saveInLocal]
})

export default store
