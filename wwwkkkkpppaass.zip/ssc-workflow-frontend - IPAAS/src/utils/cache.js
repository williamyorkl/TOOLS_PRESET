
const storageGet = (key, type = 'sessionStorage') => {
  try {
    return JSON.parse(window[type].getItem(key))
  } catch (e) {
    console.log(e)
  }
}

const storageSet = (key, val, type = 'sessionStorage') => window[type].setItem(key, JSON.stringify(val))

const storageRemove = (key, type = 'sessionStorage') => window[type].removeItem(key)

export const getSession = key => storageGet(key) 
export const setSession = (key, val) => storageSet(key, val)
export const removeSession = key => storageRemove(key) 

export const getLocal = key => storageGet(key, 'localStorage')
export const setLocal = (key, val) => storageSet(key, val, 'localStorage')
export const removeLocal = key => storageRemove(key, 'localStorage') 
