export function serialize(data) {
  const result = {}

  for (const item in data) {
    if (data.hasOwnProperty(item)) {
      // 空值不传
      if (data[item] === '' || data[item] === undefined) {
        continue
      }

      // 日期转换为时间戳
      if (data[item] instanceof Date) {
        result[item] = +data[item]
        continue
      }

      result[item] = data[item]
    }
  }

  return result
}
