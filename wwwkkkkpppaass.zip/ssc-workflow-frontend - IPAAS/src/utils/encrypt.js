import { setMaxDigits, encryptedString, RSAKeyPair } from '../lib/RSA'

export const rsaEncrypt = value => {
  setMaxDigits(130)
  const key = new RSAKeyPair('10001', '', '80fc87834076e5ef46a587481c069bbc49e6f36136101f8c26e9f69d95be5441d4051b7893fd1c740590192ac47dc87d05279d9901d3a3de7baf26c386f1e23f1b272c4e822b850225ae07cb08a9897d7d9ae8ba2d775c711663441f4aed7f3cd62f06f2276fa09c0a3dafc6ebd5d7d468ced1e076467314c5c6da81e946ca2f')
  return encryptedString(key, value)
}
