import { MessageBox, Message } from 'element-ui'
import store from '../store'
import exportModal from '../api/common/export'

const exportConfirm = function(params) {
  return new Promise((resolve, reject) => {
    if (params.query.pageIndex != undefined) delete params.query.pageIndex
    if (params.query.pageSize != undefined) delete params.query.pageSize
    MessageBox.confirm('创建导出任务后可在右侧导出队列查看和下载对应导出数据。确认创建吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning',
      lockScroll: false
    }).then(() => {
      exportModal.begin(params).then(res => { // 传参taskType和query条件
        if (res.success) {
          // 打开导出进度弹窗
          const taskId = res.data
          store.dispatch('exportList/addExport', {
            id: taskId
          })
        } else {
          Message.error(res.errorMSG || res.errMsg)
        }
      })
      return resolve()
    }).catch(() => {
      return reject()
    })
  })
}

export default exportConfirm
