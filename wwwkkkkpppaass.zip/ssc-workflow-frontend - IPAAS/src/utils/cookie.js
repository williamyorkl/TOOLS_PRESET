
var encode = encodeURIComponent
var decode = decodeURIComponent

var cookiejs = {
  /// Serialize the a name value pair into a cookie string suitable for
  /// http headers. An optional options object specified cookie parameters
  ///
  /// serialize('foo', 'bar', { httpOnly: true })
  ///   => "foo=bar; httpOnly"
  ///
  /// @param {String} name
  /// @param {String} val
  /// @param {Object} options
  /// @return {String}
  serialize: function(name, val, opt) {
    opt = opt || {}
    var enc = opt.encode || encode
    var pairs = [name + '=' + enc(val)]

    if (opt.maxAge != null) {
      var maxAge = opt.maxAge - 0
      if (isNaN(maxAge)) throw new Error('maxAge should be a Number')
      pairs.push('Max-Age=' + maxAge)
    }

    opt.domain && pairs.push('Domain=' + opt.domain)
    opt.path && pairs.push('Path=' + opt.path)
    opt.expires && pairs.push('Expires=' + opt.expires.toUTCString())
    opt.httpOnly && pairs.push('HttpOnly')
    opt.secure && pairs.push('Secure')

    return pairs.join('; ')
  },

  /// Parse the given cookie header string into an object
  /// The object has the various cookies as keys(names) => values
  /// @param {String} str
  /// @return {Object}
  parse: function(str, opt) {
    opt = opt || {}
    var obj = {}
    var pairs = str.split(/; */)
    var dec = opt.decode || decode

    pairs.forEach(function(pair) {
      var eq_idx = pair.indexOf('=')

      // skip things that don't look like key=value
      if (eq_idx < 0) {
        return
      }

      var key = pair.substr(0, eq_idx).trim()
      var val = pair.substr(++eq_idx, pair.length).trim()

      // quoted values
      if (val[0] == '"') {
        val = val.slice(1, -1)
      }

      // only assign once
      if (undefined == obj[key]) {
        try {
          obj[key] = dec(val)
        } catch (e) {
          obj[key] = val
        }
      }
    })

    return obj
  },
  setCookie: function(name, value, options) {
    options = options || {}
    var exp = new Date()
    if (!options.expireTime) {
      var Days = 30
      exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000)
    } else {
      exp = options.expireTime
    }

    return document.cookie = name + '=' + escape(value + ';expires=' + exp.toGMTString())
  },
  // 仅用来存储token，不设置过期时间
  setStoreCookie: function(name, value) {
    document.cookie = name + '=' + value
  },
  getCookie: function(name) {
    var arr = null
    var reg = new RegExp('(^| )' + name + '=([^;]*)(;|$)')
    if ((arr = document.cookie.match(reg))) {
      return unescape(arr[2])
    } else {
      return null
    }
  },
  remove: function(name) {
    var cval, exp
    exp = new Date()
    exp.setTime(exp.getTime() - 1)
    cval = this.getCookie(name)
    if (cval !== null) {
      document.cookie = name + '=' + cval + ';expires=' + exp.toGMTString()
      document.cookie = name + '=' + cval + ';domain=' + location.host + 'expires=' + exp.toGMTString()
      document.cookie = name + '=' + cval + ';domain=.midea.com;expires=' + exp.toGMTString()
      document.cookie = name + '=' + cval + ';domain=.ec.midea.com;expires=' + exp.toGMTString()
      document.cookie = name + '=' + cval + ';domain=.cm.midea.com;expires=' + exp.toGMTString()
      document.cookie = name + '=' + cval + ';path=/;expires=' + exp.toGMTString()
      document.cookie = name + '=' + cval + ';path=/;domain=' + location.host + 'expires=' + exp.toGMTString()
      document.cookie = name + '=' + cval + ';path=/;domain=.midea.com;expires=' + exp.toGMTString()
      document.cookie = name + '=' + cval + ';path=/;domain=.ec.midea.com;expires=' + exp.toGMTString()
      return document.cookie = name + '=' + cval + ';path=/;domain=.cm.midea.com;expires=' + exp.toGMTString()
    }
  }
}

export default cookiejs
