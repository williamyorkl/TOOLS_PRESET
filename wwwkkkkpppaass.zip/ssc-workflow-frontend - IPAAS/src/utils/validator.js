import { expandTree } from '@/utils'

// 是否两位小数的小数
const isDecimal = /^([1-9]\d*.?|0.)\d{0,2}$/
// 是否正整数
const isInteger = /^\d+$/

/*
正则表达式
 */
export const regExpRules = {
  variable: /^[a-zA-Z_]+[a-zA-Z_0-9]+$/, // 变量名
  letterChinese: /^[a-zA-Z\u4e00-\u9fa5]+$/, // 大小写英文，中文
  numberLetterChinese: /^[a-zA-Z0-9\u4e00-\u9fa5]+$/, // 中文数字字母
  numberLetter: /^[0-9a-zA-Z]*$/, // 数字字母
  numberLetterLine: /^[0-9a-zA-Z_\-]*$/, // 数字字母下划线中划线
  // noChinese:/^[0-9a-zA-Z_:\-]*$/,//非中文
  noChinese: /^[^\u4e00-\u9fa5]*$/, // 非中文
  allInteger: /^-?[1-9]\d*|0$/, // 整数
  positiveNumber: /^[0-9]\d*$/, // 正整数
  number: /^[0-9]*$/, // 数字
  floatNumber: /^(0|[1-9]\d*)(\s|$|\.\d{1,2}\b)/, // 可以为小数的数字/^[0-9]+(.[0-9]{0,2})?$/
  numberNegative: /^-?[0-9]*$/, // 数字，可为负
  // price: /((^[1-9]\d*)|^0)(\.\d{0,2}){0,1}$/, // 价格
  phone: /^([0-9]{3,4}-)?[0-9]{7,8}$/, // 固话
  mobile: /^1[3|4|5|6|7|8|9][0-9]\d{8}$/, // 手机号
  zip: /^[0-9]{6}$/, // 邮编
  price: /^\d{1,8}(\.\d{1,2})?$/, // 价格
  price2: /^\d{1,10}(\.\d{1,2})?$/, // 价格
  discount: /^((0\.[1-9]{1})|(([1-9]{1})(\.\d{1})?))$/, // 0-10，保留一位小数
  integer: /^\d+$/, // 正整数
  discountRate: /^\d{1,10}(\.\d{1})?$/, // 折扣
  priceNegative: /^-?\d{1,8}(\.\d{1,2})?$/, // 价格，可为负
  invoicePrice: /^\d{1,8}(\.\d{1,6})?$/, // 发票价格
  url: /^(?:([A-Za-z]+):)?(\/{0,3})([0-9.\-A-Za-z]+)(?::(\d+))?(?:\/([^?#]*))?(?:\?([^#]*))?(?:#(.*))?$/,
  link: /^https?:\/\/(([a-zA-Z0-9_-])+(\.)?)*(:\d+)?(\/((\.)?(\?)?=?&?[a-zA-Z0-9_-](\?)?)*)*$/i,
  email: /^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$/, // 邮箱
  commonCharacter: /^[ A-Za-z0-9_\u4e00-\u9fa5\"\'\,\，\.\。\！\!\?\？\-\—\_\<\>\%\;\‘\’\；\:\：\)\《\（\）\》\(\&\+\=\`\“\”\·\*\#\@\@\、\▪\の\]\[]+$/, // 常用中英文及标点符号，不允许表情符号
  textareaCharacter: /^[ A-Za-z0-9_\u4e00-\u9fa5\r\n\"\'\,\，\.\。\！\!\?\？\-\—\_\<\>\%\;\‘\’\；\:\：\)\《\（\）\》\(\&\+\=\`\“\”\·\*\#\@\@\、\▪\の\]\[]+$/, // 常用中英文及标点符号，不允许表情符号
  numberAndeChat: /^[ A-Za-z0-9_\u4e00-\u9fa5\"\'\,\，\.\。\！\!\?\？\-\—\_\<\>\%\;\‘\’\；\:\：\)\《\（\）\》\(\&\+\=\`\“\”\·\*\#\@\@\、\▪\の\]\[]+$/, // 常用中英文及标点符号空格，不允许表情符号
  noStartWithSlash: /^(?!\/).*/, // 不以/开头
  startWithSlash: /^(\/).*/, // 以/开头
  endWithSlash: /.*(\/)$/, // 以/结尾
  start_Noend_WithSlash: /^(\/).*(?<!\/)$/, // 以/开头且不以/结尾  ?<!向后匹配（加字符串为否定式向后匹配）
  ipSplitWithComma: /^(?:(?:^|,)(?:[0-9]|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5])(?:\.(?:[0-9]|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5])){3})+$/, // IP地址以逗号分隔
  urlPathParam: /\{(?:.+?)\}/g, // 解析url中参数:结果包含{}
  urlPathParamIn: /[^{\}]+(?=})/g, // 解析url中参数：结果不包含{}
  sqlSelectParams: /(?<=select).*?(?=from)/, // 解析select from之间的变量
  chunkLoadError: /Loading chunk (\d)+ failed/g, // 版本变化后，加载文件出错
  passWord: /[a-zA-Z0-9_\*\!\@\#\$\%\^\&\(\)]{4,16}/, // 4-16的数字字母下划线组合
  account: /[a-zA-Z0-9\u4e00-\u9fa5_\*\!\@\#\$\%\^\&\(\)]{2,16}/, // 4-16数字字母下划线中文
  firstNoNum: /[a-zA-Z_][a-zA-Z0-9_]*/ // 第一项输入非数字
}

export const validateFn = {
  /**
   * 用于判断某个范围内的数值
   * @param {*} min 最小值
   * @param {*} max 最大值
   * @param {*} isInt 是否必须为整数
   * @param {*} notNull 是否可以为空
   * @param {*} isPositiveNumber 是否正整数
   * @returns
   */
  checkNum: ({ min = 0, max = 100, isInt = true, notNull = true, isPositiveNumber }) => {
    return function(rule, value, callback) {
      if (notNull && (!value && value !== 0)) {
        callback(new Error('不能为空'))
      }
      if (!notNull && (!value && value !== 0)) {
        callback()
      }
      if (isPositiveNumber && !regExpRules.positiveNumber.test(value)) {
        callback(new Error('必须为正整数'))
      }
      if (isInt && !regExpRules.allInteger.test(value)) {
        callback(new Error('必须为整数'))
      }
      if (value < min) {
        callback(new Error(`不能小于${min}`))
      }
      if (value > max) {
        callback(new Error(`不能大于${max}`))
      }
      callback()
    }
  },
  checkJsonStr: (rule, value, callback) => {
    if (!value) callback()
    if (value) {
      try {
        JSON.parse(value)
        callback()
      } catch (e) {
        callback(new Error('请输入正确的JSON数据'))
      }
    }
  },
  checkRegexp(_rule, _value, _callback) {
    return function(rule, value, callback) {
      if (!value) callback()
      if (value) {
        try {
          // eslint-disable-next-line no-new
          new RegExp(value)
          callback()
        } catch (e) {
          callback(new Error('请输入正确的正则表达式'))
        }
      }
    }
  },
  validateFile: (filename, suffix) => {
    const reg = new RegExp(`^.+\\.${suffix}$`)
    return reg.test(filename)
  },
  checkNotBigThanNow: (rule, value, callback) => {
    const timestamp = new Date(value).getTime()
    if (timestamp && (timestamp < Date.now())) {
      callback(new Error('不能小于当前时间'))
    }
    callback()
  },
  checkLength: ({ minlength = 4, maxlength = 16 }) => {
    return function(rule, value, callback) {
      if (value.length < minlength || value.length > maxlength) {
        callback(new Error(`长度必须在${minlength}-${maxlength}之间`))
      }
      callback()
    }
  }
}

export function checkInt1To999999(rule, value, callback, msg = '请输入1-999999的整数') {
  if (value === '') {
    return callback(new Error(msg))
  } else {
    if (/^[+]?[0-9]+\d*$/i.test(value)) {
      if (value > 999999 || value < 1) return callback(new Error(msg))
    } else {
      return callback(new Error(msg))
    }
  }
  callback()
}

export function checkInt1To999999OrNull(rule, value, callback, msg = '请输入1-999999的整数') {
  if (value) {
    if (/^[+]?[0-9]+\d*$/i.test(value)) {
      if (value > 999999 || value < 1) return callback(new Error(msg))
    } else {
      return callback(new Error(msg))
    }
  }
  callback()
}

export function checkPrice(rule, value, callback, msg = '请输入0.01-999999.99内的金额') {
  if (value === '') {
    return callback(new Error(msg))
  } else {
    const dot = value.toString().indexOf('.')
    if (dot !== -1) {
      const dotCnt = value.toString().substring(dot + 1, value.toString().length)
      if (dotCnt.length > 2) {
        return callback(new Error(msg))
      }
    }
    if (/^\d+(\.\d+)?$/i.test(value)) {
      if (value < 0.01 || value > 999999.99) return callback(new Error(msg))
    } else {
      return callback(new Error(msg))
    }
  }
  callback()
}

export function checkPriceOrNull(rule, value, callback, msg = '请输入0.01-999999.99内的金额') {
  if (value) {
    const dot = value.toString().indexOf('.')
    if (dot !== -1) {
      const dotCnt = value.toString().substring(dot + 1, value.toString().length)
      if (dotCnt.length > 2) {
        return callback(new Error(msg))
      }
    }
    if (/^\d+(\.\d+)?$/i.test(value)) {
      if (value < 0.01 || value > 999999.99) return callback(new Error(msg))
    } else {
      return callback(new Error(msg))
    }
  }
  callback()
}

export function checkLength64(rule, value, callback, msg = '名称长度不能超过64') {
  if (value === '') {
    return callback(new Error(msg))
  } else {
    const len = value.length
    if (len > 64) {
      return callback(new Error(msg))
    }
  }
  callback()
}

export function checkPercentage(rule, value, callback, msg = '请输入0.01-99.99内数字的百分比') {
  if (value === '') {
    return callback(new Error(msg))
  } else {
    const dot = value.toString().indexOf('.')
    if (dot !== -1) {
      const dotCnt = value.toString().substring(dot + 1, value.toString().length)
      if (dotCnt.length > 1) {
        return callback(new Error(msg))
      }
    }
    if (/^\d+(\.\d+)?$/i.test(value)) {
      if (value < 0.01 || value > 99.99) return callback(new Error(msg))
    } else {
      return callback(new Error(msg))
    }
  }
  callback()
}

export function mobileRule(rule, value, callback, msg = '请输入正确的邮箱') {
  const reg = regExpRules.mobile
  if (value && !reg.test(value)) {
    return callback(new Error(msg))
  } else {
    callback()
  }
};
export function emailRule(rule, value, callback, msg = '请输入正确的邮箱') {
  const reg = regExpRules.email
  if (value && !reg.test(value)) {
    return callback(new Error(msg))
  } else {
    callback()
  }
};

export function validatePass(rule, value, callback, msg = '请输入密码') {
  if (value === '') {
    callback(new Error(msg))
  } else {
    if (this.updatePasswordForm.confirmPassword !== '') {
      this.$refs.updatePasswordForm.validateField('confirmPassword')
    }
    callback()
  }
};
export function validatePass2(rule, value, callback, emptyMsg = '请再次输入密码', errorMsg = '两次输入密码不一致!') {
  if (value === '') {
    callback(new Error(emptyMsg))
  } else if (value !== this.updatePasswordForm.newPassword) {
    callback(new Error(errorMsg))
  } else {
    callback()
  }
};

/**
 * 校验树形列表数据
 * @param {*} treeData 树形列表数据
 * @param {*} validateFn 每行校验函数， 返回值是[true]时继续执行，返回值时[false, msg]时跳出并打印错误
 * @param {*} rowIndex 当前行数
 * @param {*} isTop 是否最上层
 *
 * @returns{Array} [Boolean,  msg]
 */
export function validateTableTreeData(treeData, validateFn, rowIndex = 0, isTop = true) {
  let msg = null
  let valid = true
  // 深度遍历
  const newTreeData = treeData
  const len = newTreeData.length
  for (let i = 0; i < len; i++) {
    rowIndex++
    [valid, msg] = validateFn(newTreeData[i], isTop)
    if (!valid) {
      break
    } else if (!newTreeData[i].childrenList || newTreeData[i].childrenList.length === 0) {
      continue
    } else {
      [valid, msg, rowIndex, isTop] = validateTableTreeData(newTreeData[i].childrenList, validateFn, rowIndex, false)
      if (!valid) break
    }
  }
  return [valid, msg, rowIndex, isTop]
}

/**
 * 检测是否是某个范围的两位小数
 * @param {string | number} num 要检测的值
 * @param {Array} range 值的范围
 */
export function AmountTest(num, range = [0, 999999.99]) {
  return isDecimal.test(num) && num <= range[1] && num > range[0]
}

/**
 * 检测是否为正整数
 * @param {number | string} num 数值
 * @param {Array} range 范围
 */
/** */
export function NumTest(num, range = [0, 999999]) {
  return isInteger.test(num) && num > range[0] && num <= range[1]
}

/**
 * 仅用于判断开始时间是否大于结束时间
 * @param {Date} start 开始时间
 * @param {Date} end 结束时间
 *
 * @return {boolean} start > end 返回true
 */
export function checkDateRange(start, end) {
  return start && end && new Date(start).getTime() > new Date(end).getTime()
}

/**
 * 用于判断时分秒大小
 * @param {*} start HH:mm:ss
 * @param {*} end HH:mm:ss
 *
 * @return {boolean} start > end 返回true
 */
export function checkHMS(start, end) {
  return start.split(':').join('') > end.split(':').join('')
}

/**
 *
 * @param {Date} val 时间
 *
 * @return {boolean} val小于当前时间返回true
 */
export function checkDateVsNow(val) {
  return val && (new Date(val).getTime() < new Date().getTime())
}

export function checkInt1To99999(rule, value, callback, msg = '请输入1-99999的整数') {
  if (value === '') {
    return callback(new Error(msg))
  } else {
    if (/^[+]?[0-9]+\d*$/i.test(value)) {
      if (value > 99999 || value < 1) return callback(new Error(msg))
    } else {
      return callback(new Error(msg))
    }
  }
}

export function validateTree({ tree = [], children = 'childrenList', ruleFn }) {
  // 展开
  const list = expandTree(tree, children)
  let result = ''
  for (let i = 0; i < list.length; i++) {
    const msg = ruleFn(list[i], tree)
    if (msg) {
      result = `第${i + 1}行：${msg}`
      break
    }
  }
  return result
}
