import { Message } from 'element-ui'
export default function() {
  const scripts = [...document.querySelectorAll('script')]
  const script = scripts.pop()

  const str = script.src
  const res = str.match(/app\.(.*?)\.js/)
  let newHash = null
  if (res) {
    newHash = res[1]
  }
  if (newHash) {
    const currentHash = localStorage.getItem('ipaas-currentHash')
    if (currentHash && currentHash !== newHash) {
      Message.warning('检测到版本更新，即将自动更新...')
      setTimeout(() => {
        localStorage.clear()
        localStorage.setItem('ipaas-currentHash', newHash)
        location.reload()
      }, 1000)
    } else {
      localStorage.setItem('ipaas-currentHash', newHash || '')
    }
  }
}
