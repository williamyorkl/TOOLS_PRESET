import { regExpRules } from '@/utils/validator'
import jsonpath from 'jsonpath'
import upperFirst from 'lodash/upperFirst'

/* 使用JSON深克隆，但是undefined, symbol, 函数会被忽略，循环引用也不行 */
/**
 * [goPlatformAuth：跳转平台授权]
 * @param  {[type]} platformId   [平台id]
 * @param  {[type]} platformCode [平台code]
 * @param  {[type]} shopId       [店铺id]
 * @param  {[type]} appType      [有赞：0]
 * @param  {[type]} operate      [1：店铺接入，2：店铺续权]
 * @return {[type]}              [description]
 */
import { AUTH_REDIRECT_URL } from '../config'
import { JS_JAVA_TYPE_TRANSFORM, TIME_OPTIONS } from '@/config/enum'

export const jsonDeepClone = obj => JSON.parse(JSON.stringify(obj))

export const type = (obj) => {
  return Object.prototype.toString.call(obj).slice(8, -1).toLowerCase()
}

/**
 * 数组中的对象的key是否有重复或为null或undefined的
 *
 * @param {Array} list 数组，元素为对象
 * @param {string} key 作为判断依据的对象属性
 *
 * @returns {Boolean} flag 是否无重复项且每项的key属性不能为空，true代表有
 */
export function isUnique(list, key) {
  const obj = {}
  let flag = true
  const len = list.length
  for (let i = 0; i < len; i++) {
    if (list[i][key] === null || list[i][key] === undefined) {
      return false // 不能为空
    }
    if (obj[list[i][key]]) {
      flag = false
      break
    } else {
      obj[list[i][key]] = true
    }
  }
  return flag
}

export const deepClone = (source) => {
  let result; let item; const t = type(source)
  if (t === 'array') {
    result = []
    for (item of source) {
      result.push(deepClone(item))
    }
  } else if (t === 'object') {
    result = {}
    for (item in source) {
      result[item] = deepClone(source[item])
    }
  } else {
    result = source
  }
  return result
}

export const extend = (target, source, extendKeyList = []) => {
  extendKeyList.forEach((item) => {
    target[item] = source[item]
  })
  return target
}

/**
 * 过滤对象空属性
 * @param obj
 */
export const filterPm = (obj) => {
  const _newPar = {}
  // eslint-disable-next-line no-unused-vars
  for (const key in obj) {
    // 如果对象属性的值不为空，就保存该属性（这里我做了限制，如果属性的值为0，保存该属性。如果属性的值全部是空格，属于为空。）
    if ((obj[key] === 0 || obj[key]) && obj[key].toString().replace(/(^\s*)|(\s*$)/g, '') !== '') {
      // 记录属性
      _newPar[key] = obj[key]
    }
  }
  // 返回对象
  return _newPar
}
// 正则校验手机号或者固话
export function validatePhoneTwo(rule, value, callback) {
  const reg = /^((0\d{2,3}-\d{7,8})|(1[3456789]\d{9}))$/
  if (value === '' || value === undefined || value === null) {
    callback()
  } else {
    if ((!reg.test(value)) && value !== '') {
      callback(new Error('请输入正确的电话号码或者固话号码'))
    } else {
      callback()
    }
  }
}

/**
 * 字段拼接url
 */
export const parseParams = (param) => {
  let paramStr = ''
  // eslint-disable-next-line no-unused-vars
  for (const key in param) {
    paramStr += '&' + key + '=' + param[key]
  }
  return paramStr.substr(1)
}

export const pick = (source, pickKeyList = [], pickUndefined = true) => {
  const result = {}
  pickKeyList.forEach((key) => {
    if (pickUndefined) {
      result[key] = source[key]
    } else if (typeof source[key] !== 'undefined') {
      result[key] = source[key]
    }
  })
  return result
}

export const difference = (sourceList, targetList) => {
  return sourceList.forEach(i => targetList.indexOf(i) === -1)
}

// 判断是否为空，不包括0
export const isEmptyString = (value) => {
  if (value === undefined || value === 'undefined' || value === '' || value === null || value === 'null') {
    return true
  }
  return false
}

export const isUndefined = (item) => {
  return typeof item === 'undefined'
}

export const isDefined = (item) => {
  return !isUndefined(item)
}

export const floatAdd = (arg1, arg2) => {
  let r1, r2
  try {
    r1 = arg1.toString().split('.')[1].length
  } catch (e) {
    r1 = 0
  }
  try {
    r2 = arg2.toString().split('.')[1].length
  } catch (e) {
    r2 = 0
  }
  const m = Math.pow(10, Math.max(r1, r2))
  return (arg1 * m + arg2 * m) / m
}

export const floatSub = (arg1, arg2) => {
  let r1, r2
  try {
    r1 = arg1.toString().split('.')[1].length
  } catch (e) {
    r1 = 0
  }
  try {
    r2 = arg2.toString().split('.')[1].length
  } catch (e) {
    r2 = 0
  }
  const m = Math.pow(10, Math.max(r1, r2))
  // 动态控制精度长度
  const n = r1 >= r2 ? r1 : r2
  return ((arg1 * m - arg2 * m) / m).toFixed(n)
}

/**
 * 数据脱敏
 *
 * @param {*} data
 * @param {*} type 1 手机号  2 身份证号
 */
export const dataMasking = (data, type) => {
  if (data === '') return ''
  if (data === null || data === undefined) return ''
  let result = ''
  if (type === 1) {
    result = data.substr(0, 3) + '****' + data.substr(data.length - 4, 4)
  } else if (type === 2) {
    result = data.substr(0, 4) + '****' + data.substr(data.length - 4, 4)
  }
  return result
}

// ecm定义
export const pickQuery = (sourceList, unpickKeyList = []) => {
  return sourceList.forEach(i => unpickKeyList.indexOf(i.key) === -1)
}

export const formatTime = (val, fmt = 'yyyy-MM-dd hh:mm:ss') => {
  if (!val) return
  val = new Date(val)

  const o = {
    'M+': val.getMonth() + 1, //  月份
    'd+': val.getDate(), // 日
    'h+': val.getHours(), // 小时
    'm+': val.getMinutes(), // 分
    's+': val.getSeconds(), // 秒
    'q+': Math.floor((val.getMonth() + 3) / 3), // 季度
    S: val.getMilliseconds() // 毫秒
  }
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (val.getFullYear() + '').substr(4 - RegExp.$1.length))
  }
  // eslint-disable-next-line no-unused-vars
  for (const k in o) {
    if (new RegExp('(' + k + ')').test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)))
    }
  }
  return fmt
}

export const formatDate = (val, fmt = 'yyyy-MM-dd') => {
  if (!val) return
  val = new Date(val)

  const o = {
    'M+': val.getMonth() + 1, //  月份
    'd+': val.getDate() // 日
  }
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (val.getFullYear() + '').substr(4 - RegExp.$1.length))
  }
  // eslint-disable-next-line no-unused-vars
  for (const k in o) {
    if (new RegExp('(' + k + ')').test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)))
    }
  }
  return fmt
}

export const ComponentType = {
  NAVIGATION_BAR: 0,
  BANNER: 1,
  ACTIVITY_ENTRY: 2,
  BANNER_AD: 3,
  COUPON: 4,
  NOTICE: 5,
  LATERAL_SKU_WINDOW: 6,
  BUTTON_SKU_WINDOW: 7,
  LONGITUDINAL_SKU_WINDOW: 8,
  SEARCH_BAR: 9,
  NAV_CAT: 10,
  MALL_ACTIVE: 11,
  TOPLIST: 12,
  BRAND_LIST: 13,
  ROOM_POSITION: 14
}

export const platformType = {
  platform: {
    1: 'tmall',
    11: 'suning',
    127: 'Tmall_nr',
    2: 'jd',
    4: 'taobao',
    5: 'gongxiao',
    27: 'youzan',
    28: 'jdzy',
    30: 'pdd',
    31: 'eleme'

  },
  virtualforms: {
    1: 'tmall',
    11: 'suning',
    127: 'Tmall_nr',
    2: 'jd',
    4: 'taobao',
    5: 'gongxiao',
    27: 'youzan',
    28: 'jdzy',
    30: 'pdd',
    31: 'eleme',
    99: 'other'
  },
  allforms: {
    1: 'tmall',
    11: 'suning',
    127: 'Tmall_nr',
    2: 'jd',
    4: 'taobao',
    5: 'gongxiao',
    27: 'youzan',
    28: 'jdzy',
    30: 'pdd',
    31: 'eleme',
    99: 'other'
  }
}

export const goPlatformAuth = function(platformId, platformCode, shopId, appType, operate) {
  let state = [platformId, shopId, appType, operate]
  state = state.join(':')
  if (platformCode === 'youzan') {
    window.open('https://open.youzan.com/oauth/authorize?client_id=30ab0a1a9463f4919e&response_type=code&state=' + state + '&redirect_uri=' + AUTH_REDIRECT_URL)
  } else if (platformCode === 'jd' || platformCode === 'jdzy') {
    window.open('https://oauth.jd.com/oauth/authorize?response_type=code&client_id=7BDF42FAEDF206E65034736D05A58128&state=' + state + '&redirect_uri=' + AUTH_REDIRECT_URL)
  } else if (platformCode === 'taobao' || platformCode === 'tmall' || platformCode === 'gongxiao' || platformCode === 'Tmall_nr') {
    window.open('https://oauth.taobao.com/authorize?response_type=code&client_id=25536276&view=web&state=' + state + '&redirect_uri=' + AUTH_REDIRECT_URL)
  } else if (platformCode === 'pdd') {
    window.open('https://mms.pinduoduo.com/open.html?response_type=code&client_id=871c593e656444c7a3eacc290dd08366&state=' + state + '&redirect_uri=' + AUTH_REDIRECT_URL)
  } else if (platformCode === 'eleme') {
    window.open('https://be.ele.me/crm?qt=apishopbindpage&source=58F805C8492E7411C405AF7F512999FC43C4CF23C653BC44E57A818FE2D2DFEE&state=' + state + '&redirect_uri=' + AUTH_REDIRECT_URL)
  } else if (platformCode === 'suning') {
    window.open('https://open.suning.com/api/oauth/authorize?response_type=code&client_id=4dc11c5f0c0de631ef0217b9fcb1af7d&redirect_uri=http://ecu.yst.com.cn/shop/platform-auth&scope=item,price,order&state=1&itemcode=6012&state=' + state + '&redirect_uri=' + AUTH_REDIRECT_URL)
  }
}

// TMALL((byte)1, "天猫"),
// JD((byte)2, "京东"),
// VDIAN((byte)3, "微店"),
// TAOBAO((byte)4,"淘宝"),
// GONGXIAO((byte)5, "供销平台"),
// ALIPAY((byte)6,"支付宝"),
// FX((byte)7, "深圳分销"),
// YHD((byte)8, "一号店"),
// GOME((byte)10, "国美"),
// SUNING((byte)11, "苏宁易购"),
// LTSWAN((byte)18,"小天鹅"),
// BEIBEI((byte)19,"贝贝网"),
// QIMEN((byte)20,"奇门"),
// VIP((byte)22, "唯品会"),
// GIFTCARD((byte)23,"礼品卡"),
// SUNINGCS((byte)24,"苏宁厂送"),
// YOUZAN((byte)27, "有赞");
// JD_ZY((byte)28,"京东自营")

export const checkCommonCharacter = (rule, value, callback) => {
  if (value === '' || value === null || typeof value === 'undefined') {
    return callback()
  } else {
    // 正则校验
    const flag = regExpRules.commonCharacter.test(value)
    if (!flag) {
      return callback(new Error('不支持输入表情'))
    } else {
      return callback()
    }
  }
}
// 佣金0~1
export const checkCommission = (rule, value, callback) => {
  if (value === '' || value === null || typeof value === 'undefined') {
    return callback()
  } else {
    // 正则校验
    const flag = regExpRules.price.test(value)
    if (!flag || (flag && (value < 0 || value > 100))) {
      return callback(new Error('请输入范围是0~100的小数'))
    } else {
      return callback()
    }
  }
}

export const checkPrice = (rule, value, callback) => {
  if (value === '' || value === null || typeof value === 'undefined') {
    return callback()
  } else {
    // 正则校验
    const flag = regExpRules.price.test(value)
    if (!flag) {
      return callback(new Error('请输入最多8位整数,最多2位小数'))
    } else if (parseInt(value) > 99999999) {
      return callback(new Error('金额不能大于99999999'))
    } else {
      return callback()
    }
  }
}
export const checkPriceError = (value, name = '价格') => {
  if (value === '' || value === null || typeof value === 'undefined') {
    return name + '不能为空'
  } if (value < 0) {
    return name + '不能小于0'
  } else {
    // 正则校验
    const flag = regExpRules.price.test(value)
    if (!flag) {
      return '请输入最多8位整数,最多2位小数的' + name
    } else if (parseInt(value) > 99999999) {
      return name + '不能大于99999999'
    } else {
      return ''
    }
  }
}
export const checkPriceNegative = (rule, value, callback) => {
  if (value) {
    // 正则校验
    const flag = regExpRules.priceNegative.test(value)
    if (!flag) {
      return callback(new Error('请输入最多8位整数,最多2位小数'))
    } else if (parseInt(value) > 99999999) {
      return callback(new Error('金额不能大于99999999'))
    } else {
      return callback()
    }
  }
}

export const checkInvoicePrice = (rule, value, callback) => {
  if (value === '' || value === null || typeof value === 'undefined') {
    return callback()
  } else {
    // 正则校验
    const flag = regExpRules.invoicePrice.test(value)
    if (!flag) {
      return callback(new Error('请输入不超过6位的小数'))
    } else {
      return callback()
    }
  }
}
export const checkEmail = (rule, value, callback) => {
  if (value === '' || value === null || typeof value === 'undefined') {
    return callback()
  } else {
    // 正则校验
    const flag = regExpRules.email.test(value)
    if (!flag) {
      return callback(new Error('请输入正确的邮箱地址'))
    } else {
      return callback()
    }
  }
}
export const checkMobile = (rule, value, callback) => {
  if (value === '' || value === null || typeof value === 'undefined') {
    return callback(new Error('手机号码不能为空'))
  } else {
    // 正则校验
    const flag = regExpRules.mobile.test(value)
    if (!flag) {
      return callback(new Error('手机号码不规范'))
    } else {
      return callback()
    }
  }
}
export const checkPhoneOrMobile = (rule, value, callback) => {
  if (value === '' || value === null || typeof value === 'undefined') {
    return callback()
  } else {
    // 正则校验
    const flagMobile = regExpRules.mobile.test(value)
    const flagPhone = regExpRules.phone.test(value)
    if (!flagMobile && !flagPhone) {
      return callback(new Error('请正确的手机或座机号码'))
    } else {
      return callback()
    }
  }
}
export const checkNumber = (rule, value, callback) => {
  if (value === '' || value === null || typeof value === 'undefined') {
    return callback()
  } else {
    // 正则校验
    const flag = regExpRules.number.test(value)
    if (!flag) {
      return callback(new Error('请输入数字'))
    } else {
      return callback()
    }
  }
}
// 只允许字母数字
export const checkNumberLetter = (rule, value, callback) => {
  if (value === '' || value === null || typeof value === 'undefined') {
    return callback()
  } else {
    // 正则校验
    const flag = regExpRules.numberLetter.test(value)
    if (!flag) {
      return callback(new Error('请输入字母或数字'))
    } else {
      return callback()
    }
  }
}

export const checkNumberLetterLine = (rule, value, callback) => {
  if (value) {
    // 正则校验
    const flag = regExpRules.numberLetterLine.test(value)
    if (!flag) {
      return callback(new Error('请输入字母、数字、中划线或下划线'))
    } else {
      return callback()
    }
  } else {
    return callback()
  }
}

// 只允许中文、字母、数字
export const checkNumberLetterChinese = (rule, value, callback) => {
  if (value === '' || value === null || typeof value === 'undefined') {
    return callback()
  } else {
    // 正则校验
    const flag = regExpRules.numberLetterChinese.test(value)
    if (!flag) {
      return callback(new Error('请输入中文、字母或数字'))
    } else {
      return callback()
    }
  }
}
// 只允许中文、字母、数字
export const checkLetterChinese = (rule, value, callback) => {
  if (value === '' || value === null || typeof value === 'undefined') {
    return callback()
  } else {
    // 正则校验
    const flag = regExpRules.letterChinese.test(value)
    if (!flag) {
      return callback(new Error('请输入中文、字母'))
    } else {
      return callback()
    }
  }
}
// 不能输入中文字符和全角字符
export const checkNoChinese = (rule, value, callback) => {
  if (value) {
    // 正则校验
    const flag = regExpRules.noChinese.test(value)
    if (!flag) {
      return callback(new Error('请输入非中文字符和全角字符'))
    } else {
      return callback()
    }
  } else {
    return callback(new Error('请输入'))
  }
}
export const checkPriceTest = (rule, value, callback) => {
  if (value) {
    // 正则校验
    const flag = regExpRules.price.test(value)
    if (!flag) {
      return callback(new Error('请输入最多8位整数,最多2位小数'))
    } else if (parseInt(value) > 99999999) {
      return callback(new Error('金额不能大于99999999'))
    } else {
      return callback()
    }
  } else {
    return callback(new Error('请输入'))
  }
}

export const checkNumberTest = (rule, value, callback) => {
  if (value) {
    // 正则校验
    const flag = regExpRules.number.test(value)
    if (!flag) {
      return callback(new Error('请输入数字'))
    } else {
      return callback()
    }
  } else {
    return callback(new Error('请输入'))
  }
}

// 只允许中文、字母、数字
export const checkLetterChineseTest = (rule, value, callback) => {
  if (value) {
    // 正则校验
    const flag = regExpRules.letterChinese.test(value)
    if (!flag) {
      return callback(new Error('请输入中文、字母'))
    } else {
      return callback()
    }
  } else {
    return callback(new Error('请输入'))
  }
}

// 验证是否是[0-100]的小数
export function isBtnZeroToHundred(rule, value, callback) {
  if (!value) {
    return callback(new Error('输入不可以为空'))
  }
  setTimeout(() => {
    if (!Number(value)) {
      callback(new Error('请输入[1,100]之间的数字'))
    } else {
      if (value < 0 || value > 100) {
        callback(new Error('请输入[1,100]之间的数字'))
      } else {
        callback()
      }
    }
  }, 100)
}

// 验证是否整数,非必填
export function isIntegerNotMust(rule, value, callback) {
  if (!value) {
    callback()
  }
  setTimeout(() => {
    if (!Number(value)) {
      callback(new Error('请输入正整数'))
    } else {
      const re = /^[0-9]*[1-9][0-9]*$/
      const rsCheck = re.test(value)
      if (!rsCheck) {
        callback(new Error('请输入正整数'))
      } else {
        callback()
      }
    }
  }, 1000)
}

// 验证是否整数
export function isInteger(rule, value, callback) {
  if (!value) {
    return callback(new Error('输入不可以为空'))
  }
  setTimeout(() => {
    if (!Number(value)) {
      callback(new Error('请输入正整数'))
    } else {
      const re = /^[0-9]*[1-9][0-9]*$/
      const rsCheck = re.test(Number(value))
      if (!rsCheck) {
        callback(new Error('请输入正整数'))
      } else {
        callback()
      }
    }
  }, 0)
}

// 验证数字输入框最大数值,32767
export function checkMaxVal(rule, value, callback) {
  if (value < 0 || value > 32767) {
    callback(new Error('请输入[0,32767]之间的数字'))
  } else {
    callback()
  }
}

export function checkNumberAndeChat(rule, value, callback) {
  const reg = regExpRules.numberAndeChat
  if (!reg.test(value)) {
    return callback(
      new Error('请输入中英文常用字符，不允许输入表情')
    )
  } else {
    callback()
  }
}

export function leftTimer(leftTime) {
  const checkTime = i => {
    if (i < 0 || i === null || i === undefined) {
      i = 0
    }
    if (i < 10) {
      i = '0' + i
    }
    return i
  }
  leftTime = leftTime * 1000
  // var leftTime = (endTime * 1000) - new Date().getTime();
  let days = parseInt(leftTime / 1000 / 60 / 60 / 24, 10)
  let hours = parseInt((leftTime / 1000 / 60 / 60) % 24, 10)
  let minutes = parseInt((leftTime / 1000 / 60) % 60, 10)
  let seconds = parseInt((leftTime / 1000) % 60, 10)
  days = checkTime(days)
  hours = checkTime(hours)
  minutes = checkTime(minutes)
  seconds = checkTime(seconds)
  return {
    days: days,
    hours: hours,
    minutes: minutes,
    seconds: seconds
  }
}

export const genID = (length = 4) => {
  return Number(Math.random().toString().substr(3, length) + Date.now()).toString(36)
}

/**
 * 生成唯一标识
 * @returns {string} 唯一标识
 */
export function getUUID() {
  return Math.random().toString(36).substr(3, 10)
}

/**
 * @description 将所有source的字段都赋给target
 * @params source target excludKeyList canAddKey
 * source：赋值对象
 * target：被赋值对象
 * excludKeyList：数组中的key不会替换
 * canAddKey：是否允许在target上增加key
*/
export const setObjValue = (source = {}, target = {}, excludKeyList = [], canAddKey = false) => {
  // eslint-disable-next-line no-unused-vars
  for (const key in source) {
    if ((canAddKey || key in target) && !excludKeyList.includes(key)) {
      target[key] = source[key]
    }
  }
  return target
}
/**
 * @description 将所有source的pickKeyList字段都赋给target：
 * @params source target pickKeyList canAddKey
 * source：赋值对象
 * target：被赋值对象
 * pickKeyList：需要被赋值的key
 * canAddKey：是否允许在target上增加key
*/
export const setObjValueByKeys = (source = {}, target = {}, pickKeyList = [], canAddKey = false) => {
  // eslint-disable-next-line no-unused-vars
  for (const key in source) {
    if ((canAddKey || key in target) && pickKeyList.includes(key)) {
      target[key] = source[key]
    }
  }

  return target
}

export const isJSON = (str) => {
  if (typeof str === 'string') {
    try {
      const obj = JSON.parse(str)
      if (typeof obj === 'object' && obj) {
        return true
      } else {
        return false
      }
    } catch (e) {
      console.log('error：' + str + '!!!' + e)
      return false
    }
  }
  console.log('It is not a string!')
}

export const isObject = (data) => {
  return Object.prototype.toString.call(data) === '[object Object]'
}

/**
 * 判断类型
 * @param {*} data
 * @returns float | int | string | object | array | function | regexp | date ...
 */
export const _typeof = (data) => {
  const s = Object.prototype.toString.call(data)
  let typ = s.match(/\[object (.*?)\]/)[1].toLowerCase()
  if (typ === 'number') {
    if (parseInt(data) === data) {
      typ = 'integer'
    } else {
      typ = 'float'
    }
  }
  return typ
}

/**
 * 是否为空
 * @param {*} data
 * @returns
 */
export function isNull(data) {
  if (data === undefined || data === null || data === '') {
    return true
  }
  return false
}

// 将对象格式的数据转为树形数组
export const objIteration = (obj, tree = [], parentNode) => {
  const parentType = _typeof(obj)
  if (parentType === 'object') {
    // eslint-disable-next-line no-unused-vars
    for (const key in obj) {
      const type = _typeof(obj[key])
      const dataType = jsJavaTypeTransform(type)
      let parentPath = ''
      let parentPathPatch = ''
      if (parentNode) {
        if (parentNode.dataType === 8) {
          parentPathPatch = '[]'
        }
        parentPath = parentNode.path + parentPathPatch + '.'
      }
      let path = parentPath + key
      if (type === 'array') {
        path = parentPath + key
      }
      let children = []
      const node = {
        name: key,
        value: obj[key],
        label: `${key}: ${firstUpperCase(type)}`,
        type,
        dataType,
        children,
        path
      }
      if (_typeof(obj[key]) === 'object') {
        children = objIteration(obj[key], children, node)
      }
      if (_typeof(obj[key]) === 'array') {
        children = objIteration(obj[key][0], children, node)
      }
      tree.push(node)
    }
    return tree
  } else if (parentType === 'array') {
    obj = obj[0]
    return objIteration(obj, tree, parentNode)
  }
}

/**
 * 首字母大写
 */
export function firstUpperCase([first, ...rest]) { return first?.toUpperCase() + rest.join('') }

// 将对象格式的数据转为树形数组,childrenList
export const objIterationChildrenList = (obj, tree = [], parentNode) => {
  const parentType = _typeof(obj)
  if (parentType === 'object') {
    // eslint-disable-next-line no-unused-vars
    for (const key in obj) {
      const type = _typeof(obj[key])
      const dataType = jsJavaTypeTransform(type)
      let parentPath = ''
      let parentPathPatch = ''
      if (parentNode) {
        if (parentNode.dataType === 8) {
          parentPathPatch = '[]'
        }
        parentPath = parentNode.path + parentPathPatch + '.'
      }
      let path = parentPath + key
      if (type === 'array') {
        path = parentPath + key
      }
      let childrenList = []
      const node = {
        name: key,
        paramName: key,
        value: obj[key],
        label: `${key}: ${firstUpperCase(type)}`,
        type,
        dataType,
        childrenList,
        path
      }
      if (_typeof(obj[key]) === 'object') {
        childrenList = objIterationChildrenList(obj[key], childrenList, node)
      }
      if (_typeof(obj[key]) === 'array') {
        childrenList = objIterationChildrenList(obj[key][0], childrenList, node)
      }
      tree.push(node)
    }
    return tree
  } else if (parentType === 'array') {
    obj = obj[0]
    return objIterationChildrenList(obj, tree, parentNode)
  }
}

export function obj2Tree(obj, children = 'childrenList', tree = []) {
  const type = _typeof(obj)
  if (type === 'array') {
    obj2Tree(obj[0], children, tree)
  }
  if (type === 'object') {
    // eslint-disable-next-line no-unused-vars
    for (const key in obj) {
      const val = obj[key]
      const keyChildren = []
      const keyType = _typeof(val)
      if (val) {
        obj2Tree(val, children, keyChildren)
      }
      const dataType = jsJavaTypeTransform(keyType)
      const row = {
        dataType: dataType,
        paramName: key,
        [children]: keyChildren
      }
      tree.push(row)
    }
  }
  return tree
}

// 展开树形列表为一维列表
export const expandTree = (tree, children = 'children', arr = []) => {
  tree.forEach(item => {
    arr.push(item)
    if (item[children]) {
      expandTree(item[children], children, arr)
    }
  })
  return arr
}

/**
 * 状态码转文本
 * @param {*} code 状态码
 * @param {*} arr 枚举列表
 * @param {*} label 文本字段
 * @param {*} value 值字段
 * @returns
 */
export const code2Text = (code, arr = [], label = 'desc', value = 'type') => {
  const obj = arr.find(item => item[value] === code)
  if (obj) {
    return obj[label]
  }
  return code
}

/**
 * 从树形数据中取出某几个属性，组成新的属性数据
 * @param {*} param0
 * @returns
 */
export function takeoutParamsFromTree({ tree, childrenList = 'childrenList', keys = ['paramName', 'dataType'] }) {
  const list = []
  tree.map(item => {
    const row = {}
    keys.forEach(key => {
      row[key] = item[key]
    })
    if (item[childrenList] && item.childrenList.length > 0) {
      row[childrenList] = takeoutParamsFromTree({ tree: item[childrenList], childrenList, keys })
    }
    list.push(row)
  })
  return list
}

/**
 * {childrenList: [], dataType: 1, isRequired: false, paramName: "id", rowKey: "1637562619161"}
 * 将级联列表格式的数据格式化,需要包含{dataType: 数据类型, paramName: 属性名, label: label字段包含属性名和类型, path: 取值路径, isRequired: 是否必传， childrenList: [] }
 * 类型：1：Int，2：Long，3：boolean，4：Float，5：Double，6：String，7：Object，8：Array，9：Date，10：BigDecimal，11：Short
 * @param {*} list
 * @param {*} DataTypeEnum
 * @returns
 */
export const formatterParamList = (list = [], DataTypeEnum = [], parentPath, patchPath = '') => {
  if (!list) return
  list.forEach(item => {
    let nextPatchPath = patchPath
    item.label = `${item.paramName || item.fieldName}: ${code2Text(item.dataType, DataTypeEnum)}`
    item.path = parentPath ? parentPath + patchPath + '.' + (item.paramName || item.fieldName) : (item.paramName || item.fieldName)
    if (item.dataType === 8) {
      nextPatchPath = '[]'
    } else {
      nextPatchPath = ''
    }
    formatterParamList(item.childrenList, DataTypeEnum, item.path, nextPatchPath)
  })
  return deepClone(list)
}

// 将树形列表数据转换为mappingList中使用的数据

/**
 * 数组去重
 * @param {*} arr
 */
export const unique = (arr) => {
  return Array.from(new Set(arr))
}

/**
 * json字符串加缩进
 * @param {*} jsonStr json字符串
 * @returns 带缩进的json字符串
 */
export const prettierJson = (jsonStr) => {
  let prettierJsonStr = ''
  if (jsonStr) {
    try {
      prettierJsonStr = JSON.parse(jsonStr)
      prettierJsonStr = JSON.stringify(prettierJsonStr, null, 4)
    } catch (e) {
      return jsonStr
    }
  }
  return prettierJsonStr
}

// 前端数据类型 默认值
const defaultValue = [null, 100, 1000000, true, 1.1, 1.2, 'string', {}, [], '2021-01-01 00:00:00', 'bigdecimal', 'byte', 'short']
/**
 * 树形数组根据类型转obj并设定对应类型的默认值: 对于数组只特殊处理子元素是对象的情况
 */
export const arrayToObj = (arr, obj = {}) => {
  arr.forEach(item => {
    obj[item.paramName] = defaultValue[item.dataType || 0]
    const childrenList = item.childrenList
    if (childrenList && childrenList.length > 0) { // 有children时需要分obj和arr两种情况处理
      if (item.dataType === 8) { // 对于数组
        if (item.generic === 7) { // 子元素是对象
          obj[item.paramName] = [arrayToObj(childrenList)]
        }
      } else if (item.dataType === 7) { // 对于对象
        obj[item.paramName] = arrayToObj(childrenList)
      }
    }
  })
  return obj
}

/**
 * 转驼峰
 * 有下划线的， 将字符串转小写， 移除下划线并将下划线后的字母变大写
 * @param {*} name
 * @returns
 */
export const toHump = (name) => {
  if (typeof name !== 'string') {
    return name
  }
  if (!name.includes('_')) {
    return name
  }
  name = name.toLowerCase()
  const resultArr = name.match(/(\_[a-z])/g) || []
  resultArr.forEach(item => {
    const letter = item.slice(-1)
    const capLetter = letter.toUpperCase()
    name = name.replace(item, capLetter)
  })
  name = name.replaceAll('_', '')
  return name
}

// 后端数据类型 默认值
// const defaultValueDB = [null, 100, '示例文本', true, '2021-01-01', '2021-01-01 00:00:00', '1609430400000', 'blob']
const defaultValueDB = [null, 100, 1000000, true, 1.1, 1.2, 'string', {}, [], '2021-01-01 00:00:00', 'bigdecimal', 'byte', 'short']
/**
 * 树形数组根据类型转obj并设定对应类型的默认值: 对于数组只特殊处理子元素是对象的情况
 */
export const dbArrayToObj = (arr, obj = {}) => {
  arr.forEach(item => {
    obj[toHump(item.fieldName)] = defaultValueDB[item.dataType || 0]
  })
  console.log(obj)
  return obj
}

export const objToFormData = (obj) => {
  const formData = new FormData()
  if (_typeof(obj) !== 'object') return formData
  // eslint-disable-next-line no-unused-vars
  for (const key in obj) {
    formData.append(key, obj[key])
  }
  return formData
}

/**
 *
 * @param {http请求的完整返回结果} response
 * @param {文件名非必传，会从content-disposition中获取} filename
 */
export const downloadBlob = (response, filename = '导出文件') => {
  const blob = new Blob([response.data], {
    type: response.data.type
  })
  const disposition = response.headers['content-disposition']
  const filenameRegexp = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/
  const matches = filenameRegexp.exec(disposition)
  if (matches != null && matches[1]) {
    filename = matches[1].replace(/['"]/g, '')
  }
  const objectUrl = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = objectUrl
  a.download = filename
  a.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }))
  window.URL.revokeObjectURL(blob)
}

const regSqlSelectParams = /(?<=select).*?(?=from)/
export const sqlToObj = (sqlText) => {
  const obj = {}
  let result = sqlText.match(regSqlSelectParams)[0]
  if (result) {
    result = result.split(',')
    console.log(result)
    result.forEach(item => {
      obj[toHump(item.trim())] = '示例文本'
    })
  }
  return obj
}

/**
 *
 * @param {*} url 要解析的字符串
 * @param {*} type 是否包含
 * @returns
 */
export const matchPathParams = (url, type = 'in') => {
  let regexp = null
  if (!url) return []
  if (type === 'in') {
    regexp = regExpRules.urlPathParamIn
  } else {
    regexp = regExpRules.urlPathParam
  }
  return url.match(regexp)
}

export function jsJavaTypeTransform(jstype) {
  return JS_JAVA_TYPE_TRANSFORM[jstype] || 2
}

/**
 *
 * @param {object} obj 对象
 * @param {*} list 树形列表，用于递归中途存值
 * @param {class} RowParam 行数据原型，用于填充行数据
 * @returns list 返回树形列表
 */
export const jsonObj2Array = (obj, list = [], dataPosition, RowParam) => {
  const selfType = _typeof(obj)
  if (selfType === 'object') {
    // eslint-disable-next-line no-unused-vars
    for (const key in obj) {
      const v = obj[key]
      const vType = _typeof(v)
      let node = { rowKey: Date.now() + Math.random().toFixed(5), paramName: key, value: ['array', 'object'].includes(vType) ? null : obj[key], dataType: jsJavaTypeTransform(vType), generic: null, childrenList: [], description: null, isRequired: false, dataPosition }
      if (RowParam) {
        node = { ...new RowParam(), ...node }
      }
      if (vType === 'object') {
        jsonObj2Array(v, node.childrenList, dataPosition)
      } else if (vType === 'array') {
        if (v.length > 0) {
          const childV = v[0]
          node.generic = jsJavaTypeTransform(_typeof(childV))
          if (_typeof(childV) === 'object') {
            jsonObj2Array(childV, node.childrenList, dataPosition)
          }
        }
      }
      list.push(node)
    }
  }

  return list
}

export function geneTimeOptions(typ) {
  const arr = []
  for (let i = 0; i < TIME_OPTIONS[typ] || 0; i++) {
    const num = i + 1
    arr.push({ desc: num, type: num })
  }
  return arr
}

/**
 * 展开jsonPath类型数据
 * @param {*} infoList [{fieldName: 'obj.a', structVal: 'xxx'}]
 * @returns
 */
export function expandJSONPath(infoList) {
  const res = {}
  infoList.forEach(item => {
    jsonpath.value(res, `$.${item.fieldName}`, item.structVal)
  })
  return res
}

/**
 * 将树形数组数据的fieldName转为paramName
 * @param {*} tree
 */
export function transFieldName2ParamName(tree) {
  tree.forEach(item => {
    item.paramName = item.paramName || item.fieldName
    if (item.childrenList && item.childrenList.length > 0) {
      transFieldName2ParamName(item.childrenList)
    }
  })
  return tree
}

/**
 * 数组递归
 * @param {*} list
 * @param {处理方法} fn
 * @param {子层级字符串} children
 */
export function recursionList(list, fn, children = 'childrenList') {
  list.forEach(item => {
    if (item[children]) {
      recursionList(item[children], fn, children)
    }
    fn(item)
  })
}

/**
 * 截取字符串
 * @param {String} msg
 * @returns
 */
export function sliceText(msg) {
  if (!msg || msg.length <= 3000) {
    return msg
  } else {
    return msg.slice(0, 3000) + '...'
  }
}

/**
 * 处理url地址，用于生成WebService地址
 * @param {String} url url地址
 * @returns 移除 / \ - { }
 */
export function formatterUrlToWebService(url) {
  if (!url) {
    return url
  } else {
    return upperFirst(url.replaceAll('/', '').replaceAll('-', '').replaceAll('\\', '').replaceAll('{', '').replaceAll('}', ''))
  }
}

/**
 * mq节点和mapper节点，兼容老的json字符串数据，新的json字符串为树形数组，老的是普通的json对象，将老的修改为空数组
 * @param {*} jsonStr json数据
 * @param {*} key mq | mapper
 * @returns
 */
export function polyfillData(jsonStr, key = 'mq') {
  let outputParamList = []
  let result = jsonStr
  try {
    outputParamList = JSON.parse(jsonStr)
    const type = _typeof(outputParamList)
    if (type !== 'array') {
      result = JSON.stringify([{ paramName: key, dataType: 7, rowKey: Math.random().toFixed(5), generic: null, childrenList: [] }])
    }
    if (type === 'array' && outputParamList.length > 0) {
      const row = outputParamList[0]
      if (row.paramName !== key) {
        result = JSON.stringify([{ paramName: key, dataType: 7, rowKey: Math.random().toFixed(5), generic: null, childrenList: [] }])
      }
    }
  } catch (e) {
    result = JSON.stringify([{ paramName: key, dataType: 7, rowKey: Math.random().toFixed(5), generic: null, childrenList: [] }])
  }
  return result
}
