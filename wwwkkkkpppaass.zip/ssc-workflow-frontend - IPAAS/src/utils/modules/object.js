import { isEmptyValue, isArray, isObject, isDate } from './type'

const _hasOwn = Object.prototype.hasOwnProperty
/**
 * @param {Object} obj
 * @param {String | Number} prop
 * @return {Boolean}
 * @description 判断对象是否拥有prop属性
 */
export function hasOwn(obj, prop) {
  return _hasOwn.call(obj, prop)
}

/**
 * @param {Object} object
 * @param {String|Number} prop
 * @param {Any} defaultValue
 * @returns {Any}
 * @description 获取对象值，若不存在，返回给定的默认值
 */
export function getObjectValue(object, prop, defaultValue = null) {
  return hasOwn(object, prop) ? object[prop] : defaultValue
}

/**
 * Define a property.
 */
export function def(obj, key, val, enumerable) {
  Object.defineProperty(obj, key, {
    value: val,
    enumerable: !!enumerable,
    writable: true,
    configurable: true
  })
}

/**
 * @param {Object} obj
 * @returns {Boolean}
 * @description 判断是否为空对象
 */
export function isEmptyObject(obj) {
  if (!isObject(obj)) {
    return false
  }

  for (const i in obj) {
    if (hasOwn(obj, i)) {
      return false
    }
  }

  return true
}

/**
 * @param {Object} ary
 * @returns {Boolean}
 * @description 判断是否为空数组
 */
export function isEmptyArray(ary) {
  return isArray(ary) && !ary.length
}

/**
 * @param {Object} obj
 * @returns {Object}
 * @description 清除掉空值
 */
export function cleanupEmptyValue(obj) {
  Object.keys(obj).forEach(key => {
    const val = obj[key]

    if (isEmptyValue(val) || isEmptyArray(val) || isEmptyObject(val)) {
      delete obj[key]
    }
  })

  return obj
}

/**
 * @param {Object} json
 * @param {String | Array} path
 * @returns {Any}
 * @description 根据path获取json
 */
export function getJsonValue(json, path) {
  if (json == null) {
    return json
  }

  const pathes = isArray(path) ? path : path.split('.')

  for (let i = 0; i < pathes.length; i++) {
    json = json[pathes[i]]

    if (json == null) {
      return json
    }
  }

  return json
}

/**
 * @param {Object} json
 * @param {String} path
 * @param {Any} value
 * @returns {Boolean}
 * @description 根据path设置json
 */
export function setJsonValue(json, path, value) {
  if (json == null) {
    return false
  }

  const pathes = path.split('.')
  const field = pathes.pop()

  json = getJsonValue(json, pathes)

  if (json == null) {
    return false
  }

  json[field] = value

  return true
}
