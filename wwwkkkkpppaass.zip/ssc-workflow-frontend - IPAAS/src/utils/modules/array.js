const _slice = Array.prototype.slice
/**
 * @param {ArrayLike}
 * @returns {Array}
 * @description 讲类数组对象转换为真正的数组
 */
export function slice(arylike) {
  return _slice.call(arylike)
}

/**
 * @param {Object} map
 * @return { Function }
 * @description 高阶函数，根据map映射，如不存在，返回原值
 */
export function convert(map) {
  return function _convert(prop) {
    return map[prop] || prop
  }
}

/**
 * @param {Array} ary
 * @param {String} labelKey default label
 * @param {String} valueKey default value
 * @return {Object}
 * @description 将数组[{}, {}, {}, {}]转换为{[valueKey]: [labelKey]}
 */
export function arrayToMap(ary, labelKey = 'label', valueKey = 'value') {
  return ary.reduce((ret, item) => {
    ret[item[valueKey]] = item[labelKey]
    return ret
  }, {})
}

/**
 * @param {Array} ary
 * @param {String} labelKey default label
 * @param {String} valueKey default value
 * @return {Object}
 * @description 将数组[{}, {}, {}, {}]转换为{[valueKey]: [labelKey]}
 */
export function arrayToMaps(ary, labelKey = 'label', valueKey = 'value') {
  return ary.reduce((ret, item) => {
    const key = item[valueKey]

    ret[key] || (ret[key] = [])

    ret[key].push(item[labelKey])
    return ret
  }, {})
}
