import { isEmptyValue } from './type'
/**
 * @param {Function} fn 执行函数，必须返回Promise对象
 * @returns {Promise}
 * @description 创建单个缓存
 */
export function createCache(fn) {
  let promise = null

  const cb = function _cache(params) {
    if (!promise) {
      promise = fn.call(this, params).catch(e => {
        promise = null
        return Promise.reject(e)
      })
    }

    return promise
  }
  // 清除缓存
  cb.clear = function() {
    promise = null
  }

  return cb
}

/**
 * @param {Function} fn 执行函数，必须返回Promise对象
 * @param {String|Number} prop 缓存标识唯一的属性，从params[prop]中获取
 * @returns {Promise}
 * @description 创建多个缓存
 */
export function createCaches(fn, prop) {
  let caches = {}

  const cb = function _cache(params) {
    const key = params[prop]

    if (isEmptyValue(key)) {
      return Promise.reject(new Error(`params.${prop} is required`))
    }

    if (!caches[key]) {
      caches[key] = fn.call(this, params).catch(e => {
        delete caches[key]
        return Promise.reject(e)
      })
    }

    return caches[key]
  }
  // 清除缓存
  cb.clear = function(key) {
    isEmptyValue(key) ? (caches = {}) : (delete caches[key])
  }

  return cb
}
