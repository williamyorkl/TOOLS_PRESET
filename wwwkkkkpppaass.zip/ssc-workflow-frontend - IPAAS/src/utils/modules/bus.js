import Vue from 'vue'

export const bus = new Vue()
// 刷新卡券规则列表
export const REFRESH_CARD_RULE_LIST = 'REFRESH_CARD_RULE_LIST'
// 刷新卡券商品列表
export const REFRESH_CARD_PRODUCT_LIST = 'REFRESH_CARD_PRODUCT_LIST'
// 刷新卡券发放记录
export const REFRESH_CARD_RECORD_LIST = 'REFRESH_CARD_RECORD_LIST'
// 刷新业务员列表
export const REFRESH_STAFF_SALES_LIST = 'REFRESH_STAFF_SALES_LIST'
// 刷新社区管理列表
export const REFRESH_BASE_AREA_LIST = 'REFRESH_BASE_AREA_LIST'
// 刷新取货点管理列表
export const REFRESH_BASE_STORE_LIST = 'REFRESH_BASE_STORE_LIST'
// 刷新送货员列表
export const REFRESH_STAFF_DELIVERIES_LIST = 'REFRESH_STAFF_DELIVERIES_LIST'
// 刷新备货区域列表
export const REFRESH_AREA_STOCK_LIST = 'REFRESH_AREA_STOCK_LIST'
// 刷新区域商品管理列表
export const REFRESH_AREA_GOODS_LIST = 'REFRESH_AREA_GOODS_LIST'
