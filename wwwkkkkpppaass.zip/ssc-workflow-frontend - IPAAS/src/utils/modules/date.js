import { isNumber, isDate, isObject, isArray } from './type'

export const ONE_DAY_TIMESTAMP = 24 * 60 * 60 * 1000

/**
 * @param {Date | Number} date
 * @param {String} fmt
 * @returns {String}
 * @description 格式化日期
 */
export function formatDate(date, fmt = 'yyyy-MM-dd hh:mm:ss') {
  if (!isNumber(date) && !isDate(date)) {
    return date
  }

  if (isNumber(date)) {
    date = new Date(date)
  }

  const o = {
    'M+': date.getMonth() + 1, // 月份
    'd+': date.getDate(), // 日
    'h+': date.getHours(), // 小时
    'm+': date.getMinutes(), // 分
    's+': date.getSeconds(), // 秒
    'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
    S: date.getMilliseconds() // 毫秒
  }

  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
  }

  for (const k in o) {
    if (new RegExp('(' + k + ')').test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)))
    }
  }

  return fmt
}

export function getDateStartTimestamp(timestamp = Date.now()) {
  const date = new Date(timestamp)

  date.setHours(0)
  date.setMinutes(0)
  date.setSeconds(0)
  date.setMilliseconds(0)

  return date.getTime()
}

export function getDateEndTimestamp(timestamp = Date.now()) {
  const date = new Date(timestamp)

  date.setHours(23)
  date.setMinutes(59)
  date.setSeconds(59)
  date.setMilliseconds(999)

  return date.getTime()
}

/**
 * @param {Number} timestamp
 * @param {Number} days
 * @returns {Array}
 * @description 计算日期范围
 */
export function getRangeTimestamp(timestamp = Date.now(), days = 6) {
  const date = new Date(timestamp)

  date.setHours(23)
  date.setMinutes(59)
  date.setSeconds(59)
  date.setMilliseconds(999)

  const end = date.getTime()

  date.setDate(date.getDate() - days)

  date.setHours(0)
  date.setMinutes(0)
  date.setSeconds(0)
  date.setMilliseconds(0)

  const start = date.getTime()

  return [start, end]
}

const MONTH_DATE_MAP = {
  0: 31,
  1: 28,
  2: 31,
  3: 30,
  4: 31,
  5: 30,
  6: 31,
  7: 31,
  8: 30,
  9: 31,
  10: 30,
  11: 31
}

/**
 * @param {Number} year
 * @returns {Boolean}
 * @description 是否为闰年
 */
export function isLeapYear(year) {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0
}

/**
 * @param {Number} year
 * @param {Number} month
 * @returns {Number}
 * @description 返回当前月的天数
 */
export function getMonthDate(year, month) {
  let date = MONTH_DATE_MAP[month]

  if (month === 1 && isLeapYear(year)) {
    date = 29
  }

  return date
}

/**
 * @param {Number} timestamp
 * @returns {Array}
 * @description 计算当前月份的时间戳
 */
export function getMonthRangeTimestamp(timestamp = Date.now()) {
  const date = new Date(timestamp)

  date.setDate(1)
  date.setHours(0)
  date.setMinutes(0)
  date.setSeconds(0)
  date.setMilliseconds(0)

  const start = date.getTime()

  date.setDate(getMonthDate(date.getFullYear(), date.getMonth()))

  date.setHours(23)
  date.setMinutes(59)
  date.setSeconds(59)
  date.setMilliseconds(999)

  const end = date.getTime()

  return [start, end]
}

/**
 * @param {Number} timestamp
 * @returns {Array}
 * @description 计算当前年份的时间戳
 */
export function getYearRangeTimestamp(timestamp = Date.now()) {
  const date = new Date(timestamp)

  date.setMonth(0)
  date.setDate(1)
  date.setHours(0)
  date.setMinutes(0)
  date.setSeconds(0)
  date.setMilliseconds(0)

  const start = date.getTime()

  date.setMonth(11)
  date.setDate(31)
  date.setHours(23)
  date.setMinutes(59)
  date.setSeconds(59)
  date.setMilliseconds(999)

  const end = date.getTime()

  return [start, end]
}

export function dateToTimestamp(any) {
  if (isDate(any)) {
    return any.getTime()
  }

  if (isObject(any)) {
    Object.keys(any).forEach(key => {
      any[key] = dateToTimestamp(any[key])
    })

    return any
  }

  if (isArray(any)) {
    any.forEach((v, i) => {
      any[i] = dateToTimestamp(v)
    })

    return any
  }

  return any
}
