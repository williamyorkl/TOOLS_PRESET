import { POSITIVE_RE, INTEGER_RE, NUMBER_RE, PRICE_RE } from './reg'

/**
 *
 * @param {String | Number} val
 * @description 判断是否为正数
 * @returns boolean
 */
export function isPositiveNumber(val) {
  return POSITIVE_RE.test(val)
}

/**
 *
 * @param {String | Number} val
 * @description 判断是否为整数
 * @returns boolean
 */
export function isIntegerNumber(val) {
  return INTEGER_RE.test(val)
}

/**
 * @description 去掉多余的小数位，并将多余的小数位进行四舍五入
 * @param {Number|String} number
 * @param {Number} retain
 * @return {Number|String}
 */

export function toFixed(number, retain) {
  if (typeof number !== 'number' && typeof number !== 'string') {
    return ''
  }

  retain = parseInt(retain, 10)

  if (isNaN(retain) || retain < 0) {
    retain = 2
  }

  const str = String(number)

  if (!NUMBER_RE.test(str)) {
    return number
  }

  const index = str.indexOf('.')
  // 没有小数点
  if (index === -1) {
    return number
  }

  const decimal = str.substring(index + 1)

  if (decimal.length <= retain) {
    return number
  }

  let digits = decimal.substring(0, retain)
  let integer = parseInt(str.substring(0, index))

  const next = decimal.charAt(retain)
  // 四舍五入
  if (next >= 5) {
    // 找一个非9
    let i = digits.length

    while (i-- && digits.charAt(i) === '9') {}
    // 存在一个非9
    if (i >= 0) {
      const c = parseInt(digits.charAt(i)) + 1

      digits = digits.substring(0, i) + c
    } else {
      digits = ''
      integer = integer + (number >= 0 ? 1 : -1)
    }
  }

  if (!digits) {
    return integer
  }

  return parseFloat(integer + '.' + digits)
};

/**
 * @param {Number} number
 * @returns {Boolean}
 * @description 检测是否为合法的价格
 */

export function isValidPrice(number) {
  return PRICE_RE.test(number)
}
