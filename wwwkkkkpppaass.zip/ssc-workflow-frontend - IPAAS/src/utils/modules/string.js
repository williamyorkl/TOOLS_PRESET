import { isString } from './type'

export function revokeURL(url) {
  if (/^blob:/.test(url)) {
    URL.revokeObjectURL(url)
  }
}

/**
 * @param {String} string
 * @returns {String}
 * @description 首字母大写
 */
export function firstUpperCase(string) {
  return string.charAt(0).toUpperCase() + string.substring(1)
}

export function stringToNumber(object, transferFields) {
  transferFields.forEach(field => {
    const value = object[field]

    if (isString(value)) {
      object[field] = parseFloat(value, 10)
    }
  })

  return object
}
