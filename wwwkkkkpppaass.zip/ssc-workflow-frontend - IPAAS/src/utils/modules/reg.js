// 正数
export const POSITIVE_RE = /^(?:0|[1-9]\d*)+(?:\.\d+)?$/
// 正整数
export const INTEGER_RE = /^(?:0|[1-9]\d*)$/
// 大于0的正整数
export const RATHER_THEN_ZERO_INTEGER_RE = /^(?:[1-9]\d*)$/
// 数值
export const NUMBER_RE = /^-?\d+(\.\d+)?$/
// 手机号码
export const MOBILE_RE = /^1[3456789]\d{9}$/
// 价格
export const PRICE_RE = /^(?:0|[1-9]\d*)(?:\.\d{1,2})?$/
