import { DbType2JavaType, DataTypes } from '@/config/enum'
import { Param } from '@/views/arrange/serviceArrange/options/model'
import { deepClone, toHump } from '@/utils'
// 解析用户输入的数据，并添加到原始列表数据
export function resolveText(originalParamList, { path, paramStr, descriptionStr, dataTypeStr, dataPosition, isCamelCase }, RowParam) {
  const paramList = deepClone(originalParamList)
  const paramArr = paramStr.split('\n')
  const descriptionArr = descriptionStr.split('\n')
  const dataTypeArr = dataTypeStr.split('\n')
  const result = []
  paramArr.forEach((item, index) => {
    if (item) {
      const paramName = isCamelCase ? toHump(item) : item
      let row = { ...new Param(), ...{ paramName, dataType: transDataType(dataTypeArr[index]), description: descriptionArr[index], rowKey: Date.now() + index, dataPosition } }
      if (RowParam) {
        row = { ...RowParam, ...row }
      }
      result.push(row)
    }
  })
  if (!path) {
    paramList.push(...result)
    return paramList
  }
  const paths = path.split('.')
  let path1 = paths.shift().replace('[]', '') // 删除[]
  let currentList = paramList
  while (path1) {
    const row = currentList.find(item => {
      return item.paramName === path1
    })
    path1 = paths.shift()
    if (!path1 && row.dataType === 8) { // 数组数据的元素泛型设置为对象
      row.generic = 7
    }
    currentList = row.childrenList || []
  }
  currentList.push(...result)
  return paramList
}

export function resolveCopy({ originalParamList = [], formData = {} }) {
  const paramList = deepClone(originalParamList)
  const { path, sourceData } = formData
  if (!path) {
    if (Array.isArray(sourceData)) {
      paramList.push(...sourceData)
    } else {
      paramList.push(sourceData)
    }
  } else {
    const paths = path.split('.')
    let path1 = paths.shift().replace('[]', '') // 删除[]
    let currentList = paramList
    while (path1) {
      const row = currentList.find(item => {
        return item.paramName === path1
      })
      path1 = paths.shift()
      if (!path1 && row.dataType === 8) { // 数组数据的元素泛型设置为对象
        row.generic = 7
      }
      currentList = row.childrenList || []
    }
    if (Array.isArray(sourceData)) {
      currentList.push(...sourceData)
    } else {
      currentList.push(sourceData)
    }
  }
  return paramList
}

export function recursivelyAddAttr(data) {
  if (!Array.isArray(data)) return data
  for (let j = 0; j < data.length; j++) {
    !data[j].rowKey && (data[j].rowKey = Math.random().toFixed(5))
    !data[j].paramName && (data[j].paramName = data[j].fieldName)
    if (data[j].childrenList) {
      if (data[j].childrenList.length > 0) {
        recursivelyAddAttr(data[j].childrenList)
      }
    }
  }
  return data
}

export function transDataType(str) {
  // 删除括号以及括号中的内容
  str = str.toLowerCase()
  str = str.replace(/\([a-z0-9,]+\)/, '')
  if (DbType2JavaType.Integer.includes(str)) {
    return DataTypes.Integer
  } else if (DbType2JavaType.BigDecimal.includes(str)) {
    return DataTypes.BigDecimal
  } else if (DbType2JavaType.Boolean.includes(str)) {
    return DataTypes.Boolean
  } else if (DbType2JavaType.Byte.includes(str)) {
    return DataTypes.Byte
  } else if (DbType2JavaType.Date.includes(str)) {
    return DataTypes.Date
  } else if (DbType2JavaType.Double.includes(str)) {
    return DataTypes.Double
  } else if (DbType2JavaType.Float.includes(str)) {
    return DataTypes.Float
  } else if (DbType2JavaType.Long.includes(str)) {
    return DataTypes.Long
  } else if (DbType2JavaType.Short.includes(str)) {
    return DataTypes.Short
  } else if (DbType2JavaType.Array.includes(str)) {
    return DataTypes.Array
  } else if (DbType2JavaType.Object.includes(str)) {
    return DataTypes.Object
  } else {
    return DataTypes.String
  }
}
