import { encode } from 'js-base64'
import CryptoJS from 'crypto-js'
import JSEncrypt from 'jsencrypt'

// DES加密
export function enCode(str, key, mode = 'ECB', padding = 'Pkcs7') {
  const keyHex = CryptoJS.enc.Utf8.parse(key)
  const result = CryptoJS.DES.encrypt(str, keyHex, {
    mode: CryptoJS.mode[mode],
    padding: CryptoJS.pad[padding]
  })
  return result.ciphertext.toString(CryptoJS.enc.Hex)
}

// base64
export function enBase64(str) {
  console.log('str', str)
  return encode(str)
}

const pubKey = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCknEGcpkWxfawkqqOerNhXBEv3gAoww59wrS1R\r\nn2mYMzs95w8T7ZYam2psPoSeAsX26Sv3jUogZeJEviYjhoUh0aQKTm8qaN8uR4YHPAHCfCwFCRwd\r\nXzSP8eP4v7rElZM68n+vxgYANCT+m1mG6uiDp9eUg8MlKjJt6zlq0x8hMwIDAQAB'

// rsa加密
export function enRsa(str, key = pubKey) {
  const encrypt = new JSEncrypt()
  encrypt.setPublicKey(key)
  const result = encrypt.encrypt(str)
  return result
}
