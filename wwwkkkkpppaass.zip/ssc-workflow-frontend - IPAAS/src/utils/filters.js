
export const formatTime = (val, fmt = 'yyyy-MM-dd hh:mm:ss') => {
  if (!val) return
  val = new Date(val)

  const o = {
    'M+': val.getMonth() + 1, //  月份
    'd+': val.getDate(), // 日
    'h+': val.getHours(), // 小时
    'm+': val.getMinutes(), // 分
    's+': val.getSeconds(), // 秒
    'q+': Math.floor((val.getMonth() + 3) / 3), // 季度
    S: val.getMilliseconds() // 毫秒
  }
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (val.getFullYear() + '').substr(4 - RegExp.$1.length))
  }
  // eslint-disable-next-line no-unused-vars
  for (const k in o) {
    if (new RegExp('(' + k + ')').test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)))
    }
  }
  return fmt
}

export const formatDate = (val, fmt = 'yyyy-MM-dd') => {
  if (!val) return
  val = new Date(val)

  const o = {
    'M+': val.getMonth() + 1, //  月份
    'd+': val.getDate(), // 日
    'h+': val.getHours(), // 小时
    'm+': val.getMinutes(), // 分
    's+': val.getSeconds(), // 秒
    'q+': Math.floor((val.getMonth() + 3) / 3), // 季度
    S: val.getMilliseconds() // 毫秒
  }
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (val.getFullYear() + '').substr(4 - RegExp.$1.length))
  }
  // eslint-disable-next-line no-unused-vars
  for (const k in o) {
    if (new RegExp('(' + k + ')').test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)))
    }
  }
  return fmt
}

export function formatYesOrNo(bol) {
  return bol ? '是' : '否'
}

export function formatEnabled(bol) {
  return bol ? '启用' : '禁用'
}

export function formatSticky(bol) {
  return bol ? '已置顶' : '未置顶'
}

export function formatPublish(bol) {
  return bol ? '已上架' : '未上架'
}

export function toFixed2(value) {
  return value.toFixed(2)
}
