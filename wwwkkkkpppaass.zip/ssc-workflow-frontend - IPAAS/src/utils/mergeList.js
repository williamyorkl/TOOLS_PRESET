/**
 * 合并两个元素为对象的数组，以key作为是否相同的标识,注意：若有重复项，保留skuList
 * @param {Array} selectList 选中列表
 * @param {Array} skuList 原列表
 * @param {Array} key 重复标识
 */
export function mergeList(selectList, skuList, key) {
  const obj = {}
  const list = [...skuList, ...selectList]
  return list.reduce(function(arr, item) {
    obj[item[key]] ? '' : obj[item[key]] = true && arr.push(item)
    return arr
  }, [])
}
