import Vue from 'vue'
import echarts from 'echarts'
/**
 * 图表设置
 */

// clearInstanse(id) {
//   echarts.init(document.getElementById(id)).clear();
// },
var chart = {
  barChart: function (id, data) {
    this.myChart = echarts.init(document.getElementById(id))
   
    const option = {
      color: ['#3398DB'],
      tooltip: {
        trigger: 'axis',
        axisPointer: { // 坐标轴指示器，坐标轴触发有效
          type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
        }
      },
      grid: {
        left: '0%',
        right: '0%',
        bottom: '0%',
        top: '0%',
        containLabel: true
      },
      xAxis: [{
        type: 'category',
        data: data.dataY,
        axisTick: {
          show: false,
          alignWithLabel: true
        },
        axisLabel: {
          show: false
        },
        axisLine: {
          show: false
        }
      }],
      yAxis: [{
        type: 'value',
        min: 0,
        // max: 200,
        axisTick: {
          show: false,
          alignWithLabel: true
        },
        axisLabel: {
          show: false
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: false
        }
      }],
      series: [{
        name: data.hoverTitle,
        type: 'bar',
        barWidth: '60%',
        data: data.dataX       
      }]
    }
    this.myChart.setOption(option)
  },
  areaChart: function (id, data) {
    this.myChart = echarts.init(document.getElementById(id))
    const option = {
      color: ['#8F65DD'],
      tooltip: {
        trigger: 'axis',
        axisPointer: { // 坐标轴指示器，坐标轴触发有效
          type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
        }
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: data.dataY,
        axisTick: {
          show: false,
          alignWithLabel: true
        },
        axisLabel: {
          show: false
        },
        axisLine: {
          show: false
        }
      },
      yAxis: {
        type: 'value',
        axisTick: {
          show: false,
          alignWithLabel: true
        },
        axisLabel: {
          show: false
        },
        axisLine: {
          show: false
        },
        splitLine: {
          show: false
        }
      },
      series: [{
        data: data.dataX,
        type: 'line',
        areaStyle: {}
      }]
    }
    this.myChart.setOption(option)
  },
  lineChart: function (id, data) {
    this.myChart = echarts.init(document.getElementById(id))
    const option = {
      color: ['#3398DB'],
      tooltip: {
        trigger: 'axis'
      },
      legend: {
        data: ['邮件营销']
      },
      grid: {
        left: '2%',
        right: '4%',
        bottom: '2%',
        top: '2%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: data.dataY
      },
      yAxis: {
        type: 'value'
      },
      series: [{
        name: data.hoverTitle,
        type: 'line',
        stack: '总量',
        data: data.dataX
        // label: {
        //   show: true
        // }
      }]
    }
    this.myChart.setOption(option)
  },
  pieChart: function (id, data) {
    this.myChart = echarts.init(document.getElementById(id))
    const option = {
      color: ['#1990FF', '#2EC25B', '#F9CC14', '#F04964'],
      tooltip: {
        trigger: 'none',
        show: false,
        showContent: false
        // formatter: "{a} <br/>{b}: {c} ({d}%)"
      },
      legend: {
        orient: 'vertical',
        data: []
      },
      series: [{
        name: '',
        type: 'pie',
        radius: ['50%', '70%'],
        startAngle: 60,
        label: {        
          show: true,
          position: 'outside',
          formatter: '{b}:\n{c} ({d}%)'
        },
        // labelLine: {
        //   normal: {
        //     show: false
        //   }
        // },
        data: data
      }]
    }
    this.myChart.setOption(option)
  }
}

// function install(vue) {
//   Vue.prototype.$chart = chart;
// }
export default {
  install: install
}
