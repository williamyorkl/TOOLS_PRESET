export function iamIframeTokenValid() {
  if (window.top && window.top.getCloudToken) {
    return window.top.getCloudToken()
  } else {
    return false
  }
}
