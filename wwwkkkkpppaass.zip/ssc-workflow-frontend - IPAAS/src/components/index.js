// 注册全局组件
import Vue from 'vue'

// import Querybar from './common/querybar/'
import Selector from './common/selector/'
import Table from './common/table/'

import InputNumber from './common/input-number'
import BigImg from './big-img.vue'
import SearchBar from './common/searchBar'

// import installMcForm from './mc-form-installer';

// installMcForm(Vue);

Vue.component(Selector.name, Selector)
Vue.component(Table.name, Table)
Vue.component(InputNumber.name, InputNumber)

// Vue.component(Querybar.name, Querybar)
// Vue.component(DdLabel.name, DdLabel)

Vue.component(BigImg.name, BigImg)
// Vue.component(Export.name, Export)

Vue.component(SearchBar.name, SearchBar)
