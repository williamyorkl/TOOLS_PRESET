// import { jsPlumb } from 'jsplumb'
// 用上一行的方式引入会出现window.jsplumb.DefaultRootRouter丢失的bug
import 'jsplumb'
import jsplumbOption from '../options/jsplumbOption'
import { NodeTypeEnum, GROUP_NODES } from '@/config/enum'
import Vue from 'vue'
import { EventBus } from './event-bus'
import { getNodePrefixName } from '@/components/flow-node/biz_components/nodeOptionDialog/node-option-utils'
export default class JsplumbUtil {
  constructor() {
    this.instance = null
    this.loadEasyFlowFinish = false
  }

  getInstance = (el) => {
    if (!this.instance) {
      this.instance = window.jsPlumb.getInstance({
        Container: el
      })
      this.instance.importDefaults(jsplumbOption.jsplumbSetting)
    }
    return this.instance
  }

  init = ({ el, id, data, handleLineClick, beforeDrop, handleLineContextmenu, nodeMap = new Map() }) => {
    this.nodeMap = nodeMap
    this.handleLineClick = handleLineClick
    this.handleLineContextmenu = handleLineContextmenu
    this.beforeDrop = beforeDrop
    this.getInstance(el)
    // 绑定一些数据和方法到instance上
    this.instance.registerNode = this.registerNode
    this.instance.registerLine = this.registerLine
    this.instance.deleteLine = this.deleteLine
    this.instance.deleteNode = this.deleteNode
    this.instance._el = el // 绑定id
    this.instance._data = data
    this.parentId = id

    this.bindEventListener(el)

    this.doConnect(data)

    this.loadEasyFlowFinish = true // 初始化完成
    return this.instance
  }

  registerNode = (node, _instance) => {
    this.instance.makeSource(node.id, jsplumbOption.jsplumbSourceOptions)
    this.instance.makeTarget(node.id, jsplumbOption.jsplumbTargetOptions)
    this.instance.draggable(document.getElementById(node.id), {
      containment: 'parent' // 限制不能拖出容器
    })
    this.nodeMap.set(node.id, node)
    if (this.parentId !== 'arrange-container') {
      node.parent = this.parentId
      setTimeout(() => {
        // 判断是否分组节点，如果是分组节点，触发重新计算容器尺寸
        const parentNode = this.nodeMap.get(this.parentId)
        // 是分组节点
        if (GROUP_NODES.includes(node.type)) {
          if (!parentNode.groupChildren) {
            parentNode.groupChildren = []
            new Vue().$set(parentNode)
          }
          parentNode.groupChildren.push(node.id)
          console.log('emit update-group-children')
          EventBus.$emit('update-group-children', parentNode)
        }
      }, 0)
    }
  }

  registerLine = (line, _instance = this.instance) => {
    // console.log('创建连线')
    this.instance.connect({ source: line.from, target: line.to }, jsplumbOption.jsplumbConnectOptions)
  }

  // data是一个对象，包含nodeList和lineList，nodeList中type为group的node，要递归处理
  doConnect = (data) => {
    if (data.lineList && data.nodeList) {
      data.nodeList.forEach(item => {
        this.registerNode(item, this.instance)
      })
      data.lineList && data.lineList.forEach(item => {
        this.registerLine(item, this.instance)
      })
    }
  }

  // 删除连线：同时删除lineList中的数据
  deleteLine = (line) => {
    const conn = this.instance.getConnections({
      source: line.from,
      target: line.to
    })[0]
    this.instance.deleteConnection(conn)
    // 清除节点关系
    this.deRelationNode({ line })
  }

  // 删除节点，同时删除nodeList中的数据
  deleteNode = (nodeId, node) => {
    this.instance.removeAllEndpoints(nodeId)
    deleteArrElement(this.instance._data.nodeList, (item) => item.id === nodeId)
    this.recursionDeleteNode(nodeId, node)
    this.deRelationNode({ node })
  }

  recursionDeleteNode(nodeId, node) {
    this.nodeMap.delete(nodeId)
    // CHOICE & FOREACH需要递归删除所有子节点在map中的记录
    if (node.type === NodeTypeEnum.CHOICE) {
      const conditionList = node.nodeParamsLogicDto.choiceDto.conditionList
      conditionList && conditionList.forEach(condition => {
        const nodeList = condition.relationDto.nodeList
        nodeList && nodeList.forEach(childNode => this.recursionDeleteNode(childNode.id, childNode))
      })
    } else if (node.type === NodeTypeEnum.FOREACH) {
      const nodeList = node.nodeParamsLogicDto.forEachDto.relationDto.nodeList
      nodeList && nodeList.forEach(childNode => this.recursionDeleteNode(childNode.id, childNode))
    } else if (node.type === NodeTypeEnum.ASYNC) {
      const nodeList = node.nodeParamsLogicDto.asyncDto.relationDto.nodeList
      nodeList && nodeList.forEach(childNode => this.recursionDeleteNode(childNode.id, childNode))
    } else if (node.type === NodeTypeEnum.SYNC) {
      const nodeList = node.nodeParamsLogicDto.synchronizedDto.relationDto.nodeList
      nodeList && nodeList.forEach(childNode => this.recursionDeleteNode(childNode.id, childNode))
    } else if (node.type === NodeTypeEnum.TRY) {
      const nodeList = node.nodeParamsLogicDto.retryDto.relationDto.nodeList
      nodeList && nodeList.forEach(childNode => this.recursionDeleteNode(childNode.id, childNode))
    }
  }

  bindEventListener = (_el) => {
    // 连线时将连线存储到对应的lineList
    this.instance.bind('connection', (ev) => {
      const { sourceId, targetId } = ev
      if (this.loadEasyFlowFinish) {
        console.log('监听到手动连线')
        this.instance._data.lineList.push({ from: sourceId, to: targetId })
      }
      this.relationNode({ from: sourceId, to: targetId })
    })

    // 删除连线回调触发时删除lineList中的数据
    this.instance.bind('connectionDetached', (ev) => {
      const _data = this.instance._data
      console.log('删除连线')
      const { sourceId, targetId } = ev
      deleteArrElement(this.instance._data.lineList, (item) => item.from === sourceId && item.to === targetId)
      console.log(_data)
    })

    // 连线之前的判断
    this.instance.bind('beforeDrop', (ev) => {
      console.log('连线之前')
      if (this.loadEasyFlowFinish) {
        const { lineList, nodeList } = this.instance._data
        return this.beforeDrop(ev, lineList, nodeList, this.nodeMap)
      }
      return true
    })

    // 点击连线
    this.instance.bind('click', (conn, originalEvent) => {
      originalEvent.stopPropagation()
      console.log('点击连线')
      this.handleLineClick(conn, originalEvent)
    })

    // 连线右击
    this.instance.bind('contextmenu', (jsplumbEvt, ev) => {
      console.log('右击连线')
      ev.stopPropagation()
      // const line = { from: jsplumbEvt.sourceId, to: jsplumbEvt.targetId }
      this.handleLineContextmenu('line', ev, jsplumbEvt)
    })
  }

  // 建立节点关系
  relationNode = (line) => {
    const from = line.from
    const to = line.to
    const fromNode = this.nodeMap.get(line.from)
    const toNode = this.nodeMap.get(line.to)

    if (!fromNode.next) fromNode.next = []
    if (!toNode.prev) toNode.prev = []

    // 使用不正经手段处理一下，因为没有在重刷画布时重置nodeMap
    if (!fromNode.next.includes(to)) {
      fromNode.next.push(to)
    }
    if (!toNode.prev.includes(from)) {
      toNode.prev.push(from)
    }
  }

  // 移除节点关系
  deRelationNode = ({ line, node }) => {
    // 删除连线时触发
    if (line) {
      const from = line.from
      const to = line.to
      const fromNode = this.nodeMap.get(line.from)
      const toNode = this.nodeMap.get(line.to)
      if (fromNode.next) {
        deleteArrElement(fromNode.next, (item) => item === to)
      }
      if (toNode.prev) {
        deleteArrElement(toNode.prev, (item) => item === from)
      }
    } else if (node) {
      // 从关联节点中移除该节点
      const nodeId = node.id
      const prevList = node.prev
      const nextList = node.next
      const parent = node.parent
      prevList && prevList.forEach(prevId => {
        const prevNode = this.nodeMap.get(prevId)
        if (prevNode.next) {
          deleteArrElement(prevNode.next, (item) => item === nodeId)
        }
      })
      nextList && nextList.forEach(nextId => {
        const nextNode = this.nodeMap.get(nextId)
        if (nextNode.prev) {
          deleteArrElement(nextNode.prev, (item) => item === nodeId)
        }
      })

      // 从parent节点的children中移除
      if (parent && GROUP_NODES.includes(node.type)) {
        const parentNode = this.nodeMap.get(parent)
        parentNode.groupChildren = parentNode.groupChildren.filter(item => item !== nodeId)
        EventBus.$emit('update-group-children')
      }
    }
  }
}

function deleteArrElement(list, fn) {
  const idx = list.findIndex(item => fn(item))
  if (idx > -1) {
    list.splice(idx, 1)
  }
}

// 找到当前节点的上游节点，递归找当前节点的父节点的上游节点
// flag标识是否需要找父级
export function findPrevChain(nodeMap, currentId, nodeArr = [], flag = true, includeSelf) {
  const currentNode = nodeMap.get(currentId)
  const prevList = currentNode.prev
  const parentId = currentNode.parent
  // 需要显示本节点的，展示本节点正在设置的数据
  if (includeSelf) {
    const currentNodeData = nodeMap.get('currentNode')
    nodeArr.push(currentNodeData)
  }
  // 前置节点
  prevList && prevList.forEach(prevId => {
    // 判断是否已存在
    const node = nodeArr.find(item => item.id === prevId)

    if (!node) {
      const prevNode = nodeMap.get(prevId)
      nodeArr.push(prevNode)
      findPrevChain(nodeMap, prevId, nodeArr, false)
    }
  })

  if (parentId && flag) {
    findPrevChain(nodeMap, parentId, nodeArr, true)
  }

  return nodeArr
}

/**
 * 所有节点
 * @param {Map} nodeMap
 * @param {string} currentId  是否包含自己，不传则包含
 * @returns {List} 全部节点列表
 */
export function findCompleteChain({ nodeMap, currentId }) {
  const nodeArr = []
  nodeMap.forEach((value, key) => {
    if (key !== 'currentNode' && (currentId ? key !== currentId : true)) {
      const labelName = getNodePrefixName({ nodeId: key, nodeMap })
      nodeArr.push({ ...value, labelName })
    }
  })
  return nodeArr
}

/**
 * 判断是否允许移动操作
 * @param {String} currentId 要移动的节点Id
 * @param {String} targetId 目标节点的Id
 * @param {Map} nodeMap
 * @param {String} position 移动到的位置  上 | 下
 *
 * @returns {Boolean, String} allowMove 是否允许 msg 错误信息
 */
export function validAllowMove({ currentId, targetId, nodeMap, position }) {
  let allowMove = true
  let msg = ''
  const currentNode = nodeMap.get(currentId)
  const targetNode = nodeMap.get(targetId)
  const targetNodeType = targetNode.type
  const currentNodePrev = currentNode.prev || []
  const currentNodeNext = currentNode.next || []
  // 1. 不允许移动到开始节点前
  if (targetNodeType === NodeTypeEnum.START && position === 'up') {
    allowMove = false
    msg = '不允许移动到开始节点前面'
  }
  // 2. 不允许移动到结束节点后
  if (targetNodeType === NodeTypeEnum.END && position === 'down') {
    allowMove = false
    msg = '不允许移动到结束节点后面'
  }
  // 3. 不允许移动到当前节点的后一个节点的前面
  if (currentNodeNext.includes(targetId) && position === 'up') {
    allowMove = false
    msg = '无效操作：不允许移动到下个节点的前面'
  }
  // 4. 不允许移动到当前节点的前一个节点的后面
  if (currentNodePrev.includes(targetId) && position === 'down') {
    allowMove = false
    msg = '无效操作：不允许移动到上个节点的后面'
  }
  return [allowMove, msg]
}
