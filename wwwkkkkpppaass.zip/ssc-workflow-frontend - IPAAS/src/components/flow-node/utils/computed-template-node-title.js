import { NodeTypeEnum } from '@/config/enum'
export function computedTemplateNodeTitle(node) {
  const type = node.type
  switch (type) {
    case NodeTypeEnum.START:
      return '选择“编排开始”，查看触发器的信息'
    case NodeTypeEnum.PROCESS:
      return '选择"RPC节点"，配置调用API的信息'
    case NodeTypeEnum.DB:
      return '选择"数据库节点"，配置调用DB的信息'
    case NodeTypeEnum.MQ:
      return '选择“MQ节点”，配置调用MQ的信息'
    case NodeTypeEnum.FORWARD:
      return '选择“转发节点”，配置节点信息'
    case NodeTypeEnum.ERROR:
      return '选择“抛出异常”，在满足条件下抛出异常，中断流的执行'
    case NodeTypeEnum.RESPONSE:
      return '选择“条件返回”，在满足条件下直接返回，中断流的执行'
    case NodeTypeEnum.VARIABLE:
      return '选择“变量赋值”，声明一个变量并可以在后续节点引用'
    case NodeTypeEnum.FILTER:
      return '选择“过滤节点”，可以针对集合过滤出满足条件的数据'
    case NodeTypeEnum.MAPPER:
      return '选择“数据映射”，可以自定义录入目标数据格式，可以从上游节点查找字段并参与转换运算'
    case NodeTypeEnum.GROUP:
      return '选择“分组节点”，可以针对集合根据所选字段做分组处理'
    case NodeTypeEnum.GROOVY:
      return '选择“脚本节点”，可以通过Groovy的方式做脚本处理'
    case NodeTypeEnum.COMBINE:
      return '选择“合并节点”，可以根据映射关系合并主子集合'
    case NodeTypeEnum.END:
      return '选择“结束节点”，配置编排最终返回结果'
    case NodeTypeEnum.CHOICE:
      return '选择“choice节点”，配置分支执行子流的信息'
    case NodeTypeEnum.FOREACH:
      return '选择“forEach节点”，配置循环执行子流的信息'
    case NodeTypeEnum.BREAK:
      return '选择“break节点”，配合forEach组件使用，用来中断循环'
    case NodeTypeEnum.CONTINUE:
      return '选择“continue节点”，配合forEache组件使用，用来跳出当前循环，执行下一次循环'
    case NodeTypeEnum.SORT:
      return '选择“排序节点”，可以针对集合数据的指定字段做排序处理'
    case NodeTypeEnum.SYNC:
      return '选择“synchronized节点”，是一个分布式锁，对并发处理的请求进行加锁保护'
    case NodeTypeEnum.ASYNC:
      return '选择“async节点”，可以通过异步的方式执行子流'
    case NodeTypeEnum.CACHE:
      return '选择“缓存节点”，配置Redis连接参数'
    case NodeTypeEnum.TRY:
      return '选择“try节点，配置重试策略”'
  }
}
