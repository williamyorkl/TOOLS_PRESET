// 一些节点连线、生成节点数据等的工具函数
import { Message } from 'element-ui'
import { deepClone, unique } from '@/utils'
import { Node } from '../model/index'
import { NodeTypeEnum } from '@/config/enum'

// 过滤上游节点
export function filterPrevNodeList(nodeList, lineList, nodeId) {
  const nodeMap = new Map()
  const deepLineList = deepClone(lineList)
  deepLineList.forEach(line => {
    const hasToNode = nodeMap.has(line.to)
    const hasFromNode = nodeMap.has(line.from)
    if (!hasToNode) nodeMap.set(line.to, { nextNode: [], prevNode: [] })
    if (!hasFromNode) nodeMap.set(line.from, { nextNode: [], prevNode: [] })
    const toNode = nodeMap.get(line.to)
    const fromNode = nodeMap.get(line.from)
    toNode.prevNode.push(line.from)
    fromNode.nextNode.push(line.to)
    nodeMap.set(line.to, toNode)
    nodeMap.set(line.from, fromNode)
  })
  const currentNode = nodeMap.get(nodeId)
  const prevArr = currentNode.prevNode
  const result = recursionNode(prevArr, nodeMap)
  const uniqueResult = unique(result)
  const nodeInfoMap = new Map()
  nodeList.forEach(item => nodeInfoMap.set(item.id, item))
  const res = uniqueResult.map(item => nodeInfoMap.get(item))
  return res
}

function recursionNode(prevArr, nodeMap, result = []) {
  prevArr.forEach(prev => {
    result.push(prev)
    const currentNode = nodeMap.get(prev)
    const currentPrevArr = currentNode.prevNode
    if (currentPrevArr && currentPrevArr.length) {
      recursionNode(currentPrevArr, nodeMap, result)
    }
  })
  return result
}

// 判断是否可以连线
export function beforeDrop(evt, lineList, nodeList, nodeMap) {
  const from = evt.sourceId
  const to = evt.targetId
  if (from === to) {
    Message.error('连线失败，节点不支持连接自己')
    return false
  }
  if (nodeMap.get(from).type === NodeTypeEnum.END) {
    Message.error('连线失败，结束节点只能被连接')
    return false
  }
  if (nodeMap.get(to) === NodeTypeEnum.START) {
    Message.error('连线失败，开始节点不能被连接')
    return false
  }
  if (hasLine({ lineList }, from, to)) {
    Message.error('该关系已存在,不允许重复创建')
    return false
  }
  if (hasOppositeLine({ lineList }, from, to)) {
    Message.error('不支持两个节点之间连线回环')
    return false
  }
  // ---新增的判断
  // 非开始节点没有上个节点禁止连线
  if (!hasPreviousNode({ lineList }, from, to, nodeMap)) {
    Message.error('连线失败，需要先为该节点设置上个节点')
    return false
  }

  if (hasSameParentOrChildNode({ lineList }, from, to)) {
    Message.error('连线失败，具有相同父节点或相同子节点的两个节点不能相互连线')
    return false
  }
  if (onSameChain({ lineList }, from, to)) {
    Message.error('连线失败，已在同一条链上的两个节点不能新建相互连接')
    return false
  }

  if (toParentOnFromParentChain({ lineList }, from, to)) {
    Message.error('连线失败，被连接节点的父节点在当前节点父链上时不能连接')
    return false
  }
  Message.success('连线成功')
  return true
}

// 点击连线
export function activeLine(conn) {
  const obj = {
    type: 'line',
    from: conn.sourceId,
    to: conn.targetId
  }
  return obj
}

// 激活节点
export function activeNode(node) {
  const obj = {
    type: 'node',
    name: node.name,
    id: node.id,
    node
  }
  return obj
}

// export function lineContextmenu(ev, ) {

// }

//         // 连线右击
//         this.jsPlumb.bind('contextmenu', (jsplumbEvt, ev) => {
//           const line = { from: jsplumbEvt.sourceId, to: jsplumbEvt.targetId }
//           this.contextmenu('line', ev, line)
//         })

// 是否已有该连线
function hasLine({ lineList }, from, to) {
  for (let i = 0; i < lineList.length; i++) {
    const line = lineList[i]
    if (line.from === from && line.to === to) {
      return true
    }
  }
  return false
}

// 是否含有相反的线
function hasOppositeLine(data, from, to) {
  return hasLine(data, to, from)
}

// 是否有前置节点
function hasPreviousNode({ lineList }, from, to, nodeMap) {
  if (nodeMap.get(from).type === NodeTypeEnum.START) return true
  const previous = lineList.find(v => v.to === from)
  if (previous) {
    return true
  }
  return false
}

// 有相同父节点或子节点的两个节点不能相连
function hasSameParentOrChildNode({ lineList }, from, to) {
  const fromParents = [] // from的父节点
  const fromChildren = [] // from的子节点
  let toParents = [] // to的父节点
  const toChildren = [] // to的子节点
  lineList.forEach(item => {
    if (item.from === from) {
      fromChildren.push(item.to)
    }
    if (item.to === from) {
      fromParents.push(item.from)
    }
    if (item.from === to) {
      toChildren.push(item.to)
    }
    if (item.to === to) {
      toParents = item.from
    }
  })
  const sameParents = fromParents.filter(item => toParents.includes(item))
  const sameChildren = fromChildren.filter(item => toChildren.includes(item))
  if (sameParents.length > 0 || sameChildren.length > 0) {
    return true
  }
  return false
}

// 是否在同一条链上
function onSameChain({ lineList }, from, to) {
  const nodeMap = new Map()
  const deepLineList = deepClone(lineList)
  deepLineList.forEach(line => {
    const hasToNode = nodeMap.has(line.to)
    const hasFromNode = nodeMap.has(line.from)
    if (!hasToNode) nodeMap.set(line.to, { nextNode: [], prevNode: [] })
    if (!hasFromNode) nodeMap.set(line.from, { nextNode: [], prevNode: [] })
    const toNode = nodeMap.get(line.to)
    const fromNode = nodeMap.get(line.from)
    toNode.prevNode.push(line.from)
    fromNode.nextNode.push(line.to)
    nodeMap.set(line.to, toNode)
    nodeMap.set(line.from, fromNode)
  })
  const currentToNode = nodeMap.get(to)
  const currentFromNode = nodeMap.get(from)
  // 寻找to的所有父和子，看有没有from
  if (!currentToNode || !currentFromNode) return false
  const flag1 = toNextChainHasFrom(nodeMap, from, to)
  const flag2 = toPrevChainHasFrom(nodeMap, from, to)
  if (flag1 || flag2) return true
}

// to节点的父节点是否在from节点的父链上
function toParentOnFromParentChain({ lineList }, from, to) {
  const line = lineList.find(item => item.to === to) // to的父节点
  let toParent = null
  if (line) {
    const nodeMap = new Map()
    const deepLineList = deepClone(lineList)
    deepLineList.forEach(line => {
      const hasToNode = nodeMap.has(line.to)
      const hasFromNode = nodeMap.has(line.from)
      if (!hasToNode) nodeMap.set(line.to, { nextNode: [], prevNode: [] })
      if (!hasFromNode) nodeMap.set(line.from, { nextNode: [], prevNode: [] })
      const toNode = nodeMap.get(line.to)
      const fromNode = nodeMap.get(line.from)
      toNode.prevNode.push(line.from)
      fromNode.nextNode.push(line.to)
      nodeMap.set(line.to, toNode)
      nodeMap.set(line.from, fromNode)
    })
    const currentToNode = nodeMap.get(to)
    const currentFromNode = nodeMap.get(from)
    // 寻找to的所有父和子，看有没有from
    if (!currentToNode || !currentFromNode) return false
    toParent = line.from
    // 寻找toParent的子，看有没有from
    const flag = toNextChainHasFrom(nodeMap, from, toParent)
    if (flag) return true
  }
  return false
}

// 查找to这个节点的下游链节点是否有from
function toNextChainHasFrom(nodeMap, from, to) {
  let flag = false
  const currentToNodeObj = nodeMap.get(to) // to节点的对象
  if (!currentToNodeObj) return false
  const toNextNodes = currentToNodeObj.nextNode // to的下个节点
  while (toNextNodes.length > 0) {
    const firstNode = toNextNodes.shift()
    if (firstNode === from) {
      flag = true
      break
    }
    const nextNodeObj = nodeMap.get(firstNode)
    if (!nextNodeObj) continue
    toNextNodes.push(...nextNodeObj.nextNode)
  }
  return flag
}

// 查找to这个节点的上游链节点是否有from
function toPrevChainHasFrom(nodeMap, from, to) {
  let flag = false
  const currentToNodeObj = nodeMap.get(to) // to节点的对象
  if (!currentToNodeObj) return false
  const toPrevNodes = currentToNodeObj.prevNode // to的下个节点
  while (toPrevNodes.length > 0) {
    const firstNode = toPrevNodes.shift()
    if (firstNode === from) {
      flag = true
      break
    }
    const prevNodeObj = nodeMap.get(firstNode)
    if (!prevNodeObj) continue
    toPrevNodes.push(...prevNodeObj.prevNode)
  }
  return flag
}
