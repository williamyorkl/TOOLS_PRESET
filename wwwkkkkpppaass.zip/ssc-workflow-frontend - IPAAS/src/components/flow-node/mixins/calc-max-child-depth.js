import { EventBus } from '../utils/event-bus'
export default {
  data() {
    return {
      maxChildDepth: 1
    }
  },
  created() {
    this.listenerGroupChildChange()
  },
  activated() {
    this.listenerGroupChildChange()
  },
  methods: {
    // 监听eventbus发出的事件
    listenerGroupChildChange() {
      EventBus.$on('update-group-children', () => {
        console.log('onononoononononon')
        this.maxChildDepth = this.getMaxDepth(this.node)
      })
      this.$once('hook:beforeDestory', () => {
        EventBus.$off('update-group-children')
      })
      this.$once('hook:deactivated', () => {
        EventBus.$off('update-group-children')
      })
    },
    getMaxDepth(node) {
      if (!node) {
        return 1
      }
      let maxChildDepth = 0
      const groupChildren = node.groupChildren || []
      for (const child of groupChildren) {
        const childNode = this.nodeMap.get(child)
        const childDepth = this.getMaxDepth(childNode)
        maxChildDepth = Math.max(maxChildDepth, childDepth)
      }
      return maxChildDepth + 1
    }
  }
}
