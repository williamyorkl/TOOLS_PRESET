// 日志模式，使用不同的状态图标
export default {
  inject: {
    isLog: { default: false }, // 是否日志模式
    nodeLogMap: { default: null } // 日志记录Map
  },
  computed: {
    logStatus() {
      if (!this.isLog || !this.nodeLogMap) {
        return 0
      } else {
        const node = this.nodeLogMap.get(this.node.nodeId)
        if (!node) { // 未执行到的节点没有日志
          return 99
        } else {
          return node.status
        }
      }
    }
  }
}
