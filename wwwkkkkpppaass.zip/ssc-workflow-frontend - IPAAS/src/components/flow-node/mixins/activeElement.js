export default {
  inject: ['getActiveElement', 'setActiveElement'],
  computed: {
    activeElement: {
      get() {
        return this.getActiveElement()
      },
      set(activeElement) {
        this.setActiveElement(activeElement)
      }
    }
  }
}
