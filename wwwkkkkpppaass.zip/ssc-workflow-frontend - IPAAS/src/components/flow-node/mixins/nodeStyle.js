export default {
  props: {
    // activeElement: {
    //   type: Object,
    //   default: () => ({ name: null, type: null, id: null })
    // }
  },
  computed: {
    nodeContainerStyle() {
      return {
        top: this.node.top,
        left: this.node.left
      }
    },
    groupContainerStyle() {
      return {
        width: this.node.width,
        height: this.node.height
      }
    },
    nodeContainerClass() {
      return {
        'ef-node-container': true,
        'ef-node-active': this.activeElement.type === 'node' ? this.activeElement.id === this.node.id : false
      }
    },
    nodeIcon() {
      const nodeIcon = {}
      nodeIcon[this.node.ico] = true
      // 添加该class可以推拽连线出来，viewOnly 可以控制节点是否运行编辑
      nodeIcon['flow-node-drag'] = true
      return nodeIcon
    },
    isOldIcon() {
      const ico = this.node.ico
      if (ico.startsWith('el') || ico.startsWith('icon')) {
        return true
      } else {
        return false
      }
    }
  }
}
