// 解析节点名称，接收节点id，返回节点名称
import { resolveNodeName } from '../biz_components/nodeOptionDialog/node-option-utils'
export default {
  data() {
    return {
      resolveNodeName
    }
  }
}
