import { GROUP_NODES } from '@/config/enum'
export default {
  methods: {
    handleClick(e, node) {
      e.stopPropagation()
      this.$emit('handleClick', e, node)
    },
    handleDelete(e, node) {
      e.stopPropagation()
      this.$emit('handleDelete', e, node)
    },
    handleMouseUp(e, ref, node) {
      this.$emit('handleMouseUp', e, ref, node)
    },
    handleContextmenu(e, node) {
      e.stopPropagation()
      e.preventDefault()
      this.$emit('handleContextmenu', e, node)
    },
    handleDblclick(e, node) {
      e.stopPropagation()
      // 组节点不触发双击事件
      if (GROUP_NODES.includes(node.type)) {
        return
      }
      this.$emit('handleDblclickNode', e, node)
    }
  }
}
