export default {
  methods: {
    handleTplDesc() {
      this.$emit('handleTplDesc', this.node)
    }
  }
}
