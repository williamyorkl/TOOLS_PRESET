<template>
  <div
    class="canvas-async canvas-group"
    :id="node.id"
    :style="{...nodeContainerStyle, width: width, height: height}"
    :class="nodeContainerClass"
    @click="handleClick($event, node)"
    :ref="node.id"
    @mouseup="handleMouseUp($event, $refs[node.id], node)"
    @contextmenu="handleContextmenu($event, node)"
    @dblclick="handleDblclick($event, node)"
  >
    <groupHead :node="node" @setting="setting" :nodeIcon="nodeIcon" @handleTplDesc="handleTplDesc" />
    <div class="async-item">
      <jsplumbCanvas ref="child-jsplumb-canvas" v-on="$listeners" :canvasId="node.id" :canvasData="node.nodeParamsLogicDto.asyncDto.relationDto" />
    </div>
  </div>
</template>

<script>
import mixinNodeStyle from '../mixins/nodeStyle'
import mixinNodeEvent from '../mixins/nodeEvents'
import mixinActiveElement from '../mixins/activeElement'
import mixinCalcMaxChildDepth from '../mixins/calc-max-child-depth'
import groupHead from './group-head'
import { activeNode } from '../utils/jsplumb-render'

export default {
  name: 'Sync',
  components: { groupHead, jsplumbCanvas: () => import('./jsplumb-canvas') },
  props: {
    node: {
      required: true,
      type: Object
    }
  },
  inject: ['nodeMap'],
  mixins: [mixinNodeStyle, mixinNodeEvent, mixinActiveElement, mixinCalcMaxChildDepth],
  computed: {
    width() {
      return 500 * Math.log2(this.maxChildDepth + 1) + 'px'
    },
    height() {
      return 250 * Math.log2(this.maxChildDepth + 1) + 'px'
    }
  },
  created() {
    console.log('momnonono', this.node)
  },
  methods: {
    setting(node) {
      this.activeElement = activeNode(this.node)
      this.$emit('setting', { type: 'async', data: node })
    },
    handleTplDesc(node) {
      this.$emit('handleTplDesc', node)
    }
  }
}
</script>

<style scoped lang="scss">
.canvas-async{
  flex-direction: column;
  min-height: 250px;
  padding: 10px 20px 20px 20px;
  .async-item{
    border: 1px dashed #ccc;
    flex-grow: 1;
    overflow: auto;
  }
}
</style>
