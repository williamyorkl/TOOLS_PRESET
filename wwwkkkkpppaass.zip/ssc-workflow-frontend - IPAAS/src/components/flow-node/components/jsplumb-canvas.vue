<template>
  <draggable class="jsplumb-canvas-container" :list="canvasData.nodeList" group="jsplumb-canvas" :getInstance="getInstance" :key="key">
    <div :ref="canvasId" :id="canvasId" class="jsplumb-canvas" v-if="refresh">
      <component
        :is="renderNode(node)"
        v-for="node in canvasData.nodeList || []"
        :key="node.id"
        :node="node"
        @handleClick="handleNodeClick"
        @handleMouseUp="handleMouseUp"
        @handleDblclickNode="dblclickNode"
        @handleContextmenu="nodeContextmenu"
        @setting="setting"
        @handleTplDesc="handleTplDesc"
      />
      <!-- 设置一个占位元素，撑开画布 -->
      <div class="placeholder" />
    </div>
    <contextmenu :visible.sync="contextMenuVisible" :top="contextPosition.top" :left="contextPosition.left" :activeElement="activeElement" @deleteElement="deleteElement" @moveElement="moveElement" />
    <moveDialog :visible.sync="moveDialogVisible" :allNodeList="toMoveAllNodes" @confirm="handleConfirm" v-if="moveDialogVisible" />
  </draggable>
</template>

<script>
import draggable from 'vuedraggable'
import JsplumbUtil, { findCompleteChain, validAllowMove } from '../utils/Jsplumb'
import foreach from './foreach'
import choice from './choice'
import node from './node'
import Sync from './sync'
import Async from './async'
import Try from './try'
import { NodeTypeEnum } from '@/config/enum'
import { beforeDrop, activeLine, activeNode } from '../utils/jsplumb-render'
import contextmenu from './contextmenu.vue'
import mixinActiveElement from '../mixins/activeElement'
import { flowDrag } from '../utils/directives'
import moveDialog from './moveDialog.vue'
import cloneDeep from 'lodash/cloneDeep'
import toNumber from 'lodash/toNumber'
import { getUUID } from '@/utils'
import { getNodeIndex } from '@/components/flow-node/biz_components/nodeOptionDialog/node-option-utils'

export default {
  name: 'JsplumbCanvas',
  components: { node, choice, foreach, Sync, draggable, contextmenu, Async, Try, moveDialog },
  props: {
    canvasId: {
      default: 'jsplumb-canvas',
      type: String
    },
    canvasData: {
      default: () => {},
      type: Object
    }
  },
  mixins: [mixinActiveElement],
  inject: ['nodeMap', 'formDisabled'],
  data() {
    return {
      jsplumbInstance: null,
      contextMenuVisible: false,
      contextPosition: {
        top: 0,
        left: 0
      },
      moveDialogVisible: false,
      sourceAutoDeleteLineObj: null,
      targetAutoDeleteLineObj: null,
      toMoveAllNodes: null,
      key: 0,
      refresh: true
    }
  },
  mounted() {
    // 工具对象
    this.jsplumbUtil = new JsplumbUtil()
    this.init()
  },
  directives: {
    flowDrag
  },
  // watch: {
  //   activeElement: {
  //     handler(val, oVal) {
  //       console.log('🚀 ~ file: jsplumb-canvas.vue ~ line 82 ~ handler ~ val,oVal', val, oVal)
  //     },
  //     immediate: true,
  //     deep: true
  //   }
  // },
  methods: {
    // // 重绘
    // repaint() {
    //   console.log('repaint')
    //   this.jsplumbInstance.repaint()
    //   console.log(this.jsplumbInstance)
    // },
    // 初始化
    init() {
      this.jsplumbInstance = this.jsplumbUtil.init({
        nodeMap: this.nodeMap,
        el: this.$refs[this.canvasId],
        id: this.canvasId,
        data: this.canvasData,
        handleLineClick: (conn, originEvent) => {
          this.activeElement = activeLine(conn, originEvent)
        },
        // 判断是否可连线
        beforeDrop,
        // 右键连线
        handleLineContextmenu: this.handleLineContextmenu
      })
    },
    // 右键连线
    handleLineContextmenu(type, ev, line) {
      ev.preventDefault()
      if (this.formDisabled) {
        return false
      }
      this.activeElement = activeLine(line, ev)
      this.contextPosition.top = ev.clientY + 8
      this.contextPosition.left = ev.clientX + 8
      this.contextMenuVisible = true
    },
    // 删除激活的元素（line | node）
    deleteElement() {
      if (this.activeElement.type === 'node') {
        this.deleteNode(this.activeElement)
      } else if (this.activeElement.type === 'line') {
        this.deleteLine(this.activeElement)
      }
    },
    // 删除连线
    deleteLine(activeElement) {
      console.log('🚀 ~ file: jsplumb-canvas.vue ~ line 118 ~ deleteLine ~ activeElement', activeElement)
      this.$confirm('确定删除所选中的线吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          this.jsplumbInstance.deleteLine(activeElement)
        })
        .catch(() => {})
    },
    // 删除节点
    deleteNode(activeElement) {
      // ------新增的判断
      const type = activeElement.node.type
      if (type === NodeTypeEnum.START) {
        this.$message.error('开始节点不允许删除')
      } else if (type === NodeTypeEnum.END) {
        this.$message.error('结束节点不允许删除')
      } else {
        this.$confirm(`确定删除 <b>${activeElement.name}</b> 节点吗?`, '提示', {
          dangerouslyUseHTMLString: true,
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(() => {
            this.jsplumbInstance.deleteNode(activeElement.id, activeElement.node)
          })
          .catch(() => {})
      }
    },
    // 双击节点
    dblclickNode(nodeId, node) {
      // 双击节点，给弹窗传入node，修改nodeParamsLogicDto
      this.$emit('setting', { type: 'node', data: node })
    },
    setting({ type, data }) {
      this.$emit('setting', { type, data })
    },
    handleTplDesc(node) {
      this.$emit('handleTplDesc', node)
    },
    // 右键节点
    nodeContextmenu(ev, node) {
      ev.stopPropagation()
      ev.preventDefault()
      if (this.formDisabled) {
        return false
      }
      this.activeElement = activeNode(node, ev)

      this.contextPosition.top = ev.clientY + 8
      this.contextPosition.left = ev.clientX + 8
      this.contextMenuVisible = true

      console.log('🚀 ~ file: jsplumb-canvas.vue ~ line 175 ~ nodeContextmenu ~ this.activeElement', this.activeElement)

      // console.log('vvvv1', JSON.stringify(this.canvasData.lineList))
    },
    // 点击节点
    handleNodeClick(e, node) {
      e.stopPropagation()
      this.activeElement = activeNode(node, e)
    },
    // 当前组件
    renderNode(node) {
      const nodeType = node.type
      if (nodeType === NodeTypeEnum.FOREACH) {
        return 'foreach'
      } else if (nodeType === NodeTypeEnum.CHOICE) {
        return 'choice'
      } else if (nodeType === NodeTypeEnum.SYNC) {
        return 'sync'
      } else if (nodeType === NodeTypeEnum.ASYNC) {
        return 'async'
      } else if (nodeType === NodeTypeEnum.TRY) {
        return 'try'
      } else {
        return 'node'
      }
    },
    // 修改位置:e是点击的元素，可能是节点的子元素; ref是节点本身
    handleMouseUp(e, ref, node) {
      e.preventDefault()
      const isTarget = ref.id === node.id
      if (!isTarget) return
      const { top, left } = ref.style
      node.top !== top && (node.top = top)
      node.left !== left && (node.left = left)
    },
    // 该方法提供给refs来获取列表数据
    getSourceList() {
      return this.canvasData.nodeList
    },
    // 该方法提供给refs来获取列表数据
    getInstance() {
      return this.jsplumbInstance
    },
    refreshComp() {
      this.refresh = false

      // 在组件移除后，重新渲染组件
      // this.$nextTick可实现在DOM 状态更新后，执行传入的方法。
      this.$nextTick(() => {
        setTimeout(() => {
          this.key = toString(new Date())
        }, 2000)

        setTimeout(() => {
          this.refresh = true
        }, 2000)
      })
    },
    moveElement() {
      console.log('🚀 ~ file: jsplumb-canvas.vue ~ line 215 ~ moveElement ~ this.activeElement', this.activeElement)

      this.toMoveAllNodes = findCompleteChain(
        {
          nodeMap: this.nodeMap,
          currentId: this.activeElement.node.id
        }
      )

      // NOTE - 如果当前需要移动的元素是嵌套节点，需要过滤其子节点
      this.toMoveAllNodes = this.toMoveAllNodes.filter(item => item?.parent !== this.activeElement.id)

      this.moveDialogVisible = true
    },
    async handleConfirm({ nodeId, position }) {
      const [allowMove, msg] = validAllowMove({ currentId: this.activeElement.node.id, targetId: nodeId, nodeMap: this.nodeMap, position })
      if (!allowMove) {
        return this.$message.warning(msg)
      }

      this.moveDialogVisible = false

      await this.$nextTick()

      const selectedNode = this.nodeMap.get(nodeId)
      console.log('🚀 ~ file: jsplumb-canvas.vue ~ line 246 ~ handleConfirm ~ selectedNode', selectedNode)

      // 四、改变节点位置
      this.activeElement.node.left = toNumber(selectedNode.left.split('px')[0]) + 50 + 'px'
      this.activeElement.node.top = toNumber(selectedNode.top.split('px')[0]) + 50 + 'px'

      await this.$forceUpdate()

      // 一、判断： 【下拉选中节点】 不是在嵌套节点内 && 【右击选中节点】 也不在嵌套节点内 || 【下拉选中节点】 在嵌套节点内 && 【右击选中节点】 也在嵌套节点内
      if ((!selectedNode.parent && !this.activeElement.node.parent) || (selectedNode.parent === this.activeElement.node.parent)) {
        this.hanldeConditionMoveNode(this.jsplumbInstance, selectedNode, position, this.activeElement)
      }

      // 二、判断：【下拉选中节点】在嵌套节点内 && 【右击选中节点】不在嵌套节点内
      if (selectedNode.parent && !this.activeElement.node.parent) {
        // NOTE - 处理部分有 嵌套dom && 有条件的移动节点
        const nestedNodeIndex = getNodeIndex({ nodeId: selectedNode.id, nodeMap: this.nodeMap })

        const targetCanvasDom = this.getJsplumbDom(selectedNode.parent, nestedNodeIndex)

        const nestedInstance = this.getInstanceFromDom(targetCanvasDom)
        const newNodeIdKey = getUUID()
        const newCloneNode = {
          ...cloneDeep(this.activeElement.node),
          parent: selectedNode.parent,
          id: newNodeIdKey, // NOTE - 移进去要加parent
          nodeKey: newNodeIdKey
        }

        // NOTE - 【右击选中节点】在嵌套画布内
        this.jsplumbInstance.deleteNode(this.activeElement.id, this.activeElement.node)

        await this.$nextTick()

        const toList = this.getSourceListFromDom(targetCanvasDom)
        toList.push(newCloneNode)

        await this.$nextTick()

        nestedInstance.registerNode(newCloneNode, nestedInstance)

        await this.$nextTick()

        this.hanldeConditionMoveNode(nestedInstance, selectedNode, position, { node: newCloneNode, id: newCloneNode.id, name: newCloneNode.name, type: 'node' }, this.jsplumbInstance, 'OUTTER_CLICKNODE_INNER_SELECTNODE')

        console.log('🚀 ~ file: jsplumb-canvas.vue ~ line 317 ~ handleConfirm ~ this.nodeMap', this.nodeMap)
      }

      // 三、判断：【下拉选中节点】不在嵌套节点内 && 【右击选中节点】在嵌套节点内
      if (!selectedNode.parent && this.activeElement.node.parent) {
        // debugger // NOTE - 优先测试这个
        const activeNestedNodeIndex = getNodeIndex({ nodeId: this.activeElement.node.id, nodeMap: this.nodeMap })
        const targetCanvasDom = this.getJsplumbDom(this.activeElement.node.parent, activeNestedNodeIndex)

        const outerMainCanvasDom = document.querySelector('.jsplumb-canvas-container')
        const outerMainInstance = this.getInstanceFromDom(outerMainCanvasDom)

        const nestedInstance = this.getInstanceFromDom(targetCanvasDom)
        const newNodeIdKey = getUUID()
        const newCloneNode = {
          ...cloneDeep(this.activeElement.node),
          parent: null, // NOTE - 移出去要删parent
          id: newNodeIdKey,
          nodeKey: newNodeIdKey
        }

        // NOTE - 【右击选中节点】在嵌套画布内, 通过画布删除
        nestedInstance.deleteNode(this.activeElement.id, this.activeElement.node)

        await this.$nextTick() // 必要

        const toList = this.getSourceListFromDom(outerMainCanvasDom)
        toList.push(newCloneNode)

        await this.$nextTick() // 必要

        outerMainInstance.registerNode(newCloneNode, outerMainInstance)

        await this.$nextTick() // 必要

        this.hanldeConditionMoveNode(
          nestedInstance,
          selectedNode,
          position,
          {
            node: newCloneNode,
            id: newCloneNode.id,
            name: newCloneNode.name,
            type: 'node'
          },
          outerMainInstance,
          'INNER_CLICKNODE_OUTTER_SELECTNODE'
        )
      }

      // 四、判断：【下拉选中节点】在嵌套节点内 && 【右击选中节点】在嵌套节点内
      if (selectedNode.parent && this.activeElement.node.parent) {
        // debugger
        const selectedNestedNodeIndex = getNodeIndex({ nodeId: selectedNode.id, nodeMap: this.nodeMap })
        const selectedCanvasDom = this.getJsplumbDom(selectedNode.parent, selectedNestedNodeIndex)

        const activeNestedNodeIndex = getNodeIndex({ nodeId: this.activeElement.node.id, nodeMap: this.nodeMap })
        const activeCanvasDom = this.getJsplumbDom(this.activeElement.node.parent, activeNestedNodeIndex)

        const selectedInstance = this.getInstanceFromDom(selectedCanvasDom)
        const activeInstance = this.getInstanceFromDom(activeCanvasDom)

        const newNodeIdKey = getUUID()
        const newCloneNode = {
          ...cloneDeep(this.activeElement.node),
          parent: null,
          id: newNodeIdKey,
          nodeKey: newNodeIdKey
        }

        // NOTE - 【右击选中节点】在嵌套画布内, 通过画布删除
        activeInstance.deleteNode(this.activeElement.id, this.activeElement.node)

        await this.$nextTick()

        const toList = this.getSourceListFromDom(selectedCanvasDom)
        toList.push(newCloneNode)

        await this.$nextTick()

        selectedInstance.registerNode(newCloneNode, selectedInstance)

        await this.$nextTick()

        this.hanldeConditionMoveNode(selectedInstance, selectedNode, position, { node: newCloneNode, id: newCloneNode.id, name: newCloneNode.name, type: 'node' }, activeInstance, 'INNER_CLICKNODE_INNER_SELECTNODE')
      }
    },
    handleUpNodeMove(instance, selectedNode, activeElement) {
      // 1 被【下拉选中的节点】只有没有【出线】  // NOTE - 正常场景下这个条件不会触发
      if (!selectedNode.prev || selectedNode.prev.length === 0) {
        instance.registerLine({
          type: 'line',
          from: activeElement.node.id,
          to: selectedNode.id
        })
        return
      }

      // 1.1 被【下拉选中的节点】只有一根【出线】
      if (selectedNode.prev.length === 1) {
        const selectedPrevId = selectedNode.prev[0]

        // a）删除线
        instance.deleteLine({
          type: 'line',
          from: selectedPrevId,
          to: selectedNode.id
        })

        // b） 再执行连线
        instance.registerLine({
          type: 'line',
          from: selectedPrevId,
          to: activeElement.node.id
        })

        instance.registerLine({
          type: 'line',
          from: activeElement.node.id,
          to: selectedNode.id
        })

        return
      }

      // 2.1 被【下拉选中的节点】有多根【入线】
      if (selectedNode.prev.length > 1) {
        // NOTE - 把多根【入线】汇成一起
        const multiPrevNodeList = cloneDeep(selectedNode.prev)
        console.log('🚀 ~ file: jsplumb-canvas.vue ~ line 295 ~ handleUpNodeMove ~ multiPrevNode', multiPrevNodeList)

        // a) 删除【下拉选中节点】的汇入线
        multiPrevNodeList.forEach(item => {
          instance.deleteLine({
            type: 'line',
            from: item,
            to: selectedNode.id
          })
        })

        // b）把多根的汇入线连到【右击选中的节点】
        multiPrevNodeList.forEach(item => {
          instance.registerLine({
            type: 'line',
            from: item,
            to: activeElement.node.id
          })
        })

        // c）把【右击选中的节点】连接到【下拉选中的节点】
        instance.registerLine({
          type: 'line',
          from: activeElement.node.id,
          to: selectedNode.id
        })
      }
    },
    async handleDownNodeMove(instance, selectedNode, activeElement) {
      // 1.2.1 被下拉选中的节点没有出线
      if (!selectedNode.next || selectedNode.next.length === 0) {
        instance.registerLine({
          type: 'line',
          from: selectedNode.id,
          to: activeElement.node.id
        })
        return
      }

      // 1.2.2 被下拉选中的节点只有一根出线
      if (selectedNode.next.length === 1) {
        const selectedNextId = selectedNode.next[0]

        instance.deleteLine({
          type: 'line',
          from: selectedNode.id,
          to: selectedNextId
        })

        // b） 再执行连线
        instance.registerLine({
          type: 'line',
          from: activeElement.node.id,
          to: selectedNextId
        })

        instance.registerLine({
          type: 'line',
          from: selectedNode.id,
          to: activeElement.node.id
        })

        return
      }

      // 1.2.3 被下拉选中的节点有多根出线
      if (selectedNode.next.length > 1) {
        // NOTE - 把多根【出线】汇成一起
        const multiNextNodeList = cloneDeep(selectedNode.next)

        // a) 删除【下拉选中节点】的汇入线
        multiNextNodeList.forEach(item => {
          instance.deleteLine({
            type: 'line',
            from: selectedNode.id,
            to: item
          })
        })

        await this.$nextTick()

        // b）把多根的汇入线连到【右击选中的节点】
        multiNextNodeList.forEach(item => {
          instance.registerLine({
            type: 'line',
            from: activeElement.node.id,
            to: item
          })
        })

        await this.$nextTick()

        // c）把【右击选中的节点】连接到【下拉选中的节点】
        instance.registerLine({
          type: 'line',
          from: selectedNode.id,
          to: activeElement.node.id
        })
      }
    },
    hanldeConditionMoveNode(instanceParam, selectedNode, position, activeElement, outterInstance, controlType) {
      // NOTE - 外面canvas的node传入嵌套节点时，需要删除连线和重新连线，这时外部的连线需要用outterInstance
      let instance = instanceParam
      if (['OUTTER_CLICKNODE_INNER_SELECTNODE', 'INNER_CLICKNODE_INNER_SELECTNODE'].includes(controlType)) {
        instance = outterInstance
      }

      // 0、移动的节点没有出线和入线  // TODO - 待测试
      if (
        (!activeElement.node.prev && !activeElement.node.next) ||
        (activeElement.node.prev.length === 0 && activeElement.node.next.length === 0)
      ) {
        this.handleUpAndDownCondition(instance, instanceParam, selectedNode, outterInstance, activeElement, position, controlType)

        return
      }

      // 0.1) 移动的节点有 1根出线和 0根入线 // TODO - 待测试
      if (
        (!activeElement.node.prev && activeElement.node.next.length === 1) ||
        (activeElement.node.prev.length === 0)
      ) {
        const singleNodeNext = activeElement.node.next[0]

        // 1) 先删除执行连线
        instance.deleteLine({
          type: 'line',
          from: activeElement.node.id,
          to: singleNodeNext
        })

        //  2） 多选框下拉选中的节点
        // if (position === 'up') this.handleUpNodeMove(instance, selectedNode, activeElement)
        // if (position === 'down') this.handleDownNodeMove(instance, selectedNode, activeElement)
      }

      // 0.2) 移动的节点有 0根出线和 1根入线 // TODO - 待测试
      if (
        (activeElement.node.prev.length === 1 && !activeElement.node.next) ||
        (activeElement.node.next.length === 0)
      ) {
        const singleNodePrev = activeElement.node.prev[0]

        // 1) 先删除执行连线
        instance.deleteLine({
          type: 'line',
          from: singleNodePrev,
          to: activeElement.node.id
        })
      }

      // 1、移动的节点只有单根出线和单根入线
      if (activeElement.node.prev.length === 1 && activeElement.node.next.length === 1) {
        // debugger
        const singleNodeNext = activeElement.node.next[0]
        const singleNodePrev = activeElement.node.prev[0]

        // 1) 先删除执行连线
        instance.deleteLine({
          type: 'line',
          from: activeElement.node.id,
          to: singleNodeNext
        })

        instance.deleteLine({
          type: 'line',
          from: singleNodePrev,
          to: activeElement.node.id
        })

        // 2） 剩余的自动连上
        instance.registerLine({
          type: 'line',
          from: singleNodePrev,
          to: singleNodeNext
        })
      }

      // 2、移动的节点有多根prev【入线】，单根next【出线】 // TODO - 待测试
      if (activeElement.node.prev.length > 1 && activeElement.node.next.length === 1) {
        const multiPrevNodeList = cloneDeep(activeElement.node.prev)
        const activeNodeNextId = activeElement.node.next[0]

        // 1）【右击选中节点】删除连线
        multiPrevNodeList.forEach(item => {
          instance.deleteLine({
            type: 'line',
            from: item,
            to: activeElement.node.id
          })
        })

        instance.deleteLine({
          type: 'line',
          from: activeElement.node.id,
          to: activeNodeNextId
        })

        // 2）其它节点自己连接
        multiPrevNodeList.forEach(item => {
          instance.registerLine({
            type: 'line',
            from: item,
            to: activeNodeNextId
          })
        })

        //  3） 【多选框下拉】选中的节点连线
        // if (position === 'up') this.handleUpNodeMove(instance, selectedNode, activeElement)
        // if (position === 'down') this.handleDownNodeMove(instance, selectedNode, activeElement)
      }

      // 3、移动的节点有单根prev【入线】，多根next【出线】 // TODO - 待测试
      if (activeElement.node.prev.length === 1 && activeElement.node.next.length > 1) {
        const multiNextNodeList = cloneDeep(activeElement.node.next)
        const activeNodePrevId = activeElement.node.prev[0]

        // 1）【右击选中节点】删除连线
        multiNextNodeList.forEach(item => {
          instance.deleteLine({
            type: 'line',
            from: activeElement.node.id,
            to: item
          })
        })

        instance.deleteLine({
          type: 'line',
          from: activeNodePrevId,
          to: activeElement.node.id
        })

        // 2）其它节点自己连接
        multiNextNodeList.forEach(item => {
          instance.registerLine({
            type: 'line',
            from: activeNodePrevId,
            to: item
          })
        })

        // //  3） 【多选框下拉】选中的节点连线
        // if (position === 'up') this.handleUpNodeMove(instance, selectedNode, activeElement)
        // if (position === 'down') this.handleDownNodeMove(instance, selectedNode, activeElement)
      }

      this.handleUpAndDownCondition(instance, instanceParam, selectedNode, outterInstance, activeElement, position, controlType)
    },
    getInstanceFromDom(to) {
      let instance = null
      if (to.__vue__.$attrs.getInstance) {
        instance = to.__vue__.$attrs.getInstance()
      } else if (to.__vue__.getInstance) {
        instance = to.__vue__.getInstance()
      } else {
        instance = this.$refs['jsplumb-canvas'].getInstance()
      }
      return instance
    },
    getSourceListFromDom(to) {
      let toList = []
      // 循环引用，__vue__实例不正常，最外层可以通过 __vue__.list获取，内层需要通过自定义函数 __vue__.getList获取
      if (to.__vue__.getSourceList) {
        toList = to.__vue__.getSourceList()
      } else {
        toList = to.__vue__.list
      }
      return toList
    },
    handleUpAndDown(instance, selectedNode, activeElement, position) {
      if (position === 'up') this.handleUpNodeMove(instance, selectedNode, activeElement)
      if (position === 'down') this.handleDownNodeMove(instance, selectedNode, activeElement)
    },
    handleUpAndDownCondition(instance, instanceParam, selectedNode, outterInstance, activeElement, position, controlType) {
      if (controlType === 'INNER_CLICKNODE_OUTTER_SELECTNODE') {
        // debugger
        // 这是instance应为外面的
        this.handleUpAndDown(outterInstance, selectedNode, activeElement, position)
      } else if (controlType === 'OUTTER_CLICKNODE_INNER_SELECTNODE') {
        // 这是instance应为里面的
        this.handleUpAndDown(instanceParam, selectedNode, activeElement, position)
      } else if (controlType === 'INNER_CLICKNODE_INNER_SELECTNODE') {
        this.handleUpAndDown(instanceParam, selectedNode, activeElement, position)
      } else {
        this.handleUpAndDown(instance, selectedNode, activeElement, position)
      }
    },
    getJsplumbDom(nodeId, targetIndex) {
      const toFindNode = this.nodeMap.get(nodeId)

      switch (toFindNode.type) {
        case NodeTypeEnum.CHOICE:
          return document.querySelectorAll(`[id='${nodeId}']>.group-list>.el-row>.el-col>.choice-item>.group-item`)[targetIndex].querySelector('.jsplumb-canvas-container')

        case NodeTypeEnum.TRY:
          return document.querySelectorAll(`[id='${nodeId}']>.group-list>.choice-item>.group-item`)[targetIndex].querySelector('.jsplumb-canvas-container')

        case NodeTypeEnum.FOREACH:
          return document.querySelectorAll(`[id='${nodeId}']>.foreach-item`)[0].querySelector('.jsplumb-canvas-container')

        case NodeTypeEnum.SYNC:
          return document.querySelectorAll(`[id='${nodeId}']>.sync-item`)[0].querySelector('.jsplumb-canvas-container')

        case NodeTypeEnum.ASYNC:
          return document.querySelectorAll(`[id='${nodeId}']>.async-item`)[0].querySelector('.jsplumb-canvas-container')
      }
    }
  }

}
</script>

<style lang="scss">
.jsplumb-canvas{
  overflow: scroll;
  // flex: 1;
  .placeholder{
    width: 2000px;
    height: 2000px;
    position: absolute;
    z-index: -1;
  }
}
</style>
