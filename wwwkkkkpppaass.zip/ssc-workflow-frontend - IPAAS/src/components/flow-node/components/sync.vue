<template>
  <div
    class="canvas-sync canvas-group"
    :id="node.id"
    :style="{...nodeContainerStyle, width: width, height: height}"
    :class="nodeContainerClass"
    @click="handleClick($event, node)"
    :ref="node.id"
    @mouseup="handleMouseUp($event, $refs[node.id], node)"
    @contextmenu="handleContextmenu($event, node)"
    @dblclick="handleDblclick($event, node)"
  >
    <groupHead :node="node" @setting="setting" :nodeIcon="nodeIcon" @handleTplDesc="handleTplDesc" />
    <div class="sync-item">
      <jsplumbCanvas ref="child-jsplumb-canvas" v-on="$listeners" :canvasId="node.id" :canvasData="node.nodeParamsLogicDto.synchronizedDto.relationDto" />
    </div>
  </div>
</template>

<script>
import mixinNodeStyle from '../mixins/nodeStyle'
import mixinNodeEvent from '../mixins/nodeEvents'
import mixinActiveElement from '../mixins/activeElement'
import mixinCalcMaxChildDepth from '../mixins/calc-max-child-depth'
import groupHead from './group-head'
import { activeNode } from '../utils/jsplumb-render'

export default {
  name: 'Sync',
  components: { groupHead, jsplumbCanvas: () => import('./jsplumb-canvas') },
  props: {
    node: {
      required: true,
      type: Object
    }
  },
  inject: ['nodeMap'],
  mixins: [mixinNodeStyle, mixinNodeEvent, mixinActiveElement, mixinCalcMaxChildDepth],
  computed: {
    width() {
      return 500 * Math.log2(this.maxChildDepth + 1) + 'px'
    },
    height() {
      return 250 * Math.log2(this.maxChildDepth + 1) + 'px'
    }
  },
  methods: {
    setting(node) {
      this.activeElement = activeNode(this.node)
      this.$emit('setting', { type: 'sync', data: node })
    },
    handleTplDesc(node) {
      this.$emit('handleTplDesc', node)
    }
  }
}
</script>

<style scoped lang="scss">
.canvas-sync{
  flex-direction: column;
  min-height: 250px;
  padding: 10px 20px 20px 20px;
  .sync-item{
    border: 1px dashed #ccc;
    flex-grow: 1;
    overflow: auto;
  }
}
</style>
