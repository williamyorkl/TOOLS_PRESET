<template>
  <div class="choice-head">
    <div class="left">
      {{ type }}
    </div>
  </div>
</template>

<script>
export default {
  props: {
    type: {
      type: String,
      default: 'try'
    }
  }
}
</script>

<style lang="scss" scoped>
.choice-head {
  display: flex;
  align-items: center;
  padding: 5px;
  border-bottom: 1px solid #ccc;
  justify-content: space-between;
  .left {
    align-items: center;
    font-weight: 700;
    font-size: 16px;
    width: 100px;
  }
  .right {
    display: flex;
    align-items: center;
    cursor: pointer;
    i {
      font-size: 18px;
      margin-right: 10px;
    }
  }
}
</style>
