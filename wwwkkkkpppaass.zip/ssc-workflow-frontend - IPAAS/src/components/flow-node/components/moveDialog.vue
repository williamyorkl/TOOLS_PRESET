<template>
  <el-dialog title="选择目标节点" :visible.sync="visible" :beforeClose="handleCancel" :closeOnClickModal="true" :appendToBody="true">
    <el-form ref="form" :model="form" :rules="rules">
      <el-form-item label="目标节点" :labelWidth="formLabelWidth" prop="nodeId">
        <el-select placeholder="请选择选择目标节点" v-model="form.nodeId">
          <el-option v-for="node in allNodeList" :label="node.labelName" :value="node.id" :key="node.id" />
        </el-select>
      </el-form-item>
      <el-form-item label="位置" :labelWidth="formLabelWidth" prop="position">
        <el-select v-model="form.position" placeholder="请选择需要放置的位置">
          <el-option label="前" value="up" />
          <el-option label="后" value="down" />
        </el-select>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">取 消</el-button>
      <el-button type="primary" @click="handleConfirm">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>

export default {
  props: {
    visible: {
      default: false,
      type: Boolean
    },
    allNodeList: {
      default: () => [],
      type: Array
    }
  },
  data() {
    return {
      form: {
        nodeId: '',
        position: 'down'
      },
      rules: {
        nodeId: [
          { required: true, message: '请选择目标节点', trigger: 'change' }
        ],
        position: [
          { required: true, message: '请选择位置', trigger: 'change' }
        ]
      },
      formLabelWidth: '120px'
    }
  },
  methods: {
    handleConfirm() {
      this.$refs.form.validate(valid => {
        if (valid) {
          // 判断是否允许移动操作
          this.$emit('confirm', this.form)
        } else {
          this.$message.error('请完善表单信息')
        }
      })
    },
    handleCancel() {
      this.$emit('update:visible', false)
    }
  }
}
</script>
