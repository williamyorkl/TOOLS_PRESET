<template>
  <div class="choice-head">
    <div class="left">
      <el-select v-model="choiceItem.conditionType" :disabled="isLog" @change="conditionTypeChange">
        <el-option label="if" :value="ChoiceEnum.IF" :disabled="index !== 0"></el-option>
        <el-option label="else if" :value="ChoiceEnum.ELSE_IF" :disabled="index === 0"></el-option>
        <el-option label="else" :value="ChoiceEnum.ELSE" :disabled="index === 0 || index !== len - 1"></el-option>
      </el-select>
    </div>
    <!-- 日志模式 和 ELSE  不包括前置条件配置 -->
    <div class="right" v-if="!isLog && choiceItem.conditionType !== ChoiceEnum.ELSE">
      <i class="el-icon-s-tools" @click="handleSetting"></i>
    </div>
  </div>
</template>

<script>
import { ChoiceEnum } from '@/config/enum'
import mixinLogEvent from '../mixins/logEvent'
export default {
  props: {
    choiceItem: {
      conditionType: null
    },
    index: {},
    len: {}
  },
  data() {
    return {
      ChoiceEnum
    }
  },
  mixins: [mixinLogEvent],
  methods: {
    handleSetting() {
      this.$emit('setting', this.choiceItem)
    },
    conditionTypeChange() {
      if (this.choiceItem.conditionType === ChoiceEnum.ELSE) {
        this.choiceItem.preCondition.conditionList = null
      } else {
        this.choiceItem.preCondition.conditionList = []
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.choice-head {
  display: flex;
  align-items: center;
  padding: 5px;
  border-bottom: 1px solid #ccc;
  justify-content: space-between;
  .left {
    align-items: center;
    font-weight: 700;
    font-size: 16px;
    width: 100px;
  }
  .right {
    display: flex;
    align-items: center;
    cursor: pointer;
    i {
      font-size: 18px;
      margin-right: 10px;
    }
  }
}
</style>
