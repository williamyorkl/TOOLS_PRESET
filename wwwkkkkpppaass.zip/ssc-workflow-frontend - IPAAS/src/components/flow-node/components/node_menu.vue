<template>
  <div class="flow-menu" ref="tool">
    <div v-for="menu in menuList" :key="menu.id">
      <span class="ef-node-pmenu" @click="menu.open = !menu.open">
        <i :class="{'el-icon-caret-bottom': menu.open,'el-icon-caret-right': !menu.open}" />&nbsp;{{ menu.name }}
      </span>
      <div v-show="menu.open" class="ef-node-menu-ul">
        <draggable @start="dropStart" @end="end" v-model="menu.children" :options="draggableOptions" :group="{ name: 'jsplumb-canvas', pull: 'clone', put: false }" :clone="clone">
          <div v-for="subMenu in menu.children" class="ef-node-menu-li" :key="subMenu.id" :type="subMenu.type">
            <mc-svg-icon :icon="subMenu.ico" iconClass="iconfont1" /> {{ subMenu.name }}
          </div>
        </draggable>
      </div>
    </div>
  </div>
</template>
<script>
import draggable from 'vuedraggable'
import { menuList } from '../model/menu-list'

const mousePosition = {
  left: -1,
  top: -1
}

export default {
  data() {
    return {
      activeNames: '1',
      // draggable配置参数参考 https://www.cnblogs.com/weixin186/p/10108679.html
      draggableOptions: {
        preventOnFilter: false,
        sort: false,
        disabled: false,
        ghostClass: 'tt',
        // 不使用H5原生的配置
        forceFallback: true
        // 拖拽的时候样式
        // fallbackClass: 'flow-node-draggable'
      },
      // 默认打开的左侧菜单的id
      defaultOpeneds: ['1', '2'],
      menuList,
      nodeMenu: {}
    }
  },
  components: {
    draggable
  },
  methods: {
    // 开始拖拽时记录鼠标的位置
    dropStart(ev) {
      mousePosition.top = ev.originalEvent.offsetY
      mousePosition.left = ev.originalEvent.offsetX
    },
    // 这个方法不要删除，用于阻止拖拽时自动在目标容器生成dom的默认行为，并记录一下拖拽的节点源数据
    clone(ev) {
      this.nodeMenu = ev
    },
    // 拖拽结束时触发
    end(evt) {
      this.$emit('addNode', evt, this.nodeMenu, mousePosition)
    }
  }
}
</script>

<style scoped lang="scss">
.iconfont1{
  color: #333;
}
</style>
