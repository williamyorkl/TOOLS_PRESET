<template>
  <div class="group-head">
    <div class="left">
      <i v-if="isOldIcon" class="iconfont" :class="nodeIcon" />
      <mc-svg-icon v-else :class="nodeIcon" :icon="node.ico" iconClass="iconfont" />
      {{ node.name }}
      <!-- 节点状态图标 -->
      <div class="log-ico-container" v-if="isLog">
        <i class="log-icon el-icon-circle-check" v-if="logStatus === 0" />
        <i class="log-icon el-icon-warning" v-else-if="logStatus === 99" />
        <i class="log-icon el-icon-circle-close" v-else />
      </div>
      <!-- 模板 -->
      <div class="log-ico-container" v-else-if="mode === 'arrangeTplSet'">
        <i class="el-icon-info tpl-icon" @click="handleTplDesc" />
      </div>
    </div>
    <div class="right">
      <i class="el-icon-s-tools" @click="handleSetting" />
    </div>
  </div>
</template>

<script>
import mixinLogEvent from '../mixins/logEvent'
// import mixinNodeTplEvent from '../mixins/node-tpl-event'
export default {
  props: {
    node: {
      default: () => ({}),
      type: Object
    },
    nodeIcon: {
      default: () => ({}),
      type: Object
    }
  },
  mixins: [mixinLogEvent],
  inject: {
    mode: {
      from: 'mode',
      default: null
    }
  },
  computed: {
    isOldIcon() {
      const ico = this.node.ico
      if (ico.startsWith('el') || ico.startsWith('icon')) {
        return true
      } else {
        return false
      }
    }
  },
  methods: {
    handleSetting() {
      this.$emit('setting', this.node)
    },
    handleTplDesc() {
      this.$emit('handleTplDesc', this.node)
    }
  }
}
</script>

<style lang="scss" scoped>
.group-head {
  display: flex;
  align-items: center;
  // border-bottom: 1px solid #ccc;
  .left {
    flex: 1;
    display: flex;
    align-items: center;
    font-weight: 700;
    font-size: 16px;
    i {
      font-size: 18px;
      margin-right: 10px;
    }
    .log-ico-container {
      display: inline-block;
      width: 18px;
      margin-left: 20px;
      .log-icon, .tpl-icon {
        line-height: 32px;
        cursor: default;
        font-size: 18px;
      }
      .tpl-icon{
        cursor: pointer;
      }
      .el-icon-circle-check {
        color: #84cf65;
      }
      .el-icon-circle-close{
        color: #F56C6C
      }
      .el-icon-warning{
        color: #909399
      }
    }
  }
  .right {
    display: flex;
    align-items: center;
    cursor: pointer;
    i {
      font-size: 18px;
      margin-right: 10px;
    }
  }
}
</style>
