<template>
  <div
    class="canvas-node"
    :id="node.id"
    :style="nodeContainerStyle"
    :class="nodeContainerClass"
    @click="handleClick($event, node)"
    :ref="node.id"
    @mouseup="handleMouseUp($event, $refs[node.id], node)"
    @contextmenu="handleContextmenu($event, node)"
    @dblclick="handleDblclick($event, node)"
  >
    <!-- 最左侧的那条竖线 -->
    <div class="ef-node-left" />
    <!-- 节点类型的图标 -->
    <div class="ef-node-left-ico flow-node-drag">
      <i v-if="isOldIcon" class="iconfont" :class="nodeIcon" />
      <div v-else class="line-box">
        <mc-svg-icon :icon="node.ico" iconClass="iconfont" />
        <div :class="nodeIcon" class="icon-mask" />
      </div>
    </div>
    <!-- 节点名称 -->
    <div class="ef-node-text" :show-overflow-tooltip="true" :title="node.name">
      {{ node.name }}
    </div>
    <!-- 日志：节点状态图标 -->
    <div class="ef-node-right-ico" v-if="isLog">
      <i class="el-icon-circle-check el-node-state-success" v-if="logStatus === 0" />
      <i class="el-icon-warning el-node-state-info" v-else-if="logStatus === 99" />
      <i class="el-icon-circle-close el-node-state-error" v-else />
    </div>
    <!-- 模板 -->
    <div class="ef-node-right-ico" v-else-if="mode === 'arrangeTplSet'">
      <i class="el-icon-info el-node-state-info tpl-icon" @click="handleTplDesc" />
    </div>
    <!-- 编排：节点状态图标 -->
    <div class="ef-node-right-ico" v-else>
      <i class="el-icon-circle-check el-node-state-success" v-show="node.state === 'success'" />
      <i class="el-icon-circle-close el-node-state-error" v-show="node.state === 'error'" />
      <i class="el-icon-warning-outline el-node-state-warning" v-show="node.state === 'warning'" />
      <i class="el-icon-loading el-node-state-running" v-show="node.state === 'running'" />
    </div>
  </div>
</template>

<script>
import mixinNodeStyle from '../mixins/nodeStyle'
import mixinNodeEvent from '../mixins/nodeEvents'
import mixinActiveElement from '../mixins/activeElement'
import mixinLogEvent from '../mixins/logEvent'
import mixinNodeTplEvent from '../mixins/node-tpl-event'

export default {
  name: 'Node',
  props: {
    node: {
      default: () => ({}),
      type: Object
    }
  },
  inject: {
    mode: {
      from: 'mode',
      default: null
    }
  },
  mixins: [mixinNodeStyle, mixinNodeEvent, mixinActiveElement, mixinLogEvent, mixinNodeTplEvent],
  methods: {

  }
}
</script>

<style scoped lang="scss">
.canvas-node {
  .tpl-icon{
    cursor: pointer;
  }
  .line-box{
    position: relative;
    .icon-mask{
      position: absolute;
      width: 16px;
      height: 32px;
      top: 0px;
      left: 0px;
      background: transparent;
    }
  }
}
</style>
