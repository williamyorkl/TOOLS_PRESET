<template>
  <div
    class="canvas-choice canvas-group"
    :id="node.id"
    :style="{...nodeContainerStyle, width, height}"
    :class="nodeContainerClass"
    :ref="node.id"
    @click="handleClick($event, node)"
    @mouseup="handleMouseUp($event, $refs[node.id], node)"
    @contextmenu="handleContextmenu($event, node)"
    @dblclick="handleDblclick($event, node)"
  >
    <groupHead :node="node" @setting="setting" :nodeIcon="nodeIcon" @handleTplDesc="handleTplDesc" />
    <div class="group-list">
      <div class="choice-item">
        <tryHead type="try" />
        <div class="group-item" :style="{height: groupItemHeight}">
          <jsplumbCanvas v-on="$listeners" :canvasId="node.id" :canvasData="retryDto.relationDto" />
        </div>
      </div>
      <div class="choice-item" v-if="retryDto.catchOutputParamList && retryDto.catchOutputParamList.length > 0">
        <tryHead type="catch" />
        <div class="group-item" :style="{height: groupItemHeight}">
          <jsplumbCanvas v-on="$listeners" :canvasId="node.id" :canvasData="retryDto.catchRelationDto" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import mixinNodeStyle from '../mixins/nodeStyle'
import mixinNodeEvent from '../mixins/nodeEvents'
import mixinActiveElement from '../mixins/activeElement'
import mixinCalcMaxChildDepth from '../mixins/calc-max-child-depth'
import { activeNode } from '../utils/jsplumb-render'
import groupHead from './group-head'
import tryHead from './try-head'

export default {
  name: 'Choice',
  components: { groupHead, tryHead, jsplumbCanvas: () => import('./jsplumb-canvas') },
  props: {
    node: {
      default: () => ({}),
      type: Object
    }
  },
  data() {
    return {
      choiceOptionDialogVisible: false,
      choiceItemData: null, // 编辑中的item数据
      preCondition: {}
    }
  },
  mixins: [mixinNodeStyle, mixinNodeEvent, mixinActiveElement, mixinCalcMaxChildDepth],
  inject: ['formDisabled', 'nodeMap'],
  computed: {
    retryDto() {
      return this.node.nodeParamsLogicDto.retryDto
    },
    width() {
      let width = 500 * Math.log2(this.maxChildDepth + 1)
      width = Math.min(width, 1000)
      return width + 'px'
    },
    height() {
      let height = 320 * Math.log2(this.maxChildDepth + 1)
      height = Math.min(height, 800)
      return height + 'px'
    },
    groupItemHeight() {
      let height = 350 * Math.log2(this.maxChildDepth + 1) - 150
      height = Math.min(height, 800 - 150)
      return height + 'px'
    }
  },
  methods: {
    // handleConditionAdd(list) {
    //   const lastChild = list[(list.length - 1) || 0]
    //   if (lastChild && lastChild.conditionType === ChoiceEnum.ELSE) {
    //     this.$message.error('IF块后不允许添加更多条件')
    //     return
    //   }
    //   list.push(new ElseIf(2))
    // },
    setting() {
      this.activeElement = activeNode(this.node)
      this.$emit('setting', { type: 'try', data: this.node })
    },
    handleTplDesc(node) {
      this.$emit('handleTplDesc', node)
    }
    // choiceItemSetting(choiceItemData, _index) {
    //   this.choiceItemData = choiceItemData // 用于传入弹窗在保存时对其的preCondition赋值，作为最终数据来保存
    //   // 深拷贝preCondition，作为要编辑的源数据，在保存时将修改后的数据赋值给this.choiceItemData.preCondition
    //   this.preCondition = deepClone(this.choiceItemData.preCondition)
    //   this.choiceOptionDialogVisible = true
    // }
  }
}
</script>

<style scoped lang="scss">
.canvas-choice{
  flex-direction: column;
  padding: 10px 20px 20px 20px;
  // min-height: 300px;
  .choice-item{
    border: 1px dashed #ccc;
    overflow: auto;
    .group-item{
      // height: 200px;
    }
  }
  .group-list{
    overflow: auto;
    flex-grow: 1;
    padding-right: 15px;
    box-sizing: border-box;
  }
}
</style>
