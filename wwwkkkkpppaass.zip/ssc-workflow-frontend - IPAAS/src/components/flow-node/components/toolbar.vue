<template>
  <div class="toolbar">
    <el-link class="name" type="primary" :underline="false">{{ name }}</el-link>
    <!-- <el-divider direction="vertical"></el-divider>
    <el-button type="text" icon="el-icon-delete" size="large"></el-button>
    <el-divider direction="vertical"></el-divider>
    <el-button type="text" icon="el-icon-download" size="large" @click="downloadData"></el-button>
    <el-divider direction="vertical"></el-divider>
    <el-button type="text" icon="el-icon-plus" size="large"></el-button>
    <el-divider direction="vertical"></el-divider>
    <el-button type="text" icon="el-icon-minus" size="large"></el-button> -->
    <el-divider direction="vertical" />
    <el-button type="primary" size="mini" @click="commit" v-if="mode !== 'arrangeTplTour'">提交</el-button>

    <div class="right">
      <!-- <el-button type="info" plain round icon="el-icon-document" size="mini" @click="info">流程信息</el-button> -->
      <el-button type="info" plain round icon="el-icon-document" size="mini" @click="help">帮助</el-button>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    name: {
      type: String,
      default: '编排接口'
    },
    mode: {
      type: String,
      default: null
    }
  },
  methods: {
    commit() {
      this.$emit('commit')
    },
    info() {
      this.$emit('info')
    },
    help() {
      this.$emit('help')
    },
    downloadData() {
      this.$emit('downloadData')
    }
  }
}
</script>

<style scoped lang="scss">
.toolbar {
  padding-left: 10px;
  line-height: $toolbarHeight;
  .name{
    font-size: 16px;
  }
  .right {
    float: right;
    margin-right: 5px;
    height: $toolbarHeight;
    line-height: $toolbarHeight;
  }
}
</style>
