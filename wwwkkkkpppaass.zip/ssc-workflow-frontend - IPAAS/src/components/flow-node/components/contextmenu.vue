<template>
  <ul id="menu" v-if="visible" :style="{top: top + 'px', left: left + 'px'}">
    <li class="menu" @click="deleteElement">删除</li>
    <li class="menu" v-if="allowMove" @click.stop="moveElement">移动</li>
  </ul>
</template>

<script>
import { NodeTypeEnum } from '../../../config/enum'
export default {
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    top: {
      default: 0,
      type: Number
    },
    left: {
      default: 0,
      type: Number
    },
    // eslint-disable-next-line vue/require-default-prop
    activeElement: { type: Object }
  },
  watch: {
    visible: {
      handler(nV) {
        if (nV) {
          document.addEventListener('click', this.closeContextMenu)
        } else {
          document.removeEventListener('click', this.closeContextMenu)
        }
      },
      immediate: true
    }

  },
  computed: {
    nodeType() {
      return this.activeElement.type
    },
    // 开始节点 | 结束节点 | 嵌套节点禁止移动
    allowMove() {
      const isNode = this.nodeType === 'node'
      if (isNode && ![
        NodeTypeEnum.START,
        NodeTypeEnum.END
        // NodeTypeEnum.SYNC,
        // NodeTypeEnum.FOREACH,
        // NodeTypeEnum.CHOICE,
        // NodeTypeEnum.TRY,
        // NodeTypeEnum.ASYNC
      ].includes(this.activeElement.node.type)) {
        return true
      }
      return false
    }
  },
  methods: {
    deleteElement() {
      this.closeContextMenu('update:visible', false)
      this.$emit('deleteElement')
    },
    closeContextMenu() {
      this.$emit('update:visible', false)
    },
    moveElement() {
      this.closeContextMenu('update:visible', false)
      this.$emit('moveElement')
    }
  }
}
</script>

<style scoped lang="scss">
/*css代码*/
#menu{

  margin: 0;
  background: rgb(255,255,255,.7);
  z-index: 999;
  position: fixed;
  list-style-type: none;
  padding: 5px 0;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 400;
  color: #333;
  box-shadow: 2px 2px 3px 0 rgba(0, 0, 0, 0.3);
  li {
    margin: 0;
    padding: 0 20px;
    line-height: 25px;
    cursor: pointer;
    &:hover {
      background: #eee;
    }
  }
}
</style>
