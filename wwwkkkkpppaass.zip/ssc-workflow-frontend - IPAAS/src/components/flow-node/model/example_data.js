
export default {
  convertMsgFlag: 0,
  apiCacheTime: 0,
  groupId: 1,
  remark: '',
  outputParamMd5: 'ddbbf14cdbd2812e33a245fa06703487',
  type: 0,
  apiInParam: '[{"isRequired":false,"dataType":2,"paramCheck":{"flowFieldFunCheck":{"parameters":[]},"apiCheckFlag":0,"flowFieldApiCheck":{"definitionReqList":[]},"funCheckFlag":0},"paramName":"id","childrenList":[],"dataPosition":4,"rowKey":"1653967162003"},{"isRequired":false,"dataType":6,"paramCheck":{"flowFieldFunCheck":{"parameters":[]},"apiCheckFlag":0,"flowFieldApiCheck":{"definitionReqList":[]},"funCheckFlag":0},"paramName":"name","childrenList":[],"dataPosition":4,"rowKey":"1653967169457"}]',
  apiOutParam: '[{"dataType":2,"paramCheck":{"flowFieldFunCheck":{"parameters":[]},"apiCheckFlag":0,"flowFieldApiCheck":{"definitionReqList":[]},"funCheckFlag":0},"paramName":"id","childrenList":[],"rowKey":"1653967198021"},{"dataType":6,"paramCheck":{"flowFieldFunCheck":{"parameters":[]},"apiCheckFlag":0,"flowFieldApiCheck":{"definitionReqList":[]},"funCheckFlag":0},"paramName":"name","childrenList":[],"rowKey":"1653967204380"}]',
  apiInParamList: [
    {
      isRequired: false,
      dataType: 2,
      paramCheck: {
        apiCheckFlag: 0,
        flowFieldApiCheck: {
          definitionReqList: []
        },
        flowFieldFunCheck: {
          parameters: []
        },
        funCheckFlag: 0
      },
      paramName: 'id',
      childrenList: [],
      dataPosition: 4,
      rowKey: '1653967162003'
    },
    {
      isRequired: false,
      dataType: 6,
      paramCheck: {
        apiCheckFlag: 0,
        flowFieldApiCheck: {
          definitionReqList: []
        },
        flowFieldFunCheck: {
          parameters: []
        },
        funCheckFlag: 0
      },
      paramName: 'name',
      childrenList: [],
      dataPosition: 4,
      rowKey: '1653967169457'
    }
  ],
  apiOutParamList: [
    {
      isRequired: false,
      dataType: 2,
      paramCheck: {
        apiCheckFlag: 0,
        flowFieldApiCheck: {
          definitionReqList: []
        },
        flowFieldFunCheck: {
          parameters: []
        },
        funCheckFlag: 0
      },
      paramName: 'id',
      childrenList: [],
      rowKey: '1653967198021'
    },
    {
      isRequired: false,
      dataType: 6,
      paramCheck: {
        apiCheckFlag: 0,
        flowFieldApiCheck: {
          definitionReqList: []
        },
        flowFieldFunCheck: {
          parameters: []
        },
        funCheckFlag: 0
      },
      paramName: 'name',
      childrenList: [],
      rowKey: '1653967204380'
    }
  ],
  crossFlag: 0,
  requestUrl: '/checkChoice',
  id: 350,
  businessApiName: '测试Choice节点',
  requestTimeout: 5000,
  httpFlag: 2,
  requestType: 2,
  apiAuthType: 2,
  baseUrl: '',
  webServiceFlag: 1,
  tenantId: '1',
  developer: '',
  inputParamMd5: 'ddbbf14cdbd2812e33a245fa06703487',
  status: 0,
  lineList: [
    {
      from: 'startNode',
      to: 'nodeB'
    },
    {
      from: 'nodeB',
      to: 'endNode'
    }
  ],
  nodeList: [
    {
      ico: 'el-icon-caret-right',
      name: '编排开始',
      id: 'startNode',
      nodeId: null,
      nodeKey: 'startNode',
      left: '26px',
      top: '161px',
      state: 'success',
      type: 1,
      retryPolicy: '',
      nodeParamsLogicDto: {
        type: 1
      }
    },
    {
      ico: 'icon-APIguanli',
      name: 'Choice选择节点',
      id: 'nodeB',
      nodeId: null,
      nodeKey: 'nodeB',
      left: '331px',
      top: '161px',
      state: 'success',
      type: 16,
      retryPolicy: '',
      nodeParamsLogicDto: {
        type: 16,
        choiceDto: {
          conditionList: [
            {
              relationDto: {
                nodeList: [
                  {
                    ico: 'el-icon-caret-right',
                    name: '编排开始',
                    id: 'startNode1',
                    nodeId: null,
                    nodeKey: 'startNode1',
                    left: '26px',
                    top: '161px',
                    state: 'success',
                    type: 1,
                    retryPolicy: '',
                    nodeParamsLogicDto: {
                      type: 1
                    }
                  },
                  {
                    ico: 'el-icon-caret-right',
                    name: '数据库',
                    id: 'dbNode',
                    nodeId: null,
                    nodeKey: 'dbNode',
                    left: '126px',
                    top: '161px',
                    state: 'success',
                    type: 3,
                    retryPolicy: '',
                    nodeParamsLogicDto: {
                      type: 3,
                      nodeParamsDbDto: {
                        dbId: 1,
                        tableName: null,
                        sqlList: [
                          {
                            isInputSql: 0,
                            sqlMethod: 'select',
                            timeOut: 5,
                            textSql: null,
                            collectionName: null,
                            collectionNodeKey: null,
                            mainKeyName: null,
                            mainKeyNameNodeKey: null,
                            selectFieldList: [
                              {
                                fieldName: 'id',
                                dataType: 2
                              },
                              {
                                fieldName: 'name',
                                dataType: 6
                              },
                              {
                                fieldName: 'age',
                                dataType: 1
                              },
                              {
                                fieldName: 'add',
                                dataType: 6
                              }
                            ],
                            pageFieldList: [],
                            sortFieldList: [],
                            updateFieldList: [],
                            whereFieldList: [],
                            referenceFieldList: [],
                            tableName: 'test_sql'
                          }
                        ]
                      }
                    }
                  },
                  {
                    ico: 'el-icon-caret-right',
                    name: '编排结束',
                    id: 'endNode1',
                    nodeId: null,
                    nodeKey: 'endNode1',
                    left: '226px',
                    top: '161px',
                    state: 'success',
                    type: 15,
                    retryPolicy: '',
                    nodeParamsLogicDto: {
                      type: 15,
                      nodeParamsRpcDto: {
                        mappingList: [
                          {
                            dataType: 2,
                            functionList: [],
                            referenceType: 1,
                            scriptData: null,
                            sorted: 0,
                            sourceNodeKey: 'dbNode',
                            sourceNodeName: '数据库节点',
                            sourceNodePath: 'sql1[].id',
                            targetNodePath: 'id',
                            bizDictMapId: null,
                            isRequired: false,
                            id: null,
                            nodeId: null,
                            _XID: 'row_2'
                          },
                          {
                            dataType: 6,
                            functionList: [],
                            referenceType: 1,
                            scriptData: null,
                            sorted: 0,
                            sourceNodeKey: 'dbNode',
                            sourceNodeName: '数据库节点',
                            sourceNodePath: 'sql1[].name',
                            targetNodePath: 'name',
                            bizDictMapId: null,
                            isRequired: false,
                            id: null,
                            nodeId: null,
                            _XID: 'row_3'
                          }
                        ]
                      }
                    }
                  }
                ],
                lineList: [
                  {
                    from: 'startNode1',
                    to: 'dbNode'
                  },
                  {
                    from: 'dbNode',
                    to: 'endNode1'
                  }
                ]
              },
              conditionType: 1,
              preCondition: {
                condLogicExp: 'c1',
                condLogicRpn: null,
                conditionList: [
                  {
                    c1: {
                      attrName: 'c1',
                      type: 1,
                      dataType: 2,
                      nodeKey: 'startNode',
                      value: 'id'
                    },
                    c2: {
                      attrName: 'c2',
                      type: 0,
                      dataType: 2,
                      nodeKey: null,
                      value: '1'
                    },
                    compareSymbol: 1
                  }
                ]
              }
            }
          ],
          outputParamList: [
            {
              paramName: 'id',
              dataType: 2,
              generic: null,
              value: null,
              desc: null,
              rowKey: '16539786445470.8104',
              childrenList: []
            },
            {
              paramName: 'name',
              dataType: 6,
              generic: null,
              value: null,
              desc: null,
              rowKey: '16539786511360.4107',
              childrenList: []
            }
          ]
        }
      }
    },
    {
      ico: 'icon-jieshu',
      name: '编排结束',
      id: 'endNode',
      nodeId: null,
      nodeKey: 'endNode',
      left: '618.2px',
      top: '161px',
      state: 'success',
      type: 15,
      retryPolicy: '',
      nodeParamsLogicDto: {
        type: 15,
        nodeParamsRpcDto: {
          mappingList: [
            {
              dataType: 2,
              functionList: [],
              referenceType: 1,
              scriptData: null,
              sorted: 0,
              sourceNodeKey: 'nodeB',
              sourceNodeName: 'choice节点',
              sourceNodePath: 'choiceInfo.id',
              targetNodePath: 'id',
              bizDictMapId: null,
              isRequired: false,
              id: null,
              nodeId: null,
              _XID: 'row_2'
            },
            {
              dataType: 6,
              functionList: [],
              referenceType: 1,
              scriptData: null,
              sorted: 0,
              sourceNodeKey: 'nodeB',
              sourceNodeName: 'choice节点',
              sourceNodePath: 'choiceInfo.name',
              targetNodePath: 'name',
              bizDictMapId: null,
              isRequired: false,
              id: null,
              nodeId: null,
              _XID: 'row_3'
            }
          ]
        }
      }
    }
  ]
}
