import { PreCondition, RelationDto } from './index'
import { getUUID } from '@/utils'

// 开始节点参数
export class NodeParamsStartDto {
}

// RPC节点参数
export class NodeParamsRpcDto {
  constructor() {
    this.apiId = null
    this.apiName = null
    this.apiDesc = null // 方法描述，编辑回显字段
    this.apiRequestContentType = null // 接口请求内容类型(编辑回显字段,新增不传值)
    this.apiRequestMethod = null // 接口请求方式(编辑回显字段,新增不传值)
    this.apiRequestProtocol = null // 接口请求协议(编辑回显字段,新增不传值
    this.apiRequestTimeout = null // 微服务接口请求超时时间(ms)
    this.apiRequestUrl = null // 接口请求URL(编辑回显字段,新增不传值)
    this.apiType = null // api类型 1前端api 2后端api
    this.fallBack = 'stop' // 异常返回OR继续:stop、continue
    this.filterForwardHeaderParams = null // 过滤掉转发的请求头参数,多个参数以逗号分割
    this.forwardCookie = null // 是否转发cookie
    this.forwardHeader = null // 是否转发请求头
    this.forwardHeaderParams = null // 指定转发的请求头参数,多个参数以逗号分割
    this.gateAppId = null // gateAppId
    this.group = null // 分组(编辑回显字段,新增不传值)

    this.inputParamType = null // 接口入参类型(编辑回显字段,新增不传值)  false
    this.interfaceType = null // 接口类型 0-dubbo,1-http 2-springcloud 3-native 4-soap 5-local  false
    this.mappingList = [] // 字段映射关系  false
    this.methodName = null // 方法名(编辑回显字段,新增不传值)  false
    this.modelId = null // 模型id  false
    this.namespace = null // 命名空间  false
    this.retryNum = null // 重试次数  false
    this.serviceDesc = null // 服务描述(编辑回显字段,新增不传值)  false
    this.serviceInstance = null // 服务实例(编辑回显字段,新增不传值)  false
    this.serviceName = null // 服务名称(编辑回显字段,新增不传值)  false
    this.staticMethodFlag = null // 是否静态(编辑回显字段,新增不传值)  false
    this.tenantId = null // 租户  false
    this.usedCondLogicExp = null // 是否使用条件表达式  false
    this.version = null // 版本(编辑回显字段,新增不传值)  false

    this.inputParamList = [] // 输入参数
    this.outputParamList = [] // 出参(编辑回显字段,新增不传值)  false
  }
}

// Db节点参数
export class NodeParamsDbDto {
  constructor() {
    this.dbId = null
    this.tableName = null // 数据库名称
    this.dataBaseType = null // 数据库类型
    this.sqlList = [new SqlParams()] // 放多个sql配置
  }
}

// 开始节点参数
export class NodeParamsMqDto {
  constructor() {
    this.keyPrefix = null
    this.mappingList = []
    this.targetMessage = null // 用于存储用户输入的json对象
    this.mqServerId = null
    this.mqType = null
    this.topic = null
    this.tags = null
  }
}

// 开始节点参数
export class NodeParamsForwardDto {
  constructor() {
    this.completeUrl = null // 用户接口路径
    this.routeId = null // 服务id
    this.srvName = null // 后端服务名
    this.reqPathPrefix = null // 后端API路径
    this.timeOut = null // 超时时间
    this.registryName = null // 注册中心名称
  }
}

// 开始节点参数
export class ErrorDto {
  constructor() {
    this.errorId = null
    this.errorInfo = {
      errorId: null,
      infoList: [],
      structHeadId: null,
      structName: null
    }
    this.preCondition = new PreCondition() // if块的前置条件
  }
}

// 开始节点参数
export class ResponseDto {
  constructor() {
    this.mappingList = []
    this.targetMessage = null
    this.preCondition = new PreCondition() // if块的前置条件
  }
}

// 开始节点参数
export class Variable {
  constructor() {
    this.dataType = null
    this.express = null
    this.parameters = []
    this.referenceType = null
    this.scope = null
    this.sourceNodeKey = null
    this.sourceNodeName = null
    this.sourceNodePath = null
    this.variableName = null
  }
}

// 函数参数
export class Parameter {
  constructor({ paramName, dataType, referenceType }) {
    this.paramName = paramName
    this.dataType = dataType
    this.referenceType = referenceType
    this.sourceNodeKey = null
    this.sourceNodePath = null
    this.sourceNodeName = null
  }
}

// 开始节点参数
export class Filter {
  constructor() {
    this.nodeKey = null // 节点key
    this.nodeName = null // 节点名字
    this.outputParamList = [] // 输出参数
    this.filterCondition = { // 过滤条件
      condLogicExp: null,
      conditionList: []
    }
    this.value = null
  }
}

// 开始节点参数
export class Mapper {
  constructor() {
    this.outputParamList = []
    this.targetMessage = null
    this.inputList = []
    this.mappingList = []
  }
}

// 开始节点参数
export class Group {
  constructor() {
    this.nodeName = null
    this.outputParamList = []
    this.groupKey = null
    this.nodeKey = null
    this.value = null
  }
}

// 开始节点参数
export class Groovy {
  constructor() {
    this.outputParamList = [] // 输出参数列表
    this.inputParamList = [] // 输出参数列表
    this.groovyScript = null // 脚本
  }
}

// 开始节点参数
export class Combine {
  constructor() {
    this.fieldName = null
    this.listFlag = 0
    this.mappingList = []
    this.nodeKeyList = [{
      dataType: null,
      nodeKey: null,
      value: null
    }, {
      dataType: null,
      nodeKey: null,
      value: null
    }]
  }
}

// 开始节点参数
export class NodeParamsEndDto {
  constructor() {
    this.mappingList = []
    this.interfaceType = 0 // 参数类型
  }
}

// DB数据库节点多sql配置
export class SqlParams {
  constructor() {
    this.isInputSql = 0
    this.sqlMethod = null
    this.timeOut = 5
    this.textSql = null
    this.description = null

    this.collectionName = null // 集合对象
    this.collectionNodeKey = null // 节点key
    this.mainKeyName = null // 主键
    this.mainKeyNameNodeKey = null // 主键节点key

    this.queryCount = false // 是否查询记录总数
    this.returnPkFlag = 0 // 是否返回主键ID

    this.selectFieldList = [] // select 参数列表
    this.relationSelectList = []
    this.relationSelectOnList = []
    this.pageFieldList = []
    this.sortFieldList = []
    this.updateFieldList = []
    this.whereFieldList = []
    this.referenceFieldList = []
  }
}

// groovy入参
export class GroovyInputParam {
  constructor() {
    this.className = null
    this.nodeKey = null
    this.nodeName = null
    this.desc = null
  }
}

// groovy出参
export class GroovyOutputParam {
  constructor() {
    this.paramName = null
    this.dataType = null
    this.generic = null
    this.value = null
    this.desc = null
    this.rowKey = Date.now() + Math.random().toFixed(4)
    this.childrenList = []
  }
}

// break
export class BreakDto {
  constructor() {
    this.preCondition = new PreCondition()
  }
}

// continue
export class ContinueDto {
  constructor() {
    this.preCondition = new PreCondition()
  }
}

// sort
export class SortDto {
  constructor() {
    this.collectionName = null
    this.nodeKey = null
    this.dataType = null // 数据类型
    this.generic = null // 元素泛型
    this.fieldList = [] // 排序字段
  }
}

// sort节点的fieldList数据
export class SortFieldItem {
  constructor({ fieldName, dataType }) {
    this.fieldName = fieldName // 字段名
    this.dataType = dataType // 数据类型
    this.sortType = 1 // 排序方式
    this.index = null //
  }
}

// Synchronize 节点
export class SynchronizeDto {
  constructor() {
    this.fieldMappingList = [] // 变量：和variableDto.variables相同结构
    this.lockFailedMappingList = [] // 字段映射
    this.maxHold = null // 最大锁持有时长
    this.maxWait = null // 最大锁等待时间
    this.outputParamList = [] // 节点出参
    this.relationDto = new RelationDto()
  }
}

// Async 节点
export class AsyncDto {
  constructor() {
    this.relationDto = new RelationDto()
  }
}

// Cache 节点
export class CacheDto {
  constructor() {
    this.operateList = [] // 操作列表
    this.sourceId = null // 缓存数据源
    this.sourceName = null
  }
}

export class RetryDto {
  constructor() {
    this.outputParamList = []
    this.relationDto = new RelationDto()
    this.retryContext = {
      // conditionDto: new PreCondition(),
      conditionDto: null,
      expression: null,
      onlyBreak: false,
      retryWhenException: true
    }

    this.catchRelationDto = new RelationDto()
    this.catchOutputParamList = []
  }
}

// 缓存：操作
export class Operate {
  constructor() {
    this.operateType = null // 操作类型
    this.mappings = [] // 泛型和Variable一致
  }
}

// db类型节点的一些属性类
// DB:分页字段
export class PageField {
  constructor() {
    this.dataType = 1
    this.fieldName = null
    this.logicalOperator = ''
    this.nodeKey = ''
    this.nodeKey1 = ''
    this.operator = null
    this.type = null
    this.type1 = null
    this.value = ''
    this.value1 = ''
  }
}

// DB: 查询字段
export class SelectField {
  constructor({ fieldName, dataType }) {
    this.dataType = dataType
    this.fieldName = fieldName
    this.alisName = null
  }
}

// DB: 多表连查字段
export class SelectRelationField {
  constructor() {
    this.joinFieldName = null
    this.joinType = null
    this.relationTable = null
    this.relationTableFieldName = null
    this.relationConditionList = []
    this.rowKey = getUUID()
  }
}

// DB: 多表连查Child字段
export class SelectRelationChildField {
  constructor() {
    this.joinFieldName = null
    // this.joinType = null
    // this.relationTable = null
    this.relationTableFieldName = null
    this.rowKey = getUUID()
  }
}

// DB: 多表连查字段on条件
export class RelationOnField {
  constructor() {
    this.joinFieldName = null
    this.joinType = null
    this.relationTable = null
    this.relationTableFieldName = null
    this.dataType = null
    this.fieldName = ''
    this.logicalOperator = ''
    this.isGroup = 1
    this.nodeKey = ''
    this.nodeKey1 = ''
    this.operator = null
    this.type = null
    this.type1 = null
    this.value = ''
    this.value1 = ''
    this.rowKey = getUUID()
    this.groups = []
  }
}

// DB:排序字段
export class SortField {
  constructor() {
    this.direction = null
    this.field = null
  }
}

// DB:update字段
export class UpdateField {
  constructor() {
    this.dataType = null
    this.fieldName = ''
    this.logicalOperator = ''
    this.nodeKey = ''
    this.nodeKey1 = ''
    this.operator = null
    this.type = null
    this.value = ''
    this.isCheckKey = null
    this.isInsertKey = 1
    this.isUpdateKey = 1
  }
}

// DB:where字段
export class WhereField {
  constructor() {
    this.dataType = null
    this.fieldName = ''
    this.logicalOperator = ''
    this.isGroup = 1
    this.nodeKey = ''
    this.nodeKey1 = ''
    this.operator = null
    this.type = null
    this.type1 = null
    this.value = ''
    this.value1 = ''
    this.rowKey = getUUID()
    this.groups = []
  }
}

// DB:referenceField
export class ReferenceField {
  constructor() {
    this.dataType = null
    this.fieldName = ''
    this.nodeKey = ''
    this.type = null
    this.value = ''
  }
}
