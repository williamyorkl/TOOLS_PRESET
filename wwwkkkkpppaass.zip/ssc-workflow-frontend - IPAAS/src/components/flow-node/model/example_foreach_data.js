export default {
  lineList: [
    {
      from: 'startNode',
      to: 'nodeB'
    },
    {
      from: 'nodeB',
      to: 'endNode'
    }
  ],
  nodeList: [
    {
      ico: 'el-icon-caret-right',
      name: '编排开始',
      id: 'startNode',
      nodeId: null,
      nodeKey: 'startNode',
      left: '26px',
      top: '161px',
      state: 'success',
      type: 1,
      retryPolicy: '',
      nodeParamsLogicDto: {
        type: 1,
        nodeParamsStartDto: {}
      }
    },
    {
      ico: 'icon-APIguanli',
      name: 'Foreach循环节点',
      id: 'nodeB',
      nodeId: null,
      nodeKey: 'nodeB',
      left: '331px',
      top: '161px',
      state: 'success',
      type: 17,
      retryPolicy: '',
      nodeParamsLogicDto: {
        type: 17,
        forEachDto: {
          nodeKey: 'startNode',
          value: 'list',
          variable: 'obj',
          generic: 7,
          outputParamList: [
            {
              paramName: 'name',
              dataType: 6,
              generic: null,
              value: null,
              desc: null,
              rowKey: '16540883087750.8423',
              childrenList: []
            }
          ],
          relationDto: {
            nodeList: [
              {
                ico: 'el-icon-caret-right',
                name: '编排开始',
                id: 'startNode1',
                nodeId: null,
                nodeKey: 'startNode1',
                left: '26px',
                top: '161px',
                state: 'success',
                type: 1,
                retryPolicy: '',
                nodeParamsLogicDto: {
                  type: 1
                }
              },
              {
                ico: 'el-icon-caret-right',
                name: '数据库',
                id: 'dbNode',
                nodeId: null,
                nodeKey: 'dbNode',
                left: '126px',
                top: '161px',
                state: 'success',
                type: 3,
                retryPolicy: '',
                nodeParamsLogicDto: {
                  type: 3,
                  nodeParamsDbDto: {
                    dbId: 1,
                    tableName: null,
                    sqlList: [
                      {
                        isInputSql: 1,
                        sqlMethod: 'select',
                        timeOut: 5,
                        textSql: 'select id,name from `test_sql` where id = $id',
                        collectionName: null,
                        collectionNodeKey: null,
                        mainKeyName: null,
                        mainKeyNameNodeKey: null,
                        queryCount: false,
                        selectFieldList: [
                          {
                            dataType: 2,
                            fieldName: 'id'
                          },
                          {
                            dataType: 6,
                            fieldName: 'name'
                          }
                        ],
                        pageFieldList: [],
                        sortFieldList: [],
                        updateFieldList: [],
                        whereFieldList: [],
                        referenceFieldList: [
                          {
                            dataType: 2,
                            fieldName: 'id',
                            nodeKey: 'startNode1',
                            type: 1,
                            value: 'obj.id'
                          }
                        ],
                        tableName: 'test_sql'
                      }
                    ]
                  }
                }
              },
              {
                ico: 'el-icon-caret-right',
                name: '编排结束',
                id: 'endNode1',
                nodeId: null,
                nodeKey: 'endNode1',
                left: '226px',
                top: '161px',
                state: 'success',
                type: 15,
                retryPolicy: '',
                nodeParamsLogicDto: {
                  type: 15,
                  nodeParamsRpcDto: {
                    mappingList: [
                      {
                        dataType: 6,
                        functionList: [],
                        referenceType: 1,
                        scriptData: null,
                        sorted: 0,
                        sourceNodeKey: 'dbNode',
                        sourceNodeName: '数据库节点',
                        sourceNodePath: 'sql1[].name',
                        targetNodePath: 'name',
                        bizDictMapId: null,
                        isRequired: false,
                        id: null,
                        nodeId: null,
                        _XID: 'row_3'
                      }
                    ]
                  }
                }
              }
            ],
            lineList: [
              {
                from: 'startNode1',
                to: 'dbNode'
              },
              {
                from: 'dbNode',
                to: 'endNode1'
              }
            ]
          }
        }
      }
    },
    {
      ico: 'icon-jieshu',
      name: '编排结束',
      id: 'endNode',
      nodeId: null,
      nodeKey: 'endNode',
      left: '618.2px',
      top: '161px',
      state: 'success',
      type: 15,
      retryPolicy: '',
      nodeParamsLogicDto: {
        type: 15,
        nodeParamsEndDto: {
          mappingList: [
            {
              dataType: 8,
              functionList: [],
              referenceType: 1,
              scriptData: null,
              sorted: 0,
              sourceNodeKey: 'nodeB',
              sourceNodeName: 'foreach节点',
              sourceNodePath: 'foreachInfo',
              targetNodePath: 'list',
              bizDictMapId: null,
              isRequired: false,
              id: null,
              nodeId: null,
              _XID: 'row_2'
            }
          ]
        }
      }
    }
  ]
}
