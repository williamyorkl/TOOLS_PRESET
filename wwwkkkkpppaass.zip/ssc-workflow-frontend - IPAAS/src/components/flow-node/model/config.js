export const autoMappingTitle = '1. 自动映射支持选定属性的映射关系\n 2. 基本属性映射规则：检查字段名和字段类型是否相同\n 3. array和object映射规则: 单个不检查名称，多个检查名称+类型\n 4. array和object映射时递归检查子字段，回归基本类型映射逻辑'
