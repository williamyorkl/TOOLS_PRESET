import { NodeTypeEnum } from '@/config/enum'
export const normalNode = ['start', 'end', 'process', 'db', 'mq', 'handle']

export const menuList = [
  // {
  //   id: 0,
  //   type: 'group',
  //   name: '基础节点',
  //   ico: 'start',
  //   open: false,
  //   children: [
  //     {
  //       id: 'startNode',
  //       type: NodeTypeEnum.START,
  //       name: '编排开始',
  //       ico: 'start',
  //       // 自定义覆盖样式
  //       style: {}
  //     },
  //     {
  //       id: 'endNode',
  //       type: NodeTypeEnum.END,
  //       name: '编排结束',
  //       ico: 'end',
  //       // 自定义覆盖样式
  //       style: {}
  //     }
  //   ]
  // },
  {
    id: 1,
    type: 'group',
    name: '技术连接器',
    ico: 'start',
    open: true,
    children: [
      {
        id: null,
        type: NodeTypeEnum.PROCESS,
        name: 'RPC节点',
        ico: 'rpc',
        // 自定义覆盖样式
        style: {}
      },
      {
        id: null,
        type: NodeTypeEnum.DB,
        name: '数据库节点',
        ico: 'db',
        // 自定义覆盖样式
        style: {}
      },
      {
        id: null,
        type: NodeTypeEnum.MQ,
        name: 'MQ节点',
        ico: 'mq',
        // 自定义覆盖样式
        style: {}
      }
    ]
  },
  {
    id: 2,
    type: 'group',
    name: '逻辑处理器',
    ico: 'start',
    open: true,
    children: [
      {
        id: null,
        type: NodeTypeEnum.CHOICE,
        name: 'choice节点',
        ico: 'choice',
        // 自定义覆盖样式
        style: {}
      },
      {
        id: null,
        type: NodeTypeEnum.FOREACH,
        name: 'forEach节点',
        ico: 'foreach',
        // 自定义覆盖样式
        style: {}
      },
      {
        id: null,
        type: NodeTypeEnum.ERROR,
        name: '抛出异常',
        ico: 'error1',
        // 自定义覆盖样式
        style: {}
      },
      {
        id: null,
        type: NodeTypeEnum.RESPONSE,
        name: '条件返回',
        ico: 'response',
        // 自定义覆盖样式
        style: {}
      },
      {
        id: null,
        type: NodeTypeEnum.VARIABLE,
        name: '变量赋值',
        ico: 'var',
        // 自定义覆盖样式
        style: {}
      },
      {
        id: null,
        type: NodeTypeEnum.FILTER,
        name: '过滤节点',
        ico: 'filter',
        // 自定义覆盖样式
        style: {}
      },
      {
        id: null,
        type: NodeTypeEnum.MAPPER,
        name: '数据映射',
        ico: 'mapper',
        // 自定义覆盖样式
        style: {}
      },
      {
        id: null,
        type: NodeTypeEnum.GROUP,
        name: '分组节点',
        ico: 'group',
        // 自定义覆盖样式
        style: {}
      },
      {
        id: null,
        type: NodeTypeEnum.COMBINE,
        name: '合并节点',
        ico: 'combine',
        // 自定义覆盖样式
        style: {}
      },
      {
        id: null,
        type: NodeTypeEnum.BREAK,
        name: 'break节点',
        ico: 'break',
        // 自定义覆盖样式
        style: {}
      },
      {
        id: null,
        type: NodeTypeEnum.CONTINUE,
        name: 'continue节点',
        ico: 'continue',
        // 自定义覆盖样式
        style: {}
      },
      {
        id: null,
        type: NodeTypeEnum.SORT,
        name: '排序节点',
        ico: 'sort',
        // 自定义覆盖样式
        style: {}
      }
    ]
  },
  {
    id: 3,
    type: 'group',
    name: '技术组件',
    ico: 'start',
    open: true,
    children: [
      {
        id: null,
        type: NodeTypeEnum.GROOVY,
        name: '脚本节点',
        ico: 'groovy',
        // 自定义覆盖样式
        style: {}
      }, {
        id: null,
        type: NodeTypeEnum.SYNC,
        name: 'synchronized节点',
        ico: 'sync',
        // 自定义覆盖样式
        style: {}
      }, {
        id: null,
        type: NodeTypeEnum.ASYNC,
        name: 'async节点',
        ico: 'async',
        // 自定义覆盖样式
        style: {}
      }, {
        id: null,
        type: NodeTypeEnum.CACHE,
        name: '缓存节点',
        ico: 'cache',
        // 自定义覆盖样式
        style: {}
      },
      {
        id: null,
        type: NodeTypeEnum.TRY,
        name: 'try节点',
        ico: 'try',
        // 自定义覆盖样式
        style: {}
      }
    ]
  }
]
