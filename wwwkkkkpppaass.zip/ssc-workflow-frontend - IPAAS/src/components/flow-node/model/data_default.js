import { Node } from './index'
import { NodeTypeEnum } from '@/config/enum'
import { getUUID } from '@/utils'

export function geneDefaultData({ isChild = false }) {
  const startId = getUUID()
  const midId = getUUID()
  const endId = getUUID()

  const nodeList = [
    new Node({ ico: 'start', id: startId, name: isChild ? '子流开始' : '编排开始', left: '10px', top: '10px', type: NodeTypeEnum.START }),
    new Node({ ico: 'rpc', id: midId, name: 'RPC节点', left: '10px', top: '80px', type: NodeTypeEnum.PROCESS }),
    new Node({ ico: 'end', id: endId, name: isChild ? '子流结束' : '编排结束', left: '10px', top: '150px', type: NodeTypeEnum.END })
  ]
  const lineList = [
    { from: startId, to: midId },
    { from: midId, to: endId }
  ]

  return [nodeList, lineList]
}
