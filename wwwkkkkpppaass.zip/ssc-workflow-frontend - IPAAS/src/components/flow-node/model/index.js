import { NodeTypeEnum, ChoiceEnum, GROUP_NODES } from '@/config/enum'
import { getUUID } from '@/utils'
import { geneDefaultData } from './data_default'
import random from 'lodash/random'
import { NodeParamsStartDto, NodeParamsRpcDto, NodeParamsDbDto, NodeParamsMqDto, NodeParamsForwardDto, ErrorDto, ResponseDto, Filter, Mapper, Group, Groovy, Combine, NodeParamsEndDto, BreakDto, ContinueDto, SortDto, RetryDto, SynchronizeDto, AsyncDto, CacheDto } from './nodeParams_model'
// 输出参数
export class OutputParam {
  constructor({ paramName, dataType, generic, value, desc }) {
    this.paramName = paramName // 参数名
    this.dataType = dataType // 参数类型
    this.generic = generic // 数组元素泛型
    this.value = value // 值
    this.desc = desc // 描述
    this.rowKey = random(1, 50000) + Date.now() // key
    this.childrenList = []
  }
}

// 一组条件控制
export class Condition {
  constructor() {
    this.c1 = { attrName: 'c1', type: null, dataType: null, nodeKey: null, value: null }
    this.c2 = { attrName: 'c2', type: null, dataType: null, nodeKey: null, value: null }
    this.compareSymbol = null
  }
}

// 条件控制值
export class C {
  constructor(attrName = 'c1', type = null, dataType = null, value = null) {
    this.attrName = attrName // 字段名称：前端生成一个本条件列表中唯一的名称
    this.type = type // 类型（固定-0 | 引用-1）
    this.dataType = dataType // 数据类型
    this.nodeKey = null // 目标节点的key，前端的id
    this.value = value // 值：固定类型-直接填值，引用类型-选择其他节点的出参path
  }
}

// 过滤条件: 用于filter节点的过滤条件
export class FilterCondition {
  constructor() {
    this.c1 = new C(null, 0, null, 'morenzhi') // c1不需要value，为了兼容后端的非空验证，此处放一个默认值
    this.c2 = new C('c2')
    this.compareSymbol = null
  }
}

// if的前置条件
export class PreCondition {
  constructor() {
    this.condLogicExp = 'c1' // 逻辑关系, c1 && c2 ...
    this.condLogicRpn = null
    this.conditionList = [new Condition()]
  }
}

// 子编排
export class RelationDto {
  constructor() {
    [this.nodeList, this.lineList] = geneDefaultData({ isChild: true })
    // this.lineList = []
  }
}

// choice的elseif数据
export class ElseIf {
  constructor(conditionType = ChoiceEnum.ELSE_IF) {
    this.conditionType = conditionType // elseif
    this.preCondition = new PreCondition() // if块的前置条件
    this.relationDto = new RelationDto()
  }
}

// 节点储存数据
export class NodeParamsLogicDto {
  constructor({ type }) {
    this.type = type
    this.apiType = null
    this.apiId = null
    switch (type) {
      case NodeTypeEnum.CHOICE: // choice节点数据
        this.choiceDto = {
          conditionList: [new ElseIf(ChoiceEnum.IF)],
          outputParamList: []
        }
        break
      case NodeTypeEnum.FOREACH: // forEach节点数据
        this.forEachDto = {
          nodeKey: null,
          value: null,
          variable: 'entity',
          generic: null,
          outputParamList: [],
          relationDto: new RelationDto()
        }
        break
      case NodeTypeEnum.START:
        this.nodeParamsStartDto = new NodeParamsStartDto()
        break
      case NodeTypeEnum.PROCESS:
        this.nodeParamsRpcDto = new NodeParamsRpcDto()
        break
      case NodeTypeEnum.DB: // DB节点数据
        this.nodeParamsDbDto = new NodeParamsDbDto()
        break
      case NodeTypeEnum.MQ:
        this.nodeParamsMqDto = new NodeParamsMqDto()
        break
      case NodeTypeEnum.FORWARD:
        this.nodeParamsForwardDto = new NodeParamsForwardDto()
        break
      case NodeTypeEnum.ERROR:
        this.errorDto = new ErrorDto()
        break
      case NodeTypeEnum.RESPONSE:
        this.responseDto = new ResponseDto()
        break
      case NodeTypeEnum.VARIABLE:
        this.variableDto = {
          variables: [],
          outputParamList: []
        }
        break
      case NodeTypeEnum.FILTER:
        this.filter = new Filter()
        break
      case NodeTypeEnum.MAPPER:
        this.mapper = new Mapper()
        break
      case NodeTypeEnum.GROUP:
        this.group = new Group()
        break
      case NodeTypeEnum.GROOVY:
        this.groovy = new Groovy()
        break
      case NodeTypeEnum.COMBINE:
        this.combine = new Combine()
        break
      case NodeTypeEnum.END:
        this.nodeParamsEndDto = new NodeParamsEndDto()
        break
      case NodeTypeEnum.BREAK:
        this.breakDto = new BreakDto()
        break
      case NodeTypeEnum.CONTINUE:
        this.continueDto = new ContinueDto()
        break
      case NodeTypeEnum.SORT:
        this.sortDto = new SortDto()
        break
      case NodeTypeEnum.TRY:
        this.retryDto = new RetryDto()
        break
      case NodeTypeEnum.SYNC:
        this.synchronizedDto = new SynchronizeDto()
        break
      case NodeTypeEnum.ASYNC:
        this.asyncDto = new AsyncDto()
        break
      case NodeTypeEnum.CACHE:
        this.cacheDto = new CacheDto()
        break
    }
  }
}

let i = 0
export class Node {
  constructor({ ico, name, id = getUUID(), nodeId, left = '0px', top = '0px', state = 'success', type, retryPolicy }) {
    this.ico = ico
    // 开始节点和结束节点不拼接随机数
    if (![NodeTypeEnum.START, NodeTypeEnum.END].includes(type)) {
      name = name + '-' + ++i
    }
    this.name = name // 参数名称
    this.id = id
    this.nodeId = nodeId
    this.nodeKey = id
    this.left = left
    this.top = top
    this.state = state
    this.type = type
    // this.groupChildren = []
    this.retryPolicy = retryPolicy
    if (GROUP_NODES.includes(this.type)) {
      this.width = '500px'
      this.height = '250px'
    }
    this.nodeParamsLogicDto = new NodeParamsLogicDto({ type: this.type })
  }
}

export class FieldMapping {
  constructor() {
    this.dataType = null // 入参数据类型 对应paramList数据类型
    this.functionList = [] // 函数列表
    this.referenceType = 1 // 入参类型( 固定-0 | 引用-1 | 请求参数-2)
    this.scriptData = null // 脚本
    this.sorted = 0 // 排序
    this.sourceNodeKey = null // 源字段节点key(id: 前端生成的id)
    this.sourceNodeName = null // 源字段节点名称
    this.sourceNodePath = null // 源字段节点路径
    this.targetNodePath = null // 目标节点路径 对应paramListpath
    this.bizDictMapId = null
    this.dataPosition = null // 参数位置 对应paramList  dataPosition
    this.isRequired = null // 是否必传 对应paramList  isRequired
    this.id = null
    this.nodeId = null
    this.dictMapping = null
  }
}

// 结束节点，映射
export class DictMapping {
  constructor() {
    this.dictMapId = null
    this.dictMapName = null
    this.paramList = []
  }
}

// 结束节点，映射，映射参数列表
export class DictMapParamList {
  constructor() {
    this.dataType = null
    this.paramName = null
    this.description = null
    this.referenceType = null
    this.nodeKey = null
    this.value = null
  }
}
