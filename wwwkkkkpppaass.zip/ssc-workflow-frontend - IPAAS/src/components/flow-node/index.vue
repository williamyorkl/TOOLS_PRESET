<template>
  <div class="arrange-container-wrapper">
    <toolbar v-if="!formDisabled || ['arrangeTplSet', 'arrangeTplTour'].includes(mode)" class="toolbar" :name="formData.businessApiName" @commit="commitForm" @downloadData="downloadData" @help="help" @info="info" :mode="mode" />
    <div class="arrange-container">
      <div class="menu-container" style="" v-if="!formDisabled">
        <node-menu @addNode="addNode" ref="nodeMenu" />
      </div>
      <jsplumbCanvas v-if="renderCanvas" @setting="setting" @handleTplDesc="handleTplDesc" ref="jsplumb-canvas" canvasId="arrange-container" :canvasData="formData" />

      <!-- 节点编辑的弹窗 -->
      <NodeOptionDialog :activeElement="activeElement" :formData="formData" :visible.sync="nodeOptionDialogVisible" v-if="nodeOptionDialogVisible" @save="saveNodeOption" />
      <!-- 节点操作指引的配置弹窗 -->
      <TplDescDialog :formData="tplDescData" :visible.sync="tplDescDialog" v-if="tplDescDialog" @save="saveTplOption" />
    </div>
    <!-- 流程数据详情 -->
    <flow-info v-if="flowInfoVisible" ref="flowInfo" :data="formData" />
    <flow-help v-if="flowHelpVisible" ref="flowHelp" />
  </div>
</template>

<script>
import './index.scss'
import choiceData from './model/example_data'
import foreachData from './model/example_foreach_data'
import jsplumbCanvas from './components/jsplumb-canvas'
import nodeMenu from './components/node_menu'
import { geneNodeDataByNodeMenu } from './utils/jsplumb-render'
import toolbar from './components/toolbar'
import NodeOptionDialog from './biz_components/nodeOptionDialog'
import TplDescDialog from './biz_components/tpl-desc-dialog'
import { NodeTypeEnum } from '@/config/enum'
import flowInfo from './components/info'
import flowHelp from './components/help'
import { computedTemplateNodeTitle } from './utils/computed-template-node-title'

export default {
  name: 'CanvasContainer',
  components: { jsplumbCanvas, nodeMenu, toolbar, NodeOptionDialog, flowHelp, flowInfo, TplDescDialog },
  props: {
    canvasId: {
      default: 'jsplumb-canvas',
      type: String
    },
    formData: {
      type: Object,
      default: () => ({ businessName: '测试节点' })
    },
    nodeDescMap: {
      type: Map,
      default: () => new Map()
    },
    // 不同类型的编排有不同的baseDetail，用于渲染开始节点的内容，暂只在顶层画布做不同的开始节点渲染
    baseDetail: {
      type: Object,
      required: true
    }
  },
  inject: {
    formDisabled: {
      from: 'formDisabled'
    },
    mode: {
      from: 'mode',
      default: 'edit'
    }
  },
  data() {
    return {
      choiceData,
      foreachData,
      activeElement: {},
      nodeMap: new Map(),
      nodeOptionDialogVisible: false,
      flowInfoVisible: false,
      flowHelpVisible: false,
      renderCanvas: true,
      tplDescDialog: false,
      tplDescData: {}
    }
  },
  provide() {
    return {
      // activeElement通过inject配合mixin: ../mixins/activeElement.js传递
      getActiveElement: () => {
        return this.activeElement
      },
      setActiveElement: (activeElement) => {
        this.activeElement = activeElement
      },
      nodeMap: this.nodeMap,
      baseDetail: this.baseDetail
    }
  },
  watch: {
    // formData: {
    // handler(nV) {
    // console.log('formData', JSON.stringify(nV.lineList))
    // },
    // immediate: true
    // }
  },
  methods: {
    // 打开对应节点的弹窗，并设置对应的数据,该方法需要从外部通过refs调用
    openTourDialog(nodeKey) {
      this.activeElement.node = this.nodeMap.get(nodeKey)
      this.nodeOptionDialogVisible = true
      console.log(nodeKey)
    },
    closeTourDialog() {
      this.nodeOptionDialogVisible = false
    },
    // 保存数据
    saveTplOption(formData) {
      this.$emit('saveTplOption', formData)
    },
    // 打开节点操作指引弹窗
    handleTplDesc(node) {
      const nodeKey = node.nodeKey
      // 打开弹窗时，根据节点id查询是否已做过修改
      const formData = this.nodeDescMap.get(nodeKey) || {
        nodeKey,
        templateNodeDesc: null,
        templateNodeTitle: computedTemplateNodeTitle(node)
      }
      this.tplDescDialog = true
      this.tplDescData = formData
    },
    // 打开节点操作设置弹窗
    setting({ type, data }) {
      console.log('setting', type, data)
      this.nodeOptionDialogVisible = true
    },
    // 保存节点配置信息
    async saveNodeOption(nodeFormData) {
      this.activeElement.node = Object.assign(this.activeElement.node, nodeFormData)
      this.nodeOptionDialogVisible = false
      this.forceUpdate()
    },
    // 强制刷一下，更新为新数据。木的办法
    async forceUpdate() {
      this.renderCanvas = false
      this.nodeMap.clear()
      await this.$nextTick()
      this.renderCanvas = true
    },
    // 提交数据
    commitForm() {
      console.log('this.formData', this.formData)
      this.$emit('commit', this.formData)
    },
    /**
     * 添加节点
     * @param {Object} evt 包装过的事件对象
     * @param {Object} nodeMenu 拖拽的节点菜单
     * @param {Obejct} mousePosition 鼠标在菜单项上的位置，用于计算节点最终在画布上的位置
     */
    async addNode(evt, nodeMenu, mousePosition) {
      /**
       * 进行业务判断，是否可以添加，添加到哪个数组
       */
      const to = evt.to
      if (to.className !== 'jsplumb-canvas-container') {
        return this.$message.error('请拖拽到canvas容器中')
      }

      if (NodeTypeEnum.START === nodeMenu.type) {
        return this.$message.error('开始节点已存在')
      }

      if (NodeTypeEnum.END === nodeMenu.type) {
        return this.$message.error('结束节点已存在')
      }

      const toParent = to.parentElement
      if ([NodeTypeEnum.BREAK, NodeTypeEnum.CONTINUE].includes(nodeMenu.type) && toParent.className !== 'foreach-item') {
        return this.$message.error('break和continue块只能放在forEach节点中')
      }

      const newNode = geneNodeDataByNodeMenu(evt, nodeMenu, mousePosition)
      // 这两行要放到await前面
      const toList = this.getSourceList(to)
      toList.push(newNode)
      await this.$nextTick()

      const instance = this.getInstance(to)
      console.log('🚀 ~ file: index.vue ~ line 186 ~ addNode ~ to', to)
      console.log('🚀 ~ file: index.vue ~ line 183 ~ addNode ~ newNode', newNode)
      instance.registerNode(newNode, instance)
      console.log('nodeMap', this.nodeMap)
    },
    // getSourceList和getInstance的逻辑混乱
    getSourceList(to) {
      let toList = []
      // 循环引用，__vue__实例不正常，最外层可以通过 __vue__.list获取，内层需要通过自定义函数 __vue__.getList获取
      if (to.__vue__.getSourceList) {
        toList = to.__vue__.getSourceList()
      } else {
        toList = to.__vue__.list
      }
      return toList
    },
    getInstance(to) {
      let instance = null
      if (to.__vue__.$attrs.getInstance) {
        instance = to.__vue__.$attrs.getInstance()
      } else if (to.__vue__.getInstance) {
        instance = to.__vue__.getInstance()
      } else {
        instance = this.$refs['jsplumb-canvas'].getInstance()
      }
      return instance
    },
    info() {
      this.flowInfoVisible = true
      this.$nextTick(function() {
        this.$refs.flowInfo.init()
      })
    },
    help() {
      this.flowHelpVisible = true
      this.$nextTick(function() {
        this.$refs.flowHelp.init()
      })
    },
    // 下载数据
    downloadData() {
      this.$confirm('确定要下载该流程数据吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        closeOnClickModal: false
      })
        .then(() => {
          const datastr =
            'data:text/json;charset=utf-8,' +
            encodeURIComponent(JSON.stringify(this.formData, null, '\t'))
          const downloadAnchorNode = document.createElement('a')
          downloadAnchorNode.setAttribute('href', datastr)
          downloadAnchorNode.setAttribute('download', 'data.json')
          downloadAnchorNode.click()
          downloadAnchorNode.remove()
          this.$message.success('正在下载中,请稍后...')
        })
        .catch(() => {})
    }
  }
}
</script>

<style scoped lang="scss">
.arrange-container-wrapper{
  height: 100%;
  display: flex;
  flex-direction: column;
  .toolbar{
    height: $toolbarHeight;
    box-sizing: border-box;
    border-bottom: 1px solid rgb(207, 205, 205);
    box-shadow: 0px 3px 0px 0px rgba(0, 0, 0, 0.05);
  }
  .arrange-container {
    margin-left: 10px;
    height: calc(100% - #{$toolbarHeight});
    display: flex;
    flex-grow: 1;
    .menu-container{
      max-height: 100%;
      overflow-y: auto;
      overflow-x: hidden;
      width: 220px;
      border-right: 1px solid #dce3e8;
    }
  }
}
</style>
