<template>
  <Fragment>
    <el-col :span="12">
      <el-form-item label="协议" prop="webServiceFlag">
        <el-checkbox v-model="formData.httpFlag" :trueLabel="2" :falseLabel="1" :disabled="true">Http</el-checkbox>
        <el-checkbox v-model="formData.webServiceFlag" :trueLabel="2" :falseLabel="1" :disabled="true">
          WebService
        </el-checkbox>
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item label="请求方式" prop="requestType" v-if="formData.httpFlag === 2">
        <el-select v-model="formData.requestType" placeholder="请求方式" :disabled="true">
          <el-option v-for="item in requestTypes" :key="item.type" :label="item.desc" :value="item.type" />
        </el-select>
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item label="服务分组" prop="groupId">
        <el-select v-model="formData.groupId" placeholder="服务分组" clearable :disabled="true">
          <el-option v-for="item in groupList" :key="item.id" :label="item.groupName" :value="item.id" />
        </el-select>
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item label="安全认证" prop="apiAuthType">
        <el-select v-model="formData.apiAuthType" placeholder="安全认证" clearable :disabled="true">
          <el-option v-for="item in ApiAuthTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
        </el-select>
      </el-form-item>
    </el-col>

    <el-col :span="12">
      <el-form-item label="BasePath" prop="baseUrl">
        <el-input v-model="formData.baseUrl" :disabled="true" />
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item label="接口请求URL" prop="requestUrl">
        <el-input v-model="formData.requestUrl" :disabled="true" />
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item label="超时时间(ms)" prop="requestTimeout">
        <el-input type="number" v-model.number="formData.requestTimeout" :disabled="true" />
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item label="日志等级" prop="logLevel">
        <el-radio-group v-model="formData.logLevel" :disabled="true">
          <el-radio :label="1">info</el-radio>
          <el-radio :label="2">debug</el-radio>
        </el-radio-group>
      </el-form-item>
    </el-col>
  </Fragment>
</template>

<script>
import { mapActions } from 'vuex'
import groupApi from '@/api/arrange'
import { Fragment } from 'vue-fragment'

export default {
  components: { Fragment },
  props: {
    formData: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      requestTypes: [],
      groupList: [],
      ApiAuthTypeEnum: []

    }
  },
  async created() {
    [this.requestTypes, this.ApiAuthTypeEnum] = await this.getDicts(['MethodTypeEnum', 'ApiAuthTypeEnum'])
    this.groupList = await this.getGroupList()
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),

    async getGroupList() {
      return await groupApi.listGroupCtrl()
    }
  }
}
</script>

<style>

</style>
