<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" :maxlength="32" />
    </el-form-item>
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
export default {
  props: {
    nodeFormData: {
      required: true,
      type: Object
    }
  },
  inject: ['formDisabled', 'nodeMap', 'getFormData'],
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ]
      }
    }
  },
  computed: {
    formData() {
      return this.getFormData()
    },
    asyncDto() {
      return this.nodeFormData.nodeParamsLogicDto.asyncDto
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        fn(valid)
      })
    }
  }
}
</script>

<style>

</style>
