<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" :maxlength="32" />
    </el-form-item>
    <McList :list="variableDto.variables" @handleAdd="handleAddVariable">
      <template slot-scope="scope">
        <Variables :id="'tour-variable-' + scope.index" :formItem="scope.item" :index="scope.index" :data-list="variableDto.variables" v-on="$listeners" />
      </template>
    </McList>
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
import { Variable } from '../../../model/nodeParams_model'
import Variables from '../../components/variables/index.vue'
import funcApi from '@/api/platformConfig/func'
import { resolveCollection } from '../node-option-utils'
import { code2Text, recursionList } from '@/utils'

export default {
  components: { Variables },
  props: {
    nodeFormData: {
      type: Object,
      required: true
    }
  },
  inject: ['formDisabled', 'nodeMap', 'getFormData'],
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ]
      },
      DataTypeEnum: []
    }
  },
  computed: {
    variableDto() {
      return this.nodeFormData.nodeParamsLogicDto.variableDto
    },
    formData() {
      return this.getFormData()
    }
  },
  async created() {
    [this.DataTypeEnum] = await this.getDicts(['DataTypeEnum'])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    handleAddVariable(list) {
      list.push(new Variable())
    },
    validateFormData(fn) {
      this.$refs.form.validate(async valid => {
        if (valid) {
          const outputParamList = await this.transformVariables(this.variableDto.variables)
          this.variableDto.outputParamList = [
            {
              paramName: 'variables',
              dataType: 7,
              childrenList: outputParamList
            }
          ]
          fn(valid)
        } else {
          fn(valid)
        }
      })
    },
    // 处理函数参数
    async transformVariables(variables) {
      return Promise.all(variables.map(async item => {
        return new Promise((resolve, reject) => {
          // 函数类型，调接口转换参数
          if (item.referenceType === 2) {
            const resultRootName = item.variableName
            const express = item.express
            const parameters = item.parameters
            const fixedParams = []
            const refTypes = {}
            parameters.forEach(parameter => {
              if (parameter.referenceType === 0) { // 固定值
                // fixedParams[parameter.paramName] = parameter.sourceNodePath
                fixedParams.push({ key: parameter.paramName, dataType: parameter.dataType, value: parameter.sourceNodePath })
              } else if (parameter.referenceType === 1) { // 引用值
                // 先根据sourceNodeKey和sourceNodePath找出引用的节点对应的数据集
                const collectionData = resolveCollection({ nodeId: parameter.sourceNodeKey, collectionName: parameter.sourceNodePath, nodeMap: this.nodeMap, formData: this.formData })
                refTypes[parameter.paramName] = []
                this.recursionCollection([collectionData], refTypes[parameter.paramName])
              }
            })
            try {
              funcApi.transParams({ resultRootName, express, fixedParams, refTypes }).then(resp => {
                recursionList(resp, subItem => {
                  subItem.paramName = subItem.key
                  subItem.childrenList = subItem.subFields || []
                  if (subItem.dataType === 8 && subItem.childrenList) {
                    subItem.generic = 7
                  }
                }, 'subFields')
                if (resp && resp.length > 0) {
                  resolve(resp[0])
                } else {
                  resolve({ paramName: resultRootName, dataType: 'undefined' })
                }
              }).catch(err => {
                reject(err)
              })
            } catch (e) {
              reject(e)
            }
          } else {
            resolve({ ...item, paramName: item.variableName })
          }
        })
      }))
    },
    recursionCollection(collectionArr, arr = []) {
      collectionArr.forEach(item => {
        const row = { key: item.paramName, dataType: item.dataType, type: code2Text(item.dataType, this.DataTypeEnum), subFields: [] }
        arr.push(row)
        this.recursionCollection(item.childrenList || [], row.subFields)
      })
    }
  }
}
</script>

<style>

</style>
