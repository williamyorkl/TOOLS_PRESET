<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" :maxlength="32" />
    </el-form-item>
    <el-row :gutter="10">
      <el-col :span="12">
        <el-form-item label="用户接口路径">
          <el-input v-model="nodeParamsForwardDto.completeUrl" :disabled="true" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="后端服务名">
          <el-input v-model="nodeParamsForwardDto.srvName" :disabled="true" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="URL匹配前缀">
          <el-input v-model="nodeParamsForwardDto.reqPathPrefix" :disabled="true" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="超时时间(ms)">
          <el-input v-model="nodeParamsForwardDto.timeOut" />
        </el-form-item>
      </el-col>
      <el-col :span="24">
        <el-alert title="提示：网关访问地址格式为: http://{目标服务ip:port}/get/list" type="info" />
      </el-col>
    </el-row>
  </el-form>
</template>

<script>
export default {
  props: {
    nodeFormData: {
      type: Object,
      default: () => ({})
    },
    formData: {
      type: Object,
      default: () => ({})
    }
  },
  inject: ['formDisabled'],
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ]
      }
    }
  },
  computed: {
    nodeParamsForwardDto() {
      return this.nodeFormData.nodeParamsLogicDto.nodeParamsForwardDto
    }
  },
  methods: {
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        fn(valid)
      })
    }
  }
}
</script>

<style>

</style>
