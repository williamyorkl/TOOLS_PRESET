<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" :maxlength="32" />
    </el-form-item>
    <el-form-item label="缓存数据源" prop="nodeParamsLogicDto.cacheDto.sourceId" id="tour-cache-db">
      <mc-popover-select v-model="cacheDto.sourceId" clearable :disabled="formDisabled" :defaultValue="cacheDto.sourceName" :apiFunc="apiFunc" :tableColumn="sourceTableColumn" :param="{usable: true}" :queryList="sourceQueryList" labelKey="sourceName" valueKey="id" @changeRow="sourceRowClick" />
    </el-form-item>
    <McList :list="cacheDto.operateList" @handleAdd="handleAddVariable">
      <template slot-scope="scope">
        <mc-collapse-panel :label="'CACHE_'+(scope.index+1)" :initState="false">
          <operate-list :id="'tour-cache-cache-' + scope.index" :formItem="scope.item" :index="scope.index" :data-list="cacheDto.operateList" v-on="$listeners" />
          <!-- <Variables :formItem="scope.item" :index="scope.index" :data-list="cacheDto.operateList" v-on="$listeners" /> -->
        </mc-collapse-panel>
      </template>
    </McList>
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
import { Operate } from '../../../model/nodeParams_model'
import OperateList from '../../components/operate-list/index.vue'
import cacheModel from '@/config/popContentTableConfig/cache.config'

export default {
  components: { OperateList },
  props: {
    nodeFormData: {
      type: Object,
      required: true
    }
  },
  inject: ['formDisabled', 'nodeMap', 'getFormData'],
  data() {
    return {
      apiFunc: cacheModel.apiFunc,
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.cacheDto.sourceId': [
          { required: true, message: '请选择数据源', trigger: 'change' }
        ]
      },
      CacheOperateTypeEnum: [],
      DataTypeEnum: [],
      sourceTableColumn: [],
      sourceQueryList: []
    }
  },
  computed: {
    cacheDto() {
      return this.nodeFormData.nodeParamsLogicDto.cacheDto
    },
    formData() {
      return this.getFormData()
    }
  },
  async created() {
    [this.CacheOperateTypeEnum, this.DataTypeEnum] = await this.getDicts(['CacheOperateTypeEnum', 'DataTypeEnum'])
    this.sourceTableColumn = cacheModel.getTableColumn()
    this.sourceQueryList = cacheModel.getQueryList()
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    sourceRowClick(row) {
      this.cacheDto.sourceName = row.sourceName
    },
    handleAddVariable(list) {
      list.push(new Operate())
      console.log(list)
    },
    validateFormData(fn) {
      this.$refs.form.validate(async valid => {
        if (valid) {
          fn(valid)
        } else {
          fn(valid)
        }
      })
    }
  }
}
</script>

<style>

</style>
