
// 当前的节点类型
export function getCurrentComponent(typ) {
  const componentList = ['DubboOption', 'HttpOption', 'SpringcloudOption', 'NativeOption', 'SoapOption', 'LocalOption', 'SapOption']
  return componentList[typ]
}
