<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" maxlength="32" />
    </el-form-item>
    <el-row :gutter="10">
      <el-col :span="24" class="filter-item">
        <el-form-item label="关联映射" id="tour-combine-data">
          <el-col :span="12" v-for="(item, index) in combine.nodeKeyList" :key="item + index">
            <el-col :span="12">
              <el-form-item labelWidth="60px" :label="index === 0 ? '主数据' : '子数据'" :rules="rules.value" :prop="'nodeParamsLogicDto.combine.nodeKeyList.' + index + '.value'">
                <el-input v-model="item.value" placeholder="请选择" :readonly="true">
                  <el-button slot="append" icon="el-icon-setting" @click="showJsonTree(item)" />
                </el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item labelWidth="70px" label="节点名称">
                <el-input :value="resolveNodeName(item.nodeKey, nodeMap)" disabled placeholder="节点名称" />
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-card class="box-card">
                <el-tree class="tree" :data="index === 0 ? mainData : lineData" :props="treeDataProps" nodeKey="key" defaultExpandAll checkOnClickNode @node-contextmenu="(event, treeNode) => rightClickTree(treeNode, index)" />
              </el-card>
            </el-col>
          </el-col>
        </el-form-item>
      </el-col>
      <el-col class="mb-16" :span="24">
        <el-form-item label="数据映射" id="tour-combine-mapping">
          <MappingList ref="mappingList" :tableList="combine.mappingList" @rowClick="mappingRowClick" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="1-n关联">
          <el-checkbox v-model="combine.listFlag" :trueLabel="1" :falseLabel="0" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="字段名称" prop="nodeParamsLogicDto.combine.fieldName" id="tour-combine-fieldName">
          <el-input v-model="combine.fieldName" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="出参">
          <el-card class="box-card">
            <el-tree class="tree" :data="displayTreeData" :props="treeDataProps" nodeKey="key" defaultExpandAll checkOnClickNode />
          </el-card>
        </el-form-item>
      </el-col>
    </el-row>
    <!-- 数据源json弹窗 -->
    <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px" v-if="jsonTreeDialogVisible">
      <JsonTree wrapRoot="$" title="源数据" :selectNodeId.sync="selectNodeId" :data.sync="sourceData" @rightClick="rightClick" :multipleNode="true" />
    </el-dialog>
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
import { deepClone } from '@/utils'
import { formatterParamList, resolveCombineTreeData } from '@/components/flow-node/biz_components/nodeOptionDialog/node-option-utils'
import { findPrevChain } from '@/components/flow-node/utils/Jsplumb'
import MappingList from '@/components/flow-node/biz_components/components/paramList/combineMappingList'
import JsonTree from '@/components/flow-node/biz_components/components/jsonTree'
import mixinResolveNodeName from '@/components/flow-node/mixins/resolveNodeName'

export default {
  components: { MappingList, JsonTree },
  props: {
    nodeFormData: {
      type: Object,
      default: () => ({})
    }
  },
  inject: ['formDisabled', 'nodeMap', 'getFormData'],
  mixins: [mixinResolveNodeName],
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ],
        value: [
          { required: true, message: '请选择数据集', trigger: 'change' }
        ],
        'nodeParamsLogicDto.combine.fieldName': [
          { required: true, message: '请输入字段名称', trigger: 'blur' }
        ]
      },
      jsonTreeDialogVisible: false,
      selectNodeId: null,
      currentData: {},
      mainData: [],
      lineData: [],
      treeDataProps: { children: 'childrenList' },
      currentRow: null,
      DataTypeEnum: [],
      sourceData: []
    }
  },
  computed: {
    combine() {
      return this.nodeFormData.nodeParamsLogicDto.combine
    },
    formData() {
      return this.getFormData()
    },
    // 根据lineList和nodeList解析出上游节点
    prevChainNodeList() {
      const list = findPrevChain(this.nodeMap, this.nodeFormData.id)
      return list
    },
    displayTreeData() {
      const mainTree = deepClone(this.mainData)
      const lineTree = deepClone(this.lineData)
      const listFlag = this.combine.listFlag
      const fieldName = this.combine.fieldName

      let lineData = null
      let mainData = null
      if (mainTree && mainTree[0]) {
        mainData = mainTree[0]
      }

      if (lineTree && lineTree[0]) {
        lineData = lineTree[0]
      }

      if (!mainData) {
        return []
      }
      mainData.label = mainData.label.replace(mainData.paramName, 'combineRecord')
      mainData.paramName = 'combineRecord'
      mainData.path = 'combineRecord'
      if (fieldName && lineData) {
        mainData.childrenList.push({
          dataType: listFlag ? 8 : 7,
          paramName: fieldName,
          path: listFlag ? `combineRecord[].${fieldName}` : `combineRecord.${fieldName}`,
          childrenList: lineTree[0].childrenList
        })
      }
      const res = formatterParamList([mainData], this.DataTypeEnum)
      return res
    }
  },
  watch: {
    'combine.nodeKeyList': {
      async handler(nV) {
        [this.DataTypeEnum] = await this.getDicts(['DataTypeEnum'])
        if (!nV || nV.length <= 0) {
          return
        }
        if (nV[0] && nV[0].value) {
          this.mainData = await resolveCombineTreeData(nV[0], this.nodeMap, this.DataTypeEnum, this.formData)
        }
        if (nV[1] && nV[1].value) {
          this.lineData = await resolveCombineTreeData(nV[1], this.nodeMap, this.DataTypeEnum, this.formData)
        }
      },
      immediate: true,
      deep: true
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    showJsonTree(currentData) {
      this.currentData = currentData
      this.jsonTreeDialogVisible = true
    },
    mappingRowClick(row) {
      this.currentRow = row
    },
    handleMainTreeClick(treeNode) {
      this.currentRow = this.combine.mappingList.find(item => item.mainFieldName === treeNode.path)
      if (!this.currentRow) {
        this.currentRow = { mainFieldName: treeNode.path, lineFieldName: null }
        this.combine.mappingList.push(this.currentRow)
      }
      this.$refs.mappingList.setCurrentRow(this.currentRow)
    },
    handleSubTreeClick(treeNode) {
      if (!this.currentRow) {
        return this.$message.error('请先选中行')
      }
      this.currentRow.lineFieldName = treeNode.path
    },
    rightClickTree(treeNode, index) {
      // if (treeNode.root) {
      // return this.$message.error('不能选择根元素')
      // }
      if (index === 0) {
        this.handleMainTreeClick(treeNode)
      } else if (index === 1) {
        this.handleSubTreeClick(treeNode)
      }
    },
    rightClick(node, nodeId) {
      const dataType = node.dataType
      const genericType = node.generic
      if (!((dataType === 8 && genericType === 7) || dataType === 7)) {
        return this.$message.error('必须选择对象或元素泛型为对象的数组')
      }
      this.jsonTreeDialogVisible = false
      this.$set(this.currentData, 'nodeKey', nodeId)
      this.$set(this.currentData, 'value', node.path)
      this.$set(this.currentData, 'dataType', dataType)
    },
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        fn(valid)
      })
    }
  }
}
</script>

<style scope lang="scss">
.filter-item{
  margin-bottom: 16px !important;
}
.code-container{
  margin-top: 10px;
}
.box-card{
  margin-top: 16px;
  .tree {
    height: 200px;
    max-height: 200px;
    overflow: auto;
  }
}
::v-deep .current-row{
  border: 1px solid red;
}
</style>
