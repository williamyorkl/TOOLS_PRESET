<template>
  <el-table ref="multipleTable" :data="tableList" highlightCurrentRow style="width: 100%" @selection-change="handleSelectionChange" maxHeight="250">
    <el-table-column type="selection" width="55" />

    <el-table-column label="字段名" prop="paramName" />
    <el-table-column label="字段类型" prop="dataType" :formatter="formatterDataType" />
  </el-table>
</template>

<script>
import { code2Text } from '@/utils'
import { mapActions } from 'vuex'
export default {
  props: {
    tableList: {
      default: () => [],
      type: Array
    },
    selectRows: {
      default: () => [],
      type: Array
    },
    title: {
      default: 'inParamTable',
      type: String
    },
    mode: {
      type: String,
      default: null
    }
  },
  data() {
    return {
      rules: {},
      DataTypeEnum: []
    }
  },
  computed: {
    disabled() { return this.mode === 'snapshot' }
  },
  async created() {
    [this.DataTypeEnum] = await this.getDicts([
      'DataTypeEnum'
    ])
  },
  async mounted() {
    this.initSelectRows(this.selectRows)
  },
  watch: {
    selectRows: {
      handler(nV) {
        if (this.$refs.multipleTable) {
          this.initSelectRows(nV)
        }
      },
      immediate: true
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    async initSelectRows(rows) {
      await this.$nextTick()
      this.$refs.multipleTable.clearSelection()
      rows.forEach(row => {
        this.$refs.multipleTable.toggleRowSelection(row)
      })
    },
    handleSelectionChange(rows) {
      this.$emit('selectionChange', rows)
    },
    formatterDataType(row, col, val) {
      return code2Text(val, this.DataTypeEnum)
    },
    clearSelection() {
      this.$refs.multipleTable.clearSelection()
    }
  }
}
</script>

<style scoped lang="scss">
table-add-btn {
  width: 100%;
}
</style>
