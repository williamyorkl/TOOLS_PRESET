<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" maxlength="32" />
    </el-form-item>
    <el-row :gutter="10">
      <el-col :span="12">
        <el-form-item label="数据集" prop="nodeParamsLogicDto.group.value" id="tour-group-value">
          <el-input v-model="group.value" placeholder="请选择" :readonly="true">
            <el-button slot="append" icon="el-icon-setting" @click="showJsonTree" />
          </el-input>
        </el-form-item>
      </el-col>
      <el-col :span="6">
        <el-form-item label="节点名称">
          <el-input :value="resolveNodeName(group.nodeKey, nodeMap)" :disabled="true" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-form-item label="分组字段" prop="nodeParamsLogicDto.group.groupKey" id="tour-group-groupKey">
      <el-select v-model="group.groupKey" placeholder="请输入分组字段">
        <el-option v-for="item in allOutputList" :key="item.paramName" :label="item.paramName" :value="item.paramName" :disabled="[7,8].includes(item.dataType)" />
      </el-select>
    </el-form-item>
    <el-form-item label="输出字段" prop="nodeParamsLogicDto.group.outputParamList" id="tour-group-outputParamList">
      <outputParamList :tableList="allOutputList" :selectRows="selectRows" :filterData="group" @selectionChange="selectionChange" />
    </el-form-item>

    <!-- 数据源json弹窗 -->
    <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px" v-if="jsonTreeDialogVisible">
      <JsonTree title="源数据" :selectNodeId.sync="group.nodeKey" :data.sync="sourceData" @rightClick="rightClick" :multipleNode="true" />
    </el-dialog>
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
import { deepClone, expandTree } from '@/utils'
import { resolveDefaultNode, resolveOutputParamList, formatterParamList } from '../../node-option-utils'
import JsonTree from '../../../components/jsonTree'
import outputParamList from './paramList/outputParamList'
import mixinResolveNodeName from '../../../../mixins/resolveNodeName'

export default {
  components: { JsonTree, outputParamList },
  props: {
    nodeFormData: {
      type: Object,
      default: () => ({})
    }
  },
  inject: ['formDisabled', 'nodeMap', 'getFormData'],
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.group.value': [
          { required: true, message: '请选择数据集', trigger: 'change' }
        ],
        'nodeParamsLogicDto.group.groupKey': [
          { required: true, message: '请选择分组字段', trigger: 'change' }
        ]
      },
      jsonTreeDialogVisible: false,
      selectNodeId: null,
      sourceData: [],
      currentRow: null,
      allOutputList: [],
      selectRows: []
    }
  },
  mixins: [mixinResolveNodeName],
  computed: {
    group() {
      return this.nodeFormData.nodeParamsLogicDto.group
    },
    formData() {
      return this.getFormData()
    }
  },
  watch: {
    'group.value': {
      async handler(nV) {
        // 找出对应节点的对应path的对象数据
        if (nV) {
          [this.DataTypeEnum] = await this.getDicts(['DataTypeEnum'])
          const selectNode = this.nodeMap.get(this.group.nodeKey)
          this.group.nodeKey = selectNode.id
          this.group.nodeName = selectNode.name
          const selectOutputList = resolveOutputParamList(deepClone(selectNode), this.formData, this.nodeMap) // 获取所选节点的输出参数，找到当前节点所选的数据集输出字段，拉取字段的childrenList与filter的outputParamList比对，重复的为选中的
          const pathOutputList = formatterParamList(selectOutputList, this.DataTypeEnum)
          const list = expandTree(pathOutputList, 'childrenList') // 展开为一维数组
          const currentArray = list.find(item => item.path === nV)
          const allOutputList = currentArray.childrenList; // 需要结合filter的outputParamList,转换为outputParamList的数据格式，然后将outputParamList中的数据设置为选中行
          [this.allOutputList, this.selectRows] = this.transformOutputList(allOutputList, this.group.outputParamList)
        }
      },
      immediate: true
    }
  },
  async created() {
    this.selectNodeId = resolveDefaultNode(this.group.mappingList, this.nodeFormData, this.nodeMap)
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    selectionChange(rows) {
      this.group.outputParamList = rows
    },
    showJsonTree() {
      this.jsonTreeDialogVisible = true
    },
    rightClick(node, nodeId) {
      const dataType = node.dataType
      const genericType = node.generic
      if (!(dataType === 8 && genericType === 7)) {
        return this.$message.error('必须选择元素泛型为对象的数组')
      }
      this.jsonTreeDialogVisible = false
      this.$set(this.group, 'nodeKey', nodeId)
      this.$set(this.group, 'value', node.path)
      this.$set(this.group, 'outputParamList', [])
    },
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        fn(valid)
      })
    },
    transformOutputList(allOutputList, outputParamList) {
      const selectRows = []
      const selectParams = outputParamList.map(item => {
        return item.paramName || item.fieldName
      })
      const list = allOutputList.map((item, index) => {
        const row = { paramName: item.paramName || item.fieldName, dataType: item.dataType, rowKey: Date.now() + index, childrenList: [] }
        if (selectParams.includes(item.paramName || item.fieldName)) {
          selectRows.push(row)
        }
        return row
      })
      return [list, selectRows]
    }
  }
}
</script>

<style>

</style>
