<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" :maxlength="32" />
    </el-form-item>

    <el-row :gutter="10">
      <el-col :span="12">
        <el-form-item label="数据集" prop="nodeParamsLogicDto.forEachDto.value" id="tour-foreach-value">
          <el-input v-model="forEachDto.value" placeholder="请选择" :readonly="true">
            <el-button slot="append" icon="el-icon-setting" @click="showJsonTree" />
          </el-input>
        </el-form-item>
      </el-col>
      <el-col :span="6">
        <el-form-item label="节点名称">
          <el-input :value="resolveNodeName(forEachDto.nodeKey, nodeMap)" :disabled="true" />
        </el-form-item>
      </el-col>
      <el-col :span="6">
        <el-form-item label="泛型类型">
          <el-input :value="code2Text(forEachDto.generic, DataTypeEnum)" :disabled="true" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-form-item label="出参配置" id="tour-foreach-outputParamList">
      <el-tabs v-model="activeName" type="border-card">
        <el-tab-pane label="出参配置" name="params" :disabled="formDisabled">
          <span slot="label">出参配置 <i class="el-icon-edit" @click="showJsonVisible('outputParamList')" /></span>
          <ParamList class="param-list" type="outParams" :tableData="forEachDto.outputParamList" />
        </el-tab-pane>
      </el-tabs>
    </el-form-item>
    <!-- 数据源json弹窗 -->
    <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px" v-if="jsonTreeDialogVisible">
      <JsonTree title="源数据" :selectNodeId.sync="forEachDto.nodeKey" :data.sync="sourceData" @rightClick="rightClick" :multipleNode="true" />
    </el-dialog>
    <JsonAutoResolveDialog :visible.sync="jsonDialogVisible" :allowCopy="true" :originalParamList="forEachDto.outputParamList" :type="currentJsonKey" @confirm="confirmJsonData" :needPos="false" width="70%" v-if="jsonDialogVisible" />
  </el-form>
</template>

<script>
import ParamList from '@/components/flow-node/biz_components/components/outputParamList'
import JsonAutoResolveDialog from '@/components/jsonAutoResolveDialog'
import jsonAutoResolveMixin from '@/components/jsonAutoResolveDialog/mixin'
import mixinResolveNodeName from '@/components/flow-node/mixins/resolveNodeName'
import JsonTree from '@/components/flow-node/biz_components/components/jsonTree'
import { code2Text } from '@/utils'
import { mapActions } from 'vuex'
export default {
  components: { ParamList, JsonTree, JsonAutoResolveDialog },
  props: {
    nodeFormData: {
      required: true,
      type: Object
    }
  },
  inject: ['formDisabled', 'nodeMap', 'getFormData'],
  mixins: [mixinResolveNodeName, jsonAutoResolveMixin],
  data() {
    return {
      activeName: 'params',
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.forEachDto.value': [
          { required: true, message: '请选择数据集', trigger: 'blur' }
        ]
      },
      jsonTreeDialogVisible: false,
      selectNodeId: null,
      sourceData: [],
      currentRow: null,
      code2Text,
      DataTypeEnum: []
    }
  },
  computed: {
    formData() {
      return this.getFormData()
    },
    forEachDto() {
      return this.nodeFormData.nodeParamsLogicDto.forEachDto
    }
  },
  async created() {
    [this.DataTypeEnum] = await this.getDicts(['DataTypeEnum'])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        fn(valid)
      })
    },
    showJsonTree() {
      this.jsonTreeDialogVisible = true
    },
    rightClick(node, nodeId) {
      const dataType = node.dataType
      const genericType = node.generic
      if (!(dataType === 8)) {
        return this.$message.error('必须选择数组类型数据')
      }
      this.jsonTreeDialogVisible = false
      this.$set(this.forEachDto, 'nodeKey', nodeId)
      this.$set(this.forEachDto, 'value', node.path)
      this.$set(this.forEachDto, 'generic', genericType)
    },
    confirmJsonData(data) {
      this.forEachDto[this.currentJsonKey] = data
      this.jsonDialogVisible = false
    }
  }
}
</script>

<style>

</style>
