<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" :maxlength="32" />
    </el-form-item>
    <el-form-item label="配置出参">
      <mc-form-item-label slot="label" label="配置出参" icon="el-icon-info">
        1、「右键」目标数据，可自动选中下方列表中对应行，「右键」源数据可将选中数据填充至下方列表，并自动切换至下一行 <br>
        2、「单击」下方表格某一行则可选中行
      </mc-form-item-label>
      <el-card>
        <el-row :gutter="20">
          <el-col :span="12" id="tour-mapper-targetMessage">
            <JsonTree ref="leftTree" title="目标数据" wrapStr="mapper" :data="targetOutputParamList" @listChange="listChange" :allowEdit="true" :multipleNode="false" @rightClick="targetRightClick" />
          </el-col>
          <el-col :span="12">
            <JsonTree ref="rightTree" title="源数据" :selectNodeId.sync="selectNodeId" :multipleNode="true" :data.sync="sourceData" :allowEdit="false" @rightClick="sourceRightClick" />
          </el-col>
        </el-row>
      </el-card>
    </el-form-item>
    <el-form-item v-if="!formDisabled">
      <el-popconfirm :title="autoMappingTitle" @confirm="autoMappingList">
        <el-button slot="reference">自动映射</el-button>
      </el-popconfirm>
      忽略参数类型 <el-checkbox v-model="ignoreDataType" />
    </el-form-item>
    <el-form-item label="字段映射" id="tour-mapper-mappingList">
      <fieldMappingTable :allowAdd="false" :needIsRequired="false" ref="inParamTable" title="inParamTable" :tableList="mapper.mappingList" @eventLinstener="eventLinstener" />
    </el-form-item>
  </el-form>
</template>

<script>
import JsonTree from '@/components/flow-node/biz_components/components/jsonTree'
import { resolveDefaultNode, fillMappingTable, removeNullRow, compareAndMapping } from '@/components/flow-node/biz_components/nodeOptionDialog/node-option-utils'
import fieldMappingTable from '@/components/flow-node/biz_components/components/fieldMappingTable'
import { polyfillData } from '@/utils'
import { autoMappingTitle } from '@/components/flow-node/model/config'
export default {
  components: { JsonTree, fieldMappingTable },
  props: {
    nodeFormData: {
      required: true,
      type: Object
    },
    formData: {
      required: true,
      type: Object
    }
  },
  inject: ['formDisabled', 'nodeMap'],
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.mapper.mqServerId': [
          { required: true, message: '请选择MQ数据源', trigger: 'change' }
        ]
      },
      selectNodeId: null,
      sourceData: [],
      currentRow: null,
      autoMappingTitle,
      ignoreDataType: false
    }
  },
  computed: {
    mapper() {
      return this.nodeFormData.nodeParamsLogicDto.mapper
    },
    targetOutputParamList() {
      let outputParamList = []
      try {
        outputParamList = JSON.parse(this.mapper.targetMessage) || []
      } catch (e) {
        outputParamList = []
      }
      console.log(outputParamList)
      return outputParamList || []
    }
  },
  created() {
    this.mapper.targetMessage = polyfillData(this.mapper.targetMessage, 'mapper')
    this.selectNodeId = resolveDefaultNode(this.mapper.mappingList, this.nodeFormData, this.nodeMap)
    // 补充提交数据时删掉的空row
  },
  watch: {
    'mapper.targetMessage': {
      handler(nV) {
        if (nV) {
          const paramList = JSON.parse(nV)
          this.mapper.mappingList = fillMappingTable(paramList, this.mapper.mappingList)
        } else {
          this.mapper.mappingList = []
        }
      },
      immediate: true
    }
  },
  methods: {
    listChange(data) {
      this.mapper.targetMessage = JSON.stringify(data)
    },
    // 切换数据源
    mqServerChange(row) {
      this.mapper.mqType = row.mqType
      if (row.mqType === 3) { // rabbitMq不设置tags和keyPrefix
        this.mapper.tags = null
        this.mapper.keyPrefix = null
      }
    },
    // 右击目标数据设置对应行高亮
    async targetRightClick(treeNode) {
      this.$refs.inParamTable.setCurrentRow(treeNode)
      await this.$nextTick()
      // 点击时修改当前行的数据类型
      this.currentRow.dataType = treeNode.dataType
    },
    // 右击源数据填充到高亮行
    sourceRightClick(treeNode, selectNodeId, selectNode) {
      if (!selectNodeId) selectNodeId = this.nodeFormData.id

      if (!this.currentRow) {
        this.$message.error('请先选中行')
      } else {
        if (this.currentRow.referenceType === 0) { return this.$message.error('固定值请自行输入') }
        this.currentRow.sourceNodePath = treeNode.path
        this.currentRow.sourceNodeKey = selectNodeId
        this.currentRow.sourceNodeName = selectNode.name
        this.currentRow.sourceDataType = treeNode.dataType
        this.$refs.inParamTable.activeNextRow()
      }
    },
    eventLinstener({ type, row, _list, title }) {
      switch (type) {
        case 'currentChange':
          this.currentChange(title, row)
          break
      }
    },
    currentChange(title, row) {
      if (title === 'inParamTable') {
        this.currentRow = row
      }
    },
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        removeNullRow(this.mapper.mappingList)
        fn(valid)
      })
    },
    // 自动映射左右数据
    autoMappingList() {
      const leftTree = this.targetOutputParamList
      const rightTree = this.sourceData
      const leftSelectRow = this.$refs.leftTree.getSelectRow()
      const rightSelectRow = this.$refs.rightTree.getSelectRow()
      if (!leftTree || !rightTree || leftTree.length === 0 || rightTree.length === 0) {
        return this.$message.error('匹配失败，数据不完整')
      }
      // 进行匹配映射
      compareAndMapping({ leftTree, rightTree, leftSelectRow, rightSelectRow, mappingList: this.mapper.mappingList, rightNodeId: this.selectNodeId, ignoreDataType: this.ignoreDataType })
    }
  }
}
</script>

<style>

</style>
