<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-row :gutter="10">
      <el-col :span="24">
        <el-form-item label="节点名称" prop="name" id="tour-node-name">
          <el-input v-model.trim="nodeFormData.name" :maxlength="32" />
        </el-form-item>
      </el-col>
      <div id="tour-start-trigger" style="display: inline-block;" v-if="!GROUP_NODES.includes(parentNode.type)">
        <el-col :span="24">
          <el-form-item label="触发器类型">
            {{ categoryText }}
          </el-form-item>
        </el-col>
        <component :is="currentTrigger" :formData="baseFormData" />
      </div>
      <el-col :span="24">
        <!-- 开始节点，只需要配置一套入参json，供前端人员查看和后续节点选用 -->
        <!-- 入配置 -->
        <el-form-item label="请求入参" id="tour-start-inparams">
          <mc-form-item-label slot="label" label="请求入参" description="GET请求请输入对象形式的键值对，值仅支持基本类型（示例： {&quot;name&quot;: &quot;admin&quot;, id: 1}）" icon="el-icon-info" />
          <JsonTree title="目标数据" :data="startNodeTreeData" :allowEdit="false" :multipleNode="false" />
        </el-form-item>
      </el-col>
    </el-row>
  </el-form>
</template>

<script>
import JsonTree from '@/components/flow-node/biz_components/components/jsonTree'
import { getStartOutputList } from '@/components/flow-node/biz_components/nodeOptionDialog/node-option-utils'
import { TemplateCategoryEnum, GROUP_NODES } from '@/config/enum'
import ServiceTrigger from './components/service-trigger'
import DispatchTrigger from './components/dispatch-trigger'
import MqTrigger from './components/mq-trigger'
import CdcTrigger from './components/cdc-trigger'

export default {
  name: 'Start',
  components: { JsonTree, ServiceTrigger, DispatchTrigger, MqTrigger, CdcTrigger },
  props: {
    nodeFormData: {
      default: () => ({}),
      type: Object
    },
    formData: {
      default: () => ({}),
      type: Object
    }
  },
  inject: ['formDisabled', 'nodeMap', 'baseDetail'],
  data() {
    return {
      GROUP_NODES,
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ]
      },
      startNodeTreeData: [],
      arrangeCategory: null
    }
  },
  created() {
    this.arrangeCategory = this.$route.query.templateCategory
    console.log(this.arrangeCategory)
    this.startNodeTreeData = getStartOutputList({ node: this.nodeFormData, formData: this.formData, nodeMap: this.nodeMap })
  },
  computed: {
    categoryText() {
      const arrangeCategory = Number(this.arrangeCategory)
      switch (arrangeCategory) {
        case TemplateCategoryEnum.ServiceArrangeList:
          return 'API调用'
        case TemplateCategoryEnum.DispatchArrangeList:
          return '定时任务'
        case TemplateCategoryEnum.MqArrangeList:
          return '消息订阅'
        case TemplateCategoryEnum.CdcArrangeList:
          return '实时CDC'
        default:
          return '开始节点'
      }
    },
    currentTrigger() {
      const arrangeCategory = Number(this.arrangeCategory)
      switch (arrangeCategory) {
        case TemplateCategoryEnum.ServiceArrangeList:
          return 'ServiceTrigger'
        case TemplateCategoryEnum.DispatchArrangeList:
          return 'DispatchTrigger'
        case TemplateCategoryEnum.MqArrangeList:
          return 'MqTrigger'
        case TemplateCategoryEnum.CdcArrangeList:
          return 'CdcTrigger'
      }
    },
    baseFormData() {
      const arrangeCategory = Number(this.arrangeCategory)
      switch (arrangeCategory) {
        case TemplateCategoryEnum.ServiceArrangeList:
          return this.baseDetail.definitionBasicDetail
        case TemplateCategoryEnum.DispatchArrangeList:
        case TemplateCategoryEnum.MqArrangeList:
        case TemplateCategoryEnum.CdcArrangeList:
          return this.baseDetail.logicBasicDetail
      }
    },
    parentNode() {
      const parentId = this.nodeFormData.parent
      if (!parentId) {
        return {}
      } else {
        return this.nodeMap.get(parentId)
      }
    }
  },
  methods: {
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        fn(valid)
      })
    }
  }
}
</script>

<style>

</style>
