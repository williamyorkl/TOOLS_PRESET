<template>
  <div>
    <el-row :gutter="20">
      <el-col :span="12">
        <el-form-item label="超时时间(ms)" prop="nodeParamsLogicDto.nodeParamsRpcDto.apiRequestTimeout">
          <el-input v-model.number="nodeParamsRpcDto.apiRequestTimeout"></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="fallBack" prop="nodeParamsLogicDto.nodeParamsRpcDto.fallBack">
          <el-select v-model="nodeParamsRpcDto.fallBack" clearable placeholder="请选择">
            <el-option label="继续" value="continue"></el-option>
            <el-option label="中断" value="stop"></el-option>
          </el-select>
        </el-form-item>
      </el-col>
    </el-row>
    <el-divider></el-divider>
  </div>
</template>

<script>
export default {
  props: {
    nodeParamsRpcDto: {}
  }
}
</script>

<style>

</style>
