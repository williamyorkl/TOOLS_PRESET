<template>
  <el-form class="table-form" ref="mappingForm" :model="formData" :rules="rules" labelWidth="0px" size="mini" :disabled="formDisabled">
    <el-table ref="mappingTable" :data="formData.tableList" highlightCurrentRow style="width: 100%">
      <el-table-column label="序号" align="left" width="60">
        <template slot-scope="scope">
          <span>{{ 'c' + (scope.$index + 1) }}</span>
        </template>
      </el-table-column>

      <el-table-column label="字段名" align="left" minWidth="120">
        <template slot-scope="scope">
          <el-form-item :prop="'tableList.' + scope.$index + '.c1.attrName'" :rules="rules.attrName">
            <!-- 从数据集中选择 -->
            <el-select v-model="scope.row.c1.attrName" placeholder="请选择字段" @change="(e) => attrNameChange(e, scope.row)">
              <el-option :label="item.paramName" :value="item.paramName" v-for="item in allOutputList" :key="item.paramName" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="数据类型" align="left" minWidth="140">
        <template slot-scope="scope">
          <el-form-item>
            <!-- 数据集数据带出 -->
            {{ code2Text(scope.row.c1.dataType, DataTypeEnum) }}
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="逻辑操作" align="left" minWidth="150">
        <template slot-scope="scope">
          <el-form-item :prop="'tableList.' + scope.$index + '.compareSymbol'" :rules="rules.compareSymbol">
            <el-select v-model="scope.row.compareSymbol" placeholder="请选择操作符">
              <el-option v-for="item in CompareSymbolEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="取值类型" align="left" minWidth="120">
        <template slot-scope="scope">
          <el-form-item :prop="'tableList.' + scope.$index + '.c2.type'" :rules="rules.type" v-if="![9,10,11,12].includes(scope.row.compareSymbol)">
            <el-select v-model="scope.row.c2.type" placeholder="请选择取值类型" @change="typeChange(scope.row)">
              <el-option v-for="item in ParamReferenceTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="数据类型" align="left" minWidth="140">
        <template slot-scope="scope">
          <el-form-item :prop="'tableList.' + scope.$index + '.c2.dataType'" :rules="rules.dataType" v-if="![9,10,11,12].includes(scope.row.compareSymbol)">
            <el-select v-model="scope.row.c2.dataType" clearable placeholder="请选择" @change="dataTypeChange(scope.row.c2)" :disabled="true">
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="目标值" minWidth="150">
        <template slot-scope="scope">
          <el-form-item :prop="'tableList.' + scope.$index + '.c2.value'" :rules="rules.value" v-if="![9,10,11,12].includes(scope.row.compareSymbol)">
            <el-input v-if="scope.row.c2.type === 1" v-model.trim="scope.row.c2.value" placeholder="请输入内容">
              <el-button slot="append" icon="el-icon-setting" @click="showJsonTree(scope.row)" />
            </el-input>
            <mc-input v-if="scope.row.c2.type === 0" :trim="false" :dataType="scope.row.c2.dataType" v-model="scope.row.c2.value" placeholder="值" />
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="节点名称" align="left" minWidth="140">
        <template slot-scope="scope">
          <el-form-item v-if="![9,10,11,12].includes(scope.row.compareSymbol)">
            <el-input :value="resolveNodeName(scope.row.c2.nodeKey, nodeMap)" disabled placeholder="节点名称" />
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="操作" width="60" align="left" v-if="!formDisabled" fixed="right">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="deleteRow(scope.$index)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="mt-10 mb-10" v-if="!formDisabled">
      <el-button class="table-add-btn" @click="addRow" icon="el-icon-plus">添加</el-button>
    </div>

    <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px" v-if="jsonTreeDialogVisible">
      <JsonTree title="源数据" :selectNodeId.sync="selectNodeId" :data.sync="sourceData" @rightClick="rightClick" :multipleNode="true" />
    </el-dialog>
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
import JsonTree from '../../../../components/jsonTree'
import { code2Text } from '@/utils'
import mixinResolveNodeName from '@/components/flow-node/mixins/resolveNodeName'

export default {
  components: { JsonTree },
  props: {
    tableList: {
      default: () => [],
      type: Array
    },
    title: {
      default: 'inParamTable',
      type: String
    },
    nodeList: {
      type: Array,
      default: () => []
    },
    mode: {
      type: String,
      default: 'edit'
    },
    allOutputList: {
      type: Array,
      default: () => []
    }
  },
  inject: ['formDisabled', 'nodeMap'],
  mixins: [mixinResolveNodeName],
  data() {
    return {
      formData: {
        tableList: []
      },
      rules: {
        attrName: [
          { required: true, message: '请选择字段', trigger: 'change' }
        ],
        compareSymbol: [
          { required: true, message: '请选择逻辑操作符', trigger: 'change' }
        ],
        type: [
          { required: true, message: '请选择取值类型', trigger: 'change' }
        ],
        dataType: [
          { required: true, message: '请选择数据类型', trigger: 'change' }
        ],
        value: [
          { required: true, message: '请输入目标值', trigger: 'blur' }
        ]
      },
      ParamReferenceTypeEnum: [],
      DataTypeEnum: [],
      CompareSymbolEnum: [],
      jsonTreeDialogVisible: false,
      currentRow: {},
      code2Text,
      selectNodeId: null,
      sourceData: []
    }
  },
  watch: {
    tableList: {
      handler(nV) {
        if (nV) {
          this.formData.tableList = nV
          console.log(this.formData)
        }
      },
      immediate: true
    }
  },
  computed: {
    disabled() { return this.mode === 'snapshot' }
  },
  async created() {
    [this.ParamReferenceTypeEnum, this.DataTypeEnum, this.CompareSymbolEnum] = await this.getDicts([
      'ParamReferenceTypeEnum', 'DataTypeEnum', 'CompareSymbolEnum'
    ])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    dataTypeChange(row) {
      row.value = null
    },
    attrNameChange(v, row) {
      const selectAttr = this.allOutputList.find(item => v === item.paramName) || {}
      row.c1.dataType = selectAttr.dataType
      row.c2.dataType = selectAttr.dataType
    },
    typeChange(row) {
      row.value = null
      row.nodeKey = null
    },
    showJsonTree(row) {
      this.jsonTreeDialogVisible = true
      this.currentRow = row
    },
    rightClick(node, nodeId) {
      this.jsonTreeDialogVisible = false
      this.currentRow.c2.nodeKey = nodeId
      this.currentRow.c2.value = node.path
    },
    addRow() {
      this.$emit('eventLinstener', {
        type: 'add',
        title: this.title,
        list: this.tableList
      })
    },
    deleteRow(index) {
      this.$confirm(
        '确定删除此行吗? 删除不会提交数据，请点击【保存】提交',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      ).then(() => {
        this.formData.tableList.splice(index, 1)
      })
    },
    validFormData() {
      return new Promise((resolve) => {
        this.$refs.mappingForm.validate(valid => {
          resolve(valid)
        })
      })
    }
  }
}
</script>

<style scoped lang="scss">
table-add-btn {
  width: 100%;
}
</style>
