<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" :maxlength="32" />
    </el-form-item>
    <el-form-item label="出参配置">
      <el-tabs v-model="activeName" type="border-card" id="tour-sync-outputParamList">
        <el-tab-pane label="请求参数" name="params" :disabled="formDisabled">
          <span slot="label">请求参数 <i class="el-icon-edit" @click="showJsonVisible('outputParamList')" /></span>
          <ParamList class="param-list" type="outParams" :tableData="synchronizedDto.outputParamList" />
        </el-tab-pane>
      </el-tabs>
    </el-form-item>
    <el-row :gutter="10" id="tour-sync-option">
      <el-col :span="12">
        <el-form-item label="最大锁等待时长(s)" prop="nodeParamsLogicDto.synchronizedDto.maxWait">
          <el-input v-model.number="synchronizedDto.maxWait" type="number" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="最大锁持有时长(s)" prop="nodeParamsLogicDto.synchronizedDto.maxHold">
          <el-input v-model.number="synchronizedDto.maxHold" type="number" />
        </el-form-item>
      </el-col>
      <el-col :span="24">
        <!-- 加锁资源标识 -->
        <el-form-item label="加锁资源标识" prop="nodeParamsLogicDto.synchronizedDto.fieldMappingList">
          <el-card class="box-card" shadow="never">
            <McList :list="synchronizedDto.fieldMappingList" @handleAdd="handleAddVariable">
              <template slot-scope="scope">
                <Variables :formItem="scope.item" :index="scope.index" :data-list="synchronizedDto.fieldMappingList" v-on="$listeners" />
              </template>
            </McList>
          </el-card>
        </el-form-item>
      </el-col>
    </el-row>
    <!-- 枷锁失败响应结果 -->
    <el-form-item label="失败响应结果">
      <mc-form-item-label slot="label" label="失败响应结果" icon="el-icon-info">
        1、「右键」目标数据，可自动选中下方列表中对应行，「右键」源数据可将选中数据填充至下方列表，并自动切换至下一行 <br>
        2、「单击」下方表格某一行则可选中行
      </mc-form-item-label>
      <el-card>
        <el-row :gutter="20">
          <el-col :span="12">
            <JsonTree ref="leftTree" title="目标数据" :data="apiOutParamList" :allowEdit="false" :multipleNode="false" @rightClick="targetRightClick" />
          </el-col>
          <el-col :span="12">
            <JsonTree ref="rightTree" title="源数据" :selectNodeId.sync="selectNodeId" :multipleNode="true" :data.sync="sourceData" :allowEdit="false" @rightClick="sourceRightClick" />
          </el-col>
        </el-row>
      </el-card>
    </el-form-item>
    <el-form-item v-if="!formDisabled">
      <el-popconfirm :title="autoMappingTitle" @confirm="autoMappingList">
        <el-button slot="reference">自动映射</el-button>
      </el-popconfirm>
      忽略参数类型 <el-checkbox v-model="ignoreDataType" />
    </el-form-item>
    <el-form-item label="字段映射" id="tour-sync-lockFailedMappingList">
      <fieldMappingTable processType="end" :allowAdd="false" class="" ref="inParamTable" title="inParamTable" :tableList="synchronizedDto.lockFailedMappingList" @eventLinstener="eventLinstener" />
    </el-form-item>

    <!-- 数据源json弹窗 -->
    <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px" v-if="jsonTreeDialogVisible">
      <JsonTree title="源数据" :selectNodeId.sync="synchronizedDto.nodeKey" :data.sync="sourceData" @rightClick="rightClick" :multipleNode="true" />
    </el-dialog>
    <JsonAutoResolveDialog :visible.sync="jsonDialogVisible" :allowCopy="true" :type="currentJsonKey" :originalParamList="synchronizedDto.outputParamList" @confirm="confirmJsonData" :needPos="false" width="70%" v-if="jsonDialogVisible" />
  </el-form>
</template>

<script>
import ParamList from '@/components/flow-node/biz_components/components/outputParamList'
import Variables from '../../components/variables/index.vue'
import JsonAutoResolveDialog from '@/components/jsonAutoResolveDialog'
import jsonAutoResolveMixin from '@/components/jsonAutoResolveDialog/mixin'
import mixinResolveNodeName from '@/components/flow-node/mixins/resolveNodeName'
import JsonTree from '@/components/flow-node/biz_components/components/jsonTree'
import { code2Text } from '@/utils'
import { mapActions } from 'vuex'
import { resolveDefaultNode, fillMappingTable, removeNullRow, compareAndMapping } from '../node-option-utils'
import { NodeTypeEnum } from '@/config/enum'
import { Variable } from '../../../model/nodeParams_model'
import fieldMappingTable from '../../../biz_components/components/fieldMappingTable'
import { validateFn } from '@/utils/validator'
import { autoMappingTitle } from '@/components/flow-node/model/config'
export default {
  components: { ParamList, JsonTree, JsonAutoResolveDialog, Variables, fieldMappingTable },
  props: {
    nodeFormData: {
      required: true,
      type: Object
    }
  },
  inject: ['formDisabled', 'nodeMap', 'getFormData'],
  mixins: [mixinResolveNodeName, jsonAutoResolveMixin],
  data() {
    return {
      activeName: 'params',
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.synchronizedDto.maxHold': [
          { required: true, validator: validateFn.checkNum({ min: 0, max: 2147483647, notNull: true, isPositiveNumber: true }), trigger: 'blur' }
        ],
        'nodeParamsLogicDto.synchronizedDto.maxWait': [
          { required: true, validator: validateFn.checkNum({ min: 0, max: 2147483647, notNull: true, isPositiveNumber: true }), trigger: 'blur' }
        ],
        'nodeParamsLogicDto.synchronizedDto.fieldMappingList': [
          { required: true, message: '请设置枷锁资源标识', trigger: 'change', type: 'array' }
        ]
      },
      jsonTreeDialogVisible: false,
      selectNodeId: null,
      sourceData: [],
      currentRow: null,
      code2Text,
      DataTypeEnum: [],
      apiOutParamList: [],
      autoMappingTitle,
      ignoreDataType: false
    }
  },
  computed: {
    formData() {
      return this.getFormData()
    },
    synchronizedDto() {
      return this.nodeFormData.nodeParamsLogicDto.synchronizedDto
    }
  },
  async created() {
    [this.DataTypeEnum] = await this.getDicts(['DataTypeEnum'])
    this.selectNodeId = resolveDefaultNode(this.synchronizedDto.lockFailedMappingList, this.nodeFormData, this.nodeMap)
    // 补充提交数据时删掉的空row
    this.apiOutParamList = this.resolveApiOutParamList()
    this.synchronizedDto.lockFailedMappingList = fillMappingTable(this.apiOutParamList, this.synchronizedDto.lockFailedMappingList)
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    resolveApiOutParamList() {
      const nodeId = this.nodeFormData.id
      const node = this.nodeMap.get(nodeId)
      const parent = node.parent
      if (!parent) {
        return this.formData.apiOutParamList
      } else {
        const parentNode = this.nodeMap.get(parent)
        if (parentNode.type === NodeTypeEnum.CHOICE) {
          return parentNode.nodeParamsLogicDto.choiceDto.outputParamList
        } else if (parentNode.type === NodeTypeEnum.FOREACH) {
          return parentNode.nodeParamsLogicDto.forEachDto.outputParamList
        } else if (parentNode.type === NodeTypeEnum.SYNC) {
          return parentNode.nodeParamsLogicDto.synchronizedDto.outputParamList
        } else if (parentNode.type === NodeTypeEnum.ASYNC) { // 异步节点里嵌套同步节点，返回值为空
          return []
        }
      }
    },
    handleAddVariable(list) {
      list.push(new Variable())
    },
    eventLinstener({ type, row, _list, title }) {
      switch (type) {
        case 'currentChange':
          this.currentChange(title, row)
          break
      }
    },
    currentChange(title, row) {
      if (title === 'inParamTable') {
        this.currentRow = row
      }
    },
    // 右击目标数据设置对应行高亮
    async targetRightClick(treeNode) {
      this.$refs.inParamTable.setCurrentRow(treeNode)
      await this.$nextTick()
      // 点击时修改当前行的数据类型
      this.currentRow.dataType = treeNode.dataType
    },
    // 右击源数据填充到高亮行
    sourceRightClick(treeNode, selectNodeId, selectNode) {
      if (!selectNodeId) selectNodeId = this.nodeFormData.id

      if (!this.currentRow) {
        this.$message.error('请先选中行')
      } else {
        if (this.currentRow.referenceType === 0) { return this.$message.error('固定值请自行输入') }
        this.currentRow.sourceNodePath = treeNode.path
        this.currentRow.sourceNodeKey = selectNodeId
        this.currentRow.sourceNodeName = selectNode.name
        this.currentRow.sourceDataType = treeNode.dataType
        this.$refs.inParamTable.activeNextRow()
      }
    },
    showJsonTree() {
      this.jsonTreeDialogVisible = true
    },
    rightClick(node, nodeId) {
      const dataType = node.dataType
      const genericType = node.generic
      if (!(dataType === 8 && genericType === 7)) {
        return this.$message.error('必须选择元素泛型为对象的数组')
      }
      this.jsonTreeDialogVisible = false
      this.$set(this.synchronizedDto, 'nodeKey', nodeId)
      this.$set(this.synchronizedDto, 'value', node.path)
      this.$set(this.synchronizedDto, 'generic', genericType)
    },
    confirmJsonData(data) {
      this.synchronizedDto[this.currentJsonKey] = data
      this.jsonDialogVisible = false
    },
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        removeNullRow(this.synchronizedDto.lockFailedMappingList)
        fn(valid)
      })
    },
    // 自动映射左右数据
    autoMappingList() {
      const leftTree = this.apiOutParamList
      const rightTree = this.sourceData
      const leftSelectRow = this.$refs.leftTree.getSelectRow()
      const rightSelectRow = this.$refs.rightTree.getSelectRow()
      if (!leftTree || !rightTree || leftTree.length === 0 || rightTree.length === 0) {
        return this.$message.error('匹配失败，数据不完整')
      }
      // 进行匹配映射
      compareAndMapping({ leftTree, rightTree, leftSelectRow, rightSelectRow, mappingList: this.synchronizedDto.lockFailedMappingList, rightNodeId: this.selectNodeId, ignoreDataType: this.ignoreDataType })
    }
  }
}
</script>

<style>

</style>
