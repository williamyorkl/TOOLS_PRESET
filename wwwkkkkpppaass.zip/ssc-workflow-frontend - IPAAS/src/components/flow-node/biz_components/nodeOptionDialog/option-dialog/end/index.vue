<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" maxlength="32" />
    </el-form-item>

    <el-form-item label="配置出参">
      <mc-form-item-label slot="label" label="配置出参" icon="el-icon-info">
        1、「右键」目标数据，可自动选中下方列表中对应行，「右键」源数据可将选中数据填充至下方列表，并自动切换至下一行 <br>
        2、「单击」下方表格某一行则可选中行
      </mc-form-item-label>
      <el-card>
        <el-row :gutter="20">
          <el-col :span="12">
            <JsonTree ref="leftTree" title="目标数据" :data="apiOutParamList" :allowEdit="false" :multipleNode="false" @rightClick="targetRightClick" />
          </el-col>
          <el-col :span="12" id="tour-end-sourceData">
            <JsonTree ref="rightTree" title="源数据" :selectNodeId.sync="selectNodeId" :multipleNode="true" :data.sync="sourceData" :allowEdit="false" @rightClick="sourceRightClick" />
          </el-col>
        </el-row>
      </el-card>
    </el-form-item>
    <el-form-item v-if="!formDisabled">
      <el-popconfirm :title="autoMappingTitle" @confirm="autoMappingList">
        <el-button slot="reference">自动映射</el-button>
      </el-popconfirm>
      忽略参数类型 <el-checkbox v-model="ignoreDataType" />
    </el-form-item>
    <el-form-item label="字段映射" id="tour-end-mappingList">
      <fieldMappingTable processType="end" :allowAdd="false" class="" ref="inParamTable" title="inParamTable" :tableList="nodeParamsEndDto.mappingList" @eventLinstener="eventLinstener" />
    </el-form-item>
  </el-form>
</template>

<script>
import JsonTree from '../../../components/jsonTree'
import { resolveDefaultNode, fillMappingTable, compareAndMapping, resolveEndNodeOutParamList } from '../../node-option-utils'
import fieldMappingTable from '../../../../biz_components/components/fieldMappingTable'
import { autoMappingTitle } from '@/components/flow-node/model/config'
export default {
  components: { JsonTree, fieldMappingTable },
  props: {
    nodeFormData: {
      required: true,
      type: Object
    },
    formData: {
      required: true,
      type: Object
    }
  },
  inject: ['formDisabled', 'nodeMap'],
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ]
      },
      selectNodeId: null,
      sourceData: [],
      currentRow: null,
      apiOutParamList: [],
      autoMappingTitle,
      ignoreDataType: false
    }
  },
  computed: {
    nodeParamsEndDto() {
      return this.nodeFormData.nodeParamsLogicDto.nodeParamsEndDto
    }
  },
  created() {
    this.selectNodeId = resolveDefaultNode(this.nodeParamsEndDto.mappingList, this.nodeFormData, this.nodeMap)
    this.apiOutParamList = resolveEndNodeOutParamList({ nodeId: this.nodeFormData.id, nodeMap: this.nodeMap, formData: this.formData })
    this.nodeParamsEndDto.mappingList = fillMappingTable(this.apiOutParamList, this.nodeParamsEndDto.mappingList)
  },
  methods: {
    // 右击目标数据设置对应行高亮
    async targetRightClick(treeNode) {
      this.$refs.inParamTable.setCurrentRow(treeNode)
      await this.$nextTick()
      // 点击时修改当前行的数据类型
      this.currentRow.dataType = treeNode.dataType
    },
    // 右击源数据填充到高亮行
    sourceRightClick(treeNode, selectNodeId, selectNode) {
      if (!selectNodeId) selectNodeId = this.nodeFormData.id

      if (!this.currentRow) {
        this.$message.error('请先选中行')
      } else {
        if (this.currentRow.referenceType === 0) { return this.$message.error('固定值请自行输入') }
        this.currentRow.sourceNodePath = treeNode.path
        this.currentRow.sourceNodeKey = selectNodeId
        this.currentRow.sourceNodeName = selectNode.name
        this.currentRow.sourceDataType = treeNode.dataType
        this.$refs.inParamTable.activeNextRow()
      }
    },
    eventLinstener({ type, row, _list, title }) {
      switch (type) {
        case 'currentChange':
          this.currentChange(title, row)
          break
      }
    },
    currentChange(title, row) {
      if (title === 'inParamTable') {
        this.currentRow = row
      }
    },
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        fn(valid)
      })
    },
    // 自动映射左右数据
    autoMappingList() {
      const leftTree = this.apiOutParamList
      const rightTree = this.sourceData
      const leftSelectRow = this.$refs.leftTree.getSelectRow()
      const rightSelectRow = this.$refs.rightTree.getSelectRow()
      if (!leftTree || !rightTree || leftTree.length === 0 || rightTree.length === 0) {
        return this.$message.error('匹配失败，数据不完整')
      }
      // 进行匹配映射
      compareAndMapping({ leftTree, rightTree, leftSelectRow, rightSelectRow, mappingList: this.nodeParamsEndDto.mappingList, rightNodeId: this.selectNodeId, ignoreDataType: this.ignoreDataType })
    }
  }
}
</script>

<style>

</style>
