<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" maxlength="32" />
    </el-form-item>

    <el-form-item label="DB数据源" prop="nodeParamsLogicDto.nodeParamsDbDto.dbId" id="tour-db">
      <mc-popover-select v-model="nodeParamsDbDto.dbId" clearable :disabled="formDisabled" :defaultValue="nodeParamsDbDto.dbName" :apiFunc="dbListApiFunc" :tableColumn="dbTableColumn" :param="{usable: true}" :queryList="dbQueryList" labelKey="dataBaseName" valueKey="id" @changeRow="dbRowClick" />
    </el-form-item>
    <mc-list :list="nodeParamsDbDto.sqlList" @handleAdd="handleSqlAdd" :limit="1">
      <template slot-scope="scope">
        <sqlItem :nodeFormData="nodeFormData" :sqlItemData="scope.item" :index="scope.index" :dbTableList="dbTableList" />
      </template>
    </mc-list>
  </el-form>
</template>

<script>
import { SqlParams } from '../../../../model/nodeParams_model'
import databaseApi from '@/api/database'
import { mapActions } from 'vuex'
import sqlItem from './sqlItem.vue'
import { getTableColumn as getDbTableColumn, getQueryList as getDbQueryList } from '@/config/popContentTableConfig/db.config'

export default {
  components: { sqlItem },
  props: {
    nodeFormData: {
      type: Object,
      default: () => ({})
    },
    formData: {
      type: Object,
      default: () => ({})
    }
  },
  inject: ['formDisabled', 'nodeMap'],
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.nodeParamsDbDto.dbId': [
          { required: true, message: '请选择数据源', trigger: 'change' }
        ]
      },
      databaseList: [],
      DbSqlMethodEnum: [],
      dbTableList: [],
      dbListApiFunc: databaseApi.getDatabaseList,
      dbTableColumn: getDbTableColumn(),
      dbQueryList: getDbQueryList(),
      options: {
        mode: { name: 'sql', json: true },
        theme: 'base16-dark',
        lineNumbers: true
      }
    }
  },
  computed: {
    nodeParamsDbDto() {
      return this.nodeFormData.nodeParamsLogicDto.nodeParamsDbDto
    }
  },
  async created() {
    this.DbSqlMethodEnum = await this.getDicts('DbSqlMethodEnum')
    await this.getDicts('DataTypeEnum')
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    dbRowClick(row) {
      this.nodeParamsDbDto.dbName = row.dataBaseName
      this.nodeParamsDbDto.sqlList = [new SqlParams()]
      this.nodeParamsDbDto.dataBaseType = row.dataBaseType
    },
    // 添加一条sql数据
    handleSqlAdd() {
      if (!this.nodeParamsDbDto.sqlList) {
        this.$set(this.nodeParamsDbDto, 'sqlList', [])
      }
      this.nodeParamsDbDto.sqlList.push(new SqlParams())
    },
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        fn(valid)
      })
    }
  }
}
</script>

<style>

</style>
