<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" maxlength="32" />
    </el-form-item>
    <el-row :gutter="20">
      <el-col :span="12">
        <el-form-item label="后端服务" prop="nodeParamsLogicDto.nodeParamsRpcDto.apiId" id="tour-rpc-apiId">
          <mc-popover-select v-model="nodeParamsRpcDto.apiId" :disabled="formDisabled" :defaultValue="nodeParamsRpcDto.apiName || nodeParamsRpcDto.methodName" :apiFunc="interfaceApi.getInterfaceList" :tableColumn="nativeApiTableColumn" :queryList="nativeApiQueryList" labelKey="apiName" valueKey="id" @changeRow="rowClick" :validateRowData="validateParamValidatorRowData" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-button @click="showApiInfo(nodeParamsRpcDto.apiId)">查看接口信息</el-button>
        <!-- http | springcloud | dubbo可以配置回滚接口 -->
        <el-button @click="showRollbackInfo(nodeParamsRpcDto.apiId)" v-if="[0,1,2].includes(nodeParamsRpcDto.interfaceType)">查看回滚接口</el-button>
      </el-col>
    </el-row>
    <!-- 不同类型接口轩然不同组件 -->
    <component :is="currentComponent" :nodeParamsRpcDto="nodeParamsRpcDto" />

    <el-form-item label="配置入参">
      <mc-form-item-label slot="label" label="配置入参" icon="el-icon-info">
        1、「右键」目标数据，可自动选中下方列表中对应行，「右键」源数据可将选中数据填充至下方列表，并自动切换至下一行 <br>
        2、「单击」下方表格某一行则可选中行
      </mc-form-item-label>
      <el-card>
        <el-row :gutter="20">
          <el-col :span="12">
            <JsonTree ref="leftTree" title="目标数据" :data="nodeParamsRpcDto.inputParamList" :allowEdit="false" :multipleNode="false" @rightClick="targetRightClick" />
          </el-col>
          <el-col :span="12" id="tour-rpc-sourceData">
            <JsonTree ref="rightTree" title="源数据" :selectNodeId.sync="selectNodeId" :multipleNode="true" :data.sync="sourceData" :allowEdit="false" @rightClick="sourceRightClick" />
          </el-col>
        </el-row>
      </el-card>
    </el-form-item>
    <el-form-item v-if="!formDisabled">
      <el-popconfirm :title="autoMappingTitle" @confirm="autoMappingList">
        <el-button slot="reference">自动映射</el-button>
      </el-popconfirm>
      忽略参数类型 <el-checkbox v-model="ignoreDataType" />
    </el-form-item>
    <el-form-item label="字段映射" id="tour-rpc-mappingList">
      <!-- {{nodeParamsRpcDto.mappingList}} -->
      <fieldMappingTable :allowAdd="false" class="" ref="inParamTable" title="inParamTable" :tableList="nodeParamsRpcDto.mappingList" @eventLinstener="eventLinstener" />
    </el-form-item>
    <!-- 回滚配置弹窗 -->
    <RollbackDialog :formData.sync="rollbackFormData" :visible.sync="rollbackDialogVisible" mode="view" title="回滚接口配置信息" width="1000px" />

    <!-- 接口详情的弹窗 -->
    <ViewApiDialog1 :formData.sync="currentApi" :visible.sync="ViewApiDialog1Visible1" mode="view" title="接口详情" width="70%" :jsonData="jsonData" :jsonData2="jsonData2" :appendToBody="true" />
    <ViewApiDialog2 :formData.sync="currentApi" :visible.sync="ViewApiDialog1Visible2" mode="view" title="接口详情" width="70%" :appendToBody="true" />
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
import JsonTree from '../../../components/jsonTree'
import interfaceApi from '@/api/interface'
import { getCurrentComponent } from './utils'
import { deepClone } from '@/utils'
import { validateFn } from '@/utils/validator'
import { formatterParamList, resolveDefaultNode, fillMappingTable, removeNullRow, compareAndMapping } from '../../node-option-utils'
import { getTableColumn as getNativeApiTableColumn, getQueryList as getNativeApiQueryList } from '@/config/popContentTableConfig/nativeInterface.config'
import DubboOption from './components-option/dubbo-option'
import HttpOption from './components-option/http-option'
import SapOption from './components-option/sap-option'
import SoapOption from './components-option/soap-option'
import { RollbackForm } from '@/views/serviceRegister/interfaceManage/model/model'
import RollbackDialog from '@/views/serviceRegister/interfaceManage/components/rollback-dialog.vue'
import ViewApiDialog1 from '@/views/serviceRegister/interfaceManage/components/view-dialog.vue'
import ViewApiDialog2 from '@/views/serviceRegister/interfaceManage/components/edit-dialog.vue'
import fieldMappingTable from '../../../../biz_components/components/fieldMappingTable'
import { autoMappingTitle } from '@/components/flow-node/model/config'

export default {
  components: {
    JsonTree,
    DubboOption,
    HttpOption,
    SapOption,
    SoapOption,
    NativeOption: DubboOption, // native和dubbo配置一样
    SpringcloudOption: HttpOption, // springcloud和http配置一样
    LocalOption: DubboOption, // local和dubbo一样
    RollbackDialog,
    ViewApiDialog1,
    ViewApiDialog2,
    fieldMappingTable
  },
  props: {
    nodeFormData: {
      required: true,
      type: Object
    },
    formData: {
      required: true,
      type: Object
    }
  },
  inject: ['formDisabled', 'nodeMap'],
  data() {
    return {
      nativeApiTableColumn: getNativeApiTableColumn(),
      nativeApiQueryList: getNativeApiQueryList({ allType: true }),
      interfaceApi,
      ServiceTypeEnum: [],
      DataTypeEnum: [],
      currentApi: null,
      jsonData: [],
      jsonData2: [],
      ViewApiDialog1Visible1: false,
      ViewApiDialog1Visible2: false,
      rollbackDialogVisible: false,
      rollbackFormData: {},
      currentRow: null,
      sourceData: [],
      selectNodeId: null,
      autoMappingTitle,
      ignoreDataType: false,
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.nodeParamsRpcDto.apiId': [
          { required: true, message: '请选择后端服务', trigger: 'change' }
        ],
        'nodeParamsLogicDto.nodeParamsRpcDto.apiRequestTimeout': [
          { required: true, message: '请输入超时时间', trigger: 'blur' },
          { validator: validateFn.checkNum({ notNull: false, min: 0, max: 300000 }), message: '请输入0~300000之间的数值', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.nodeParamsRpcDto.retryNum': [
          { required: true, message: '请输入重试次数', trigger: 'blur' },
          { validator: validateFn.checkNum({ notNull: false, min: 0, max: 20 }), message: '请输入0~20之间的数值', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.nodeParamsRpcDto.fallBack': [
          { required: true, message: '请选择fallBack', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.nodeParamsRpcDto.forwardHeaderParams': [
          // { validator: validateFn.checkLength()}
        ]
      }
    }
  },
  async created() {
    [this.ServiceTypeEnum, this.DataTypeEnum] = await this.getDicts(['ServiceTypeEnum', 'DataTypeEnum'])
    this.nativeApiQueryList = getNativeApiQueryList({ allType: true, ServiceTypeEnum: this.ServiceTypeEnum })
    this.selectNodeId = resolveDefaultNode(this.nodeParamsRpcDto.mappingList, this.nodeFormData, this.nodeMap)
    this.nodeParamsRpcDto.mappingList = fillMappingTable(this.nodeParamsRpcDto.inputParamList, this.nodeParamsRpcDto.mappingList)
  },
  computed: {
    nodeParamsRpcDto() {
      return this.nodeFormData.nodeParamsLogicDto.nodeParamsRpcDto
    },
    currentComponent() {
      return getCurrentComponent(this.nodeParamsRpcDto.interfaceType)
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    validateParamValidatorRowData(row) {
      // 检测参数校验选中的接口是否是原接口
      if (row.id === this.formData.id) {
        return '不能选择原接口'
      } else {
        return 'RESOLVE'
      }
    },
    // 右击目标数据设置对应行高亮
    async targetRightClick(treeNode) {
      this.$refs.inParamTable.setCurrentRow(treeNode)
      await this.$nextTick()
      // 点击时修改当前行的数据类型
      this.currentRow.dataType = treeNode.dataType
    },
    // 右击源数据填充到高亮行
    sourceRightClick(treeNode, selectNodeId, selectNode) {
      if (!selectNodeId) selectNodeId = this.nodeFormData.id

      if (!this.currentRow) {
        this.$message.error('请先选中行')
      } else {
        if (this.currentRow.referenceType === 0) { return this.$message.error('固定值请自行输入') }
        this.currentRow.sourceNodePath = treeNode.path
        this.currentRow.sourceNodeKey = selectNodeId
        this.currentRow.sourceNodeName = selectNode.name
        this.currentRow.sourceDataType = treeNode.dataType
        this.$refs.inParamTable.activeNextRow()
      }
    },
    eventLinstener({ type, row, _list, title }) {
      switch (type) {
        case 'currentChange':
          this.currentChange(title, row)
          break
      }
    },
    currentChange(title, row) {
      if (title === 'inParamTable') {
        this.currentRow = row
      }
    },

    // 查看接口详情
    showApiInfo(id) {
      if (!id) return
      this.view()
    },
    // 查看回滚信息
    async showRollbackInfo(id) {
      if (!id) return
      const resp = await interfaceApi.detailRollback({ apiId: id })
      this.rollbackFormData = deepClone(Object.assign(new RollbackForm({ apiId: id }), resp || {}))
      this.rollbackDialogVisible = true
    },
    // 查看信息，分dubbo  和   http|springcloud两种
    async view() {
      const row = await interfaceApi.interfaceDetail({ id: this.nodeParamsRpcDto.apiId, apiType: this.nodeParamsRpcDto.apiType })
      this.currentApi = row
      // 判断是哪种类型,dubbo和springcloud/http/native使用不同的弹窗
      if (row.serviceType === 1 || row.serviceType === 2 || row.serviceType === 3) {
      // http|springcloud
        this.currentApi.inputParamList = JSON.parse(this.currentApi.inputParam || null) || []
        this.currentApi.outputParamList = JSON.parse(this.currentApi.outputParam || null) || []
        this.ViewApiDialog1Visible2 = true
      } else {
      // dubbo | local | native | soap, 直接使用inputParamList和outputParamList,不再使用inputParamTmp
        this.jsonData = formatterParamList(
          row.inputParamList,
          this.DataTypeEnum
        )
        this.jsonData2 = formatterParamList(
          row.outputParamList,
          this.DataTypeEnum
        )
        this.ViewApiDialog1Visible1 = true
      }
    },
    rowClick(row) {
      this.nodeFormData.name = row.apiName || this.nodeFormData.name // 使用接口名称覆盖节点名称
      this.nodeParamsRpcDto.apiRequestTimeout = row.timeout // 超时时间
      this.nodeParamsRpcDto.retryNum = row.retryNum // 重试次数
      this.nodeParamsRpcDto.interfaceType = row.serviceType // 接口类型
      this.nodeParamsRpcDto.apiType = row.apiType
      this.nodeParamsRpcDto.apiName = row.apiName
      this.nodeParamsRpcDto.methodName = row.methodName
      this.nodeParamsRpcDto.tenantId = row.tenantId

      // 如果是http或springcloud或soap，将入参和出参存下来，入参作为请求参数的目标数据，出参作为其他下游节点的源数据
      this.nodeParamsRpcDto.inputParamList = row.inputParamList || [] // 接口入参
      this.nodeParamsRpcDto.outputParamList = row.outputParamList || [] // 接口出参
      this.nodeParamsRpcDto.mappingList = fillMappingTable(
        row.inputParamList,
        this.nodeParamsRpcDto.mappingList
      )
    },
    // 从外部调用，触发表单校验
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        removeNullRow(this.nodeParamsRpcDto.mappingList)
        fn(valid)
      })
    },
    // 自动映射左右数据
    autoMappingList() {
      const leftTree = this.nodeParamsRpcDto.inputParamList
      const rightTree = this.sourceData
      const leftSelectRow = this.$refs.leftTree.getSelectRow()
      const rightSelectRow = this.$refs.rightTree.getSelectRow()
      if (!leftTree || !rightTree || leftTree.length === 0 || rightTree.length === 0) {
        return this.$message.error('匹配失败，数据不完整')
      }
      // 进行匹配映射
      compareAndMapping({ leftTree, rightTree, leftSelectRow, rightSelectRow, mappingList: this.nodeParamsRpcDto.mappingList, rightNodeId: this.selectNodeId, ignoreDataType: this.ignoreDataType })
    }
  }
}
</script>

<style>

</style>
