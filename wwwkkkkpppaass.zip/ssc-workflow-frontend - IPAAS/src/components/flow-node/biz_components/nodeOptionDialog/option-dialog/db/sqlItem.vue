<template>
  <mc-collapse-panel class="sql-item" :label="'SQL' + (index + 1)" :initState="false" :disabled="formDisabled">
    <el-form-item slot="desc" label="SQL描述" labelWidth="70px">
      <el-input v-model.trim="sqlItemData.description" placeholder="请输入SQL描述" maxlength="32" :disabled="formDisabled" />
    </el-form-item>
    <!-- <el-input slot="desc" v-model="sqlItemData.description" maxlength="128" :disabled="formDisabled" placeholder="请输入SQL描述"></el-input> -->
    <el-row :gutter="10">
      <el-col :span="12">
        <el-form-item label="输入SQL">
          <el-switch v-model.trim="sqlItemData.isInputSql" :activeValue="1" :inactiveValue="0" @change="isInputSqlChange" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="超时时间(s)" :rules="rules.timeOut" :prop="'nodeParamsLogicDto.nodeParamsDbDto.sqlList.' + index + '.timeOut'">
          <el-input v-model.number="sqlItemData.timeOut" type="number" />
        </el-form-item>
      </el-col>
      <el-col :span="12" v-if="sqlItemData.isInputSql">
        <el-form-item label="查询记录总数">
          <el-switch v-model="sqlItemData.queryCount" />
        </el-form-item>
      </el-col>
    </el-row>
    <!-- 输入SQL开启时显示，显示输入框用户自定义SQL -->
    <template v-if="sqlItemData.isInputSql === 1">
      <el-divider />
      <!-- sql变量列表 -->
      <el-form-item label="SQL变量" class="lazy-render-wrap" v-loading="!lazyRender">
        <ReferenceParamList v-if="lazyRender" :tableList="sqlItemData.referenceFieldList" :columnMap="columnMap" title="reference" @eventLinstener="eventLinstener" :includeSelf="true" :nodeFormData="nodeFormData" :index="index" />
      </el-form-item>
      <el-divider />
      <el-form-item label="SQL语句">
        <mc-form-item-label slot="label" label="SQL语句" :description="sqlTips" icon="el-icon-info" />
        <codemirror v-model.trim="sqlItemData.textSql" @blur="textareaBlur" :options="options" class="code-container" />
      </el-form-item>
      <el-divider />
      <el-form-item label="结果映射" class="lazy-render-wrap" v-loading="!lazyRender">
        <ResultParamList v-if="lazyRender" :tableList="sqlItemData.selectFieldList" :columnList="columnList" :columnMap="columnMap" title="select" @eventLinstener="eventLinstener" />
      </el-form-item>
    </template>

    <!-- 不输入SQL，通过配置生成操作 -->
    <template v-else>
      <el-row :gutter="10" :id="'tour-isInputSql-' + index">
        <el-col :span="12">
          <el-form-item label="SQL操作" :rules="rules.sqlMethod" :prop="'nodeParamsLogicDto.nodeParamsDbDto.sqlList.' + index + '.sqlMethod'">
            <el-select v-model="sqlItemData.sqlMethod" clearable placeholder="请选择SQL方法" @change="sqlMethodChange">
              <el-option v-for="item in DbSqlMethodEnum" :key="item.desc" :value="item.desc" :label="item.desc" />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="数据表" :rules="rules.tableName" :prop="'nodeParamsLogicDto.nodeParamsDbDto.sqlList.' + index + '.tableName'">
            <mc-popover-select v-model="sqlItemData.tableName" clearable :defaultValue="sqlItemData.tableName" :apiFunc="tableApiFunc" :tableColumn="tablesTableColumn" :queryList="tablesQueryList" labelKey="tableName" valueKey="tableName" @changeRow="rowClick" :param="{id: nodeParamsDbDto.dbId}" />
          </el-form-item>
        </el-col>
        <el-col :span="12" v-if="sqlItemData.sqlMethod === 'select'">
          <el-form-item label="查询记录总数">
            <el-switch v-model="sqlItemData.queryCount" />
          </el-form-item>
        </el-col>
        <template>
          <el-col :span="12" v-if="['batch_insert_or_update', 'batch_insert', 'batch_update'].includes(sqlItemData.sqlMethod)">
            <!-- 从前置节点选一个数组 -->
            <el-form-item label="数据集" :rules="rules.collectionName" :prop="'nodeParamsLogicDto.nodeParamsDbDto.sqlList.' + index + '.collectionName'">
              <el-input v-model="sqlItemData.collectionName" placeholder="请选择" :readonly="true">
                <el-button slot="append" icon="el-icon-setting" @click="showJsonTree" />
              </el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12" v-if="sqlItemData.collectionNodeKey && ['batch_insert_or_update', 'batch_insert', 'batch_update'].includes(sqlItemData.sqlMethod)">
            <!-- 数据集所属节点 -->
            <el-form-item label="数据集节点">
              <el-input :value="resolveNodeName(sqlItemData.collectionNodeKey, nodeMap)" placeholder="请选择" :disabled="true" />
            </el-form-item>
          </el-col>
          <!-- 目前仅支持MySQL数据库 -->
          <el-col :span="12" v-if="['insert', 'batch_insert', 'batch_insert_or_update'].includes(sqlItemData.sqlMethod) && nodeParamsDbDto.dataBaseType === 1">
            <el-form-item label="返回主键ID">
              <el-switch v-model="sqlItemData.returnPkFlag" :activeValue="1" :inactiveValue="0" />
            </el-form-item>
          </el-col>
        </template>
      </el-row>
      <!-- 连接条件：relation_select独有 -->
      <template v-if="sqlItemData.sqlMethod === 'relation_select'">
        <el-divider />
        <el-form-item label="连接条件" class="lazy-render-wrap" v-loading="!lazyRender">
          <RelationParamList v-if="lazyRender" :sqlItemData="sqlItemData" :tableList="sqlItemData.relationSelectList" :columnList="columnList" :columnMap="columnMap" title="relation_select" @eventLinstener="eventLinstener" :DbSqlJoinEnum="DbSqlJoinEnum" :relationTableFieldList="relationTableFieldList" :nodeFormData="nodeFormData" :index="index" @handleUpdateSubColumnMap="handleUpdateSubColumnMap" />
        </el-form-item>
      </template>
      <!-- on条件：relation_select独有 -->
      <template v-if="sqlItemData.sqlMethod === 'relation_select'">
        <el-divider />
        <el-form-item label="on条件" class="lazy-render-wrap" v-loading="!lazyRender">
          <OnParamList v-if="lazyRender" :tableList="sqlItemData.relationSelectOnList" :columnList="columnList" :columnMap="columnMap" title="relation_select_on" @eventLinstener="eventLinstener" :DbSqlJoinEnum="DbSqlJoinEnum" :nodeFormData="nodeFormData" :index="index" :relationTableList="relationTableList" />
        </el-form-item>
      </template>
      <template v-if="['batch_insert_or_update', 'batch_update', 'batch_insert'].includes(sqlItemData.sqlMethod)">
        <el-button @click="autoFill">自动映射</el-button>
        忽略参数类型 <el-checkbox v-model="ignoreDataType" />
      </template>
      <!-- 选择表字段有两种情况，select|relation_select一种；insert|update|batch_insert_or_update一种 -->
      <template v-if="['select', 'relation_select'].includes(sqlItemData.sqlMethod)">
        <el-divider />
        <el-form-item label="选择表字段" class="lazy-render-wrap" v-loading="!lazyRender">
          <SelectParamList v-if="lazyRender" :tableList="sqlItemData.selectFieldList" :sqlMethod="sqlItemData.sqlMethod" :columnList="columnList" :columnMap="columnMap" title="select" @eventLinstener="eventLinstener" />
        </el-form-item>
      </template>
      <template v-if="['insert', 'update', 'batch_insert_or_update', 'batch_insert', 'batch_update'].includes(sqlItemData.sqlMethod)">
        <el-divider />
        <el-form-item label="选择表字段" class="lazy-render-wrap" v-loading="!lazyRender">
          <UpdateParamList v-if="lazyRender" :key="sqlItemData.sqlMethod" :sqlMethod="sqlItemData.sqlMethod" :tableList="sqlItemData.updateFieldList" :columnList="columnList" :columnMap="columnMap" title="update" :nodeId="sqlItemData.mainKeyNameNodeKey" @eventLinstener="eventLinstener" :collectionFields="collectionFields" :includeSelf="true" :nodeFormData="nodeFormData" :index="index" />
        </el-form-item>
      </template>

      <!-- where条件: insert外的3中类型都有 -->
      <template v-if="sqlItemData.sqlMethod && ['update', 'select', 'delete', 'batch_update', 'relation_select'].includes(sqlItemData.sqlMethod)">
        <el-divider />
        <el-form-item label="where条件" class="lazy-render-wrap" v-loading="!lazyRender">
          <WhereParamList v-if="lazyRender" :sqlMethod="sqlItemData.sqlMethod" :tableList="sqlItemData.whereFieldList" :columnList="columnList" :columnMap="columnMap" title="where" :nodeId="sqlItemData.mainKeyNameNodeKey" @eventLinstener="eventLinstener" :collectionFields="collectionFields" :includeSelf="true" :nodeFormData="nodeFormData" :index="index" />
        </el-form-item>
      </template>
      <!-- 排序和分页: 只有select|relation_select有 -->
      <template v-if="['select', 'relation_select'].includes(sqlItemData.sqlMethod)">
        <el-divider />
        <el-form-item label="排序" class="lazy-render-wrap" v-loading="!lazyRender">
          <SortParamList v-if="lazyRender" :tableList="sqlItemData.sortFieldList" :columnList="columnList" :columnMap="columnMap" title="sort" @eventLinstener="eventLinstener" />
        </el-form-item>
      </template>
      <template v-if="['select', 'relation_select'].includes(sqlItemData.sqlMethod)">
        <el-divider />
        <el-form-item label="分页">
          <PageParamList :tableList="sqlItemData.pageFieldList" title="page" @eventLinstener="eventLinstener" :includeSelf="true" :nodeFormData="nodeFormData" :index="index" />
        </el-form-item>
      </template>
    </template>

    <!-- 数据源json弹窗 -->
    <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px" v-if="jsonTreeDialogVisible">
      <JsonTree title="源数据" :selectNodeId.sync="sqlItemData.collectionNodeKey" :data.sync="sourceData" @rightClick="rightClick" :multipleNode="true" :includeSelf="true" />
    </el-dialog>
  </mc-collapse-panel>
</template>

<script>
import { mapActions } from 'vuex'
import {
  SqlParams,
  UpdateField,
  WhereField,
  SortField,
  SelectField,
  PageField,
  ReferenceField,
  SelectRelationField,
  RelationOnField,
  SelectRelationChildField
} from '@/components/flow-node/model/nodeParams_model.js'
import arrangeApi from '@/api/arrange'
import ResultParamList from '@/components/flow-node/biz_components/components/paramList/resultParamList'
import SelectParamList from '@/components/flow-node/biz_components/components/paramList/selectParamList'
import RelationParamList from '@/components/flow-node/biz_components/components/paramList/relation-param-list'
import UpdateParamList from '@/components/flow-node/biz_components/components/paramList/updateParamList'
import WhereParamList from '@/components/flow-node/biz_components/components/paramList/whereParamList'
import SortParamList from '@/components/flow-node/biz_components/components/paramList/sortParamList'
import PageParamList from '@/components/flow-node/biz_components/components/paramList/pageParamList'
import ReferenceParamList from '@/components/flow-node/biz_components/components/paramList/referenceParamList'
import OnParamList from '@/components/flow-node/biz_components/components/paramList/on-param-list'
import { codemirror } from 'vue-codemirror'
import 'codemirror/lib/codemirror.css'
import 'codemirror/theme/base16-dark.css'
import { validateFn } from '@/utils/validator'
import JsonTree from '@/components/flow-node/biz_components/components/jsonTree'
import { expandTree, deepClone, toHump } from '@/utils'
import 'codemirror/mode/sql/sql.js'
import 'codemirror/addon/display/placeholder.js'
import tablesOption from '@/config/popContentTableConfig/table.config.js'
import dbApi from '@/api/database'
import { resolveOutputParamList, formatterParamList, validDbCanUse } from '@/components/flow-node/biz_components/nodeOptionDialog/node-option-utils'
import mixinResolveNodeName from '@/components/flow-node/mixins/resolveNodeName'

export default {
  components: {
    OnParamList,
    RelationParamList,
    ResultParamList,
    SelectParamList,
    UpdateParamList,
    WhereParamList,
    SortParamList,
    PageParamList,
    ReferenceParamList,
    codemirror,
    JsonTree
  },
  props: {
    index: {
      type: Number,
      default: 0
    },
    nodeFormData: {
      // 节点完整的配置数据
      type: Object,
      default: () => ({})
    },
    sqlItemData: {
      type: Object,
      default: () => (new SqlParams())
    },
    dbTableList: {
      type: Array,
      default: () => []
    }
  },
  mixins: [mixinResolveNodeName],
  inject: ['formDisabled', 'nodeMap', 'getFormData'],
  data() {
    return {
      lazyRender: false,
      options: {
        mode: { name: 'sql', json: true },
        theme: 'base16-dark',
        lineNumbers: true
      },
      DbSqlMethodEnum: [],
      jsonTreeDialogVisible: false,
      rules: {
        timeOut: [
          { required: true, validator: validateFn.checkNum({ min: 0, max: 2147483647, notNull: true, isPositiveNumber: true }), trigger: 'change' }
        ],
        sqlMethod: [
          { required: true, message: '请选择SQL操作', trigger: 'change' }
        ],
        tableName: [
          { required: true, message: '请选择数据表', trigger: 'change' }
        ],
        collectionName: [
          { required: true, message: '请选择数据集', trigger: 'change' }
        ]
      },
      sqlTips: '示例：select id,app_code,app_name  from flow_app where id in ($id) and app_name like concat("%",$name,"%") and app_code = $code;',
      tableApiFunc: tablesOption.apiFunc,
      tablesTableColumn: tablesOption.getTableColumn(),
      tablesQueryList: tablesOption.getQueryList(),
      columnList: [],
      selectNodeId: null,
      sourceData: [],
      // relation_select类型时，连接条件只选主表字段，选择表字段、where条件、排序需要主从都选，columnList用来存主从全部字段，mainColumnList用来存主表字段
      mainCloumnList: [],
      DbSqlJoinEnum: [],
      relationTableFieldList: [],
      mainRelationTableColumnList: [], // 主表field字段
      ignoreDataType: false
    }
  },
  watch: {
    'sqlItemData.tableName': {
      async handler(_nV) {
        await this.getCurrentTableColumnDtos(true)
        this.handleInitialRelationSubColumnMap()
      },
      immediate: true
    },
    'sqlItemData.sqlMethod': {
      handler(_nV, _oV) {
        this.getCurrentTableColumnDtos()
      }
    }
  },
  computed: {
    formData() {
      return this.getFormData()
    },
    nodeParamsDbDto() {
      return this.nodeFormData.nodeParamsLogicDto.nodeParamsDbDto
    },
    columnMap() {
      const map = new Map()

      this.columnList.forEach((item) => {
        map.set(item.name, item)
      })
      return map
    },
    // 所选数据集的所有字段
    collectionFields() {
      if (!this.sqlItemData.collectionName) return []
      const collectionNodeKey = this.sqlItemData.collectionNodeKey
      const collectionName = this.sqlItemData.collectionName
      // const selectNode = this.nodeList.find(item => item.id === collectionNodeKey)
      const selectNode = this.nodeMap.get(collectionNodeKey)
      const selectOutputList = resolveOutputParamList(selectNode, this.formData, this.nodeMap) // 获取所选节点的输出参数，找到当前节点所选的数据集输出字段，拉取字段的childrenList与filter的outputParamList比对，重复的为选中的
      const pathOutputList = formatterParamList(deepClone(selectOutputList), [])
      const list = expandTree(pathOutputList, 'childrenList') // 展开为一维数组
      const currentArray = list.find(item => item.path === collectionName) // 找到当前数据集
      if (!currentArray) {
        return []
      }
      return currentArray.childrenList || []
    },
    relationTableList() {
      let list = []
      list = this.nodeFormData.nodeParamsLogicDto.nodeParamsDbDto.sqlList[this.index].relationSelectList.map((item) => {
        return {
          relationTable: item.relationTable
        }
      }).filter(v => v.relationTable !== undefined && v.relationTable !== '' && v.relationTable !== null && v.relationTable)
      return list
    }
  },
  async created() {
    this.DbSqlMethodEnum = await this.getDicts('DbSqlMethodEnum')
    this.DbSqlJoinEnum = await this.getDicts('DbSqlJoinEnum')
  },
  mounted() {
    setTimeout(() => {
      this.lazyRender = true
    }, 300)
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    autoFill() {
      this.fieldMapping()
    },
    isInputSqlChange(_v) {
      this.sqlItemData.selectFieldList = []
      this.$set(this.sqlItemData, 'queryCount', false)
    },
    // blur解析sql语句
    async textareaBlur() {
      const oldList = this.sqlItemData.selectFieldList
      const newList = []
      const oldMap = new Map()
      const resp = await arrangeApi.parseSql({ sql: this.sqlItemData.textSql })
      oldList.forEach(item => { oldMap.set(item.fieldName, item) })
      resp.forEach(item => {
        let param = oldMap.get(item)
        if (!param) {
          param = new SelectField({ fieldName: item })
        }
        newList.push(param)
      })
      this.sqlItemData.selectFieldList = newList
    },
    sqlMethodChange() {
      this.tableChange()
    },
    async rowClick(_row) {
      this.getCurrentTableColumnDtos()
    },
    async getCurrentTableColumnDtos(isInit) {
      if (!this.nodeParamsDbDto.dbId || !this.sqlItemData.tableName) {
        this.columnList = []

        if (!isInit) {
          this.tableChange()
        }
        return
      }
      const resp = await dbApi.getFields({ id: this.nodeParamsDbDto.dbId, tableName: this.sqlItemData.tableName })
      this.columnList = resp.columnDtos || []

      if (this.sqlItemData.sqlMethod === 'relation_select') {
        this.columnList = resp.columnDtos.map(item => {
          return {
            ...item,
            name: this.sqlItemData.tableName + '.' + item.name
          }
        })

        // 记录主表的字段
        this.mainRelationTableColumnList = resp.columnDtos.map(item => {
          return {
            ...item,
            name: this.sqlItemData.tableName + '.' + item.name
          }
        })
      }

      if (!isInit) {
        this.tableChange()
      }
    },
    // 切换数据表，
    tableChange() {
      // 选择表字段，type为select、insert、update时直接带出全部字段
      this.sqlItemData.sortFieldList = []
      this.sqlItemData.updateFieldList = []
      this.sqlItemData.whereFieldList = []
      this.sqlItemData.selectFieldList = []
      this.sqlItemData.relationSelectList = []
      this.sqlItemData.relationSelectOnList = []

      if (['select', 'relation_select'].includes(this.sqlItemData.sqlMethod)) {
        this.sqlItemData.selectFieldList = this.columnList.map(item => ({ fieldName: item.name, dataType: this.columnMap.get(item.name).type }))
      }
      if (['insert', 'update', 'batch_insert_or_update', 'batch_update', 'batch_insert'].includes(this.sqlItemData.sqlMethod)) {
        this.sqlItemData.updateFieldList = this.columnList.map(item => ({ ...new UpdateField(), fieldName: item.name, dataType: this.columnMap.get(item.name).type }))
      }
      this.fieldMapping()
    },
    handleAdd(title, list) {
      if (title === 'select') {
        list.push(new SelectField({}))
      } else if (title === 'relation_select_on') {
        list.push(new RelationOnField())
      } else if (title === 'relation_select') {
        list.push(new SelectRelationField({}))
      } else if (title === 'add_relation_child') {
        list.push(new SelectRelationChildField())
      } else if (title === 'update') {
        list.push(new UpdateField())
      } else if (title === 'where') {
        list.push(new WhereField())
      } else if (title === 'sort') {
        list.push(new SortField())
      } else if (title === 'page') {
        if (list.length > 1) return this.$message.error('只能设置两行')
        list.push(new PageField())
      } else if (title === 'reference') {
        list.push(new ReferenceField())
      } else if (title === 'addChildRow') {
        list.push(new WhereField())
      }
    },
    eventLinstener({ type, title, list }) {
      switch (type) {
        case 'add':
          this.handleAdd(title, list)
          break
      }
    },
    showJsonTree() {
      this.jsonTreeDialogVisible = true
    },
    async rightClick(node, nodeId) {
      const dataType = node.dataType
      const genericType = node.generic
      // 如果选择的是当前节点，校验不能选择index大于等于自己的
      const canUse = validDbCanUse({ selectNodeId: nodeId, selectPath: node.path, currentNodeId: this.nodeFormData.id, currentIndex: this.index })
      if (!canUse) {
        return this.$message.error('不能引用当前SQL以及当前SQL之后的SQL数据')
      }
      if (!(dataType === 8 && genericType === 7)) {
        return this.$message.error('必须选择元素泛型为对象的数组')
      }
      this.jsonTreeDialogVisible = false
      this.sqlItemData.collectionName = node.path
      this.sqlItemData.collectionNodeKey = nodeId
      // 重置主键字段
      this.sqlItemData.mainKeyName = null
      this.sqlItemData.mainKeyNameNodeKey = nodeId
      await this.$nextTick()
      this.fieldMapping()
    },
    fieldMapping() {
      const destList = this.sqlItemData.updateFieldList
      const sourceList = this.collectionFields
      const sqlMethod = this.sqlItemData.sqlMethod
      const nodeKey = this.sqlItemData.mainKeyNameNodeKey
      const needMapping = ['batch_insert_or_update', 'batch_update', 'batch_insert'].includes(sqlMethod)
      // 映射, 查看destList中的字段是否在sourceLsit中，如果在sourceList中，查看类型是否一致，类型一致时自动映射到destList的(先转驼峰)
      if (needMapping && destList && destList.length && sourceList && sourceList.length) {
        const fieldMap = new Map()
        destList.forEach(item => {
          const hump = toHump(item.paramName || item.fieldName)
          const lower = hump.toLowerCase()
          fieldMap.set(lower, item)
        })
        sourceList.forEach(item => {
          const hump = toHump(item.paramName || item.fieldName)
          const lower = hump.toLowerCase()
          // const referenceTypes = [DataTypes.Object, DataTypes.Array]
          const sourceRowDataType = item.dataType
          const destRow = fieldMap.get(lower)
          if (destRow) {
            // 没有忽略 类型但是类型不相同
            if (!this.ignoreDataType && destRow.dataType !== sourceRowDataType) {
              return
            }
            const currentField = fieldMap.get(lower)
            currentField.value = item.path || item.paramName || item.fieldName // 这里直接展示完整的path了，不用数据集里的数据
            currentField.nodeKey = nodeKey
            currentField.type = 1 // 引用值
          }
        })
      }
    },
    handleUpdateSubColumnMap(sColumnMap, oldValTableName) {
      console.log('🚀 ~ file: sqlItem.vue ~ line 436 ~ handleUpdateSubColumnMap ~ subColumnMap, oldValTableName', sColumnMap, oldValTableName)
      const subColumnMap = sColumnMap
      const subColumnMapList = []

      subColumnMap.forEach(value => {
        subColumnMapList.push(value)
      })

      // NOTE - 需要做一个去重，表自关联会导致key值重复报错问题
      const _columnList = [
        ...this.mainRelationTableColumnList,
        ...this.columnList,
        ...subColumnMapList
      ]

      const map = new Map()
      // eslint-disable-next-line no-unused-vars
      for (const item of _columnList) {
        if (!map.has(item.name)) {
          map.set(item.name, item)
        };
      };

      this.columnList = [...map.values()]

      // NOTE - columnList 删除旧数据
      for (let i = 0; i < this.columnList.length; i++) {
        if (!this.columnList[i]) return
        if (this.columnList[i].name.split('.')[0] === oldValTableName) {
          if (oldValTableName === this.sqlItemData.tableName) {
            continue
          } else {
            this.columnList.splice(i, 1, null)
          }
        }
      }

      this.columnList = this.columnList.filter(item => item && item)

      this.sqlItemData.selectFieldList = this.columnList.map(item => ({ fieldName: item.name, dataType: this.columnMap.get(item.name).type }))

      console.log('🚀 ~ file: sqlItem.vue ~ line 527 ~ handleUpdateSubColumnMap ~ this.sqlItemData.selectFieldList', this.sqlItemData.selectFieldList)
    },
    async handleInitialRelationSubColumnMap() {
      // NOTE - 初始化的时候处理 this.columnList

      if (this.sqlItemData.sqlMethod !== 'relation_select') return

      const _columnList = [...this.columnList]

      const promiseArr = []

      this.sqlItemData.relationSelectList.forEach(item => {
        if (item.relationTable) {
          promiseArr.push(dbApi.getFields({ id: this.nodeParamsDbDto.dbId, tableName: item.relationTable }))
        }
      })

      const respList = await Promise.all(promiseArr)

      respList.forEach(resp => {
        resp.columnDtos.forEach(i2 => {
          _columnList.push({
            ...i2,
            name: resp.tableName + '.' + i2.name
          })
        })
      })

      const map = new Map()
      // eslint-disable-next-line no-unused-vars
      for (const item of _columnList) {
        if (!map.has(item.name)) {
          map.set(item.name, item)
        };
      };

      this.columnList = [...map.values()]
    }
  }
}
</script>

<style scope lang="scss">
.sql-item{
  margin-bottom: 10px;
}
.lazy-render-wrap{
  min-height:  100px;
}
</style>
