<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" maxlength="32" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" maxlength="32" />
    </el-form-item>
    <el-row :gutter="10">
      <el-col :span="12">
        <el-form-item label="数据集" prop="nodeParamsLogicDto.sortDto.collectionName" id="tour-sort-collectionName">
          <el-input v-model="sortDto.collectionName" placeholder="请选择" :readonly="true">
            <el-button slot="append" icon="el-icon-setting" @click="showJsonTree" />
          </el-input>
        </el-form-item>
      </el-col>
      <el-col :span="6">
        <el-form-item label="节点名称">
          <el-input :value="resolveNodeName(sortDto.nodeKey, nodeMap)" :disabled="true" />
        </el-form-item>
      </el-col>
      <el-col :span="24" v-if="treeData && treeData.length > 0">
        <el-form-item>
          <el-card>
            <JsonTree title="集合元素数据" :data="treeData" :allowEdit="false" :multipleNode="false" @rightClick="targetRightClick" />
          </el-card>
        </el-form-item>
      </el-col>
    </el-row>
    <el-form-item label="排序字段" id="tour-sort-fieldList">
      <mc-form-item-label slot="label" label="排序字段" icon="el-icon-info">
        拖动行调整顺序
      </mc-form-item-label>
      <FieldList :tableList="sortDto.fieldList" />
    </el-form-item>
    <!-- 数据源json弹窗 -->
    <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px" v-if="jsonTreeDialogVisible">
      <JsonTree title="源数据" :selectNodeId.sync="sortDto.nodeKey" :data.sync="sourceData" @rightClick="rightClick" :multipleNode="true" />
    </el-dialog>
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
import { resolveDefaultNode, formatterParamList, resolveCollection } from '../../node-option-utils'
import JsonTree from '../../../components/jsonTree'
import FieldList from './paramList/field-list'
import { SortFieldItem } from '../../../../model/nodeParams_model'
import mixinResolveNodeName from '../../../../mixins/resolveNodeName'

export default {
  components: { JsonTree, FieldList },
  props: {
    nodeFormData: {
      required: true,
      type: Object
    }
  },
  inject: ['formDisabled', 'nodeMap', 'getFormData'],
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.sortDto.collectionName': [
          { required: true, message: '请选择数据集', trigger: 'blur' }
        ]
      },
      jsonTreeDialogVisible: false,
      selectNodeId: null,
      sourceData: [],
      currentRow: null,
      allOutputList: [],
      selectRows: []
    }
  },
  mixins: [mixinResolveNodeName],
  computed: {
    sortDto() {
      return this.nodeFormData.nodeParamsLogicDto.sortDto
    },
    formData() {
      return this.getFormData()
    },
    treeData() {
      const nodeId = this.sortDto.nodeKey
      const collectionName = this.sortDto.collectionName
      if (!nodeId || !collectionName) {
        return []
      }
      const nodeData = resolveCollection({ nodeId, collectionName, nodeMap: this.nodeMap, formData: this.formData })
      if (!nodeData) {
        return []
      }
      if (nodeData.generic === 7) {
        nodeData.paramName = 'entity'
        const treeData = formatterParamList([nodeData], [])
        return treeData
      } else {
        nodeData.paramName = 'entity'
        nodeData.dataType = nodeData.generic || 6
        const treeData = formatterParamList([nodeData], [])
        return treeData
      }
    }
  },
  async created() {
    this.selectNodeId = resolveDefaultNode(this.sortDto.mappingList, this.nodeFormData, this.nodeMap)
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    targetRightClick(treeNode) {
      if ([7, 8].includes(treeNode.dataType)) {
        return this.$message.error('不能选择非基础类型变量')
      }
      const currentRow = this.sortDto.fieldList.find(row => row.fieldName === treeNode.path)
      if (!currentRow) { // 检查一下是否已经添加过
        this.sortDto.fieldList.push(new SortFieldItem({ fieldName: treeNode.path, dataType: treeNode.dataType }))
      } else {
        return this.$message.error('该条数据已存在')
      }
    },
    showJsonTree() {
      this.jsonTreeDialogVisible = true
    },
    rightClick(node, nodeId) {
      const dataType = node.dataType
      const generic = node.generic
      if (dataType !== 8) {
        return this.$message.error('必须选择数组数据')
      }
      this.jsonTreeDialogVisible = false
      this.$set(this.sortDto, 'nodeKey', nodeId)
      this.$set(this.sortDto, 'dataType', dataType)
      this.$set(this.sortDto, 'collectionName', node.path)
      this.$set(this.sortDto, 'generic', generic)
      this.$set(this.sortDto, 'fieldList', [])
    },
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        fn(valid)
      })
    }
  }
}
</script>

<style>

</style>
