<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" :maxlength="32" />
    </el-form-item>
    <!-- 前置条件 -->
    <el-form-item label="前置条件" id="tour-error-conditionList">
      <el-card class="card">
        <ConditionList :preConditionList="errorDto.preCondition.conditionList" referenceTypeEnum="ParamReferenceTypeEnum" />
      </el-card>
    </el-form-item>
    <el-form-item label="逻辑关系">
      <el-input :disabled="errorDto.preCondition.conditionList.length <= 1" v-model="errorDto.preCondition.condLogicExp" placeholder="示例：(c1 && c2) && (c3 || c4)" />
    </el-form-item>
    <el-form-item label="异常错误码" prop="nodeParamsLogicDto.errorDto.errorId" id="tour-error-errorId">
      <mc-popover-select v-model="errorDto.errorId" :defaultValue="errorDto.errorName" :apiFunc="apiFunc" :tableColumn="resInfoPopTableColumn" :queryList="resInfoPopQueryList" valueKey="errorId" labelKey="errorName" @changeRow="changeRow" :disabled="formDisabled" :param="{infoList: []}" />
    </el-form-item>
    <el-form-item label="错误信息">
      <el-input v-model="errorInfo" disabled type="textarea" rows="5" />
    </el-form-item>
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
import { getTableColumn, getQueryList } from '@/config/popContentTableConfig/resInfo.config'
import resInfoApi from '@/api/platformConfig/resInfo'
import { expandJSONPath } from '@/utils'
import ConditionList from '../../components/conditionSelector'
export default {
  components: { ConditionList },
  props: {
    nodeFormData: {
      type: Object,
      default: () => ({})
    },
    formData: {
      type: Object,
      default: () => ({})
    }
  },
  inject: ['formDisabled', 'nodeMap'],
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.errorDto.errorId': [
          { required: true, message: '请选择异常错误码', trigger: 'change' }
        ]
      },
      apiFunc: resInfoApi.listResInfo,
      resInfoPopTableColumn: getTableColumn(),
      resInfoPopQueryList: [],
      errorInfo: null
    }
  },
  computed: {
    errorDto() {
      return this.nodeFormData.nodeParamsLogicDto.errorDto
    }
  },
  watch: {
    'errorDto.errorInfo': {
      immediate: true,
      deep: true,
      handler(nV) {
        if (typeof nV === 'object' && nV !== null) {
          const { infoList = [] } = nV
          const res = expandJSONPath(infoList)
          this.errorInfo = JSON.stringify(res, null, 2)
        }
      }
    },
    'errorDto.preCondition.conditionList': {
      handler(nV) {
        let str = ''
        if (nV) {
          nV.forEach((_, index) => {
            if (!str) {
              str += `c${index + 1}`
            } else {
              str += ` && c${index + 1}`
            }
          })
        }
        this.errorDto.preCondition.condLogicExp = str
      }
    }
  },
  async created() {
    const [TrueFalseEnum] = await this.getDicts(['TrueFalseEnum'])
    this.resInfoPopQueryList = getQueryList({ TrueFalseEnum })
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    changeRow(row) {
      this.$set(this.errorDto, 'errorInfo', row)
      this.$set(this.errorDto, 'errorName', row.errorName)
    },
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        fn(valid)
      })
    }
  }
}
</script>

<style>

</style>
