<template>
  <el-table ref="multipleTable" :data="tableList" highlightCurrentRow style="width: 100%" maxHeight="250" rowKey="fieldName" border>
    <el-table-column label="字段名" prop="fieldName" />
    <el-table-column label="升序" prop="sortType">
      <template slot-scope="scope">
        <el-form-item>
          <el-checkbox v-model="scope.row.sortType" :disabled="formDisabled" :trueLabel="1" :falseLabel="0" />
        </el-form-item>
      </template>
    </el-table-column>
    <el-table-column label="字段类型" prop="dataType" :formatter="formatterDataType" />

    <el-table-column label="操作" width="60" align="left" v-if="!formDisabled" fixed="right">
      <template slot-scope="scope">
        <el-button type="text" size="mini" @click="deleteRow(scope.$index)">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
import { code2Text } from '@/utils'
import { mapActions } from 'vuex'
import Sortable from 'sortablejs'

export default {
  props: {
    tableList: {
      default: () => [],
      type: Array
    },
    title: {
      default: 'inParamTable',
      type: String
    }
  },
  inject: ['formDisabled', 'nodeMap', 'getFormData'],
  data() {
    return {
      rules: {},
      DataTypeEnum: []
    }
  },
  async created() {
    [this.DataTypeEnum] = await this.getDicts([
      'DataTypeEnum'
    ])
  },
  mounted() {
    this.rowDrop()
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    formatterDataType(row, col, val) {
      return code2Text(val, this.DataTypeEnum)
    },
    deleteRow(index) {
      this.tableList.splice(index, 1)
    },
    rowDrop() {
      const tbody = document.querySelector('.el-table__body-wrapper tbody')
      Sortable.create(tbody, {
        animation: 1000,
        onEnd: ({ newIndex, oldIndex }) => {
          const currentRow = this.tableList.splice(oldIndex, 1)[0]
          this.tableList.splice(newIndex, 0, currentRow)
        }
      })
    }
  }
}
</script>

<style scoped lang="scss">
table-add-btn {
  width: 100%;
}
</style>
