<template>
  <Fragment>
    <el-col :span="24">
      <el-col :span="6">
        <el-form-item label="是否分页">
          <el-switch v-model="formData.basicTaskDto.isPage" :disabled="true" />
        </el-form-item>
      </el-col>
      <el-col :span="6" v-if="formData.basicTaskDto.isPage">
        <el-form-item label="是否反向翻页">
          <mc-form-item-label slot="label" label="是否反向翻页" description="反向翻页适用于分页查询过程中数据动态减少，导致数据查漏的场景" />
          <el-switch v-model="formData.basicTaskDto.isReversePage" :disabled="true" />
        </el-form-item>
      </el-col>
      <el-col :span="12" v-if="formData.basicTaskDto.isPage">
        <el-form-item label="最大页码">
          <mc-form-item-label slot="label" label="最大页码" description="0为无限制" />
          <el-input type="number" v-model.number="formData.basicTaskDto.maxPageNo" :disabled="true" />
        </el-form-item>
      </el-col>
    </el-col>
    <el-col :span="24">
      <el-col :span="12">
        <el-form-item label="是否增量">
          <el-switch v-model="formData.basicTaskDto.isIncTime" :disabled="true" />
        </el-form-item>
      </el-col>
      <el-col :span="12" v-if="formData.basicTaskDto.isIncTime">
        <el-form-item label="时间补偿(s)">
          <el-input v-model.trim.number="formData.basicTaskDto.compensateTime" :disabled="true" />
        </el-form-item>
      </el-col>
    </el-col>
    <el-col :span="24">
      <el-col :span="12">
        <el-form-item label="调度超时时间(ms)">
          <el-input v-model.trim.number="formData.basicTaskDto.requestTimeout" :disabled="true" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="计划执行时间">
          <el-date-picker v-model="formData.basicTaskDto.triggerTime" type="datetime" valueFormat="yyyy-MM-dd HH:mm:ss" placeholder="选择日期时间" :disabled="true" />
        </el-form-item>
      </el-col>
      <el-col :span="24">
        <el-col :span="8">
          <el-form-item label="执行频率">
            <el-select v-model="formData.basicTaskDto.executeFrequency" :disabled="true">
              <el-option v-for="item in ExecuteFrequency" :key="item.type" :value="item.type" :label="item.desc" />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="4" v-if="[8,9,10,11,12].includes(formData.basicTaskDto.executeFrequency)">
          <el-form-item label="" labelWidth="0">
            <el-input v-model.trim="formData.basicTaskDto.executeTimeMap.few" placeholder="请输入间隔时间" :disabled="true" />
          </el-form-item>
        </el-col>
        <el-col :span="16" v-if="formData.basicTaskDto.executeFrequency && formData.basicTaskDto.executeFrequency !== 1">
          <el-form-item label="执行时间" v-if="formData.basicTaskDto.executeFrequency > 1 && formData.basicTaskDto.executeFrequency < 7">
            <!-- 传入type，返回时间选择矩阵 -->
            <mc-time :type="formData.basicTaskDto.executeFrequency" :formData="formData" :timeMap="formData.basicTaskDto.executeTimeMap" :disabled="true" />
          </el-form-item>
          <el-form-item label="cron表达式" v-if="formData.basicTaskDto.executeFrequency === 7">
            <el-input v-model="formData.basicTaskDto.cron" placeholder="0 * * * * " :disabled="true" />
          </el-form-item>
        </el-col>
      </el-col>
    </el-col>
  </Fragment>
</template>

<script>
import { mapActions } from 'vuex'
import { Fragment } from 'vue-fragment'
import McTime from '@/components/mc-time'

export default {
  components: { Fragment, McTime },
  props: {
    formData: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      ExecuteFrequency: []
    }
  },
  async created() {
    console.log(this.formData);
    [this.ExecuteFrequency] = await this.getDicts(['ExecuteFrequency'])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts'])

  }
}
</script>

<style>

</style>
