<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" maxlength="32" />
    </el-form-item>
    <el-form-item label="入参">
      <inputParamsList :tableList="groovy.inputParamList" :prevChainNodeList="prevChainNodeList" @eventLinstener="eventLinstener" />
    </el-form-item>
    <el-form-item label="出参">
      <el-tabs v-model="activeName" type="border-card">
        <el-tab-pane label="请求参数" name="params" :disabled="formDisabled">
          <span slot="label">请求参数 <i class="el-icon-edit" @click="showJsonVisible('outputParamList')" /></span>
          <outputParamsList class="param-list" type="outParamTable" :tableData="groovy.outputParamList" @eventLinstener="eventLinstener" />
        </el-tab-pane>
      </el-tabs>
    </el-form-item>
    <el-form-item label="Groovy" class="groovy-item" prop="nodeParamsLogicDto.groovy.groovyScript">
      <el-button @click="refreshStruct" type="primary" id="tour-groovy-refresh">刷新结构</el-button>
      <codemirror v-model.trim="groovy.groovyScript" :options="options" class="code-container" />
    </el-form-item>
    <JsonAutoResolveDialog :visible.sync="jsonDialogVisible" :allowCopy="true" :type="currentJsonKey" :originalParamList="groovy.outputParamList" @confirm="confirmJsonData" :needPos="false" width="70%" v-if="jsonDialogVisible" />
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
import { deepClone, transFieldName2ParamName } from '@/utils'
import { resolveOutputParamList } from '@/components/flow-node/biz_components/nodeOptionDialog/node-option-utils'
import inputParamsList from '@/components/flow-node/biz_components/components/paramList/groovyInputParamList'
import outputParamsList from '@/components/flow-node/biz_components/components/paramList/groovyOutputParamList'
import { findPrevChain } from '@/components/flow-node/utils/Jsplumb'
import { GroovyOutputParam, GroovyInputParam } from '@/components/flow-node/model/nodeParams_model'
import arrangeApi from '@/api/arrange'
import JsonAutoResolveDialog from '@/components/jsonAutoResolveDialog'
import jsonAutoResolveMixin from '@/components/jsonAutoResolveDialog/mixin'

import { codemirror } from 'vue-codemirror'
import 'codemirror/lib/codemirror.css'
import 'codemirror/theme/base16-dark.css'
import 'codemirror/mode/groovy/groovy.js'
import 'codemirror/addon/display/placeholder.js'
export default {
  components: { inputParamsList, outputParamsList, codemirror, JsonAutoResolveDialog },
  props: {
    nodeFormData: {
      required: true,
      type: Object
    }
  },
  inject: ['formDisabled', 'nodeMap', 'getFormData'],
  mixins: [jsonAutoResolveMixin],
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.groovy.groovyScript': [
          { required: true, message: '请输入Groovy脚本', trigger: 'blur' }
        ]
      },
      jsonTreeDialogVisible: false,
      selectNodeId: null,
      sourceData: [],
      currentRow: null,
      allOutputList: [],
      selectRows: []
    }
  },
  computed: {
    groovy() {
      return this.nodeFormData.nodeParamsLogicDto.groovy
    },
    formData() {
      return this.getFormData()
    },
    options() {
      return {
        mode: { name: 'groovy', json: true },
        theme: 'base16-dark',
        lineNumbers: true,
        readOnly: this.disabled
      }
    },
    // 根据lineList和nodeList解析出上游节点
    prevChainNodeList() {
      const list = findPrevChain(this.nodeMap, this.nodeFormData.id)
      return list
    }
  },

  methods: {
    ...mapActions('new_dict', ['getDicts']),
    async refreshStruct() {
      const data = deepClone(this.groovy)
      let flag = true
      for (let i = 0; i < data.inputParamList.length; i++) {
        const item = data.inputParamList[i]
        if (!item.nodeKey) {
          this.$message.error('输入参数中的节点不能为空')
          flag = false
          break
        } else {
          // paramList中补充所选节点的输出参数
          const itemNode = this.nodeMap.get(item.nodeKey)
          const apiOutParamList = resolveOutputParamList(itemNode, this.formData, this.nodeMap)
          item.apiOutParamList = transFieldName2ParamName(apiOutParamList)
        }
      }
      if (flag) {
        const resp = await arrangeApi.getGroovyCode(data)
        this.groovy.groovyScript = resp.script
      }
    },
    handleAdd(title, list, row) {
      console.log(title, list, row)
      if (title === 'inParamTable') {
        list.push(new GroovyInputParam())
      }
      if (title === 'outParamTable') {
        if (row) {
          row.childrenList.push(new GroovyOutputParam({}))
        } else {
          list.push(new GroovyOutputParam({}))
        }
      }
    },
    eventLinstener({ type, title, list, row }) {
      switch (type) {
        case 'add':
          this.handleAdd(title, list, row)
          break
      }
    },

    confirmJsonData(data) {
      // this.groovy.outputParamList = data
      this.groovy[this.currentJsonKey] = data
      this.jsonDialogVisible = false
    },
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        fn(valid)
      })
    }
  }
}
</script>

<style>

</style>
