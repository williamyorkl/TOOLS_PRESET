<template>
  <Fragment>
    <el-col :span="12">
      <el-form-item label="MQ数据源">
        <el-input :value="formData.logicMqDto.mqName" :disabled="true" />
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item label="组名">
        <el-input v-model.trim="formData.logicMqDto.groupName" placeholder="请输入组名" maxlength="100" :disabled="true" />
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item label="消费者数量">
        <el-input v-model="formData.logicMqDto.concurrency" maxlength="100" :disabled="true" />
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item label="消费者数量">
        <el-input v-model="formData.logicMqDto.concurrency" maxlength="100" :disabled="true" />
      </el-form-item>
    </el-col>
    <el-col :span="24">
      <el-form-item label="监听Topic">
        <McList :list="formData.logicMqDto.topics" :disabled="true">
          <template slot-scope="scope">
            <el-row class="topic-box">
              <el-col :span="6">
                <el-input v-model.trim="scope.item.topicName" placeholder="topic" maxlength="100" :disabled="true" />
              </el-col>
              <!-- kafka不需要设置tag -->
              <el-col :span="1" v-if="formData.logicMqDto.mqConfigDto.mqType === 1">
                <el-divider direction="vertical" />
              </el-col>
              <el-col :span="17" v-if="formData.logicMqDto.mqConfigDto.mqType === 1">
                <mc-tag-list :tagList="scope.item.tagNameList" :disabled="true" />
              </el-col>
            </el-row>
          </template>
        </McList>
      </el-form-item>
    </el-col>
  </Fragment>
</template>

<script>
import { Fragment } from 'vue-fragment'

export default {
  components: { Fragment },
  props: {
    formData: {
      type: Object,
      required: true
    }
  },
  data() {
    return {

    }
  },
  created() {
    console.log(this.formData)
  }
}
</script>

<style>

</style>
