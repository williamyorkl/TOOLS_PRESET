<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" maxlength="32" />
    </el-form-item>
    <!-- 前置条件 -->
    <el-form-item label="前置条件" id="tour-break-conditionList">
      <el-card class="card">
        <ConditionList :preConditionList="breakDto.preCondition.conditionList" referenceTypeEnum="ParamReferenceTypeEnum" />
      </el-card>
    </el-form-item>
    <el-form-item label="逻辑关系">
      <el-input :disabled="breakDto.preCondition.conditionList.length <= 1" v-model="breakDto.preCondition.condLogicExp" placeholder="示例：(c1 && c2) && (c3 || c4)" />
    </el-form-item>
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
import ConditionList from '@/components/flow-node/biz_components/components/conditionSelector'
export default {
  components: { ConditionList },
  props: {
    nodeFormData: {
      type: Object,
      default: () => ({})
    },
    formData: {
      type: Object,
      default: () => ({})
    }
  },
  inject: ['formDisabled', 'nodeMap'],
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ]
        // 'nodeParamsLogicDto.breakDto.errorId': [
        //   { required: true, message: '请选择异常错误码', trigger: 'change' }
        // ]
      }
    }
  },
  computed: {
    breakDto() {
      return this.nodeFormData.nodeParamsLogicDto.breakDto
    }
  },
  watch: {
    'breakDto.preCondition.conditionList': {
      handler(nV) {
        let str = ''
        if (nV) {
          nV.forEach((_, index) => {
            if (!str) {
              str += `c${index + 1}`
            } else {
              str += ` && c${index + 1}`
            }
          })
        }
        this.breakDto.preCondition.condLogicExp = str
      }
    }
  },
  async created() {
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        fn(valid)
      })
    }
  }
}
</script>

<style>

</style>
