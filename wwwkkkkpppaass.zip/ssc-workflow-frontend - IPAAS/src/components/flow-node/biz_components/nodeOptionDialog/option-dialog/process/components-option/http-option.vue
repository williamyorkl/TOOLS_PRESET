<template>
  <div>
    <el-row :gutter="20">
      <el-col :span="12">
        <el-form-item label="超时时间(ms)" prop="nodeParamsLogicDto.nodeParamsRpcDto.apiRequestTimeout">
          <el-input v-model.number="nodeParamsRpcDto.apiRequestTimeout"></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="重试次数" prop="nodeParamsLogicDto.nodeParamsRpcDto.retryNum">
          <el-input v-model.number="nodeParamsRpcDto.retryNum"></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="fallBack" prop="nodeParamsLogicDto.nodeParamsRpcDto.fallBack">
          <el-select v-model="nodeParamsRpcDto.fallBack" clearable placeholder="请选择">
            <el-option label="继续" value="continue"></el-option>
            <el-option label="中断" value="stop"></el-option>
          </el-select>
        </el-form-item>
      </el-col>
    </el-row>
    <el-divider></el-divider>
    <el-row :gutter="20" class="row-wrapper-formitem">
      <el-col :span="12">
        <el-form-item label="是否转发网关请求头" label-width="140px" prop="nodeParamsLogicDto.nodeParamsRpcDto.forwardHeader">
          <el-checkbox v-model="nodeParamsRpcDto.forwardHeader" @change="forwardHeaderChange"></el-checkbox>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="是否转发网关Cookie" label-width="140px" prop="nodeParamsLogicDto.nodeParamsRpcDto.forwardCookie">
          <el-checkbox v-model="nodeParamsRpcDto.forwardCookie"></el-checkbox>
        </el-form-item>
      </el-col>
      <template v-if="nodeParamsRpcDto.forwardHeader">
        <el-col :span="12">
          <el-form-item label="转发请求头指定参数" label-width="140px" prop="nodeParamsLogicDto.nodeParamsRpcDto.forwardHeaderParams">
            <el-input v-model.trim="nodeParamsRpcDto.forwardHeaderParams" placeholder="请输入要转发的请求头参数，以,分割" :disabled="!!nodeParamsRpcDto.filterForwardHeaderParams" maxlength="512"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="过滤请求头指定参数" label-width="140px" prop="nodeParamsLogicDto.nodeParamsRpcDto.filterForwardHeaderParams">
            <el-input v-model.trim="nodeParamsRpcDto.filterForwardHeaderParams" placeholder="请输入要过滤的请求头参数，以,分割" :disabled="!!nodeParamsRpcDto.forwardHeaderParams" maxlength="512"></el-input>
          </el-form-item>
        </el-col>
      </template>
    </el-row>
    <el-divider></el-divider>
  </div>
</template>

<script>
export default {
  props: {
    nodeParamsRpcDto: {}
  },
  methods: {

    forwardHeaderChange() {
      if (!this.nodeParamsRpcDto.forwardHeader) {
        this.nodeParamsRpcDto.forwardHeaderParams = ''
        this.nodeParamsRpcDto.filterForwardHeaderParams = ''
      }
    }
  }
}
</script>

<style>

</style>
