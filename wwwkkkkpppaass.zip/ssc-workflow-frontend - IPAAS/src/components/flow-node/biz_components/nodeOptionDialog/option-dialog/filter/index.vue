<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" maxlength="32" />
    </el-form-item>
    <el-row :gutter="10">
      <el-col :span="12">
        <el-form-item label="数据集" prop="nodeParamsLogicDto.filter.value" id="tour-filter-value">
          <el-input v-model="filter.value" placeholder="请选择" :readonly="true">
            <el-button slot="append" icon="el-icon-setting" @click="showJsonTree" />
          </el-input>
        </el-form-item>
      </el-col>
      <el-col :span="6">
        <el-form-item label="节点名称">
          <el-input :value="resolveNodeName(filter.nodeKey, nodeMap)" :disabled="true" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-form-item label="输出字段" prop="nodeParamsLogicDto.filter.outputParamList" id="tour-filter-outputParamList">
      <outputParamList ref="outputParamList" :tableList="allOutputList" :selectRows="selectRows" :filterData="filter" @selectionChange="selectionChange" />
    </el-form-item>
    <el-form-item label="过滤条件" prop="nodeParamsLogicDto.filter.filterCondition.conditionList" id="tour-filter-conditionList">
      <filterList ref="filterTable" :tableList="filter.filterCondition.conditionList" :allOutputList="allOutputList" :filterData="filter" @eventLinstener="eventLinstener" />
    </el-form-item>
    <el-form-item label="逻辑关系">
      <el-input :disabled="filter.filterCondition.conditionList.length <= 1" v-model="filter.filterCondition.condLogicExp" placeholder="示例：(c1 && c2) && (c3 || c4)" />
    </el-form-item>

    <!-- 数据源json弹窗 -->
    <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px" v-if="jsonTreeDialogVisible">
      <JsonTree title="源数据" :selectNodeId.sync="filter.nodeKey" :data.sync="sourceData" @rightClick="rightClick" :multipleNode="true" />
    </el-dialog>
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
import { deepClone, expandTree } from '@/utils'
import { resolveDefaultNode, resolveOutputParamList, formatterParamList } from '../../node-option-utils'
import JsonTree from '../../../components/jsonTree'
import outputParamList from './paramList/outputParamList'
import filterList from './paramList/filterList'
import { FilterCondition } from '../../../../model'
import mixinResolveNodeName from '../../../../mixins/resolveNodeName'

export default {
  components: { JsonTree, outputParamList, filterList },
  props: {
    nodeFormData: {
      required: true,
      type: Object
    }
  },
  inject: ['formDisabled', 'nodeMap', 'getFormData'],
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.filter.errorId': [
          { required: true, message: '请选择异常错误码', trigger: 'change' }
        ],
        'nodeParamsLogicDto.filter.value': [
          { required: true, message: '请选择数据集', trigger: 'change' }
        ],
        'nodeParamsLogicDto.filter.outputParamList': [
          { required: true, message: '请勾选输出字段', trigger: 'change' }
        ],
        'nodeParamsLogicDto.filter.filterCondition.conditionList': [
          { required: true, message: '请设置过滤条件', trigger: 'change' }
        ]
      },
      jsonTreeDialogVisible: false,
      selectNodeId: null,
      sourceData: [],
      currentRow: null,
      allOutputList: [],
      selectRows: []
    }
  },
  mixins: [mixinResolveNodeName],
  computed: {
    filter() {
      return this.nodeFormData.nodeParamsLogicDto.filter
    },
    formData() {
      return this.getFormData()
    }
  },
  watch: {
    'filter.value': {
      async handler(nV) {
        // 找出对应节点的对应path的对象数据
        if (nV) {
          [this.DataTypeEnum] = await this.getDicts(['DataTypeEnum'])
          const selectNode = this.nodeMap.get(this.filter.nodeKey)
          this.filter.nodeKey = selectNode.id
          this.filter.nodeName = selectNode.name
          const selectOutputList = resolveOutputParamList(deepClone(selectNode), this.formData, this.nodeMap) // 获取所选节点的输出参数，找到当前节点所选的数据集输出字段，拉取字段的childrenList与filter的outputParamList比对，重复的为选中的
          const pathOutputList = formatterParamList(selectOutputList, this.DataTypeEnum)
          const list = expandTree(pathOutputList, 'childrenList') // 展开为一维数组
          const currentArray = list.find(item => item.path === nV)
          const allOutputList = currentArray.childrenList; // 需要结合filter的outputParamList,转换为outputParamList的数据格式，然后将outputParamList中的数据设置为选中行
          [this.allOutputList, this.selectRows] = this.transformOutputList(allOutputList, this.filter.outputParamList)
        }
      },
      immediate: true
    },
    'filter.filterCondition.conditionList': {
      handler(nV) {
        let str = ''
        if (nV) {
          nV.forEach((_, index) => {
            if (!str) {
              str += `c${index + 1}`
            } else {
              str += ` && c${index + 1}`
            }
          })
        }
        this.filter.filterCondition.condLogicExp = str
      }
    }
  },
  async created() {
    this.selectNodeId = resolveDefaultNode(this.filter.mappingList, this.nodeFormData, this.nodeMap)
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    selectionChange(rows) {
      this.filter.outputParamList = rows
    },
    handleFilterAdd(title, list) {
      const filterCondition = new FilterCondition()
      list.push(filterCondition)
    },
    eventLinstener({ type, title, list }) {
      switch (type) {
        case 'add':
          this.handleFilterAdd(title, list)
          break
      }
    },
    showJsonTree() {
      this.jsonTreeDialogVisible = true
    },
    rightClick(node, nodeId) {
      const dataType = node.dataType
      const genericType = node.generic
      if (!(dataType === 8 && genericType === 7)) {
        return this.$message.error('必须选择元素泛型为对象的数组')
      }
      this.jsonTreeDialogVisible = false
      this.$set(this.filter, 'nodeKey', nodeId)
      this.$set(this.filter, 'value', node.path)
      this.$set(this.filter, 'outputParamList', [])
      this.$refs.outputParamList.clearSelection()
    },
    validateFormData(fn) {
      this.$refs.form.validate(async valid => {
        const filterValid = await this.$refs.filterTable.validFormData()
        fn(valid && filterValid)
      })
    },
    transformOutputList(allOutputList, outputParamList) {
      const selectRows = []
      const selectParams = outputParamList.map(item => {
        return item.paramName || item.fieldName
      })
      const list = allOutputList.map((item, index) => {
        const row = { paramName: item.paramName || item.fieldName, dataType: item.dataType, rowKey: Date.now() + index, childrenList: [] }
        if (selectParams.includes(item.paramName || item.fieldName)) {
          selectRows.push(row)
        }
        return row
      })
      return [list, selectRows]
    }
  }
}
</script>

<style>

</style>
