<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" :maxlength="32" />
    </el-form-item>

    <el-form-item label="出参配置" id="tour-choice-outputParamList">
      <el-tabs v-model="activeName" type="border-card">
        <el-tab-pane label="出参配置" name="params" :disabled="formDisabled">
          <span slot="label">出参配置 <i class="el-icon-edit" @click="showJsonVisible('outputParamList')" /></span>
          <ParamList class="param-list" type="outParams" :tableData="choiceDto.outputParamList" />
        </el-tab-pane>
      </el-tabs>
    </el-form-item>
    <JsonAutoResolveDialog :visible.sync="jsonDialogVisible" :allowCopy="true" :originalParamList="choiceDto.outputParamList" :type="currentJsonKey" @confirm="confirmJsonData" :needPos="false" width="70%" v-if="jsonDialogVisible" />
  </el-form>
</template>

<script>
import ParamList from '@/components/flow-node/biz_components/components/outputParamList'
import JsonAutoResolveDialog from '@/components/jsonAutoResolveDialog'
import jsonAutoResolveMixin from '@/components/jsonAutoResolveDialog/mixin'
export default {
  components: { ParamList, JsonAutoResolveDialog },
  props: {
    nodeFormData: {
      required: true,
      type: Object
    }
  },
  inject: ['formDisabled', 'nodeMap', 'getFormData'],
  mixins: [jsonAutoResolveMixin],
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.errorDto.errorId': [
          { required: true, message: '请选择异常错误码', trigger: 'change' }
        ]
      }
    }
  },
  computed: {
    formData() {
      return this.getFormData()
    },
    choiceDto() {
      return this.nodeFormData.nodeParamsLogicDto.choiceDto
    }
  },
  methods: {
    confirmJsonData(data) {
      this.choiceDto[this.currentJsonKey] = data
      this.jsonDialogVisible = false
    },
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        fn(valid)
      })
    }
  }
}
</script>

<style>

</style>
