<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" :maxlength="32" />
    </el-form-item>

    <el-form-item label="try出参配置" id="tour-try-outputParamList">
      <el-tabs v-model="activeName" type="border-card">
        <el-tab-pane label="出参配置" name="params" :disabled="formDisabled">
          <span slot="label">出参配置 <i class="el-icon-edit" @click="showJsonVisible('outputParamList')" /></span>
          <ParamList class="param-list" type="outParams" :tableData="retryDto.outputParamList" />
        </el-tab-pane>
      </el-tabs>
    </el-form-item>

    <el-form-item label="catch出参配置" id="tour-catch-outputParamList">
      <mc-form-item-label slot="label" label="catch出参配置" description="若为空则无catch块" />
      <el-tabs v-model="activeName" type="border-card">
        <el-tab-pane label="出参配置" name="params" :disabled="formDisabled">
          <span slot="label">出参配置 <i class="el-icon-edit" @click="showJsonVisible('catchOutputParamList')" /></span>
          <ParamList class="param-list" type="outParams" :tableData="retryDto.catchOutputParamList" />
        </el-tab-pane>
      </el-tabs>
    </el-form-item>

    <!-- 前置条件 -->
    <!-- <el-form-item label="前置条件" id="tour-response-conditionList">
      <el-card class="card">
        <ConditionList :preConditionList="retryDto.retryContext.conditionDto.conditionList" :includeSelf="true" referenceTypeEnum="ParamReferenceTypeEnum" />
      </el-card>
    </el-form-item>
    <el-form-item label="逻辑关系">
      <el-input :disabled="retryDto.retryContext.conditionDto.conditionList.length <= 1" v-model="retryDto.retryContext.conditionDto.condLogicExp" placeholder="示例：(c1 && c2) && (c3 || c4)" />
    </el-form-item> -->
    <el-row :gutter="10">
      <el-col :span="4">
        <el-form-item label="是否异常重试">
          <el-switch v-model="retryDto.retryContext.retryWhenException" :disabled="formDisabled" activeColor="#13ce66" inactiveColor="#ff4949" />
        </el-form-item>
      </el-col>
      <template v-if="retryDto.retryContext.retryWhenException">
        <el-col :span="4">
          <el-form-item label="从断点处开始重试">
            <el-switch v-model="retryDto.retryContext.onlyBreak" :disabled="formDisabled" activeColor="#13ce66" inactiveColor="#ff4949" />
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="重试阶梯表达式" prop="nodeParamsLogicDto.retryDto.retryContext.expression">
            <ladder-expression ref="ladderExpression" :data.sync="retryDto.retryContext.expression" :uniqe="true" />
          </el-form-item>
        </el-col>
      </template>
    </el-row>

    <!-- 数据源json弹窗 -->
    <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px" v-if="jsonTreeDialogVisible">
      <JsonTree title="源数据" :selectNodeId.sync="retryDto.nodeKey" :data.sync="sourceData" @rightClick="rightClick" :multipleNode="true" />
    </el-dialog>
    <JsonAutoResolveDialog :visible.sync="jsonDialogVisible" :allowCopy="true" :originalParamList="originalParamList" :type="currentJsonKey" @confirm="confirmJsonData" :needPos="false" width="70%" v-if="jsonDialogVisible" />
  </el-form>
</template>

<script>
import ParamList from '@/components/flow-node/biz_components/components/outputParamList'
import JsonAutoResolveDialog from '@/components/jsonAutoResolveDialog'
import jsonAutoResolveMixin from '@/components/jsonAutoResolveDialog/mixin'
import mixinResolveNodeName from '@/components/flow-node/mixins/resolveNodeName'
import JsonTree from '@/components/flow-node/biz_components/components/jsonTree'
// import ConditionList from '../../components/conditionSelector'
import LadderExpression from '@/components/ladder-expression'
import { RelationDto } from '@/components/flow-node/model'
import { code2Text } from '@/utils'
import { mapActions } from 'vuex'
export default {
  components: {
    ParamList,
    JsonTree,
    JsonAutoResolveDialog,
    // ConditionList,
    LadderExpression
  },
  props: {
    nodeFormData: {
      required: true,
      type: Object
    }
  },
  inject: ['formDisabled', 'nodeMap', 'getFormData'],
  mixins: [mixinResolveNodeName, jsonAutoResolveMixin],
  data() {
    return {
      activeName: 'params',
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.retryDto.retryContext.expression': [
          { required: true, message: '请设置重试阶梯表达式', trigger: 'change' }
        ]
      },
      jsonTreeDialogVisible: false,
      selectNodeId: null,
      sourceData: [],
      currentRow: null,
      code2Text,
      DataTypeEnum: []
    }
  },
  computed: {
    formData() {
      return this.getFormData()
    },
    retryDto() {
      return this.nodeFormData.nodeParamsLogicDto.retryDto
    },
    originalParamList() {
      return this.retryDto[this.currentJsonKey]
    }
  },
  watch: {
    'retryDto.catchOutputParamList.length': {
      handler(nV, oV) {
        // 有到无，清空
        if (!nV) {
          this.retryDto.catchRelationDto = null
        } else if (!oV) { // 无到有，设置值
          this.retryDto.catchRelationDto = new RelationDto()
        }
      },
      immediate: true
    }
    // 'retryDto.retryContext.conditionDto.conditionList': {
    //   handler(nV) {
    //     let str = ''
    //     if (nV) {
    //       nV.forEach((_, index) => {
    //         if (!str) {
    //           str += `c${index + 1}`
    //         } else {
    //           str += ` && c${index + 1}`
    //         }
    //       })
    //     }
    //     this.retryDto.retryContext.conditionDto.condLogicExp = str
    //   }
    // }
  },
  async created() {
    [this.DataTypeEnum] = await this.getDicts(['DataTypeEnum'])
    // 初始化为空数组
    if (!this.retryDto.outputParamList) {
      this.retryDto.outputParamList = []
    }
    if (!this.retryDto.catchOutputParamList) {
      this.retryDto.catchOutputParamList = []
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    validateFormData(fn) {
      this.$refs.form.validate(async valid => {
        let ladderExpressionValid = true
        if (this.$refs.ladderExpression) {
          ladderExpressionValid = await this.$refs.ladderExpression.validateForm()
        }
        fn(valid && ladderExpressionValid)
      })
    },
    showJsonTree() {
      this.jsonTreeDialogVisible = true
    },
    rightClick(node, nodeId) {
      const dataType = node.dataType
      const genericType = node.generic
      if (!(dataType === 8)) {
        return this.$message.error('必须选择数组类型数据')
      }
      this.jsonTreeDialogVisible = false
      this.$set(this.retryDto, 'nodeKey', nodeId)
      this.$set(this.retryDto, 'value', node.path)
      this.$set(this.retryDto, 'generic', genericType)
    },
    confirmJsonData(data) {
      this.retryDto[this.currentJsonKey] = data
      this.jsonDialogVisible = false
    }
  }
}
</script>

<style>

</style>
