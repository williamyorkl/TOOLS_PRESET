<template>
  <Fragment>
    <el-col :span="12">
      <el-form-item label="CDC源">
        <el-input :value="formData.logicMqDto.cdcName" :disabled="true" />
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item label="组名">
        <el-input v-model.trim="formData.logicMqDto.groupName" placeholder="请输入组名" maxlength="100" :disabled="true" />
      </el-form-item>
    </el-col>
    <el-col :span="12">
      <el-form-item label="数据表">
        <el-input v-model="formData.logicMqDto.dbTable" placeholder="请输入组名" :disabled="true" />
      </el-form-item>
    </el-col>
  </Fragment>
</template>

<script>
import { Fragment } from 'vue-fragment'

export default {
  components: { Fragment },
  props: {
    formData: {
      type: Object,
      required: true
    }
  },
  data() {
    return {

    }
  }
}
</script>

<style>

</style>
