<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" :maxlength="32" />
    </el-form-item>
    <!-- 前置条件 -->
    <el-form-item label="前置条件" id="tour-response-conditionList">
      <el-card class="card">
        <ConditionList :preConditionList="responseDto.preCondition.conditionList" referenceTypeEnum="ParamReferenceTypeEnum" />
      </el-card>
    </el-form-item>
    <el-form-item label="逻辑关系">
      <el-input :disabled="responseDto.preCondition.conditionList.length <= 1" v-model="responseDto.preCondition.condLogicExp" placeholder="示例：(c1 && c2) && (c3 || c4)" />
    </el-form-item>

    <el-form-item label="响应结果">
      <mc-form-item-label slot="label" label="响应结果" icon="el-icon-info">
        1、「右键」目标数据，可自动选中下方列表中对应行，「右键」源数据可将选中数据填充至下方列表，并自动切换至下一行 <br>
        2、「单击」下方表格某一行则可选中行
      </mc-form-item-label>
      <el-card>
        <el-row :gutter="20">
          <el-col :span="12">
            <JsonTree ref="leftTree" title="目标数据" :data="apiOutParamList" :allowEdit="false" :multipleNode="false" @rightClick="targetRightClick" />
          </el-col>
          <el-col :span="12">
            <JsonTree ref="rightTree" title="源数据" :selectNodeId.sync="selectNodeId" :multipleNode="true" :data.sync="sourceData" :allowEdit="false" @rightClick="sourceRightClick" />
          </el-col>
        </el-row>
      </el-card>
    </el-form-item>
    <el-form-item v-if="!formDisabled">
      <el-popconfirm :title="autoMappingTitle" @confirm="autoMappingList">
        <el-button slot="reference">自动映射</el-button>
      </el-popconfirm>
      忽略参数类型 <el-checkbox v-model="ignoreDataType" />
    </el-form-item>
    <el-form-item label="字段映射" id="tour-response-mappingList">
      <fieldMappingTable :allowAdd="false" class="" ref="inParamTable" title="inParamTable" :tableList="responseDto.mappingList" @eventLinstener="eventLinstener" />
    </el-form-item>
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
import { getTableColumn } from '@/config/popContentTableConfig/resInfo.config'
import resInfoApi from '@/api/platformConfig/resInfo'
import ConditionList from '../../components/conditionSelector'
import fieldMappingTable from '../../../biz_components/components/fieldMappingTable'
import { resolveDefaultNode, removeNullRow, fillMappingTable, compareAndMapping, resolveEndNodeOutParamList } from '../node-option-utils'
import JsonTree from '../../components/jsonTree'
import { autoMappingTitle } from '@/components/flow-node/model/config'
export default {
  components: { ConditionList, JsonTree, fieldMappingTable },
  props: {
    nodeFormData: {
      type: Object,
      default: () => ({})

    },
    formData: {
      type: Object,
      default: () => ({})

    }
  },
  inject: ['formDisabled', 'nodeMap'],
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.responseDto.errorId': [
          { required: true, message: '请选择异常错误码', trigger: 'change' }
        ]
      },
      apiFunc: resInfoApi.listResInfo,
      resInfoPopTableColumn: getTableColumn(),
      resInfoPopQueryList: [],
      selectNodeId: null,
      sourceData: [],
      currentRow: null,
      apiOutParamList: [],
      autoMappingTitle,
      ignoreDataType: false
    }
  },
  computed: {
    responseDto() {
      return this.nodeFormData.nodeParamsLogicDto.responseDto
    }
  },
  watch: {
    'responseDto.preCondition.conditionList': {
      handler(nV) {
        let str = ''
        if (nV) {
          nV.forEach((_, index) => {
            if (!str) {
              str += `c${index + 1}`
            } else {
              str += ` && c${index + 1}`
            }
          })
        }
        this.responseDto.preCondition.condLogicExp = str
      }
    },
    // 填充mappingList数据（将为空的删掉的行补回来）
    'responseDto.targetMessage': {
      // handler(nV) {
      //   if (nV) {
      //     this.responseDto.mappingList = fillMappingTable(obj2Tree(JSON.parse(this.responseDto.targetMessage)), this.responseDto.mappingList)
      //   } else {
      //     this.responseDto.mappingList = []
      //   }
      // },
      // immediate: true
    }
  },
  async created() {
    this.selectNodeId = resolveDefaultNode(this.responseDto.mappingList, this.nodeFormData, this.nodeMap)
    // this.apiOutParamList = this.formData.apiOutParamList
    this.apiOutParamList = resolveEndNodeOutParamList({ nodeId: this.nodeFormData.id, nodeMap: this.nodeMap, formData: this.formData })
    this.responseDto.mappingList = fillMappingTable(this.apiOutParamList, this.responseDto.mappingList)
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    // 右击目标数据设置对应行高亮
    async targetRightClick(treeNode) {
      this.$refs.inParamTable.setCurrentRow(treeNode)
      await this.$nextTick()
      // 点击时修改当前行的数据类型
      this.currentRow.dataType = treeNode.dataType
    },
    // 右击源数据填充到高亮行
    sourceRightClick(treeNode, selectNodeId, selectNode) {
      if (!selectNodeId) selectNodeId = this.nodeFormData.id

      if (!this.currentRow) {
        this.$message.error('请先选中行')
      } else {
        if (this.currentRow.referenceType === 0) { return this.$message.error('固定值请自行输入') }
        this.currentRow.sourceNodePath = treeNode.path
        this.currentRow.sourceNodeKey = selectNodeId
        this.currentRow.sourceNodeName = selectNode.name
        this.currentRow.sourceDataType = treeNode.dataType
        this.$refs.inParamTable.activeNextRow()
      }
    },
    eventLinstener({ type, row, _list, title }) {
      switch (type) {
        case 'currentChange':
          this.currentChange(title, row)
          break
      }
    },
    currentChange(title, row) {
      if (title === 'inParamTable') {
        this.currentRow = row
      }
    },
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        removeNullRow(this.responseDto.mappingList)
        fn(valid)
      })
    },
    // 自动映射左右数据
    autoMappingList() {
      const leftTree = this.apiOutParamList
      const rightTree = this.sourceData
      const leftSelectRow = this.$refs.leftTree.getSelectRow()
      const rightSelectRow = this.$refs.rightTree.getSelectRow()
      if (!leftTree || !rightTree || leftTree.length === 0 || rightTree.length === 0) {
        return this.$message.error('匹配失败，数据不完整')
      }
      // 进行匹配映射
      compareAndMapping({ leftTree, rightTree, leftSelectRow, rightSelectRow, mappingList: this.responseDto.mappingList, rightNodeId: this.selectNodeId, ignoreDataType: this.ignoreDataType })
    }
  }
}
</script>

<style>

</style>
