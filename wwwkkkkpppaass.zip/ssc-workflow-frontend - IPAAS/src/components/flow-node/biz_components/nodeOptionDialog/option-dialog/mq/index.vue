<template>
  <el-form ref="form" :model="nodeFormData" :rules="rules" labelWidth="120px" :disabled="formDisabled">
    <el-form-item label="节点名称" prop="name" id="tour-node-name">
      <el-input v-model.trim="nodeFormData.name" maxlength="32" />
    </el-form-item>

    <el-row :gutter="10" id="tour-mq-mqOption">
      <el-col :span="12">
        <el-form-item label="MQ数据源" prop="nodeParamsLogicDto.nodeParamsMqDto.mqServerId">
          <mc-popover-select v-model="nodeParamsMqDto.mqServerId" :defaultValue="nodeParamsMqDto.mqName" :apiFunc="mqListApiFunc" :disabled="formDisabled" :tableColumn="mqTableColumn" :queryList="mqQueryList" labelKey="name" @changeRow="mqServerChange" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="topic" prop="nodeParamsLogicDto.nodeParamsMqDto.topic">
          <el-input v-model.trim="nodeParamsMqDto.topic" />
        </el-form-item>
      </el-col>
      <el-col :span="12" v-if="nodeParamsMqDto.mqType !== 3">
        <el-form-item label="tags" prop="nodeParamsLogicDto.nodeParamsMqDto.tags">
          <el-input v-model.trim="nodeParamsMqDto.tags" />
        </el-form-item>
      </el-col>
      <el-col :span="12" v-if="nodeParamsMqDto.mqType !== 3">
        <el-form-item label="keyPrefix" prop="nodeParamsLogicDto.nodeParamsMqDto.keyPrefix">
          <el-input v-model.trim="nodeParamsMqDto.keyPrefix" />
        </el-form-item>
      </el-col>
    </el-row>

    <el-form-item label="配置出参">
      <mc-form-item-label slot="label" label="配置出参" icon="el-icon-info">
        1、「右键」目标数据，可自动选中下方列表中对应行，「右键」源数据可将选中数据填充至下方列表，并自动切换至下一行 <br>
        2、「单击」下方表格某一行则可选中行
        3、前缀「mq」默认拼接做字段映射，实际发送消息内容以编辑的模板为准
      </mc-form-item-label>
      <el-card>
        <el-row :gutter="20">
          <el-col :span="12">
            <JsonTree ref="leftTree" title="目标数据" wrapStr="mq" :data="targetOutputParamList" @listChange="listChange" :allowEdit="true" :multipleNode="false" @rightClick="targetRightClick" />
          </el-col>
          <el-col :span="12">
            <JsonTree ref="rightTree" title="源数据" :selectNodeId.sync="selectNodeId" :multipleNode="true" :data.sync="sourceData" :allowEdit="false" @rightClick="sourceRightClick" />
          </el-col>
        </el-row>
      </el-card>
    </el-form-item>
    <el-form-item v-if="!formDisabled">
      <el-popconfirm :title="autoMappingTitle" @confirm="autoMappingList">
        <el-button slot="reference">自动映射</el-button>
      </el-popconfirm>
      忽略参数类型 <el-checkbox v-model="ignoreDataType" />
    </el-form-item>
    <el-form-item label="字段映射" id="tour-mq-mappingList">
      <fieldMappingTable :allowAdd="false" :needIsRequired="false" ref="inParamTable" title="inParamTable" :tableList="nodeParamsMqDto.mappingList" @eventLinstener="eventLinstener" />
    </el-form-item>
  </el-form>
</template>

<script>
import JsonTree from '../../../components/jsonTree'
import { resolveDefaultNode, fillMappingTable, removeNullRow, compareAndMapping } from '../../node-option-utils'
import fieldMappingTable from '../../../../biz_components/components/fieldMappingTable'
import { getTableColumn as getMqTableColumn, getQueryList as getMqQueryList } from '@/config/popContentTableConfig/mq.config'
import mqApi from '@/api/mq'
import { polyfillData } from '@/utils'
import { autoMappingTitle } from '@/components/flow-node/model/config'
export default {
  components: { JsonTree, fieldMappingTable },
  props: {
    nodeFormData: {
      required: true,
      type: Object
    },
    formData: {
      required: true,
      type: Object
    }
  },
  inject: ['formDisabled', 'nodeMap'],
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入节点名称', trigger: 'blur' }
        ],
        'nodeParamsLogicDto.nodeParamsMqDto.mqServerId': [
          { required: true, message: '请选择MQ数据源', trigger: 'change' }
        ],
        'nodeParamsLogicDto.nodeParamsMqDto.topic': [
          { required: true, message: '请输入topic', trigger: 'blur' }
        ]
      },
      mqListApiFunc: mqApi.getMqList,
      mqTableColumn: getMqTableColumn(),
      mqQueryList: getMqQueryList(),
      selectNodeId: null,
      sourceData: [],
      currentRow: null,
      autoMappingTitle,
      ignoreDataType: false
    }
  },
  computed: {
    nodeParamsMqDto() {
      return this.nodeFormData.nodeParamsLogicDto.nodeParamsMqDto
    },
    targetOutputParamList() {
      let outputParamList = []
      try {
        outputParamList = JSON.parse(this.nodeParamsMqDto.targetMessage) || []
      } catch (e) {
        outputParamList = []
      }
      console.log(outputParamList)
      return outputParamList || []
    }
  },
  created() {
    this.nodeParamsMqDto.targetMessage = polyfillData(this.nodeParamsMqDto.targetMessage, 'mq')
    this.selectNodeId = resolveDefaultNode(this.nodeParamsMqDto.mappingList, this.nodeFormData, this.nodeMap)
    // 补充提交数据时删掉的空row
  },
  watch: {
    'nodeParamsMqDto.targetMessage': {
      handler(nV) {
        if (nV) {
          // const paramList = [{ paramName: 'mq', dataType: 7, childrenList: JSON.parse(nV) }]
          const paramList = JSON.parse(nV)
          this.nodeParamsMqDto.mappingList = fillMappingTable(paramList, this.nodeParamsMqDto.mappingList)
        } else {
          this.nodeParamsMqDto.mappingList = []
        }
      },
      immediate: true
    }
  },
  methods: {
    listChange(data) {
      this.nodeParamsMqDto.targetMessage = JSON.stringify(data)
    },
    // 切换数据源
    mqServerChange(row) {
      console.log(row)
      this.nodeParamsMqDto.mqType = row.mqType
      this.nodeParamsMqDto.mqName = row.name
      if (row.mqType === 3) { // rabbitMq不设置tags和keyPrefix
        this.nodeParamsMqDto.tags = null
        this.nodeParamsMqDto.keyPrefix = null
      }
    },
    // 右击目标数据设置对应行高亮
    async targetRightClick(treeNode) {
      this.$refs.inParamTable.setCurrentRow(treeNode)
      await this.$nextTick()
      // 点击时修改当前行的数据类型
      this.currentRow.dataType = treeNode.dataType
    },
    // 右击源数据填充到高亮行
    sourceRightClick(treeNode, selectNodeId, selectNode) {
      if (!selectNodeId) selectNodeId = this.nodeFormData.id

      if (!this.currentRow) {
        this.$message.error('请先选中行')
      } else {
        if (this.currentRow.referenceType === 0) { return this.$message.error('固定值请自行输入') }
        this.currentRow.sourceNodePath = treeNode.path
        this.currentRow.sourceNodeKey = selectNodeId
        this.currentRow.sourceNodeName = selectNode.name
        this.currentRow.sourceDataType = treeNode.dataType
        this.$refs.inParamTable.activeNextRow()
      }
    },
    eventLinstener({ type, row, _list, title }) {
      switch (type) {
        case 'currentChange':
          this.currentChange(title, row)
          break
      }
    },
    currentChange(title, row) {
      if (title === 'inParamTable') {
        this.currentRow = row
      }
    },
    validateFormData(fn) {
      this.$refs.form.validate(valid => {
        removeNullRow(this.nodeParamsMqDto.mappingList)
        fn(valid)
      })
    },
    // 自动映射左右数据
    autoMappingList() {
      const leftTree = this.targetOutputParamList
      const rightTree = this.sourceData
      const leftSelectRow = this.$refs.leftTree.getSelectRow()
      const rightSelectRow = this.$refs.rightTree.getSelectRow()
      if (!leftTree || !rightTree || leftTree.length === 0 || rightTree.length === 0) {
        return this.$message.error('匹配失败，数据不完整')
      }
      // 进行匹配映射
      compareAndMapping({ leftTree, rightTree, leftSelectRow, rightSelectRow, mappingList: this.nodeParamsMqDto.mappingList, rightNodeId: this.selectNodeId, ignoreDataType: this.ignoreDataType })
    }
  }
}
</script>

<style>

</style>
