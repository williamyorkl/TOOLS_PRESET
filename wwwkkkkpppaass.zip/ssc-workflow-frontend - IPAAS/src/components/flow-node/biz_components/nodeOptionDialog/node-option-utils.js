import { deepClone, code2Text, takeoutParamsFromTree, toHump, isNull, expandTree, getUUID, unique } from '@/utils'
import { NodeTypeEnum, DataTypes } from '@/config/enum'
import { FieldMapping } from '../../model'

// 不同类型节点，输出不同的出参供其他节点引用
export function resolveOutputParamList(node, formData = {}, nodeMap = new Map()) {
  const type = node.type
  let outputParamList = []
  switch (type) {
    case NodeTypeEnum.START:
      outputParamList = getStartOutputList({ node, formData, nodeMap })
      break
    case NodeTypeEnum.PROCESS:
      outputParamList = node.nodeParamsLogicDto.nodeParamsRpcDto.outputParamList
      break
    case NodeTypeEnum.DB:
      outputParamList = getDbOutputList(node)
      break
    case NodeTypeEnum.FILTER:
      outputParamList = getFilterOutputList(node)
      break
    case NodeTypeEnum.MAPPER:
      outputParamList = getMapperOutputList(node)
      break
    case NodeTypeEnum.GROUP:
      outputParamList = getGroupOutputList(node)
      break
    case NodeTypeEnum.GROOVY:
      outputParamList = getGroovyOutputList(node)
      break
    case NodeTypeEnum.COMBINE:
      outputParamList = getCombineOutputList(node, nodeMap, formData)
      break
    case NodeTypeEnum.CHOICE:
      outputParamList = getChoiceOutputList(node)
      break
    case NodeTypeEnum.FOREACH:
      outputParamList = getForeachOutputList(node)
      break
    case NodeTypeEnum.VARIABLE:
      outputParamList = getVariableOutputList(node)
      break
    case NodeTypeEnum.SORT:
      outputParamList = getSortOutputList({ node, formData, nodeMap })
      break
    case NodeTypeEnum.SYNC:
      outputParamList = getSyncOutputList({ node, formData, nodeMap })
      break
    case NodeTypeEnum.ASYNC:
      outputParamList = getAsyncOutputList({ node, formData, nodeMap })
      break
    case NodeTypeEnum.CACHE:
      outputParamList = getCacheOutputList({ node, formData, nodeMap })
      break
    case NodeTypeEnum.TRY:
      outputParamList = getTryOutputList({ node, formData, nodeMap })
      break
    case NodeTypeEnum.END:
      outputParamList = getEndOutputList({ node, formData, nodeMap })
      break
  }
  return outputParamList
}

/**
 * 将数据转为可在tree中展示 lable: Type的形式
 * {childrenList: [], dataType: 1, isRequired: false, paramName: "id", rowKey: "1637562619161"}
 * 将级联列表格式的数据格式化,需要包含{dataType: 数据类型, paramName: 属性名, label: label字段包含属性名和类型, path: 取值路径, isRequired: 是否必传， childrenList: [] }
 * 类型：1：Int，2：Long，3：boolean，4：Float，5：Double，6：String，7：Object，8：Array，9：Date，10：BigDecimal，11：Short
 *
 * 注意：因为修改的源数据，所以建议传入深拷贝后的数据
 * @param {*} list
 * @param {*} DataTypeEnum
 * @returns
 */
export const formatterParamList = (list = [], DataTypeEnum = [], parentPath, patchPath = '', pathKey = 'path') => {
  if (!list) return
  list.forEach(item => {
    let nextPatchPath = patchPath
    item.label = `${item.paramName || item.fieldName}: ${code2Text(item.dataType, DataTypeEnum)}`
    item[pathKey] = parentPath ? parentPath + patchPath + '.' + (item.paramName || item.fieldName) : (item.paramName || item.fieldName)
    if (item.dataType === 8) {
      nextPatchPath = '[]'
    } else {
      nextPatchPath = ''
    }
    if (item.childrenList && item.childrenList.length > 0) {
      formatterParamList(item.childrenList, DataTypeEnum, item[pathKey], nextPatchPath, pathKey)
    }
  })
  return list
}

// 根据数据集和节点id，查找数据集数据 {obj: {arr: [{}]}}  val: 'obj.arr'  nodeId
export function resolveCollection({ nodeId, collectionName, nodeMap, formData }) {
  const node = nodeMap.get(nodeId)
  // 找到所选节点的出参
  let nodeOutputParamList = resolveOutputParamList(node, formData, nodeMap)
  // 从出参中找到所选数据集的数据
  nodeOutputParamList = formatterParamList(deepClone(nodeOutputParamList))
  const list = expandTree(nodeOutputParamList, 'childrenList')
  const collectionData = list.find(item => item.path === collectionName)

  return collectionData
}

// 根据节点id解析节点名称
export function resolveNodeName(nodeId, nodeMap) {
  if (!nodeId) return ''
  const node = nodeMap.get(nodeId)
  if (node) {
    return node.name
  } else {
    return nodeId
  }
}

/**
 * 对list做映射处理
 * @param {*} list
 */
export function doMapping(list, selectNodeId, nodeMap) {
  const selectNode = nodeMap.get(selectNodeId)
  list.forEach(item => {
    item.sourceNodeKey = selectNode.id
    item.sourceNodeName = selectNode.name
    item.sourceNodePath = item.targetNodePath
    item.sourceDataType = item.dataType
  })
}

// mappingList填充
// 深度优先递归解析inputParamList，得到一个一维数组,与oldMap比对 ，将path一致的 用老数据填充
export function fillMappingTable(inputParamList, oldMapList) {
  const paramList = formatterParamList(deepClone(inputParamList))
  // 填充数据，移除类型为(对象 && 有子级)的行
  return iterList(paramList, oldMapList)
}

function iterList(paramList, oldMapList = [], list = []) {
  if (Array.isArray(paramList)) {
    paramList.forEach((item) => {
      const children = item.childrenList
      const ban = item.dataType === 7 && children && children.length > 0 // 没有属性的对象要展示在mappingList，有属性的不展示
      if (!ban) {
        const oldMapping = oldMapList.find(
          (oldMappingItem) => oldMappingItem.targetNodePath === item.path
        )
        const apiObj = {
          // 取oldMapping的dataType，如果没有，取item的dataType
          dataType: item.dataType,
          targetNodePath: item.path,
          dataPosition: item.dataPosition,
          isRequired: item.isRequired
        }
        let mapping = { ...new FieldMapping(), ...apiObj }
        if (oldMapping) {
          mapping = { ...oldMapping, ...apiObj }
        }
        list.push(mapping)
      }
      if (item.childrenList && item.childrenList.length > 0) {
        iterList(item.childrenList, oldMapList, list)
      }
    })
  }
  return list
}

/**
 * 若每一行的paramName和dataType完全一样则自动匹配
 */
export function autoMapping(sourceList, targetList) {
  if (!sourceList || !targetList || sourceList.length === 0 || targetList.length === 0) return [false]
  const list1 = takeoutParamsFromTree({ tree: sourceList, keys: ['paramName', 'dataType'], childrenList: 'childrenList' })
  const list2 = takeoutParamsFromTree({ tree: targetList, keys: ['paramName', 'dataType'], childrenList: 'childrenList' })
  if (JSON.stringify(list1) === JSON.stringify(list2)) {
    return [true, list1]
  }
  return [false]
}

/**
 * 计算源数据中应该默认展示的节点：mappingList中所有行的源数据节点一致，则返回这个源数据节点，否则返回上个节点中的任意一个(第一个)
 * @param {Array} mappingList 字段映射列表
 * @param {Object} currentNode 当前正配置的节点
 * @param {map} nodeMap
 */
export function resolveDefaultNode(mappingList, currentNode, nodeMap) {
  let arr = []
  mappingList.forEach(item => {
    arr.push(item.sourceNodeKey)
  })
  arr = unique(arr).filter(item => !!item)
  if (arr.length === 1 && nodeMap.has(arr[0])) {
    return arr[0]
  } else {
    return currentNode?.prev ? currentNode?.prev[0] : null
  }
}

/**
 * 移除mappingList中sourceNodePath为空的行
 * @param {Array} mappingList
 */
export function removeNullRow(mappingList) {
  for (let i = 0; i < mappingList.length;) {
    const row = mappingList[i]
    // 没有设置sourceNodePath且没有设置函数，移除该行数据
    if (isNull(row.sourceNodePath) && (!row.functionList || row.functionList.length === 0)) {
      mappingList.splice(i, 1)
    } else {
      i++
    }
  }
}

// combine组件根据选择的节点和path解析path对应的数据,combine需要多包一层$
export function resolveCombineTreeData({ nodeKey, value }, nodeMap, DataTypeEnum, formData) {
  const selectNode = nodeMap.get(nodeKey)
  let selectOutputList = resolveOutputParamList(deepClone(selectNode), formData, nodeMap) // 获取所选节点的输出参数，找到当前节点所选的数据集输出字段
  selectOutputList = [{
    paramName: '$',
    dataType: 7,
    childrenList: selectOutputList
  }]
  const pathOutputList = formatterParamList(deepClone(selectOutputList), DataTypeEnum)
  const list = expandTree(pathOutputList, 'childrenList') // 展开为一维数组
  const currentData = list.find(item => item.path === value) // 找到当前数据集
  const res = formatterParamList([currentData], DataTypeEnum)
  if (res && res[0]) {
    res[0].root = true
  }
  return res
}

// 根据类型获取对应的组件
export function getCurrentNode(type) {
  switch (type) {
    case NodeTypeEnum.CHOICE: // choice节点数据
      return 'choice-option'
    case NodeTypeEnum.FOREACH: // forEach节点数据
      return 'foreach-option'
    case NodeTypeEnum.SYNC: // sync节点数据
      return 'sync-option'
    case NodeTypeEnum.ASYNC: // sync节点数据
      return 'async-option'
    case NodeTypeEnum.START:
      return 'start-option'
    case NodeTypeEnum.PROCESS:
      return 'process-option'
    case NodeTypeEnum.DB: // DB节点数据
      return 'db-option'
    case NodeTypeEnum.MQ:
      return 'mq-option'
    case NodeTypeEnum.FORWARD:
      return 'forward-option'
    case NodeTypeEnum.ERROR:
      return 'error-option'
    case NodeTypeEnum.RESPONSE:
      return 'response-option'
    case NodeTypeEnum.VARIABLE:
      return 'variable-option'
    case NodeTypeEnum.FILTER:
      return 'filter-option'
    case NodeTypeEnum.MAPPER:
      return 'mapper-option'
    case NodeTypeEnum.GROUP:
      return 'group-option'
    case NodeTypeEnum.GROOVY:
      return 'groovy-option'
    case NodeTypeEnum.COMBINE:
      return 'combine-option'
    case NodeTypeEnum.END:
      return 'end-option'
    case NodeTypeEnum.BREAK:
      return 'break-option'
    case NodeTypeEnum.CONTINUE:
      return 'continue-option'
    case NodeTypeEnum.SORT:
      return 'sort-option'
    case NodeTypeEnum.TRY:
      return 'try-option'
    case NodeTypeEnum.CACHE:
      return 'cache-option'
    default:
      break
  }
}

export function getStartOutputList({ node, formData, nodeMap }) {
  const parentId = node.parent
  if (!parentId) {
    return formData.apiInParamList
  } else {
    const parentNode = nodeMap.get(parentId)
    // sync节点的开始节点出参和最外层开始节点的节点出参一致
    if (parentNode.type !== NodeTypeEnum.FOREACH) {
      return formData.apiInParamList
    } else {
      const forEachDto = parentNode.nodeParamsLogicDto.forEachDto
      const collectionData = resolveCollection({ nodeId: forEachDto.nodeKey, collectionName: forEachDto.value, nodeMap, formData })
      return resolveStartOutputListByCollection({ variable: forEachDto.variable, collectionData })
    }
  }
}

function getDbOutputList(node) {
  const outputParamList = []
  const sqlList = node.nodeParamsLogicDto.nodeParamsDbDto.sqlList
  sqlList.forEach((item, index) => {
    if (!isSelect(item)) {
      outputParamList.push({ paramName: `sql${index + 1}`, dataType: 1, childrenList: [] })
      // insert, batch_insert && returnPkFlag时需要返回sqlX_pkId
      if (item.returnPkFlag) {
        let row = null
        if (item.sqlMethod === 'insert') {
          row = { paramName: `sql${index + 1}_pkId`, dataType: DataTypes.Object, generic: null, childrenList: [] }
        } else {
          row = {
            paramName: `sql${index + 1}_pkIds`,
            dataType: DataTypes.Array,
            generic: DataTypes.Object,
            childrenList: [
              { paramName: 'id', dataType: DataTypes.Object, childrenList: [] }
            ]
          }
        }
        outputParamList.push(row)
      }
    } else if (item.sqlMethod === 'relation_select') {
      const childrenList = item.selectFieldList.map(subItem => ({ fieldName: subItem.aliasName ? toHump(subItem.aliasName) : toHump(subItem.fieldName.split('.')[1]), dataType: subItem.dataType }))
      outputParamList.push({
        paramName: `sql${index + 1}`,
        dataType: 8,
        generic: 7,
        childrenList
      })
      if (item.queryCount) {
        outputParamList.push({
          paramName: `sql${index + 1}_count`,
          dataType: 1
        })
      }
    } else {
      outputParamList.push({
        paramName: `sql${index + 1}`,
        dataType: 8,
        generic: 7,
        childrenList: item.selectFieldList.map(subItem => ({ fieldName: toHump(subItem.fieldName), dataType: subItem.dataType }))
      })
      if (item.queryCount) {
        outputParamList.push({
          paramName: `sql${index + 1}_count`,
          dataType: 1
        })
      }
    }
  })

  return outputParamList
}

function getFilterOutputList(node) {
  const outputParamList = []
  const filter = node.nodeParamsLogicDto.filter.outputParamList
  outputParamList.push({
    dataType: 8, // 数组
    generic: 7,
    paramName: 'filter',
    rowKey: Date.now() + Math.random().toFixed(5),
    childrenList: filter
  })
  return outputParamList
}

function getMapperOutputList(node) {
  const targetMessage = node.nodeParamsLogicDto.mapper.targetMessage || null
  const outputParamList = JSON.parse(targetMessage) || []
  return outputParamList
}

function getGroupOutputList(node) {
  const outputParamList = []
  const groupData = node.nodeParamsLogicDto.group
  const groupValueRecordSet = groupData.outputParamList
  const groupKey = groupData.groupKey
  const groupKeyDataType = (groupValueRecordSet.find(item => (item.paramName === groupKey)) || { dataType: 6 }).dataType
  const value = groupData.value
  const valueArr = value.split('.')
  const valueParam = valueArr[valueArr.length - 1] || value
  if (groupData.groupKey) {
    outputParamList.push({
      dataType: 8,
      generic: 7,
      paramName: 'group',
      rowKey: Date.now() + Math.random().toFixed(5),
      childrenList: [
        { dataType: groupKeyDataType, paramName: groupKey, rowKey: Date.now() + Math.random().toFixed(5), childrenList: [] },
        { dataType: 8, paramName: valueParam, generic: 7, rowKey: Date.now() + Math.random().toFixed(5), childrenList: groupValueRecordSet }
      ]
    })
  }
  return outputParamList
}

function getGroovyOutputList(node) {
  const outputParamList = []
  const groovyData = node.nodeParamsLogicDto.groovy
  const groovy = groovyData.outputParamList
  outputParamList.push({
    dataType: 7, // 对象
    paramName: 'groovy',
    rowKey: Date.now() + Math.random().toFixed(4),
    childrenList: groovy
  })
  return outputParamList
}

function getCombineOutputList(node, nodeMap, formData) {
  const outputParamList = []
  const combineData = node.nodeParamsLogicDto.combine
  const res = resolveCombineOutputList({ combineData: deepClone(combineData), nodeMap, formData })
  if (res && Array.isArray(res) && res.length > 0) {
    outputParamList.push(res[0])
  }
  return outputParamList
}

function getChoiceOutputList(node) {
  const outputParamList = []
  const choiceData = node.nodeParamsLogicDto.choiceDto
  const choiceOutputList = choiceData.outputParamList
  outputParamList.push({
    paramName: 'choiceInfo',
    dataType: 7,
    rowKey: getUUID(),
    childrenList: choiceOutputList
  })
  return outputParamList
}

function getForeachOutputList(node) {
  const outputParamList = []
  const forEachData = node.nodeParamsLogicDto.forEachDto
  const choiceOutputList = forEachData.outputParamList
  outputParamList.push({
    paramName: 'foreach',
    dataType: 8,
    generic: 7,
    rowKey: getUUID(),
    childrenList: choiceOutputList
  })
  return outputParamList
}

function getSyncOutputList({ node }) {
  const outputParamList = []
  const synchronizedDto = node.nodeParamsLogicDto.synchronizedDto
  const syncOutputList = synchronizedDto.outputParamList
  outputParamList.push({
    paramName: 'synchronized',
    dataType: 7,
    rowKey: getUUID(),
    childrenList: syncOutputList
  })
  return outputParamList
}

function getAsyncOutputList({ _node }) {
  return []
}

function getCacheOutputList({ node }) {
  const cacheData = node.nodeParamsLogicDto.cacheDto
  const operateList = cacheData.operateList || []
  const outputParamList = []
  operateList.map((item, index) => {
    const outParam = JSON.parse(item.outParam || '{}')
    outputParamList.push({
      paramName: `cache${index + 1}`,
      dataType: outParam.dataType,
      childrenList: []
    })
  })
  return outputParamList
}

function getTryOutputList({ node }) {
  const retryDto = node.nodeParamsLogicDto.retryDto
  /**
   * tryCatch: Object
   *    isSuccess: Boolean
   *    tryResult: Object
   *    catchResult: Object
   *      errorMsg: String
   *      result: Object // catchOutputParamList为空时不显示
   */

  // catchResult的下级
  const catchResultChildrenList = []
  // tryCatch的下级
  const tryCatchChildrenList = [
    {
      paramName: 'isSuccess',
      dataType: DataTypes.Boolean
    },
    {
      paramName: 'tryResult',
      dataType: DataTypes.Object,
      childrenList: retryDto.outputParamList
    },
    {
      paramName: 'catchResult',
      dataType: DataTypes.Object,
      childrenList: catchResultChildrenList
    }
  ]
  catchResultChildrenList.push({
    paramName: 'errorMsg',
    dataType: DataTypes.String
  })
  // 有catchOutputParamList才推入catchResult.result
  if (retryDto.catchOutputParamList && retryDto.catchOutputParamList.length > 0) {
    catchResultChildrenList.push(
      {
        paramName: 'result',
        dataType: DataTypes.Object,
        childrenList: retryDto.catchOutputParamList
      })
  }
  const outputParamList = [{
    paramName: 'tryCatch',
    dataType: DataTypes.Object, // object
    childrenList: tryCatchChildrenList
  }]
  return outputParamList
}

// 结束节点的出参
function getEndOutputList({ node, formData, nodeMap }) {
  const nodeId = node.id
  const outputParamList = resolveEndNodeOutParamList({ nodeId, nodeMap, formData })
  return outputParamList
}

function getVariableOutputList(node) {
  const variableData = node.nodeParamsLogicDto.variableDto
  const outputParamList = variableData.outputParamList
  return outputParamList
}

function getSortOutputList({ node, formData, nodeMap }) {
  const sortDto = node.nodeParamsLogicDto.sortDto
  const collectionData = resolveCollection({ nodeId: sortDto.nodeKey, collectionName: sortDto.collectionName, nodeMap, formData })
  collectionData.paramName = 'sort'
  const outputParamList = formatterParamList([deepClone(collectionData)])
  return outputParamList
}

// 结束节点的出参
export function resolveEndNodeOutParamList({ nodeId, nodeMap, formData }) {
  const node = nodeMap.get(nodeId)
  const parent = node.parent
  if (!parent) {
    return formData.apiOutParamList
  } else {
    const parentNode = nodeMap.get(parent)
    if (parentNode.type === NodeTypeEnum.CHOICE) {
      return parentNode.nodeParamsLogicDto.choiceDto.outputParamList
    } else if (parentNode.type === NodeTypeEnum.FOREACH) {
      return parentNode.nodeParamsLogicDto.forEachDto.outputParamList
    } else if (parentNode.type === NodeTypeEnum.SYNC) {
      return parentNode.nodeParamsLogicDto.synchronizedDto.outputParamList
    } else if (parentNode.type === NodeTypeEnum.TRY) {
      // 在try的数据里找nodeId，如果在try里找到了就是try，否则就是catch
      const subType = getTrySubType({ nodeId, parentNode })
      if (subType === 'try') {
        return parentNode.nodeParamsLogicDto.retryDto.outputParamList
      } else {
        return parentNode.nodeParamsLogicDto.retryDto.catchOutputParamList
      }
    } else if (parentNode.type === NodeTypeEnum.ASYNC) { // 异步节点出参为空
      return []
    }
  }
}

/**
 * 全节点列表，返回节点别名
 * @param {String} nodeId 节点id
 * @param {Map} nodeMap 节点map
 *
 * @returns
 */
export function getNodePrefixName({ nodeId, nodeMap }) {
  const node = nodeMap.get(nodeId)
  const parentId = node.parent
  if (!parentId) { // 没有父节点
    return node.name
  }
  if (parentId) {
    const parentNode = nodeMap.get(parentId)
    const parentType = parentNode.type
    switch (parentType) {
      // 直接返回父节点名称 + node.name
      case NodeTypeEnum.FOREACH:
      case NodeTypeEnum.SYNC:
      case NodeTypeEnum.ASYNC:
        return `${parentNode.name}【${node.name}】`
        // 拼接choice的序号
      case NodeTypeEnum.CHOICE:
        return `${parentNode.name}【${getChoiceIndex({ nodeId, parentNode })}】【${node.name}】`
      case NodeTypeEnum.TRY:
        // 拼接try/catch类型
        return `${parentNode.name}【${getTrySubType({ nodeId, parentNode })}】【${node.name}】`
      default:
        return node.name
    }
  }
}

/**
 *
 * 获取节点在嵌套节点内的索引（适用于多重条件判断的节点）
 * @param {String} nodeId 节点id
 * @param {Map} nodeMap 节点map
 * @returns index
 */
export function getNodeIndex({ nodeId, nodeMap }) {
  const node = nodeMap.get(nodeId)
  const parentId = node.parent
  if (!parentId) { // 没有父节点
    return 0
  }
  if (parentId) {
    const parentNode = nodeMap.get(parentId)
    const parentType = parentNode.type
    switch (parentType) {
      // 直接返回父节点名称 + node.name
      case NodeTypeEnum.FOREACH:
      case NodeTypeEnum.SYNC:
      case NodeTypeEnum.ASYNC:
        return 0
        // 拼接choice的序号
      case NodeTypeEnum.CHOICE:
        return getChoiceIndex({ nodeId, parentNode }) - 1 // NOTE - choice节点返回的数值是用户友好，这里要减1
      case NodeTypeEnum.TRY:
        // 拼接try/catch类型
        return getTrySubType({ nodeId, parentNode }) === 'try' ? 0 : 1
      default:
        return 0
    }
  }
}

/**
 * 获取try节点的子节点 在try块中还是catch块中
 * @param {*} nodeId 节点id
 * @param {*} parentNode 父节点数据
 * @returns
 */
export function getTrySubType({ nodeId, parentNode }) {
  const retryDto = parentNode.nodeParamsLogicDto.retryDto
  const tryRelationDto = retryDto.relationDto
  const tryNodelist = tryRelationDto.nodeList
  const result = tryNodelist.find(item => item.id === nodeId)
  if (result) {
    return 'try'
  } else {
    return 'catch'
  }
}

/**
 * 获取choice中的子节点的序号
 * @param {*} nodeId 节点id
 * @param {*} parentNode 父节点数据
 * @returns 序号
 */
export function getChoiceIndex({ nodeId, parentNode }) {
  const choiceDto = parentNode.nodeParamsLogicDto.choiceDto
  const conditionList = choiceDto.conditionList
  // 寻找nodeId在哪个condition中，返回对应的index和ifelse类型
  let index = null
  const len = conditionList.length
  for (let i = 0; i < len; i++) {
    const nodeList = conditionList[i].relationDto.nodeList
    const result = nodeList.findIndex(item => {
      return item.id === nodeId
    })
    if (result >= 0) {
      index = i
      break
    }
  }
  return index + 1
}

function isSelect(item) {
  if (['select', 'relation_select'].includes(item.sqlMethod) || (item.isInputSql && item.textSql.toLowerCase().includes('select'))) {
    return true
  } else {
    return false
  }
}

/**
 * 解析combine节点的输出参数
 * @param {*} param0
 * @returns
 */
function resolveCombineOutputList({ combineData, nodeMap, DataTypeEnum = [], formData = {} }) {
  const nodeKeyList = combineData.nodeKeyList
  let mainTree, lineTree
  if (nodeKeyList[0] && nodeKeyList[0].value) {
    mainTree = resolveCombineTreeData(nodeKeyList[0], nodeMap, DataTypeEnum, formData)
  }
  if (nodeKeyList[1] && nodeKeyList[1].value) {
    lineTree = resolveCombineTreeData(nodeKeyList[1], nodeMap, DataTypeEnum, formData)
  }
  return displayTreeData(combineData, mainTree, lineTree, DataTypeEnum)
}

function displayTreeData(combineData, mainTree, lineTree, DataTypeEnum) {
  const listFlag = combineData.listFlag
  const fieldName = combineData.fieldName

  let lineData = null
  let mainData = null
  if (mainTree && mainTree[0]) {
    mainData = mainTree[0]
  }

  if (lineTree && lineTree[0]) {
    lineData = lineTree[0]
  }

  if (!mainData) {
    return []
  }
  mainData.label = mainData.label.replace(mainData.paramName, 'combineRecord')
  mainData.paramName = 'combineRecord'
  mainData.path = 'combineRecord'
  if (fieldName && lineData) {
    mainData.childrenList.push({
      dataType: listFlag ? 8 : 7,
      paramName: fieldName,
      generic: listFlag ? 7 : null,
      path: listFlag ? `combineRecord[].${fieldName}` : `combineRecord.${fieldName}`,
      childrenList: lineTree[0].childrenList
    })
  }
  const res = formatterParamList([mainData], DataTypeEnum)
  return res
}

// 开始节点根据数据集数据组装出参数据
function resolveStartOutputListByCollection({ variable, collectionData }) {
  const collectionDataGeneric = collectionData.generic
  let treeData = [{
    paramName: variable,
    dataType: collectionDataGeneric,
    childrenList: collectionData.childrenList || []
  }]
  treeData = formatterParamList(deepClone(treeData))
  return treeData
}

export function wrapJsonStr(str, wrapper) {
  if (!wrapper || !str) {
    return {}
  }
  try {
    let jsonObj = JSON.parse(str)
    jsonObj = { [wrapper]: jsonObj }
    return jsonObj
  } catch (e) {
    return {}
  }
}

/**
 * 比较左侧右侧树选中的行，按规则填充到mappingList
 * @param {Array} leftTree 目标树
 * @param {Array} rightTree 源数据树
 * @param {Object} leftSelectRow 左侧选中行
 * @param {Object} rightSelectRow 右侧选中行
 * @param {Array} mappingList 最终映射树的源数据
 * @param {Boolean} ignoreDataType 忽略参数类型（基本类型）
 */
export function compareAndMapping({ leftTree, rightTree, leftSelectRow, rightSelectRow, mappingList, rightNodeId, ignoreDataType = false }) {
  // 深拷贝源数据，避免修改到源数据
  leftTree = deepClone(leftTree)
  rightTree = deepClone(rightTree)
  // 添加path操作，不能删除
  // eslint-disable-next-line no-unused-vars
  const leftAbsPathMap = treeToMap(leftTree, 'path')
  // eslint-disable-next-line no-unused-vars
  const rightAbsPathMap = treeToMap(rightTree, 'path')
  // 从leftMap和rightMap上找到leftSelectRow和rightSelectRow
  leftSelectRow = getSourceData(leftTree, leftSelectRow)
  rightSelectRow = getSourceData(rightTree, rightSelectRow)
  const leftRelPathMap = treeToMap([leftSelectRow], 'relPath')
  const rightRelPathtMap = treeToMap([rightSelectRow], 'relPath')
  console.log('leftAbsPathMap', leftAbsPathMap)
  console.log('rightAbsPathMap', rightAbsPathMap)
  console.log('leftRelPathMap', leftRelPathMap)
  console.log('rightRelPathtMap', rightRelPathtMap)
  leftRelPathMap.forEach((value, key) => {
    // 左右相对路径相等且数据类型相等时，查看绝对路径中是否都有[],若满足，则对比类型并进行匹配根据绝对路径值写入到mapplist
    if (rightRelPathtMap.has(key)) {
      const leftRow = value
      const rightRow = rightRelPathtMap.get(key)
      const leftDataType = value.dataType
      const rightDataType = rightRow.dataType
      // 后追加的$没有绝对路径，设置绝对路径为$$，没有实际作用，避免includes报错
      const leftAbsPath = leftRow.path || '$$'
      const rightAbsPath = rightRow.path || '$$'
      // 都有[]或都没有[]才匹配
      const leftHasArr = leftAbsPath.includes('[')
      const rightHasArr = rightAbsPath.includes('[')
      // 是否比较类型(仅针对基本类型): 勾选忽略类型且两边类型都不是引用类型时不用比较类型
      const referenceTypes = [DataTypes.Object, DataTypes.Array]
      const dataTypePass = (ignoreDataType && !referenceTypes.includes(leftDataType) && !referenceTypes.includes(rightDataType)) ? true : leftDataType === rightDataType
      if (leftHasArr === rightHasArr && dataTypePass) {
        // mappingList中对应的行
        // const row = mappingList.find(item => item.targetNodePath === leftAbsPath)
        const row = mappingList.find(item => {
          const res = toHump(item.targetNodePath).toLowerCase() === toHump(leftAbsPath).toLowerCase()
          return res
        })
        // row存在
        if (row) {
          // row值为空
          if (!row.sourceNodePath && (!row.functionList || row.functionList.length <= 0)) {
            // row的映射值设置为右侧树对应行的绝对路径
            row.sourceNodePath = rightAbsPath
            row.sourceNodeKey = rightNodeId
            row.referenceType = 1
            row.sourceDataType = rightDataType
          }
        }
      }
    }
  })
}

// 1. 加path  2. 拍平  3. 写入map(需要将map的key转驼峰后转纯小写)
function treeToMap(tree, pathKey) {
  const map = new Map()
  const pathTree = formatterParamList(tree, undefined, undefined, undefined, pathKey)
  const list = expandTree(pathTree, 'childrenList')
  list.forEach(item => {
    map.set(toHump(item[pathKey]).toLowerCase(), item)
  })
  return map
}

/**
 * 找到选中行在源数据中的对应数据
 */
function getSourceData(tree, selectRow) {
  if (!selectRow) {
    return ({
      paramName: '$',
      dataType: 7,
      childrenList: tree,
      rowKey: Math.random().toFixed(5)
    })
  }
  const list = expandTree(tree, 'childrenList')

  const result = list.find(item => item.path === selectRow.path)
  // 如果是引用类型，将paramName转为$
  if ([7, 8].includes(selectRow.dataType)) {
    result.paramName = '$'
  }
  return result
}

/**
 * 对于数据库节点判断是否可选择该行数据
 * @param {*} param0
 * @param {Number} selectNodeId 选中的节点id
 * @param {Number} currentNodeId 当前的节点id
 * @param {Number} selectPath 选中的path，用于解析当前sql的index
 * @param {Number} currentIndex 当前的SQL索引
 * @returns {Boolean} 是否可选择
 */
export function validDbCanUse({ selectNodeId, selectPath, currentNodeId, currentIndex }) {
  // 从selectPath中找到select的index
  const result = selectPath.match(/([0-9]+)/)
  const selectIndex = result ? result[1] - 1 : 9999
  let canUse = true
  if (selectNodeId === currentNodeId && currentIndex <= selectIndex) { // 选择当前节点时，判断一下index是否在前
    canUse = false
  }
  return canUse
}
