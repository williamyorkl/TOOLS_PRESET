<template>
  <el-dialog :title="nodeFormData.name || '节点配置'" :visible.sync="visible" :beforeClose="handleCancel" width="90%" appendToBody :class="{tour: isTour}">
    <!-- 不同type渲染不同编辑弹窗 -->
    <component v-if="nodeFormData" ref="option-form" :is="currentNodeDialog" :formData="formData" :nodeFormData="nodeFormData" />

    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel" v-if="!formDisabled">取 消</el-button>
      <el-button type="primary" @click="handleConfirm" v-if="!formDisabled">确 定</el-button>
      <el-button @click="handleCancel" v-if="formDisabled">关 闭</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { deepClone } from '@/utils'
import { getCurrentNode } from './node-option-utils'
import choiceOption from './option-dialog/choice'
import combineOption from './option-dialog/combine'
import dbOption from './option-dialog/db'
import endOption from './option-dialog/end'
import errorOption from './option-dialog/error'
import filterOption from './option-dialog/filter'
import foreachOption from './option-dialog/foreach'
import SyncOption from './option-dialog/sync'
import AsyncOption from './option-dialog/async'
import forwardOption from './option-dialog/forward'
import groovyOption from './option-dialog/groovy'
import groupOption from './option-dialog/group'
import mapperOption from './option-dialog/mapper'
import mqOption from './option-dialog/mq'
import processOption from './option-dialog/process'
import responseOption from './option-dialog/response'
import startOption from './option-dialog/start'
import variableOption from './option-dialog/variable'
import breakOption from './option-dialog/breakDto'
import continueOption from './option-dialog/continueDto'
import sortOption from './option-dialog/sort'
import cacheOption from './option-dialog/cache'
import tryOption from './option-dialog/try'
export default {
  name: 'NodeOptionDialog',
  components: { choiceOption, combineOption, dbOption, endOption, errorOption, filterOption, foreachOption, SyncOption, forwardOption, groovyOption, groupOption, mapperOption, mqOption, processOption, responseOption, startOption, variableOption, breakOption, continueOption, sortOption, AsyncOption, cacheOption, tryOption },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    formData: {
      default: () => ({}),
      type: Object
    },
    activeElement: {
      // 节点完整的配置数据
      type: Object,
      default: () => ({})
    },
    mode: {
      type: String,
      default: 'edit'
    }
  },
  data() {
    return {
      nodeFormData: null
      // rules: {
      //   name: [{ required: true, message: '请输入节点名称', trigger: 'blur' }]
      // },
      // // formData: new Node({})
      // formData: {}
    }
  },
  provide() {
    return {
      getNodeFormData: () => { return this.nodeFormData }
    }
  },
  created() {
    this.nodeFormData = deepClone(this.activeElement.node)
    this.nodeMap.set('currentNode', this.nodeFormData)
  },
  inject: {
    formDisabled: {
      from: 'formDisabled'
    },
    mode: {
      from: 'mode',
      default: 'edit'
    },
    nodeMap: {
      from: 'nodeMap'
    }
  },
  computed: {
    currentNodeDialog() {
      return getCurrentNode(this.nodeFormData.type)
    },
    isTour() {
      return this.mode === 'arrangeTplTour'
    }
  },
  methods: {
    handleConfirm() {
      this.$refs['option-form'].validateFormData(valid => {
        if (valid) {
          this.$emit('update:visible', false)
          this.$emit('save', this.nodeFormData)
          console.log(this.nodeFormData.nodeParamsLogicDto.nodeParamsDbDto)
        } else {
          this.$message.error('请按照提示完善表单数据')
          return false
        }
      })
    },
    handleCancel() {
      this.$emit('update:visible', false)
    }
  }
}
</script>

<style scoped lang="scss">
.tour {
  position: absolute !important;
}
</style>
