<template>
  <el-dialog :title="'条件配置'" :visible.sync="visible" :before-close="handleCancel" width="90%" append-to-body>
    <el-form ref="form" :model="preCondition" :rules="rules" label-width="120px" :disabled="formDisabled">
      <el-form-item label="前置条件">
          <el-card class="card">
            <ConditionList :preConditionList="preCondition.conditionList" referenceTypeEnum="ParamReferenceTypeEnum" />
          </el-card>
        </el-form-item>
        <el-form-item label="逻辑关系">
          <el-input :disabled="preCondition.conditionList.length <= 1" v-model="preCondition.condLogicExp" placeholder="示例：(c1 && c2) && (c3 || c4)"></el-input>
        </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel" v-if="!formDisabled">取 消</el-button>
      <el-button type="primary" @click="handleConfirm" v-if="!formDisabled">确 定</el-button>
      <el-button @click="handleCancel" v-if="formDisabled">关 闭</el-button>
    </span>

  </el-dialog>
</template>

<script>
import { deepClone } from '@/utils'
import ConditionList from '../components/conditionSelector'

export default {
  name: 'ChoiceOptionDialog',
  components: { ConditionList },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    choiceItemData: {},
    activeElement: {},
    preCondition: {
      type: Object,
      default: () => ({
        conditionList: [],
        condLogicExp: ''
      })
    }
  },
  data() {
    return {
      // preCondition: null,
      rules: {
        name: [{ required: true, message: '请输入节点名称', trigger: 'blur' }]
      }
    }
  },
  provide() {
    return {
      getNodeFormData: () => { return this.nodeFormData }
    }
  },
  inject: ['formDisabled'],
  watch: {
    'preCondition.conditionList': {
      handler(nV) {
        console.log('nV', nV)
        let str = ''
        if (nV) {
          nV.forEach((_, index) => {
            if (!str) {
              str += `c${index + 1}`
            } else {
              str += ` && c${index + 1}`
            }
          })
        }
        this.preCondition.condLogicExp = str
      }
    }
  },
  computed: {
    nodeFormData() {
      return this.activeElement.node
    }
  },
  methods: {
    handleConfirm() {
      this.$refs.form.validate(valid => {
        if (valid) {
          // 替换源数据中的preCondition，这个preCondition是深拷贝后的，和choiceItemData中的数据不一致
          this.choiceItemData.preCondition = this.preCondition
          this.$emit('update:visible', false)
        } else {
          this.$message.error('请按照提示完善表单数据')
          return false
        }
      })
    },
    handleCancel() {
      this.$emit('update:visible', false)
    }
  }
}
</script>

<style>
</style>
