<template>
  <el-dialog :title="'节点操作指引信息'" :visible.sync="visible" :beforeClose="handleCancel" width="50%" appendToBody>
    <el-form ref="form" :model="formData" :rules="rules" labelWidth="120px">
      <el-form-item label="标题" prop="templateNodeTitle">
        <el-input v-model.trim="formData.templateNodeTitle" readonly />
      </el-form-item>
      <el-form-item label="描述" prop="templateNodeDesc">
        <el-input v-model.trim="formData.templateNodeDesc" type="textarea" />
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">取 消</el-button>
      <el-button type="primary" @click="handleConfirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>

export default {
  name: 'ChoiceOptionDialog',
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    formData: {
      type: Object,
      default: () => ({
        nodeKey: null,
        templateNodeDesc: null,
        templateNodeTitle: null
      })
    }
  },
  data() {
    return {
      // preCondition: null,
      rules: {
        templateNodeDesc: [{ required: true, message: '请输入描述', trigger: 'blur' }]
      }
    }
  },
  methods: {
    handleConfirm() {
      this.$refs.form.validate(valid => {
        if (valid) {
          console.log('confirm node desc', this.formData)
          this.$emit('save', this.formData)
          this.$emit('update:visible', false)
        } else {
          this.$message.error('请按照提示完善表单数据')
          return false
        }
      })
    },
    handleCancel() {
      this.$emit('update:visible', false)
    }
  }
}
</script>

<style>
</style>
