<template>
  <el-form ref="form" :model="formItem" class="condition-form" labelWidth="76px" :disabled="formDisabled">
    <el-row :gutter="10">
      <el-col :span="8">
        <el-form-item required label="变量名">
          <el-input v-model="formItem.variableName" placeholder="请输入变量名" @blur="variableChange" />
        </el-form-item>
      </el-col>
      <el-col :span="8">
        <el-form-item required label="取值类型">
          <el-select v-model="formItem.referenceType" placeholder="请选择取值方式" @change="typeChange">
            <el-option v-for="item in ReferenceTypeFuncEnum" :key="item.type" :label="item.desc" :value="item.type" />
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="8">
        <el-form-item required label="数据类型">
          <el-select v-model="formItem.dataType" placeholder="请选择参数值类型" @change="variableChange" :disabled="formItem.referenceType !== 0">
            <el-option v-for="item in dataTypeList" :key="item.type" :label="item.desc" :value="item.type" />
          </el-select>
        </el-form-item>
      </el-col>
      <!-- 固定值 -->
      <template v-if="formItem.referenceType === 0">
        <el-col :span="8">
          <el-form-item required label="值">
            <!-- String不需要trim -->
            <mc-input :data-type="formItem.dataType" :trim="false" v-model="formItem.sourceNodePath" placeholder="值" :disabled="formDisabled" />
          </el-form-item>
        </el-col>
      </template>
      <!-- 引用值 -->
      <template v-if="formItem.referenceType === 1">
        <el-col :span="8">
          <el-form-item required label="源字段节点">
            <el-input :value="resolveNodeName(formItem.sourceNodeKey, nodeMap)" disabled />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item required label="源字段">
            <el-input v-model="formItem.sourceNodePath" placeholder="请输入内容" :disabled="true">
              <el-button slot="append" icon="el-icon-setting" @click="showJsonTree(formItem)" />
            </el-input>
          </el-form-item>
        </el-col>
      </template>
      <!-- 函数 -->
      <template v-if="formItem.referenceType === 2">
        <el-col :span="24">
          <FunctionSetting :formItem="formItem" />
        </el-col>
      </template>
      <!-- 全局变量 -->
      <template v-if="formItem.referenceType === 3">
        <el-col :span="8">
          <el-form-item required label="变量">
            <mc-popover-select v-model="formItem.sourceNodePath" :disabled="formDisabled" :defaultValue="formItem.sourceNodePath" :apiFunc="globalVariableApiFunc" :tableColumn="globalVariableTableColumn" :queryList="globalVariableQueryList" labelKey="keyName" valueKey="keyName" @changeRow="keyNameChange" />
          </el-form-item>
        </el-col>
      </template>
    </el-row>
    <!-- 数据源json弹窗 -->
    <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px">
      <JsonTree title="源数据" :selectNodeId.sync="selectNodeId" :data.sync="sourceData" :multipleNode="true" @rightClick="rightClick" />
    </el-dialog>
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
import { Variable } from '../../../model/nodeParams_model'
import JsonTree from '../jsonTree'
import FunctionSetting from './functionSetting'
import mixinResolveNodeName from '../../../mixins/resolveNodeName'
import globalVariableOption from '@/config/popContentTableConfig/globalVariable.config'

export default {
  name: 'VariablesTable',
  components: { JsonTree, FunctionSetting },
  props: {
    dataList: {
      type: Array,
      default: () => []
    },
    formItem: {
      type: Object,
      default: () => ({})
    }
  },
  inject: ['nodeMap', 'formDisabled'],
  mixins: [mixinResolveNodeName],
  data() {
    return {
      globalVariableApiFunc: globalVariableOption.apiFunc,
      globalVariableTableColumn: [],
      globalVariableQueryList: [],
      includeList: [1, 2, 3, 4, 5, 6, 7, 8],
      // 参数类型枚举  引用 固定
      ReferenceTypeFuncEnum: [],
      // 数据类型枚举
      dataTypeList: [],
      // 比较符枚举
      compareTypeList: [],
      jsonTreeDialogVisible: false,
      selectNodeId: null,
      sourceData: [],
      currentRow: null

    }
  },
  async created() {
    const [GlobalKeyValTypeEnum] = await this.getDicts(['GlobalKeyValTypeEnum', 'DataTypeEnum'])
    this.globalVariableQueryList = globalVariableOption.getQueryList({ GlobalKeyValTypeEnum })
    this.globalVariableTableColumn = globalVariableOption.getTableColumn()
  },
  mounted() {
    this.getDict()
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    keyNameChange(row) {
      console.log('keyChange', row)
      this.formItem.dataType = row.dataType
    },
    variableChange() {
      this.$emit('variableChange')
    },
    compareChange(_v, _formItem) {
      console.log('compareChange')
      // if (this.includeList.includes(v)) {
      //   formItem.c2 = new C('c2')
      // } else {
      //   formItem.c2 = null
      // }
    },
    showJsonTree(c) {
      if (c.referenceType === undefined) return this.$message.warning('请先选择参数类型')
      if (c.referenceType === 1) {
        // 引用值，显示弹窗
        this.jsonTreeDialogVisible = true
        this.currentRow = c
      }
    },
    rightClick(node, nodeId, selectNode) {
      this.jsonTreeDialogVisible = false
      this.currentRow.sourceNodeKey = nodeId
      this.currentRow.sourceNodePath = node.path
      this.currentRow.sourceNodeName = selectNode.name
      this.currentRow.dataType = node.dataType
    },
    typeChange() {
      this.formItem.sourceNodePath = null
      this.formItem.sourceNodeName = null
      this.formItem.sourceNodeKey = null
      this.formItem.express = null
      this.formItem.parameters = []
      this.formItem.dataType = null
    },
    // 获取数据字典
    async getDict() {
      [this.dataTypeList, this.compareTypeListm, this.ReferenceTypeFuncEnum] =
        await this.getDicts([
          'DataTypeEnum',
          'CompareSymbolEnum',
          'ReferenceTypeFuncEnum'
        ])
    },
    // 添加条件
    pushCondition() {
      this.dataList.push(new Variable())
    },
    // 删除条件
    reduceCondition(index) {
      this.dataList.splice(index, 1)
    }
    // getFuncVariableMapNodeName() {
    //   // 函数类型，要根据nodeId获取一下函数参数的引用节点的nodeName
    //   if (this.formItem.referenceType === 2) {
    //     const parameters = this.formItem.parameters
    //     parameters && parameters.length > 0 && parameters.forEach(parameter => {
    //       const node = this.nodeMap.get(parameter.sourceNodeKey)
    //       if (node) {
    //         this.$set(parameter, 'sourceNodeName', node.name)
    //       }
    //     })
    //   }
    // }
  }
}
</script>

<style lang="scss" scoped>
.condition-form {
  border: 1px dotted #ccc;
  padding: 8px;
  ::v-deep .el-form-item {
    margin-bottom: 8px;
    padding-left: 8px;
  }
}
.el-icon-remove-outline {
  color: red;
  font-size: 22px;
  cursor: pointer;
}
.btn {
  display: block;
  width: 92%;
  border-style: dotted;
}
</style>
