// 字段映射列表
<template>
  <el-form class="table-form" ref="mappingForm" :model="formData" :rules="rules" labelWidth="0px" size="mini" v-if="doRender" :disabled="formDisabled">
    <ux-grid ref="mappingTable" class="param-table" :data="formData.tableList" highlightCurrentRow @current-change="handleCurrentChange" :maxHeight="maxHeight" :scrollX="{gt: -1}" @table-body-scroll="tableBodyScroll">
      <ux-table-column resizable title="序号" type="index" align="left" width="60" />

      <!-- 类型为 固定值和请求入参时才支持手动输入，其他情况只能从树中选择 -->
      <ux-table-column resizable field="targetNodePath" title="目标字段名" align="left" :showOverflowTooltip="false" minWidth="200px">
        <template slot-scope="scope">
          <el-form-item>
            <el-input type="text" v-model="scope.row.targetNodePath" disabled placeholder="请从目标数据选择" />
          </el-form-item>
        </template>
      </ux-table-column>

      <!-- <ux-table-column resizable v-if="false" field="dataPosition" title="参数位置" align="left" :show-overflow-tooltip="false" min-width="170px">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.dataPosition" disabled clearable placeholder="请选择">
              <el-option v-for="item in DataPosEnum" :key="item.type" :label="item.desc" :value="item.type">
              </el-option>
            </el-select>
          </el-form-item>
        </template>
      </ux-table-column> -->

      <!-- 出参配置不包含类型和数据类型设置,限制必须从源数据中选择 -->
      <ux-table-column resizable field="referenceType" title="取值类型" align="left" :showOverflowTooltip="false" minWidth="200px">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.referenceType" placeholder="请选择" @change="referenceTypeChange($event, scope.row)">
              <!-- 数组不允许选固定值 -->
              <el-option v-for="item in ParamReferenceTypeEnum" :key="item.type" :label="item.desc" :value="item.type" :disabled="scope.row.dataType === 8 && item.type === 0" />
            </el-select>
          </el-form-item>
        </template>
      </ux-table-column>

      <ux-table-column resizable field="dataType" title="数据类型" align="left" :showOverflowTooltip="false" minWidth="130px">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.dataType" placeholder="请选择" @change="dataTypeChange(scope.row)" :disabled="!allowSetDataType">
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </ux-table-column>

      <ux-table-column resizable v-if="needIsRequired" field="isRequired" title="是否必填" align="left" :showOverflowTooltip="false" minWidth="100px">
        <template slot-scope="scope">
          <el-form-item>
            <el-switch v-model="scope.row.isRequired" disabled />
          </el-form-item>
        </template>
      </ux-table-column>

      <ux-table-column resizable field="sourceNodeName" title="源字段节点" align="left" :showOverflowTooltip="false" minWidth="200px">
        <template slot-scope="scope">
          <el-form-item>
            <el-input :value="resolveNodeName(scope.row.sourceNodeKey, nodeMap)" :disabled="true" />
          </el-form-item>
        </template>
      </ux-table-column>
      <!-- 类型为 固定值和请求入参时才支持手动输入，其他情况只能从树中选择 -->
      <ux-table-column resizable field="sourceNodePath" title="源字段或值" align="left" :showOverflowTooltip="false" minWidth="200px">
        <template slot-scope="scope">
          <el-form-item>
            <mc-input v-if="scope.row.referenceType === 0" :data-type="scope.row.dataType" :trim="false" v-model="scope.row.sourceNodePath" placeholder="源字段或值" />
            <!-- 引用值时禁用 -->
            <el-input v-else type="text" v-model.trim="scope.row.sourceNodePath" :disabled="scope.row.referenceType === 1" />
          </el-form-item>
        </template>
      </ux-table-column>

      <ux-table-column resizable title="操作" width="200px" align="left">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="editFunction(scope.row,scope.rowIndex, scope)" :disabled="scope.row.dataType === 8">函数{{ scope.row.functionList&&scope.row.functionList.length ? '('+scope.row.functionList.length+')':'' }}</el-button>
          <el-button type="text" size="mini" @click="editMapping(scope.row,scope.rowIndex)">映射{{ scope.row.dictMapping?'(1)':'' }}</el-button>
          <el-button type="text" size="mini" @click="editScript(scope.row,scope.rowIndex)">脚本{{ scope.row.scriptData?'(1)':'' }}</el-button>
          <el-button type="text" size="mini" @click="resetRow(scope.row,scope.rowIndex)">重置</el-button>
        </template>
      </ux-table-column>
      <ux-table-column resizable title="操作" width="150px" align="left" v-if="allowAdd && !formDisabled">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="deleteRow(scope.rowIndex)">删除</el-button>
        </template>
      </ux-table-column>
    </ux-grid>
    <div class="mt-10 mb-10" v-if="allowAdd && !formDisabled">
      <el-button class="table-add-btn" @click="addRow" icon="el-icon-plus">添加</el-button>
    </div>
    <FunctionSettingDialog ref="functionRfc" v-if="functionDialogVisible" :dialogData="selectRow" :visible.sync="functionDialogVisible" @finish="(val)=>updateRow(val, 'functionList')" />
    <ScriptSetting :dialogForm="selectRow" v-if="scriptDialogVisible" :visible.sync="scriptDialogVisible" @finish="(val)=>updateRow(val, 'scriptData')" />
    <MappingSetting :dialogForm="selectRow" v-if="mappingDialogVisible" :visible.sync="mappingDialogVisible" @finish="(val)=>updateDictMappingRow(val, 'dictMapping')" />
  </el-form>
</template>

<script>
import ScriptSetting from './dialog/scriptSetting'
import MappingSetting from './dialog/mappingSetting'
import FunctionSettingDialog from './dialog/function-setting/function-setting-dialog'

import { mapActions } from 'vuex'
import { activeNextRow, setCurrentRow } from '@/base_components/utils/uTableUtils'
import mixinResolveNodeName from '@/components/flow-node/mixins/resolveNodeName'
let left = 0
let top = 0
export default {
  components: { FunctionSettingDialog, ScriptSetting, MappingSetting },
  props: {
    tableList: {
      default: () => [],
      type: Array
    },
    title: {
      default: 'inParamTable',
      type: String
    },
    allowAdd: {
      type: Boolean,
      default: true
    },
    maxHeight: {
      default: '300px',
      type: String
    },
    needIsRequired: {
      default: true,
      type: Boolean
    },
    allowSetDataType: {
      default: false,
      type: Boolean
    }
  },
  inject: ['formDisabled', 'nodeMap'],
  mixins: [mixinResolveNodeName],
  data() {
    return {
      formData: {
        tableList: this.tableList
      },
      rules: {},
      DataTypeEnum: [],
      ParamReferenceTypeEnum: [],
      DataPosEnum: [],
      selectRow: {},
      selectIndex: null,
      functionDialogVisible: false,
      scriptDialogVisible: false,
      mappingDialogVisible: false,
      activeRowIndex: 0,
      doRender: false
    }
  },
  watch: {
    tableList: {
      async handler(nV) {
        if (nV) {
          this.formData.tableList = nV
          await this.$nextTick()
          this.doRender = true
        }
      },
      immediate: true
    }
  },
  async created() {
    [this.DataTypeEnum, this.ParamReferenceTypeEnum, this.DataPosEnum] = await this.getDicts([
      'DataTypeEnum',
      'ParamReferenceTypeEnum',
      'DataPosEnum'
    ])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    dataTypeChange(row) {
      row.sourceNodePath = null
      row.functionList = []
      row.sourceNodeKey = null
      if (row.dataType === 8) {
        row.referenceType = 1
      }
    },
    handleCurrentChange(row) {
      this.currentRow = row
      this.$emit('eventLinstener', {
        type: 'currentChange',
        row: row,
        list: this.tableList,
        title: this.title
      })
    },
    activeNextRow() {
      this.activeRowIndex = activeNextRow(this.formData.tableList, this.currentRow, this.$refs.mappingTable, 'targetNodePath')
      const currentRow = this.formData.tableList[this.activeRowIndex]
      this.handleCurrentChange(currentRow)
      top = top + 49
      this.$refs.mappingTable.pagingScrollTopLeft(top, left)
    },
    setCurrentRow(row) {
      const currentRow = setCurrentRow(this.formData.tableList, row, this.$refs.mappingTable, 'targetNodePath')
      this.handleCurrentChange(currentRow)
      if (!currentRow) return this.$message.error('自动匹配行失败，请手动选择')
    },
    scrollToActiveRow() {
      let scrollTop = (this.activeRowIndex - 1) * 49
      const scrollHeight = this.$refs.mappingTable.bodyWrapper.scrollHeight
      if (scrollTop > scrollHeight) scrollTop = scrollHeight
      this.$refs.mappingTable.bodyWrapper.scrollTop = scrollTop
    },
    tableBodyScroll({ scrollTop, scrollLeft }) {
      left = scrollLeft
      top = scrollTop
    },
    addRow() {
      this.$emit('eventLinstener', {
        type: 'add',
        title: this.title,
        list: this.tableList
      })
    },
    editFunction(row, index) {
      this.functionDialogVisible = true
      if (!row.functionList) row.functionList = []
      this.selectRow = row
      this.selectIndex = index
    },
    resetRow(row, _index) {
      console.log('row', row)
      row.functionList = []
      row.dictMapping = null
      row.scriptData = null
      row.sourceNodeKey = null
      row.sourceNodeName = null
      row.sourceNodePath = null
    },
    // 编辑脚本
    editScript(row, index) {
      this.scriptDialogVisible = true
      this.selectRow = row
      this.selectIndex = index
    },
    editMapping(row, index) {
      console.log(row)
      this.mappingDialogVisible = true
      this.selectRow = row
      this.selectIndex = index
    },
    updateRow(formData, key) {
      console.log(formData, key)
      const selectIndex = this.selectIndex
      this.formData.tableList[selectIndex][key] = formData[key]
      this.scriptDialogVisible = false
      this.functionDialogVisible = false
    },
    updateDictMappingRow(formData, key) {
      const selectIndex = this.selectIndex
      if (!formData[key].dictMapId) {
        formData[key] = null
      }
      this.formData.tableList[selectIndex][key] = formData[key]
      this.scriptDialogVisible = false
      this.functionDialogVisible = false
      this.mappingDialogVisible = false
    },
    deleteRow(index) {
      this.$confirm(
        '确定删除此行吗? 删除不会提交数据，请点击【保存】提交',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      ).then(() => {
        this.formData.tableList.splice(index, 1)
      })
    },
    referenceTypeChange(v, row) {
      row.sourceNodeKey = null
      row.sourceNodePath = null
      row.sourceNodeName = null
    }
  }
}
</script>

<style scoped lang="scss">
.table-add-btn {
  width: 100%;
}
</style>
