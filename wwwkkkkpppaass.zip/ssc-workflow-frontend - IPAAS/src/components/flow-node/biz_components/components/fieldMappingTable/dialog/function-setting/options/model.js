// 组合函数的设置
export class FunctionDTO {
  constructor() {
    this.express = null
    this.parameters = {}
    this.scope = null
  }
}
