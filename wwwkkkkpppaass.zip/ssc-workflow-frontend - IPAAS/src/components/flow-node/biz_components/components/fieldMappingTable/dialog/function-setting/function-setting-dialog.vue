<template>
  <el-dialog title="函数设置" :visible="visible" width="70%" @close="$emit('update:visible', false)" appendToBody>
    <FunctionSetting ref="functionRfc" :targetDataType="dialogForm.dataType" :tableData="dialogForm.functionList" />
    <span slot="footer" class="dialog-footer">
      <el-button v-if="formDisabled" @click="$emit('update:visible', false)">关 闭</el-button>
      <el-button v-else @click="$emit('update:visible', false)">取 消</el-button>
      <el-button type="primary" @click="sure">确 定</el-button>

    </span>
  </el-dialog>
</template>

<script>
import { deepClone } from '@/utils'
import { validateTree } from '@/utils/validator'
import FunctionSetting from './index'

export default {
  name: 'FunctionSettingDialog',
  components: { FunctionSetting },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    id: {
      type: [String, Number],
      default: ''
    },
    dialogData: {
      type: [Object],
      default: function() {
        return { functionList: [] }
      }
    }
  },
  inject: ['formDisabled'],
  data() {
    return {
      dialogForm: {
        functionList: []
      }
    }
  },
  created() {
    this.dialogForm = deepClone(this.dialogData)
  },
  methods: {
    sure() {
      const msg = validateTree({
        tree: this.dialogForm.functionList,
        ruleFn(row) {
          if (!row.express) {
            return '函数名称不能为空'
          }
          const parameters = row.parameters || []
          let hasNullParameter = false
          for (let i = 0; i < parameters.length; i++) {
            const parameter = parameters[i]
            if (!parameter.sourceNodePath) {
              hasNullParameter = true
              break
            }
          }
          if (hasNullParameter) {
            return '函数参数值不能为空'
          }
        }
      })
      if (msg) {
        return this.$message.error(msg)
      }
      this.$emit('finish', this.dialogForm)
    }

  }

}
</script>
