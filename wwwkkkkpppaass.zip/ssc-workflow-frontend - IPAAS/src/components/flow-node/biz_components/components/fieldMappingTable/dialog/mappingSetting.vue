<template>
  <el-dialog title="字段映射设置" :visible="visible" width="800px" :beforeClose="handleCancel" appendToBody>
    <el-table border :data="tableData" :spanMethod="collapseMethod">
      <el-table-column label="映射" minWidth="120">
        <!-- eslint-disable-next-line vue/no-unused-vars -->
        <template slot-scope="scope">
          <mc-popover-select v-model="formItem.dictMapId" clearable :disabled="formDisabled" :defaultValue="formItem.dictMapName" :apiFunc="dictMappingApiFunc" :tableColumn="dictMappingTableColumn" :queryList="dictMappingQueryList" labelKey="name" valueKey="id" @changeRow="rowClick" :param="{}" />
        </template>
      </el-table-column>
      <template v-if="formItem.paramList.length > 0">
        <el-table-column label="参数名称" minWidth="120">
          <template slot-scope="scope">
            {{ scope.row.paramName }}
          </template>
        </el-table-column>
        <el-table-column label="数据类型" minWidth="120">
          <template slot-scope="scope">
            {{ code2Text(scope.row.dataType, DataTypeEnum) }}
          </template>
        </el-table-column>
        <el-table-column label="参数描述" minWidth="120">
          <template slot-scope="scope">
            {{ scope.row.desc }}
          </template>
        </el-table-column>
        <el-table-column label="取值类型" minWidth="120">
          <template slot-scope="scope">
            <el-select v-model="scope.row.referenceType" placeholder="请选择取值方式" @change="typeChange(scope.row)">
              <el-option v-for="item in ParamReferenceTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </template>
        </el-table-column>

        <el-table-column label="源字段节点" minWidth="180">
          <template slot-scope="scope">
            <el-input :value="resolveNodeName(scope.row.nodeKey, nodeMap)" disabled />
          </template>
        </el-table-column>
        <el-table-column label="源字段或值" minWidth="240">
          <template slot-scope="scope">
            <el-input v-if="scope.row.referenceType === 1" v-model="scope.row.value" placeholder="请输入内容" disabled>
              <el-button slot="append" icon="el-icon-setting" @click="showJsonTree(scope.row)" />
            </el-input>
            <mc-input v-else :data-type="scope.row.dataType" :trim="false" v-model="scope.row.value" placeholder="源字段或值" :disabled="formDisabled" />
          </template>
        </el-table-column>
      </template>

      <!-- 数据源json弹窗 -->
      <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px">
        <!-- 此处需要将apiInParamList转成对象并填充默认值 -->
        <JsonTree title="源数据" :selectNodeId.sync="selectNodeId" :data.sync="sourceData" :multipleNode="true" @rightClick="rightClick" />
      </el-dialog>
    </el-table>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel" v-if="!formDisabled">取 消</el-button>
      <el-button type="primary" @click="sure" v-if="!formDisabled">确 定</el-button>
      <el-button @click="handleCancel" v-if="formDisabled">关 闭</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { mapActions } from 'vuex'
import { DictMapping, DictMapParamList } from '@/components/flow-node/model/index'
import JsonTree from '@/components/flow-node/biz_components/components/jsonTree'
import mixinResolveNodeName from '@/components/flow-node/mixins/resolveNodeName'
import dictMapping from '@/config/popContentTableConfig/dictMapping.config.js'
import { deepClone, code2Text } from '@/utils'

export default {
  components: { JsonTree },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    dialogForm: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      code2Text,
      funcList: [],
      funcMapping: null,
      jsonTreeDialogVisible: false,
      ParamReferenceTypeEnum: [],
      selectNodeId: null,
      sourceData: [],
      currentRow: null,
      dictMappingApiFunc: dictMapping.apiFunc,
      dictMappingTableColumn: dictMapping.getTableColumn(),
      dictMappingQueryList: dictMapping.getQueryList({}),
      formItem: new DictMapping(),
      DataTypeEnum: []
    }
  },
  inject: ['nodeMap', 'formDisabled'],
  mixins: [mixinResolveNodeName],
  async created() {
    const [DictMapSrcTypeEnum, ParamReferenceTypeEnum, DataTypeEnum] = await this.getDicts(['DictMapSrcTypeEnum', 'ParamReferenceTypeEnum', 'DataTypeEnum'])
    this.ParamReferenceTypeEnum = ParamReferenceTypeEnum
    this.DataTypeEnum = DataTypeEnum
    this.dictMappingQueryList = dictMapping.getQueryList({ DictMapSrcTypeEnum })
  },
  watch: {
    visible: {
      handler(val) {
        if (val) {
          this.formData = deepClone(this.dialogForm)
          if (!this.formData.dictMapping) {
            this.formData.dictMapping = new DictMapping()
          }
          this.formItem = this.formData.dictMapping
        }
      },
      immediate: true
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    rowClick(row) {
      this.formItem.paramList = []
      this.formItem.dictMapName = row.name
      let varList = []
      if (row.sqlDto) {
        varList = row.sqlDto.varList || []
      } else if (row.apiDto) {
        varList = row.apiDto.varList || []
      }
      this.formItem.paramList = varList.map(item => {
        return ({
          ...new DictMapParamList(),
          ...{
            paramName: item.varName,
            dataType: item.dataType,
            desc: item.desc
          }
        })
      })
      console.log(this.formItem)
    },
    typeChange(row) {
      row.value = null
      row.sourceNodeName = null
      row.nodeKey = null
    },
    showJsonTree(c) {
      if (c.referenceType === undefined) return this.$message.warning('请先选择参数类型')
      if (c.referenceType === 1) {
        // 引用值，显示弹窗
        this.jsonTreeDialogVisible = true
        this.currentRow = c
      }
    },
    rightClick(node, nodeId, _selectNode) {
      this.jsonTreeDialogVisible = false
      this.currentRow.nodeKey = nodeId
      this.currentRow.value = node.path
    },
    collapseMethod({ _row, _column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        if (rowIndex === 0) {
          // 第一列，第一行，向后合并999行、一列
          return {
            rowspan: 999,
            colspan: 1
          }
        } else {
          // 第一列，其他行，变成0
          return {
            rowspan: 0,
            colspan: 0
          }
        }
      }
    },
    sure() {
      this.$emit('finish', this.formData)
    },
    handleCancel() {
      this.$emit('update:visible', false)
    }
  },
  computed: {
    tableData() {
      // 如果参数长度为0，渲染[formItem]，否则渲染paramList
      const paramLen = this.formItem.paramList.length
      let tableData = []
      if (paramLen === 0) {
        tableData = [this.formItem]
      } else {
        tableData = this.formItem.paramList
      }

      return tableData
    }
  }
}
</script>

<style>
</style>
