<template>
  <el-dialog title="脚本设置" :visible="visible" width="30%" :beforeClose="handleCancel" appendToBody>
    <el-form ref="dialogForm" :model="formData" labelWidth="120px" size="mini" labelPosition="top">
      <el-form-item label="脚本" prop="scriptData">
        <el-input type="textarea" :autosize="{ minRows: 4, maxRows: 10}" placeholder="请输入内容" v-model="formData.scriptData" :disabled="disabled" maxlength="256" />
      </el-form-item>
      <div class="tips-normal">提示：脚本语法参考QLExpress（类java语法），脚本中可以使用的变量为$raw</div>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel" v-if="!disabled">取 消</el-button>
      <el-button type="primary" @click="sure" v-if="!disabled">确 定</el-button>
      <el-button @click="handleCancel" v-if="disabled">关 闭</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { deepClone } from '@/utils'
export default {
  name: 'ScriptSetting',
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    id: {
      type: [String, Number],
      default: ''
    },
    dialogForm: {
      type: [Object],
      default: function() {
        return {}
      }
    },
    mode: {
      type: String,
      default: 'edit'
    }
  },
  watch: {
    visible: {
      handler(nV) {
        if (nV) {
          console.log(this.dialogForm)
          this.formData = deepClone(this.dialogForm)
        }
      },
      immediate: true
    }
  },
  computed: {
    disabled() { return this.mode === 'snapshot' }
  },
  data() {
    return {
      formData: {}
    }
  },

  methods: {
    sure() {
      this.$emit('finish', this.formData)
    },
    handleCancel() {
      this.$emit('update:visible', false)
    }

  }

}
</script>
