<template>
  <el-dialog title="参数设置" :visible="dialogVisible" width="70%" appendToBody :beforeClose="handleClose">
    <el-tabs v-model="activeName" type="border-card">
      <el-tab-pane label="请求参数" name="params">
        <span slot="label">请求参数 <i class="el-icon-edit" @click="showJsonVisible('apiInParamList')" /></span>
        <ParamList v-bind="$attrs" class="param-list" type="inParams" :tableData="paramList" />
      </el-tab-pane>
    </el-tabs>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" @click="commitForm">确 定</el-button>
    </span>
    <jsonAutoResolveDialog v-bind="$attrs" :visible.sync="jsonDialogVisible" :originalParamList="paramList" :allowCopy="true" :needPos="false" :type="currentJsonKey" @confirm="confirmJsonData" width="70%" v-if="jsonDialogVisible" />
  </el-dialog>
</template>

<script>
import { deepClone, arrayToObj, _typeof, toHump } from '@/utils'
import { validateTree } from '@/utils/validator'
import { transDataType } from '@/utils/resolve-data'
import 'codemirror/lib/codemirror.css'
import 'codemirror/theme/base16-dark.css'

import jsonAutoResolveDialog from '@/components/jsonAutoResolveDialog'
import jsonAutoResolveMixin from '@/components/jsonAutoResolveDialog/mixin'
import ParamList from './paramList'

export default {
  name: 'EditDialog',
  components: {
    jsonAutoResolveDialog,
    ParamList
  },
  props: {
    // jsonData: {
    //   type: String,
    //   default: null
    // },
    allowEdit: {
      type: Boolean,
      default: true
    },
    list: {
      type: Array,
      default: () => []
    }
  },
  mixins: [jsonAutoResolveMixin],
  data() {
    const validJson = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('不能为空'))
      } else {
        try {
          JSON.parse(value)
        } catch (err) {
          return callback(new Error('json格式有误'))
        }
      }
      callback()
    }
    return {
      dialogVisible: false,
      // formData: {
      //   jsonData: null
      // },
      jsonRule: {
        validator: validJson, trigger: 'blur'
      },
      inputType: 'json',
      originalParamList: [],

      options: {
        mode: { name: 'javascript', json: true },
        theme: 'base16-dark',
        lineNumbers: true
      },
      textFormData: {
        dataPosition: 2, // 参数位置
        path: '',
        isCamelCase: true,
        paramStr: '',
        dataTypeStr: '',
        descriptionStr: ''
      },
      rules: {
        dataPosition: [
          { required: true, message: '请选择参数位置', trigger: 'change' }
        ],
        paramStr: [
          { required: true, message: '请输入参数名', trigger: 'change' }
        ],
        dataTypeStr: [
          { required: true, message: '请输入参数类型', trigger: 'change' }
        ]
      },
      paramList: []
    }
  },
  // computed: {
  //   treeData() {
  //     const jsonObj = JSON.parse(this.jsonData)
  //     return objIterationChildrenList(jsonObj)
  //   }
  // },
  created() {
    this.paramList = deepClone(this.list)
  },
  methods: {

    confirmJsonData(data) {
      console.log(data)
      this.paramList = data
      this.jsonDialogVisible = false
    },
    init() {
      this.dialogVisible = true
    },
    rightClick(treeNode) {
      const dataType = treeNode.dataType
      if (![7, 8].includes(dataType)) {
        return this.$message.error('请选择【数组、对象】类型数据')
      }
      this.textFormData.path = treeNode.path
    },
    commitForm() {
      const result = validateTree({
        tree: this.paramList,
        children: 'childrenList',
        ruleFn(row) {
          if (!row.paramName) {
            return '参数名不能为空'
          } else if (!row.dataType) {
            return '参数类型不能为空'
          }
        }
      })
      if (result) {
        return this.$message.error(result)
      }
      this.$emit('listChange', this.paramList)
      this.dialogVisible = false
    },
    // 将用户输入的数据转成对象合并到jsonStr中
    combineParamList(jsonStr, textFormData) {
      const { paramStr, dataTypeStr, isCamelCase } = textFormData
      const paramList = []
      const paramArr = paramStr.split('\n')
      const dataTypeArr = dataTypeStr.split('\n')

      paramArr.forEach((item, index) => {
        const paramName = isCamelCase ? toHump(item) : item
        paramList.push({ paramName, dataType: transDataType(dataTypeArr[index]) })
      })

      const obj = arrayToObj(paramList)
      const jsonObj = JSON.parse(jsonStr) || {}

      const paths = textFormData.path.split('.')
      let path1 = paths.shift()
      let value = jsonObj
      while (path1) {
        value = jsonObj[path1]
        path1 = paths.shift()
      }
      if (_typeof(value) === 'array') {
        value = value[0]
      }
      Object.keys(obj).forEach(item => {
        value[item] = obj[item]
      })
      return JSON.stringify(jsonObj)
    },
    handleClose() {
      this.dialogVisible = false
    }
  }
}
</script>
