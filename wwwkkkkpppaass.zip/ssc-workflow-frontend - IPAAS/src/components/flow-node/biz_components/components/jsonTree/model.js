
export class Param {
  constructor({ paramName, dataType, value }) {
    this.rowKey = Date.now() + '' + Math.random().toFixed(5)
    this.childrenList = []
    this.dataType = dataType // 参数类型
    this.description = null // 描述
    this.isRequired = null // 是否必填
    this.paramName = paramName // 参数key
    this.generic = null
    this.value = value
  }
}
