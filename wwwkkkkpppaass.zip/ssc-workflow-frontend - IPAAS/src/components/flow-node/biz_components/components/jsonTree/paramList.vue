<template>
  <el-form class="table-form" ref="form" :model="formData" labelWidth="0px" size="mini">
    <el-table :data="formData.data" style="width: 100%;" :rowKey="'rowKey'" size="mini" border defaultExpandAll :treeProps="{children: 'childrenList', hasChildren: 'hasChildren'}" maxHeight="300">
      <el-table-column label="序号" prop="paramName" width="90">
        <template slot-scope="scope">
          {{ scope.$index + 1 }}
        </template>
      </el-table-column>
      <el-table-column prop="paramName" label="参数名" align="left" :showOverflowTooltip="false" width="220px">
        <template slot-scope="scope">
          <el-form-item>
            <!-- mq和mapper的编辑弹窗中不允许修改第一行的paramName -->
            <el-input v-model.trim="scope.row.paramName" placeholder="请输入参数名" :disabled="disabled || isAutoCompleteRow(scope.row) || (hasWrapper && scope.$index === 0)" maxlength="128" />
          </el-form-item>
        </template>
      </el-table-column>
      <el-table-column prop="dataType" label="参数类型" align="left" :showOverflowTooltip="false" width="130px">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.dataType" clearable placeholder="请选择参数类型" @change="docDataTypeChange($event, scope.row)" :disabled="disabled || isAutoCompleteRow(scope.row)">
              <!-- mq、mapper的第一行，参数类型只允许object和array -->
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type" :disabled="(hasWrapper && scope.$index === 0 && ![7, 8].includes(item.type))" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>
      <el-table-column prop="value" label="当前值" align="left" :showOverflowTooltip="false" width="200px" v-if="showDefaultValue">
        <template slot-scope="scope">
          <el-form-item>
            <!-- 入参的默认带出参数 initTime用户可以编辑 -->
            <el-input v-if="scope.row.dataType !== 9" v-model.trim="scope.row.value" placeholder="请输入当前值" :disabled="disabled || isAutoCompleteRow(scope.row, scope.row.paramName === 'initTime')" maxlength="128" />
            <el-date-picker v-else v-model="scope.row.value" type="datetime" placeholder="选择日期时间" :disabled="disabled || isAutoCompleteRow(scope.row, scope.row.paramName === 'initTime')" valueFormat="yyyy-MM-dd HH:mm:ss" />
          </el-form-item>
        </template>
      </el-table-column>
      <el-table-column prop="isRequired" v-if="type === 'inParams'" label="是否必填" align="left" :showOverflowTooltip="false" width="80px">
        <template slot-scope="scope">
          <el-form-item>
            <el-switch v-model="scope.row.isRequired" :disabled="disabled || isAutoCompleteRow(scope.row)" />
          </el-form-item>
        </template>
      </el-table-column>
      <!-- 只有array类型的需要设置元素泛型 -->
      <el-table-column prop="generic" label="数组元素泛型" align="left" :showOverflowTooltip="false" width="180px">
        <template slot-scope="scope">
          <el-form-item>
            <el-select :disabled="scope.row.dataType !== 8 || disabled || isAutoCompleteRow(scope.row)" v-model="scope.row.generic" clearable placeholder="请选择数组元素泛型" @change="genericChange($event, scope.row)">
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>
      <el-table-column prop="description" label="描述" align="left" :showOverflowTooltip="false">
        <template slot-scope="scope">
          <el-form-item>
            <el-input type="textarea" v-model.trim="scope.row.description" placeholder="请输入描述" :disabled="disabled || isAutoCompleteRow(scope.row)" maxlength="255" />
          </el-form-item>
        </template>
      </el-table-column>
      <el-table-column prop="operate" label="操作" width="100" v-if="mode !== 'view'" fixed="right">
        <template slot-scope="scope">
          <!-- 当前行类型不是数组或对象 时禁止添加行 -->
          <el-button type="text" @click="addRow(scope.row, scope.$index)" :disabled="!(scope.row.dataType === 7 || (scope.row.dataType === 8 && scope.row.generic === 7)) || disabled || isAutoCompleteRow(scope.row)">添加</el-button>
          <el-button type="text" @click="deleteRow(scope.row, scope.$index)" :disabled="disabled || isAutoCompleteRow(scope.row) || (hasWrapper && scope.$index === 0)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-button
      v-if="mode !== 'view' && !hasWrapper"
      class="table-add-btn"
      size="medium"
      type="dash"
      icon="el-icon-plus"
      :disabled="disabled"
      @click="addRow()"
    >
      添加
    </el-button>
  </el-form>
</template>

<script>
import { Param } from './model'
import { mapActions } from 'vuex'
export default {
  props: {
    type: {
      default: 'inParams',
      type: String
    },
    wrapStr: {
      default: null,
      type: String
    },
    tableData: {
      default: () => [],
      type: Array
    },
    showDefaultValue: {
      default: false,
      type: Boolean
    },
    mode: { default: 'edit', type: String }
  },
  data() {
    return { formData: {}, DataTypeEnum: [] }
  },
  watch: {
    tableData: {
      handler(nV) {
        this.$set(this.formData, 'data', nV)
      },
      immediate: true
    }
  },
  async created() {
    this.DataTypeEnum = await this.getDict(['DataTypeEnum'])
  },
  computed: {
    // 通过接口直连生成的数据不允许修改参数
    disabled() {
      return this.mode === 'view'
    },
    hasWrapper() {
      return ['mapper', 'mq'].includes(this.wrapStr)
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDict']),
    addRow(row) {
      if (row) {
        row.childrenList.push(new Param({}))
      } else {
        this.formData.data.push(new Param({}))
      }
    },
    deleteRow(row) {
      const { parentList, idx } = this.findParentRow(this.formData.data, row)
      parentList.splice(idx, 1)
    },
    // 参数类型改变时，清空数组元素泛型和row.childrenList
    docDataTypeChange(v, row) {
      row.generic = null
      row.childrenList = []
    },
    genericChange(v, row) {
      row.childrenList = []
    },
    isAutoCompleteRow(row, allowEdit) { // 是否是默认填充值的行
      if (this.type === 'inParams' && allowEdit) return false
      if (['offset', 'pageSize', 'resultSize', 'isSuccess', 'initTime'].includes(row.paramName)) {
        return true
      } else {
        return false
      }
    },
    // 深度优先递归
    findParentRow(list, row) {
      let parentList = []
      let idx = null
      const length = list.length
      for (let i = 0; i < length; i++) {
        if (list[i] === row) {
          return { parentList: list, idx: i }
        }
        if (list[i].childrenList) {
          const res = this.findParentRow(list[i].childrenList, row)
          if (res) {
            parentList = res.parentList
            idx = res.idx
            return { parentList, idx }
          }
        }
      }
    }
  }
}
</script>

<style scoped lang="scss">

</style>
