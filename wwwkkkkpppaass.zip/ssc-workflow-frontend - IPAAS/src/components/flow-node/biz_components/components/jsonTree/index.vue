<template>
  <div class="jsontree-panel">
    <div class="card-title">
      <span class="title-text">{{ title }}(JSON)
        <el-tooltip class="item" effect="dark" content="右键选择数据" placement="top-start">
          <i class="el-icon-info" />
        </el-tooltip>
        &nbsp;
      </span>
      <el-select v-if="multipleNode" class="node-select" v-model="selectNodeIdComputed" placeholder="请选择节点" :disabled="formDisabled">
        <el-option v-for="item in prevNodeChain" :key="item.id" :label="item.labelName || item.name" :value="item.id" />
      </el-select>
      <span v-if="allowEdit">
        <!-- <el-button type="text" size="mini" v-clipboard:copy="data" v-clipboard:success="onCopy" v-clipboard:error="onError">复制</el-button> -->
        <el-button type="text" size="mini" @click="editData" :disabled="formDisabled">编辑</el-button>
      </span>
      <div class="filter-input"><el-input v-model="filterText" placeholder="输入关键字进行检索" @input="filterTreeData" /></div>
    </div>

    <el-card class="box-card">
      <el-tree ref="tree" :data="treeData" :props="treeDataProps" highlightCurrent nodeKey="key" :expandOnClickNode="false" defaultExpandAll checkOnClickNode @node-click="nodeClick" @node-contextmenu="rightClick" :filterNodeMethod="filterNode" />
    </el-card>

    <EditDialog :allowEdit="allowEdit" ref="editForm" :list="paramList" v-bind="$attrs" v-on="$listeners" />
  </div>
</template>

<script>
import EditDialog from './editDialog'
import { mapActions } from 'vuex'
import { deepClone, getUUID } from '@/utils'
import { findPrevChain, findCompleteChain } from '../../../utils/Jsplumb'
import { resolveOutputParamList, formatterParamList } from '../../nodeOptionDialog/node-option-utils'
export default {
  components: { EditDialog },
  props: {
    title: {
      type: String,
      default: '目标数据'
    },
    data: {
      type: [Array, String, Object],
      default: null
    },
    treeDataProps: {
      type: Object,
      default: () => ({ children: 'childrenList' })
    },
    multipleNode: {
      type: Boolean,
      default: false
    },
    allowEdit: {
      type: Boolean,
      default: false
    },
    selectNodeId: {
      type: String,
      default: null
    },
    // 针对combine节点需要在展示上包一层数据
    wrapRoot: {
      default: null,
      type: String
    },
    includeSelf: {
      default: false,
      type: Boolean
    },
    selectAllNode: {
      default: false,
      type: Boolean
    }
  },
  inject: {
    formDisabled: {
      from: 'formDisabled',
      default: false
    },
    getNodeFormData: {
      from: 'getNodeFormData',
      default: () => { return {} }
    },
    nodeMap: {
      from: 'nodeMap',
      default: new Map()
    },
    getFormData: {
      from: 'getFormData',
      default: () => { return {} }
    }
  },
  // inject: ['formDisabled', 'getNodeFormData', 'nodeMap', 'getFormData'],
  data() {
    return {
      filterText: null,
      treeData: [],
      jsonStr: null,
      DataTypeEnum: [],
      currentRow: null
    }
  },
  watch: {
    selectNodeId: {
      handler(nV) {
        if (!this.allowEdit) {
          this.selectNodeChange(nV)
        }
      },
      immediate: true
    },
    data: {
      async handler(nV) {
        if (!nV || nV.length <= 0) {
          this.treeData = []
        } else {
          [this.DataTypeEnum] = await this.getDicts(['DataTypeEnum'])
          // if (this.wrapRoot) {
          //   nV = [{
          //     dataType: 7,
          //     paramName: this.wrapRoot,
          //     rowKey: getUUID(),
          //     childrenList: nV
          //   }]
          // }
          this.treeData = formatterParamList(deepClone(nV), this.DataTypeEnum)
        }
      },
      immediate: true
    }
  },
  created() {
    this.paramList = this.data
  },
  computed: {
    prevNodeChain() {
      if (!this.multipleNode) {
        return []
      }
      if (!this.selectAllNode) {
        const currentNodeId = this.nodeFormData.id
        const prevNodeChain = findPrevChain(this.nodeMap, currentNodeId, [], true, this.includeSelf) || []
        return prevNodeChain.reverse()
      } else {
        const nodeChain = findCompleteChain({ nodeMap: this.nodeMap })
        return nodeChain
      }
    },
    nodeFormData() {
      return this.getNodeFormData()
    },
    formData() {
      return this.getFormData()
    },
    selectNodeIdComputed: {
      get() {
        return this.selectNodeId
      },
      set(nV) {
        this.$emit('update:selectNodeId', nV)
      }
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    // 节点变化
    async selectNodeChange(nV) {
      [this.DataTypeEnum] = await this.getDicts(['DataTypeEnum'])
      const node = this.prevNodeChain.find(node => node.id === nV)
      let outputParamList = []
      if (!node) {
        this.treeData = []
      } else {
        // 获取节点的输出参数
        outputParamList = resolveOutputParamList(node, this.formData, this.nodeMap)
        if (this.wrapRoot) {
          outputParamList = [{
            dataType: 7,
            paramName: this.wrapRoot,
            rowKey: getUUID(),
            childrenList: outputParamList
          }]
        }
      }
      // 此处需要修改data的值，触发data的watch，用于刷新树
      this.$emit('update:data', outputParamList)
    },
    editData() {
      // this.$emit('editData')
      this.$refs.editForm.init(this.data)
    },
    confirmEdit(str) {
      this.$emit('update:data', str)
    },
    // 筛选树数据
    filterTreeData(v) {
      this.$refs.tree.filter(v)
    },
    rightClick(event, treeNode, _node, _$node) {
      if (this.formDisabled) return
      this.$emit('rightClick', treeNode, this.selectNodeId, this.nodeMap.get(this.selectNodeId))
    },
    nodeClick(row) {
      if (row === this.currentRow) {
        // 如果已经被选中了，再次点击取消选中状态，清空currentRow并取消选中状态
        this.currentRow = null
        try {
          this.$refs.tree.setCurrentNode({})
        } catch (e) {
          console.log('取消选中')
        }
      } else {
        // 如果未选中该行，修改currentRow
        this.currentRow = row
      }
    },
    getSelectRow() {
      // let currentRow = this.currentRow
      // if (!this.currentRow) {
      //   currentRow = {
      //     paramName: '$',
      //     dataType: 7,
      //     childrenList: this.data || []
      //   }
      // }
      return this.currentRow
    },
    // onCopy(v, c, b, d) {
    //   console.log('copy', v, c, b, d)
    // },
    // onError(e) {
    //   console.log('err', e)
    // },
    filterNode(value, data) {
      if (!value) return true
      const paramName = data.paramName || data.fieldName || data.label
      return paramName.indexOf(value) !== -1
    }
  }
}
</script>

<style lang="scss" scoped>
.box-card {
  height: 200px;
  overflow: auto;
  margin-top: 10px;
}
.node-select {
  width: 150px;
}

.card-title{
  display: flex;
  align-items: center;
  .title-text{
    padding-right: 10px;
  }
  .filter-input{
    width: 150px;
    margin-left: 10px;
  }
}
</style>
