<template>
  <el-form class="table-form" ref="mappingForm" :model="formData" :rules="rules" labelWidth="0px" size="mini" :disabled="formDisabled">
    <el-table ref="mappingTable" :data="formData.tableList" highlightCurrentRow style="width: 100%" maxHeight="250" border>
      <el-table-column label="序号" type="index" align="left" width="60" />

      <el-table-column label="变量名" align="left" minWidth="200">
        <template slot-scope="scope">
          <el-form-item>
            <el-input v-model.trim="scope.row.fieldName" placeholder="请输入变量名" />
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="类型" align="left" minWidth="150">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.type" placeholder="请选择类型" @change="typeChange(scope.row)">
              <el-option v-for="item in ParamReferenceTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="属性数据类型" minWidth="200">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.dataType" @change="dataTypeChange(scope.row)" placeholder="请选择属性数据类型" :readonly="true" :disabled="scope.row.type === 1">
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="节点名称" width="200">
        <template slot-scope="scope">
          <el-form-item>
            <el-input :value="resolveNodeName(scope.row.nodeKey, nodeMap)" :disabled="true" />
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="值" width="200">
        <template slot-scope="scope">
          <el-form-item>
            <el-input v-if="scope.row.type === 1" v-model.trim="scope.row.value" placeholder="请输入内容" :disabled="true">
              <el-button slot="append" icon="el-icon-setting" @click="showJsonTree(scope.row)" />
            </el-input>
            <mc-input v-else :dataType="scope.row.dataType" :trim="false" v-model="scope.row.value" placeholder="内容" />
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="操作" width="150px" align="left" v-if="!formDisabled" fixed="right">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="deleteRow(scope.$index)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="mt-10 mb-10" v-if="!formDisabled">
      <el-button class="table-add-btn" @click="addRow" icon="el-icon-plus">添加</el-button>
    </div>
    <!-- 数据源json弹窗 -->
    <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px" v-if="jsonTreeDialogVisible">
      <!-- <JsonTree title="源数据" :nodeList="nodeList" :allow-edit="false" @rightClick="rightClick" /> -->
      <JsonTree title="源数据" :selectNodeId.sync="selectNodeId" :data.sync="sourceData" @rightClick="rightClick" :multipleNode="true" :includeSelf="includeSelf" />
    </el-dialog>
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
import JsonTree from '../jsonTree/index'
import mixinResolveNodeName from '@/components/flow-node/mixins/resolveNodeName'
import { validDbCanUse } from '@/components/flow-node/biz_components/nodeOptionDialog/node-option-utils'

export default {
  components: { JsonTree },
  props: {
    tableList: {
      default: () => [],
      type: Array
    },
    title: {
      default: 'inParamTable',
      type: String
    },
    nodeList: {
      type: Array,
      default: () => []
    },
    includeSelf: {
      type: Boolean,
      default: false
    },
    index: {
      type: Number,
      default: 0
    },
    nodeFormData: {
      // 节点完整的配置数据
      type: Object,
      default: () => ({})
    }
  },
  inject: ['formDisabled', 'nodeMap'],
  mixins: [mixinResolveNodeName],
  data() {
    return {
      formData: {
        tableList: []
      },
      rules: {},
      ParamReferenceTypeEnum: [],
      DataTypeEnum: [],
      jsonTreeDialogVisible: false,
      currentRow: {},
      selectNodeId: null,
      sourceData: []
    }
  },
  watch: {
    tableList: {
      handler(nV) {
        if (nV) {
          this.formData.tableList = nV
          console.log(this.formData)
        }
      },
      immediate: true
    }
  },
  async created() {
    [this.ParamReferenceTypeEnum, this.DataTypeEnum] = await this.getDicts([
      'ParamReferenceTypeEnum', 'DataTypeEnum'
    ])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    typeChange(row) {
      row.value = null
      row.nodeKey = null
      row.dataType = null
    },
    dataTypeChange(row) {
      row.value = null
    },
    showJsonTree(row) {
      this.jsonTreeDialogVisible = true
      this.currentRow = row
    },
    rightClick(node, nodeId) {
      if (this.includeSelf) {
        // 如果选择的是当前节点，校验不能选择index大于等于自己的
        const canUse = validDbCanUse({ selectNodeId: nodeId, selectPath: node.path, currentNodeId: this.nodeFormData.id, currentIndex: this.index })
        if (!canUse) {
          return this.$message.error('不能引用当前SQL以及当前SQL之后的SQL数据')
        }
      }
      this.jsonTreeDialogVisible = false
      this.currentRow.nodeKey = nodeId
      this.currentRow.value = node.path
      this.currentRow.dataType = node.dataType
    },
    addRow() {
      this.$emit('eventLinstener', {
        type: 'add',
        title: this.title,
        list: this.tableList
      })
    },
    deleteRow(index) {
      this.$confirm(
        '确定删除此行吗? 删除不会提交数据，请点击【保存】提交',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      ).then(() => {
        this.formData.tableList.splice(index, 1)
      })
    }
  }
}
</script>

<style scoped lang="scss">
table-add-btn {
  width: 100%;
}
</style>
