export default {
  data() {
    return {

      selectRow: {},
      selectIndex: null,
      functionDialogVisible: false,
      scriptDialogVisible: false,
      mappingDialogVisible: false
    }
  },
  methods: {
    // 编辑脚本
    editScript(row, index) {
      this.scriptDialogVisible = true
      this.selectRow = row
      this.selectIndex = index
    },
    editFunction(row, index) {
      this.functionDialogVisible = true
      if (!row.functionList) row.functionList = []
      this.selectRow = row
      this.selectIndex = index
    },
    editMapping(row, index) {
      console.log(row)
      this.mappingDialogVisible = true
      this.selectRow = row
      this.selectIndex = index
    },
    updateRow(formData, _key) {
      const selectIndex = this.selectIndex
      this.formData.tableList.splice(selectIndex, 1, formData)
      this.scriptDialogVisible = false
      this.functionDialogVisible = false
    },
    updateDictMappingRow(formData, key) {
      const selectIndex = this.selectIndex
      if (!formData[key].dictMapId) {
        formData[key] = null
      }
      this.formData.tableList.splice(selectIndex, 1, formData)
      this.scriptDialogVisible = false
      this.functionDialogVisible = false
      this.mappingDialogVisible = false
    }
  }
}
