<template>
  <el-form class="table-form" ref="mappingForm" :model="formData" :rules="rules" labelWidth="0px" size="mini">
    <el-table class="edit-table" ref="mappingTable" :data="formData.tableList" highlightCurrentRow style="width: 100%" maxHeight="250" @row-click="rowClick" border>
      <el-table-column label="序号" type="index" align="left" width="60" />

      <el-table-column label="主数据" align="left" minWidth="300px" prop="mainFieldName" />
      <el-table-column label="从数据" align="left" minWidth="300px" prop="lineFieldName" />

      <el-table-column label="操作" width="150px" fixed="right" align="left" v-if="!formDisabled">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="deleteRow(scope.$index)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
export default {
  props: {
    tableList: {
      default: () => [],
      type: Array
    },
    title: {
      default: 'inParamTable',
      type: String
    },
    columnList: {
      default: () => [],
      type: Array
    },
    columnMap: {
      default: () => new Map(),
      type: Map
    }
  },
  inject: ['formDisabled'],
  data() {
    return {
      formData: {
        tableList: []
      },
      rules: {},
      DataTypeEnum: []
    }
  },
  watch: {
    tableList: {
      handler(nV) {
        if (nV) {
          this.formData.tableList = nV
        }
      },
      immediate: true
    }
  },
  async created() {
    [this.DataTypeEnum] = await this.getDicts([
      'DataTypeEnum'
    ])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    rowClick(row) {
      this.$emit('rowClick', row)
    },
    setCurrentRow(row) {
      this.$refs.mappingTable.setCurrentRow(row)
    },
    addRow() {
      this.$emit('eventLinstener', {
        type: 'add',
        title: this.title,
        list: this.tableList
      })
    },
    deleteRow(index) {
      this.$confirm(
        '确定删除此行吗? 删除不会提交数据，请点击【保存】提交',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      ).then(() => {
        this.formData.tableList.splice(index, 1)
      })
    }
  }
}
</script>

<style scoped lang="scss">
table-add-btn {
  width: 100%;
}
</style>
