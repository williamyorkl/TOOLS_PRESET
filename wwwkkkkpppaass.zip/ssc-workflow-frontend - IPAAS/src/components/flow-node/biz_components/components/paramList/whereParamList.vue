<template>
  <el-form class="table-form" ref="mappingForm" :model="formData" :rules="rules" labelWidth="0px" size="mini" :disabled="formDisabled">
    <el-table ref="mappingTable" rowKey="rowKey" :data="formData.tableList" defaultExpandAll :treeProps="{children: 'groups'}" highlightCurrentRow style="width: 100%" maxHeight="250" :indent="8" border>
      <el-table-column label="序号" prop="paramName" width="60">
        <template slot-scope="scope">
          {{ scope.$index + 1 }}
        </template>
      </el-table-column>

      <el-table-column label="逻辑符号" align="left" minWidth="100">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.logicalOperator">
              <el-option v-for="item in DbSqlLogicalEnum" :key="item.desc" :label="item.desc" :value="item.desc" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="是否分组" align="left" minWidth="85">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.isGroup" @change="isGroupChange($event, scope.row)">
              <el-option v-for="item in YesNoEnum" :key="item.desc" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="表字段" align="left" minWidth="150">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.fieldName" :disabled="scope.row.isGroup === 2" @change="fieldChange($event, scope.row)" :filterable="true">
              <el-option v-for="item in columnList" :key="item.name" :label="item.name" :value="item.name" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="属性数据类型" minWidth="200">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.dataType" placeholder="请选择属性数据类型" :disabled="true" @change="dataTypeChange(scope.row)">
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="条件符" align="left" minWidth="125">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.operator" @change="operaChange(scope.row)" :disabled="scope.row.isGroup === 2">
              <el-option v-for="item in DbOperatorEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="类型" align="left" minWidth="120">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.type" placeholder="请选择参数类型" @change="typeChange(scope.row, 0)" :disabled="scope.row.isGroup === 2">
              <el-option v-for="item in ParamReferenceTypeEnum" :key="item.type" :label="item.desc" :value="item.type"
                         :disabled="item.type === 2 && scope.row.operator === 11"
              />
            </el-select>
          </el-form-item>
          <!-- between需要两组数据 -->
          <el-form-item v-if="scope.row.operator === 11">
            <el-select v-model="scope.row.type1" placeholder="请选择参数类型" @change="typeChange(scope.row, 1)" :disabled="scope.row.isGroup === 2">
              <el-option v-for="item in ParamReferenceTypeEnum" :key="item.type" :label="item.desc" :value="item.type" :disabled="item.type === 2 && scope.row.operator === 11" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="节点名称" align="left" minWidth="120">
        <template slot-scope="scope">
          <el-form-item>
            <el-input :value="resolveNodeName(scope.row.nodeKey, nodeMap)" :disabled="true" />
          </el-form-item>
          <el-form-item v-if="scope.row.operator === 11">
            <el-input :value="resolveNodeName(scope.row.nodeKey1, nodeMap)" :disabled="true" />
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="值" minWidth="200">
        <template slot-scope="scope">
          <el-form-item>
            <el-input v-if="scope.row.type === 1" v-model.trim="scope.row.value" placeholder="请输入内容" :disabled="true">
              <el-button slot="append" icon="el-icon-setting" @click="showJsonTree(scope.row, 0)" />
            </el-input>
            <mc-input v-else :dataType="scope.row.dataType" :trim="false" v-model="scope.row.value" placeholder="内容" :disabled="scope.row.isGroup === 2" />
          </el-form-item>
          <el-form-item v-if="scope.row.operator === 11">
            <el-input v-if="scope.row.type1 === 1" v-model.trim="scope.row.value1" placeholder="请输入内容" :disabled="true">
              <el-button slot="append" icon="el-icon-setting" @click="showJsonTree(scope.row, 1)" />
            </el-input>
            <mc-input v-else :dataType="scope.row.dataType" :trim="false" v-model="scope.row.value1" placeholder="内容" :disabled="scope.row.isGroup === 2" />
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="操作" width="250px" align="left" v-if="!formDisabled" fixed="right">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="addChildRow(scope.row)" :disabled="scope.row.isGroup !== 2">添加</el-button>
          <el-button type="text" size="mini" @click="deleteRow(scope.row, scope.$index)">删除</el-button>
          <el-button type="text" size="mini" @click="editFunction(scope.row,scope.$index, scope)" :disabled="scope.row.dataType === 8">函数{{ scope.row.functionList&&scope.row.functionList.length ? '('+scope.row.functionList.length+')':'' }}</el-button>
          <el-button type="text" size="mini" @click="editMapping(scope.row,scope.$index)">映射{{ scope.row.dictMapping?'(1)':'' }}</el-button>
          <el-button type="text" size="mini" @click="editScript(scope.row,scope.$index)">脚本{{ scope.row.scriptData?'(1)':'' }}</el-button>
          <el-button type="text" size="mini" @click="resetRow(scope.row,scope.$index)">重置</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="mt-10 mb-10" v-if="!formDisabled">
      <el-button class="table-add-btn" @click="addRow" icon="el-icon-plus">添加</el-button>
    </div>
    <!-- 数据源json弹窗 -->
    <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px" v-if="jsonTreeDialogVisible">
      <!-- 以下几种方法 不做特殊处理 -->
      <!-- <JsonTree v-if="['batch_update'].includes(sqlMethod)" :data="collectionFields" title="源数据" @rightClick="rightClick" /> -->
      <JsonTree title="源数据" :selectNodeId.sync="selectNodeId" :data.sync="sourceData" @rightClick="rightClick" :multipleNode="true" :includeSelf="includeSelf" />
    </el-dialog>
    <FunctionSettingDialog ref="functionRfc" v-if="functionDialogVisible" :dialogData="selectRow" :visible.sync="functionDialogVisible" @finish="(val)=>updateRow(val, 'functionList')" />
    <ScriptSetting :dialogForm="selectRow" v-if="scriptDialogVisible" :visible.sync="scriptDialogVisible" @finish="(val)=>updateRow(val, 'scriptData')" />
    <MappingSetting :dialogForm="selectRow" v-if="mappingDialogVisible" :visible.sync="mappingDialogVisible" @finish="(val)=>updateDictMappingRow(val, 'dictMapping')" />
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
import JsonTree from '../jsonTree/index'
import mixinResolveNodeName from '@/components/flow-node/mixins/resolveNodeName'

import operateMixin from './operate.mixin.js'
import ScriptSetting from '@/components/flow-node/biz_components/components/fieldMappingTable/dialog/scriptSetting'
import MappingSetting from '@/components/flow-node/biz_components/components/fieldMappingTable/dialog/mappingSetting'
import FunctionSettingDialog from '@/components/flow-node/biz_components/components/fieldMappingTable/dialog/function-setting/function-setting-dialog'
import { validDbCanUse } from '@/components/flow-node/biz_components/nodeOptionDialog/node-option-utils'

let currentIndex = null // 针对between情况，标识当前修改的是0还是1的数据
export default {
  components: { JsonTree, FunctionSettingDialog, ScriptSetting, MappingSetting },
  props: {
    tableList: {
      default: () => [],
      type: Array
    },
    title: {
      default: 'inParamTable',
      type: String
    },
    columnList: {
      default: () => [],
      type: Array
    },
    columnMap: {
      default: () => new Map(),
      type: Map
    },
    sqlMethod: {
      type: String,
      default: 'insert'
    },
    collectionFields: {
      type: Array,
      default: () => []
    },
    includeSelf: {
      type: Boolean,
      default: false
    },
    index: {
      type: Number,
      default: 0
    },
    nodeFormData: {
      // 节点完整的配置数据
      type: Object,
      default: () => ({})
    }
    // nodeId: {
    // }
  },
  mixins: [mixinResolveNodeName, operateMixin],
  inject: ['formDisabled', 'nodeMap'],
  data() {
    return {
      formData: {
        tableList: []
      },
      rules: {},
      DataTypeEnum: [],
      DbSqlLogicalEnum: [],
      YesNoEnum: [],
      DbOperatorEnum: [],
      ParamReferenceTypeEnum: [],
      jsonTreeDialogVisible: false,
      currentRow: {},
      sourceData: [],
      selectNodeId: null
    }
  },
  watch: {
    tableList: {
      handler(nV) {
        if (nV) {
          this.formData.tableList = nV
        }
      },
      immediate: true
    }
  },
  async created() {
    [this.YesNoEnum, this.DataTypeEnum, this.DbSqlLogicalEnum, this.DbOperatorEnum, this.ParamReferenceTypeEnum] = await this.getDicts([
      'YesNoEnum',
      'DataTypeEnum',
      'DbSqlLogicalEnum',
      'DbOperatorEnum',
      'ParamReferenceTypeEnum'
    ])
    console.log(this.DbOperatorEnum)
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    fieldChange(v, row) {
      row.dataType = this.columnMap.get(v).type
      row.value = null
    },
    dataTypeChange(row) {
      row.value = null
      row.value1 = null
    },
    isGroupChange(v, row) {
      row.value = null
      row.nodeKey = null
      row.groups = []
      row.value2 = null
      row.fieldName = null
      row.operator = null
      row.value1 = null
      row.nodeKey1 = null
      row.dataType = null
      row.type = null
    },
    typeChange(row, idx) {
      if (idx === 0) {
        row.value = null
        row.nodeKey = null
        row.groups = []
      } else if (idx === 1) {
        row.value1 = null
        row.nodeKey1 = null
      }
    },
    operaChange(row) {
      row.value = null
    },
    showJsonTree(row, idx) {
      this.jsonTreeDialogVisible = true
      this.currentRow = row
      currentIndex = idx
    },
    rightClick(node, nodeId) {
      const dataType = node.dataType
      if (this.currentRow.operator === 8 && dataType !== 8) {
        return this.$message.error('必须选择元素泛型为对象的数组')
      }
      if (this.includeSelf) {
        // 如果选择的是当前节点，校验不能选择index大于等于自己的
        const canUse = validDbCanUse({ selectNodeId: nodeId, selectPath: node.path, currentNodeId: this.nodeFormData.id, currentIndex: this.index })
        if (!canUse) {
          return this.$message.error('不能引用当前SQL以及当前SQL之后的SQL数据')
        }
      }
      this.jsonTreeDialogVisible = false
      // 以下方法不做特殊处理
      // if (['batch_update'].includes(this.sqlMethod)) {
      //   nodeId = this.nodeId
      // }
      if (currentIndex === 0) {
        this.currentRow.nodeKey = nodeId
        this.currentRow.value = node.path
      } else if (currentIndex === 1) {
        this.currentRow.nodeKey1 = nodeId
        this.currentRow.value1 = node.path
      }
    },
    addRow() {
      this.$emit('eventLinstener', {
        type: 'add',
        title: this.title,
        list: this.tableList
      })
    },
    addChildRow(row) {
      if (!row.groups || row.groups === '' || row.groups === undefined || row.groups.length === 0) {
        this.$set(row, 'groups', [])
      }
      this.$emit('eventLinstener', {
        type: 'add',
        title: 'addChildRow',
        list: row.groups
      })
    },
    deleteRow(row, _index) {
      this.$confirm(
        '确定删除此行吗? 删除不会提交数据，请点击【保存】提交',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      ).then(() => {
        const { parentList, idx } = this.findParentRow(this.formData.tableList, row)
        parentList.splice(idx, 1)
      })
    },
    // 深度优先递归
    findParentRow(list, row) {
      let parentList = []
      let idx = null
      const length = list.length
      for (let i = 0; i < length; i++) {
        if (list[i] === row) {
          return { parentList: list, idx: i }
        }
        if (list[i].groups) {
          const res = this.findParentRow(list[i].groups, row)
          if (res) {
            parentList = res.parentList
            idx = res.idx
            return { parentList, idx }
          }
        }
      }
    },
    resetRow(row, _index) {
      console.log('row', row)
      row.value = null
      row.nodeKey = null
      row.functionList = []
      row.dictMapping = null
      row.scriptData = null
    }
  }
}
</script>

<style scoped lang="scss">
table-add-btn {
  width: 100%;
}
.placeholder {
  min-height: 40px;
  min-width: 100px;
  line-height: 40px;
}
</style>
