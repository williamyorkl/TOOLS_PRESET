<template>
  <el-form class="table-form" ref="form" :model="formData" label-width="0px" size="mini" :disabled="formDisabled">
    <el-table :data="formData.data" style="width: 100%;" :row-key="'rowKey'" size="mini" border default-expand-all :tree-props="{children: 'childrenList', hasChildren: 'hasChildren'}" max-height="300">
      <el-table-column label="序号" prop="paramName" width="100">
        <template slot-scope="scope">
          {{scope.$index + 1}}
        </template>
      </el-table-column>
      <el-table-column prop="paramName" label="参数名" align="left" :show-overflow-tooltip="false" width="160px">
        <template slot-scope="scope">
          <el-form-item>
            <el-input v-model.trim="scope.row.paramName" placeholder="请输入参数名" :disabled="scope.row.dataPosition === 1"></el-input>
          </el-form-item>
        </template>
      </el-table-column>
      <el-table-column prop="dataType" label="参数类型" align="left" :show-overflow-tooltip="false" width="180px">
        <template slot-scope="scope">
          <el-form-item >
            <el-select v-model="scope.row.dataType" clearable placeholder="请选择参数类型" @change="dataTypeChange($event, scope.row)">
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type">
              </el-option>
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>
      <el-table-column prop="dataPosition" v-if="type === 'inParams' && (apiType === 'springcloud' || apiType === 'http')" label="参数位置" align="left" :show-overflow-tooltip="false" width="170px">
        <template slot-scope="scope">
          <el-form-item >
            <el-select v-model="scope.row.dataPosition" clearable placeholder="请选择参数位置" :disabled="scope.row.dataPosition === 1">
              <el-option v-for="item in DataPosEnum" :key="item.type" :label="item.desc" :value="item.type" :disabled="item.type === 1">
              </el-option>
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>
      <el-table-column prop="isRequired" v-if="type === 'inParams' || type === 'headerParams'" label="是否必填" align="left" :show-overflow-tooltip="false" width="80px">
        <template slot-scope="scope">
          <el-form-item >
            <el-switch v-model="scope.row.isRequired"></el-switch>
          </el-form-item>
        </template>
      </el-table-column>
      <!-- 只有array类型的需要设置元素泛型 -->
      <el-table-column prop="generic" label="数组元素泛型" align="left" :show-overflow-tooltip="false" width="180px">
        <template slot-scope="scope">
          <el-form-item >
            <el-select :disabled="scope.row.dataType !== 8" v-model="scope.row.generic" clearable placeholder="请选择数组元素泛型" @change="genericChange($event, scope.row)">
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type">
              </el-option>
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>
      <el-table-column prop="description" label="描述" align="left" :show-overflow-tooltip="false">
        <template slot-scope="scope">
          <el-form-item >
            <el-input type="textarea" v-model="scope.row.description" placeholder="请输入描述"></el-input>
          </el-form-item>
        </template>
      </el-table-column>
      <el-table-column prop="operate" label="操作" width="100">
        <template slot-scope="scope">
          <!-- 当前行类型不是数组或对象 时禁止添加行 -->
          <el-button type="text" @click="addRow(scope.row, scope.$index)" :disabled="!(scope.row.dataType === 7 || (scope.row.dataType === 8 && scope.row.generic === 7)) || formDisabled">添加</el-button>
          <el-button type="text" @click="deleteRow(scope.row, scope.$index)" :disabled="scope.row.dataPosition === 1 || formDisabled">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-button
        class="table-add-btn"
        size="medium"
        type="dash"
        icon="el-icon-plus"
        :disabled="formDisabled"
        @click="addRow()">
        添加
      </el-button>
  </el-form>

</template>

<script>
// import { Param } from '../model/model'
import { mapActions } from 'vuex'
export default {
  props: {
    type: {
      default: 'inParams',
      type: String
    },
    apiType: {
      default: 'api',
      type: String
    },
    tableData: {
      default: () => [],
      type: Array
    },
    autoGenByServerApiId: {
      default: null,
      type: Number
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  inject: ['formDisabled'],
  data() {
    return { formData: {}, DataTypeEnum: [], DataPosEnum: [] }
  },
  watch: {
    tableData: {
      handler(nV) {
        this.$set(this.formData, 'data', nV)
      },
      immediate: true
    }
  },
  async created() {
    [this.DataTypeEnum, this.DataPosEnum] = await this.getDicts([
      'DataTypeEnum', 'DataPosEnum'
    ])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    addRow(row) {
      console.log(row)
      this.$emit('eventLinstener', {
        type: 'add',
        title: this.type,
        list: this.formData.data,
        row: row
      })
    },
    deleteRow(row) {
      const { parentList, idx } = this.findParentRow(this.formData.data, row)
      parentList.splice(idx, 1)
    },
    // 参数类型改变时，清空数组元素泛型和row.childrenList
    dataTypeChange(v, row) {
      row.generic = null
      row.childrenList = []
    },
    genericChange(v, row) {
      row.childrenList = []
    },
    // 深度优先递归
    findParentRow(list, row) {
      let parentList = []
      let idx = null
      const length = list.length
      for (let i = 0; i < length; i++) {
        if (list[i] === row) {
          return { parentList: list, idx: i }
        }
        if (list[i].childrenList) {
          const res = this.findParentRow(list[i].childrenList, row)
          if (res) {
            parentList = res.parentList
            idx = res.idx
            return { parentList, idx }
          }
        }
      }
    }
  }
}
</script>

<style scoped lang="scss">

</style>
