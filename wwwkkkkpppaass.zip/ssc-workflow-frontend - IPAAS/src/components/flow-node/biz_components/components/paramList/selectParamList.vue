<template>
  <el-form class="table-form" ref="mappingForm" :model="formData" :rules="rules" labelWidth="0px" size="mini" :disabled="formDisabled">
    <el-table ref="mappingTable" :data="formData.tableList" highlightCurrentRow style="width: 100%" maxHeight="250" border>
      <el-table-column label="序号" type="index" align="left" width="60" />

      <el-table-column label="表字段" align="left" minWidth="420px" :showOverflowTooltip="false">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.fieldName" @change="fieldChange($event, scope.row)" :filterable="true">
              <el-option v-for="item in columnList" :key="item.name" :label="item.name" :value="item.name" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column v-if="sqlMethod === 'relation_select'" label="字段别名" align="left" minWidth="220px" :showOverflowTooltip="false">
        <template slot-scope="scope">
          <el-form-item>
            <el-input v-model="scope.row.aliasName" placeholder="请输入字段别名" />
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="属性数据类型" minWidth="220px" :showOverflowTooltip="false">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.dataType" placeholder="请选择属性数据类型" :disabled="true">
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="操作" width="80px" align="left" v-if="!formDisabled" fixed="right">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="deleteRow(scope.$index)">删除</el-button>
          <!-- <el-button type="text" size="mini" @click="editFunction(scope.row,scope.$index, scope)" :disabled="scope.row.dataType === 8">函数{{ scope.row.functionList&&scope.row.functionList.length ? '('+scope.row.functionList.length+')':'' }}</el-button>
          <el-button type="text" size="mini" @click="editMapping(scope.row,scope.$index)">映射{{ scope.row.dictMapping?'(1)':'' }}</el-button>
          <el-button type="text" size="mini" @click="editScript(scope.row,scope.$index)">脚本{{ scope.row.scriptData?'(1)':'' }}</el-button> -->
        </template>
      </el-table-column>
    </el-table>
    <div class="mt-10 mb-10" v-if="!formDisabled">
      <el-button class="table-add-btn" @click="addRow" icon="el-icon-plus">添加</el-button>
    </div>
    <FunctionSettingDialog ref="functionRfc" v-if="functionDialogVisible" :dialogData="selectRow" :visible.sync="functionDialogVisible" @finish="(val)=>updateRow(val, 'functionList')" />
    <ScriptSetting :dialogForm="selectRow" v-if="scriptDialogVisible" :visible.sync="scriptDialogVisible" @finish="(val)=>updateRow(val, 'scriptData')" />
    <MappingSetting :dialogForm="selectRow" v-if="mappingDialogVisible" :visible.sync="mappingDialogVisible" @finish="(val)=>updateDictMappingRow(val, 'dictMapping')" />
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
import operateMixin from './operate.mixin.js'
import ScriptSetting from '@/components/flow-node/biz_components/components/fieldMappingTable/dialog/scriptSetting'
import MappingSetting from '@/components/flow-node/biz_components/components/fieldMappingTable/dialog/mappingSetting'
import FunctionSettingDialog from '@/components/flow-node/biz_components/components/fieldMappingTable/dialog/function-setting/function-setting-dialog'
export default {
  components: { FunctionSettingDialog, ScriptSetting, MappingSetting },
  props: {
    tableList: {
      default: () => [],
      type: Array
    },
    title: {
      default: 'inParamTable',
      type: String
    },
    columnList: {
      default: () => [],
      type: Array
    },
    columnMap: {
      default: () => new Map(),
      type: Map
    },
    sqlMethod: {
      type: String,
      default: 'select'
    }
  },
  inject: ['formDisabled'],
  mixins: [operateMixin],
  data() {
    return {
      formData: {
        tableList: []
      },
      rules: {},
      DataTypeEnum: [],
      gatherAllColumnList: []
    }
  },
  watch: {
    tableList: {
      handler(nV) {
        if (nV) {
          this.formData.tableList = nV
        }
      },
      immediate: true
    },
    columnList: {
      handler(nV, oV) {
        this.gatherAllColumnList = nV
        console.log('🚀 ~ file: selectParamList.vue ~ line 80 ~ handler ~ nV,oV', nV, oV)
      }
    }
  },
  computed: {
  },
  async created() {
    [this.DataTypeEnum] = await this.getDicts([
      'DataTypeEnum'
    ])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    fieldChange(v, row) {
      row.dataType = this.columnMap.get(v).type
      console.log('🚀 ~ file: selectParamList.vue ~ line 94 ~ fieldChange ~ row', row)
    },
    addRow() {
      this.$emit('eventLinstener', {
        type: 'add',
        title: this.title,
        list: this.tableList
      })
    },
    deleteRow(index) {
      this.formData.tableList.splice(index, 1)
    }
  }
}
</script>

<style scoped lang="scss">
table-add-btn {
  width: 100%;
}
</style>
