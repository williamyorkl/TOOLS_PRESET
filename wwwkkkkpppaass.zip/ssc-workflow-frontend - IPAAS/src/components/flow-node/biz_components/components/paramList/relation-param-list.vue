<template>
  <el-form class="table-form" ref="mappingForm" :model="formData" :rules="rules" labelWidth="0px" size="mini" :disabled="formDisabled">
    <el-table ref="mappingTable" rowKey="rowKey" :data="formData.tableList" defaultExpandAll :treeProps="{children: 'relationConditionList'}" highlightCurrentRow style="width: 100%" :indent="8" maxHeight="250" border>
      <el-table-column label="序号" prop="paramName" width="60">
        <template slot-scope="scope">
          {{ scope.$index + 1 }}
        </template>
      </el-table-column>

      <el-table-column label="连接类型" align="left" width="120px">
        <template slot-scope="scope">
          <el-form-item v-if="scope.row.relationConditionList">
            <el-select v-model="scope.row.joinType" @change="joinTypeChange($event, scope.row)" :filterable="true">
              <el-option v-for="item in DbSqlJoinEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="待关联数据表" align="left" width="250px" :showOverflowTooltip="false">
        <template slot-scope="scope">
          <el-form-item v-if="scope.row.relationConditionList" :rules="scope.row.relationConditionList ? rules.tableName : ''" :prop="scope.row.relationTable">
            <mc-popover-select v-model="scope.row.relationTable" clearable :defaultValue="scope.row.relationTable" :apiFunc="tableApiFunc" :tableColumn="tablesTableColumn" :queryList="tablesQueryList" labelKey="tableName" valueKey="tableName" :param="{id: nodeParamsDbDto.dbId}" @changeRow="rowClick" :validateRowData="validateParamValidatorRowData" />
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="数据表连接字段" align="left" :showOverflowTooltip="false">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.joinFieldName" @change="fieldChange($event, scope.row)" :filterable="true" @focus="handleRelationColumnList(scope.row, scope.$index)">
              <el-option v-for="item in columnList" :key="item.name" :label="item.name" :value="item.name" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="待关联数据表连接字段" align="left" :showOverflowTooltip="false">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.relationTableFieldName" @change="subFieldChange($event, scope.row)" :filterable="true" @focus="handleSearchColumn(scope.row)">
              <el-option v-for="item in subColumnlist" :key="item.name" :label="item.name" :value="item.name" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="操作" width="80px" align="left" v-if="!formDisabled">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="addChildRow(scope.row)" :disabled="!(scope.row.relationConditionList && scope.row.relationConditionList.length >= 0)">添加</el-button>
          <el-button type="text" size="mini" @click="deleteRow(scope.row, scope.$index)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="mt-10 mb-10" v-if="!formDisabled">
      <el-button class="table-add-btn" @click="addRow" icon="el-icon-plus">添加</el-button>
    </div>
  </el-form>
</template>

<script>
import { getUUID } from '@/utils'
import { mapActions } from 'vuex'
import {
  SqlParams
} from '@/components/flow-node/model/nodeParams_model.js'

import tablesOption from '@/config/popContentTableConfig/table.config.js'
import dbApi from '@/api/database'

export default {
  props: {
    // NOTE - 包含除了自身表字段，还有其他表字段
    tableList: {
      default: () => [],
      type: Array
    },
    title: {
      default: 'inParamTable',
      type: String
    },
    /* columnList: {
      default: () => [],
      type: Array
    }, */
    columnMap: {
      default: () => new Map(),
      type: Map
    },
    // NOTE - 数据库关联查询连接方式的枚举
    // eslint-disable-next-line vue/prop-name-casing
    DbSqlJoinEnum: {
      default: () => [],
      type: Array
    },
    relationTableFieldList: {
      default: () => [],
      type: Array
    },
    sqlItemData: {
      type: Object,
      default: () => (new SqlParams())
    },
    nodeFormData: {
      // 节点完整的配置数据
      type: Object,
      default: () => ({})
    },
    index: {
      type: Number,
      default: 0
    }
  },
  inject: ['formDisabled'],
  data() {
    return {
      formData: {
        tableList: []
      },
      rules: {},
      DataTypeEnum: [],
      tableApiFunc: tablesOption.apiFunc,
      tablesTableColumn: tablesOption.getTableColumn(),
      tablesQueryList: tablesOption.getQueryList(),
      subColumnlist: [],
      subColumnMap: new Map(),
      subColumnTableNameCal: [],
      columnList: []
    }
  },
  watch: {
    tableList: {
      handler(nV) {
        if (nV) {
          nV.forEach((row) => {
            if (!row.relationConditionList || row.relationConditionList === '' || row.relationConditionList === undefined || row.relationConditionList.length === 0) {
              this.$set(row, 'relationConditionList', [])
            } else {
              if (row.relationTable) {
                // eslint-disable-next-line no-return-assign
                row.relationConditionList.forEach(item => item.relationTable = row.relationTable)
              }
            }
          })
          nV = this.recursivelyAddAttr(nV)
          this.formData.tableList = nV
        }
      },
      immediate: true
    }
  },
  computed: {
    nodeParamsDbDto() {
      return this.nodeFormData.nodeParamsLogicDto.nodeParamsDbDto
    }
  },
  async created() {
    [this.DataTypeEnum] = await this.getDicts([
      'DataTypeEnum'
    ])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    joinTypeChange(v, row) {
      row.relationType = v
    },
    fieldChange(v, row) {
      row.dataType = this.columnMap.get(v).type
    },
    subFieldChange(v, row) {
      row.dataType = this.subColumnMap.get(v).type
    },
    addRow() {
      console.log('🚀 ~ file: relation-param-list.vue ~ line 128 ~ addRow ~ this.tableList', this.tableList)
      this.$emit('eventLinstener', {
        type: 'add',
        title: this.title,
        list: this.tableList
      })
    },
    addChildRow(row) {
      console.log(row, 'row')
      if (!row.relationTable || row.relationTable === '' || row.relationTable === undefined) return this.$message.warning('请先选择待关联数据表')
      if (!row.relationConditionList || row.relationConditionList === '' || row.relationConditionList === undefined || row.relationConditionList.length === 0) {
        this.$set(row, 'relationConditionList', [])
      }
      /* this.$emit('eventLinstener', {
        type: 'add',
        title: 'add_relation_child',
        list: row.relationConditionList
      }) */
      row.relationConditionList.push({
        relationTable: row.relationTable || null,
        joinFieldName: null,
        relationTableFieldName: null,
        rowKey: getUUID()
      })
    },
    deleteRow(row, _index) {
      this.$confirm(
        '确定删除此行吗? 删除不会提交数据，请点击【保存】提交',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      ).then(() => {
        const { parentList, idx } = this.findParentRow(this.formData.tableList, row)
        parentList.splice(idx, 1)
      })
    },
    async rowClick(row, oldVal) {
      console.log('🚀 ~ file: relation-param-list.vue ~ line 177 ~ rowClick ~ oldVal', row, oldVal)

      const resp = await dbApi.getFields({ id: this.nodeParamsDbDto.dbId, tableName: row.tableName })

      this.subColumnlist = resp.columnDtos.map(item => {
        return {
          ...item,
          name: row.tableName + '.' + item.name
        }
      })

      this.subColumnlist.forEach((item) => {
        this.subColumnMap.set(item.name, item)
      })

      if (row.tableName !== oldVal.tableName) {
        this.subColumnMap.forEach((val, key) => {
          if (oldVal.tableName === key.split('.')[0]) {
            this.subColumnMap.delete(key)
          }
        })
      }

      console.log('🚀 ~ file: relation-param-list.vue ~ line 201 ~ rowClick ~ this.subColumnMap', this.subColumnMap)

      this.$emit('handleUpdateSubColumnMap', this.subColumnMap, oldVal.tableName)
    },
    async handleSearchColumn(row) {
      const resp = await dbApi.getFields({ id: this.nodeParamsDbDto.dbId, tableName: row.relationTable })

      this.subColumnlist = resp.columnDtos.map(item => {
        return {
          ...item,
          name: row.relationTable + '.' + item.name
        }
      })
    },
    recursivelyAddAttr(data) {
      if (!Array.isArray(data)) return data
      for (let j = 0; j < data.length; j++) {
        !data[j].rowKey && (data[j].rowKey = Math.random().toFixed(5))
        if (data[j].relationConditionList) {
          if (data[j].relationConditionList.length > 0) {
            this.recursivelyAddAttr(data[j].relationConditionList)
          }
        }
      }
      return data
    },
    validateParamValidatorRowData(row) {
      // 检测参数校验选中的接口是否是原接口
      if (row.tableName === this.sqlItemData.tableName) {
        return '不能选择相同数据表'
      } else {
        return 'RESOLVE'
      }
    },
    // 深度优先递归
    findParentRow(list, row) {
      let parentList = []
      let idx = null
      const length = list.length
      for (let i = 0; i < length; i++) {
        if (list[i] === row) {
          return { parentList: list, idx: i }
        }
        if (list[i].relationConditionList) {
          const res = this.findParentRow(list[i].relationConditionList, row)
          if (res) {
            parentList = res.parentList
            idx = res.idx
            return { parentList, idx }
          }
        }
      }
    },
    // 获取columnList数据
    async handleRelationColumnList(row, index) {
      if (!row.relationConditionList) {
        this.formData.tableList.forEach((item, idx) => {
          const childrenList = item.relationConditionList
          const hasRow = !!childrenList.find(child => child === row)
          if (hasRow) {
            index = idx
          }
        })
      }
      let nameList = []
      const _columnList = []
      for (let i = 0; i <= index; i++) {
        if (this.formData.tableList[i] && this.formData.tableList[i].relationTable) {
          nameList.push(this.formData.tableList[i].relationTable)
        }
      }
      if (this.sqlItemData.tableName) {
        nameList.push(this.sqlItemData.tableName)
      }
      nameList = [...new Set(nameList)]

      this.columnMap.forEach((value, key) => {
        const tableName = key.split('.')[0]
        if (nameList.includes(tableName)) {
          if (!row.relationConditionList) {
            this.formData.tableList.forEach((item) => {
              const childrenList = item.relationConditionList
              const hasRow = !!childrenList.find(child => child === row)
              if (hasRow) {
                if (item.joinFieldName) {
                  const name = item.joinFieldName.split('.')[0]
                  if (name === tableName) {
                    _columnList.push({ name: key })
                  }
                }
              }
            })
          } else {
            _columnList.push({ name: key })
          }
        }
      })
      this.columnList = [..._columnList]
    }

  }
}
</script>

<style scoped lang="scss">
table-add-btn {
  width: 100%;
}
.placeholder {
  min-height: 40px;
  min-width: 100px;
  line-height: 40px;
}
</style>
