<template>
  <el-form class="table-form" ref="mappingForm" :model="formData" :rules="rules" labelWidth="0px" size="mini" :disabled="formDisabled">
    <el-table ref="mappingTable" :data="formData.tableList" highlightCurrentRow style="width: 100%" maxHeight="250" border>
      <el-table-column label="序号" type="index" align="left" width="60" />

      <el-table-column label="表字段" align="left" minWidth="200">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.fieldName" placeholder="请选择类型">
              <el-option label="offset" value="offset" />
              <el-option label="pageSize" value="pageSize" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="类型" align="left" minWidth="120">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.type" placeholder="请选择类型" @change="typeChange(scope.row)">
              <el-option v-for="item in ParamReferenceTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="属性数据类型" minWidth="150">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.dataType" placeholder="请选择属性数据类型" :readonly="true" :disabled="true" @change="dataTypeChange(scope.row)">
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="节点名称" minWidth="200">
        <template slot-scope="scope">
          <el-form-item>
            <el-input :value="resolveNodeName(scope.row.nodeKey, nodeMap)" :disabled="true" />
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="值" minWidth="200">
        <template slot-scope="scope">
          <el-form-item>
            <el-input v-if="scope.row.type === 1" v-model.trim="scope.row.value" placeholder="请输入内容" :disabled="true">
              <el-button slot="append" icon="el-icon-setting" @click="showJsonTree(scope.row)" />
            </el-input>
            <mc-input v-else :dataType="scope.row.dataType" :trim="false" v-model="scope.row.value" placeholder="内容" />
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="操作" width="250px" align="left" v-if="!formDisabled" fixd="right">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="deleteRow(scope.$index)">删除</el-button>
          <el-button type="text" size="mini" @click="editFunction(scope.row,scope.$index, scope)" :disabled="scope.row.dataType === 8">函数{{ scope.row.functionList&&scope.row.functionList.length ? '('+scope.row.functionList.length+')':'' }}</el-button>
          <el-button type="text" size="mini" @click="editMapping(scope.row,scope.$index)">映射{{ scope.row.dictMapping?'(1)':'' }}</el-button>
          <el-button type="text" size="mini" @click="editScript(scope.row,scope.$index)">脚本{{ scope.row.scriptData?'(1)':'' }}</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="mt-10 mb-10" v-if="!formDisabled">
      <el-button class="table-add-btn" @click="addRow" icon="el-icon-plus">添加</el-button>
    </div>
    <!-- 数据源json弹窗 -->
    <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px" v-if="jsonTreeDialogVisible">
      <JsonTree title="源数据" :selectNodeId.sync="selectNodeId" :data.sync="sourceData" @rightClick="rightClick" :multipleNode="true" :includeSelf="includeSelf" />
    </el-dialog>
    <FunctionSettingDialog ref="functionRfc" v-if="functionDialogVisible" :dialogData="selectRow" :visible.sync="functionDialogVisible" @finish="(val)=>updateRow(val, 'functionList')" />
    <ScriptSetting :dialogForm="selectRow" v-if="scriptDialogVisible" :visible.sync="scriptDialogVisible" @finish="(val)=>updateRow(val, 'scriptData')" />
    <MappingSetting :dialogForm="selectRow" v-if="mappingDialogVisible" :visible.sync="mappingDialogVisible" @finish="(val)=>updateDictMappingRow(val, 'dictMapping')" />
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
import JsonTree from '../jsonTree/index'
import mixinResolveNodeName from '../../../mixins/resolveNodeName'
import operateMixin from './operate.mixin.js'
import ScriptSetting from '@/components/flow-node/biz_components/components/fieldMappingTable/dialog/scriptSetting'
import MappingSetting from '@/components/flow-node/biz_components/components/fieldMappingTable/dialog/mappingSetting'
import FunctionSettingDialog from '@/components/flow-node/biz_components/components/fieldMappingTable/dialog/function-setting/function-setting-dialog'
import { validDbCanUse } from '@/components/flow-node/biz_components/nodeOptionDialog/node-option-utils'

export default {
  components: { JsonTree, FunctionSettingDialog, ScriptSetting, MappingSetting },
  props: {
    tableList: {
      default: () => [],
      type: Array
    },
    title: {
      default: 'inParamTable',
      type: String
    },
    nodeList: {
      type: Array,
      default: () => []
    },
    includeSelf: {
      type: Boolean,
      default: false
    },
    index: {
      type: Number,
      default: 0
    },
    nodeFormData: {
      // 节点完整的配置数据
      type: Object,
      default: () => ({})
    }
  },
  inject: ['formDisabled', 'nodeMap'],
  mixins: [mixinResolveNodeName, operateMixin],
  data() {
    return {
      formData: {
        tableList: []
      },
      rules: {},
      ParamReferenceTypeEnum: [],
      DataTypeEnum: [],
      jsonTreeDialogVisible: false,
      currentRow: {},
      sourceData: [],
      selectNodeId: null
    }
  },
  watch: {
    tableList: {
      handler(nV) {
        if (nV) {
          this.formData.tableList = nV
          console.log(this.formData)
        }
      },
      immediate: true
    }
  },
  async created() {
    [this.ParamReferenceTypeEnum, this.DataTypeEnum] = await this.getDicts([
      'ParamReferenceTypeEnum', 'DataTypeEnum'
    ])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    typeChange(row) {
      row.value = null
      row.nodeKey = null
    },
    dataTypeChange(row) {
      row.value = null
    },
    showJsonTree(row) {
      this.jsonTreeDialogVisible = true
      this.currentRow = row
    },
    rightClick(node, nodeId) {
      if (this.includeSelf) {
        // 如果选择的是当前节点，校验不能选择index大于等于自己的
        const canUse = validDbCanUse({ selectNodeId: nodeId, selectPath: node.path, currentNodeId: this.nodeFormData.id, currentIndex: this.index })
        if (!canUse) {
          return this.$message.error('不能引用当前SQL以及当前SQL之后的SQL数据')
        }
      }
      this.jsonTreeDialogVisible = false
      this.currentRow.nodeKey = nodeId
      this.currentRow.value = node.path
    },
    addRow() {
      this.$emit('eventLinstener', {
        type: 'add',
        title: this.title,
        list: this.tableList
      })
    },
    deleteRow(index) {
      this.$confirm(
        '确定删除此行吗? 删除不会提交数据，请点击【保存】提交',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      ).then(() => {
        this.formData.tableList.splice(index, 1)
      })
    }
  }
}
</script>

<style scoped lang="scss">
table-add-btn {
  width: 100%;
}
</style>
