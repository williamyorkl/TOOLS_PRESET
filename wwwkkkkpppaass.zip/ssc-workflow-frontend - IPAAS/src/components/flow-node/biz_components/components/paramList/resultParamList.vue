<template>
  <el-form class="table-form" ref="mappingForm" :model="formData" :rules="rules" labelWidth="0px" size="mini" :disabled="formDisabled">
    <el-table ref="mappingTable" :data="formData.tableList" highlightCurrentRow style="width: 100%" maxHeight="250" border>
      <el-table-column label="序号" type="index" align="left" width="60" />

      <el-table-column label="表字段" align="left">
        <template slot-scope="scope">
          <el-form-item>
            <el-input v-model.trim="scope.row.fieldName" placeholder="请输入表字段" :disabled="true" />
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="属性数据类型">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.dataType" placeholder="请选择属性数据类型">
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <!-- <el-table-column label="操作" width="150px" align="left">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="deleteRow(scope.$index)">删除</el-button>

        </template>
      </el-table-column> -->
    </el-table>
    <!-- <div class="mt-10 mb-10">
      <el-button class="table-add-btn" @click="addRow" icon="el-icon-plus">添加</el-button>
    </div> -->
  </el-form>
</template>

<script>
import { mapActions } from 'vuex'
export default {
  props: {
    tableList: {
      default: () => [],
      type: Array
    },
    title: {
      default: 'inParamTable',
      type: String
    }
  },
  inject: ['formDisabled'],
  data() {
    return {
      formData: {
        tableList: []
      },
      rules: {},
      DataTypeEnum: []
    }
  },
  computed: {
  },
  watch: {
    tableList: {
      handler(nV) {
        if (nV) {
          this.formData.tableList = nV
          console.log(this.formData)
        }
      },
      immediate: true
    }
  },
  async created() {
    [this.DataTypeEnum] = await this.getDicts([
      'DataTypeEnum'
    ])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    addRow() {
      this.$emit('eventLinstener', {
        type: 'add',
        title: this.title,
        list: this.tableList
      })
    },
    deleteRow(index) {
      this.$confirm(
        '确定删除此行吗? 删除不会提交数据，请点击【保存】提交',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      ).then(() => {
        this.formData.tableList.splice(index, 1)
      })
    }
  }
}
</script>

<style scoped lang="scss">
table-add-btn {
  width: 100%;
}
</style>
