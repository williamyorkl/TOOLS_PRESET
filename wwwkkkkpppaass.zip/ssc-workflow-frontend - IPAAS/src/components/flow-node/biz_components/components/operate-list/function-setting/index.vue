<template>
  <!-- 接收函数列表,直接就该列表进行增删改操作 -->
  <div>
    <el-form ref="formData" :model="formData" labelWidth="120px" size="mini" labelPosition="top" :disabled="formDisabled">
      <el-table :data="formData.functionList" style="width: 100%" border>
        <el-table-column label="序号" type="index" align="left" width="60" />
        <el-table-column prop="express" label="函数名称" align="left" :showOverflowTooltip="false" width="250px">
          <template slot-scope="scope">
            <el-form-item :prop="'functionList.' + scope.$index + '.express'" :rules="{ required: true, message: '请选择函数类型', trigger: 'change' }">
              <el-select v-model="scope.row.express" clearable placeholder="请选择" filterable @change="setFuncInfo($event,scope.$index,scope.row, scope)" :disabled="formDisabled">
                <el-option-group v-for="group in funcList" :key="group.label" :label="group.label">
                  <el-option v-for="item in group.options" :key="item.id" :label="item.funcCode + ' | ' + item.funcName" :value="'#' + item.funcCode" :disabled="targetDataType !== item.responseType" />
                </el-option-group>
              </el-select>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column prop="funcParaCount" label="参数个数" align="left" :showOverflowTooltip="false" width="80px">
          <template slot-scope="scope">
            {{ scope.row.parameters.length }}
          </template>
        </el-table-column>
        <el-table-column prop="" label="参数" align="left" :showOverflowTooltip="false" minWidth="100px">
          <template slot-scope="scope">
            <template v-if="scope.row.parameters">
              <el-form-item class="mb-5" v-for="(item) in scope.row.parameters" :key="item.paramName">
                {{ item.paramName }}
              </el-form-item>
            </template>
          </template>
        </el-table-column>

        <el-table-column prop="" label="取值类型" align="left" :showOverflowTooltip="false" minWidth="200px">
          <template slot-scope="scope">
            <template v-if="scope.row.parameters">
              <el-form-item class="mb-5" v-for="(item) in scope.row.parameters" :key="item.paramName">
                <el-select v-model="item.referenceType" placeholder="请选择取值类型">
                  <el-option v-for="item in ParamReferenceTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
                </el-select>
              </el-form-item>
            </template>
          </template>
        </el-table-column>

        <el-table-column prop="" label="节点名称" align="left" :showOverflowTooltip="false" width="200px">
          <template slot-scope="scope">
            <template v-if="scope.row.parameters">
              <el-form-item class="mb-5" v-for="(item) in scope.row.parameters" :key="item.paramName">
                <el-input :value="resolveNodeName(item.sourceNodeKey, nodeMap)" :disabled="true" v-if="item.referenceType === 1" />
                <el-input :value="''" :disabled="true" v-else />
              </el-form-item>
            </template>
          </template>
        </el-table-column>

        <el-table-column prop="" label="值" align="left" :showOverflowTooltip="false" width="200px">
          <template slot-scope="scope">
            <el-form-item v-for="item in scope.row.parameters" :key="item.paramName">
              <el-input v-if="item.referenceType === 1" v-model.trim="item.sourceNodePath" placeholder="请输入内容" :disabled="true">
                <el-button slot="append" icon="el-icon-setting" @click="showJsonTree(item)" />
              </el-input>
              <mc-input v-else :data-type="6" :trim="false" v-model="item.sourceNodePath" placeholder="内容" />
            </el-form-item>
          </template>
        </el-table-column>

        <el-table-column prop="remarks" label="函数描述" align="left" :showOverflowTooltip="false" minWidth="150px" />

        <el-table-column label="操作" align="left" fixed="right" v-if="!formDisabled">
          <template slot-scope="scope">
            <el-button type="text" size="mini" @click="deleteRow(scope.$index)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="rigth mt-10 mb-10" v-if="!formDisabled">
        <el-button style="width: 100%" size="medium" type="dash" @click="addRow" icon="el-icon-plus">添加</el-button>
      </div>
    </el-form>
    <!-- 数据源json弹窗 -->
    <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px">
      <JsonTree title="源数据" :selectNodeId.sync="selectNodeId" :data.sync="sourceData" @rightClick="rightClick" :multipleNode="true" />
    </el-dialog>
  </div>
</template>

<script>
import funcApi from 'api/platformConfig/func'
import { FunctionDTO } from './options/model'
import { Parameter } from '@/components/flow-node/model/nodeParams_model'
import { mapActions } from 'vuex'
import mixinResolveNodeName from '@/components/flow-node/mixins/resolveNodeName'
import JsonTree from '@/components/flow-node/biz_components/components/jsonTree/index'

export default {
  name: 'FunctionSetting',
  components: { JsonTree },
  props: {
    tableData: {
      type: [Array],
      default: () => []
    },
    funcType: {
      default: null,
      type: [String, Number]

    },
    targetDataType: {
      default: null,
      type: Number
    }
  },
  inject: ['nodeMap', 'formDisabled'],
  mixins: [mixinResolveNodeName],
  data() {
    return {
      funcList: [],
      funcMapping: null,
      formData: {
        functionList: []
      },
      ParamReferenceTypeEnum: [],
      jsonTreeDialogVisible: false,
      currentParam: {},
      sourceData: [],
      selectNodeId: null
    }
  },
  async created() {
    this.formData.functionList = this.tableData;
    [this.ParamReferenceTypeEnum] = await this.getDicts(['ParamReferenceTypeEnum'])
    this.getFuncList()
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    showJsonTree(row) {
      this.jsonTreeDialogVisible = true
      this.currentParam = row
    },
    rightClick(node, nodeId) {
      this.jsonTreeDialogVisible = false
      this.currentParam.sourceNodeKey = nodeId
      this.currentParam.sourceNodePath = node.path
    },
    spliceExpress(express) {
      if (!express) return null
      if (express.startsWith('#')) {
        express = express.slice(1)
      }
      return express
    },
    setFuncInfo(val, rowIndex, row, _scope) {
      let funcCode = val
      if (funcCode.startsWith('#')) funcCode = funcCode.slice(1)
      const item = this.funcMapping.get(funcCode)
      row.remarks = item.remarks
      row.scope = item.scope
      this.$set(row, 'parameters', [])
      if (!item.paramJson) return
      (JSON.parse(item.paramJson) || []).forEach(param => {
        row.parameters.push(new Parameter({ paramName: param.name }))
      })
    },
    // 调用函数接口加载数据
    async getFuncList() {
      const res = await funcApi.getFuncLevelTwoListAll({ type: this.funcType })
      if (!this.funcMapping) this.funcMapping = new Map()
      this.funcList = res
      res.forEach(group => {
        group.options.forEach(item => {
          this.funcMapping.set(item.funcCode, item)
        })
      })
    },
    addRow() {
      if (this.formData.functionList.length >= 1) {
        return this.$message.error('只能添加一个函数')
      }
      this.formData.functionList.push(new FunctionDTO())
    },
    // 删除，不请求后台
    deleteRow(index) {
      this.formData.functionList.splice(index, 1)
    }

  }

}
</script>
