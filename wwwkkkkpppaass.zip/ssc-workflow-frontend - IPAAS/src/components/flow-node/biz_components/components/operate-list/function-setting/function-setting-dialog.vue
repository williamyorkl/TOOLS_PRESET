<template>
  <el-dialog title="函数设置" :visible="visible" width="70%" @close="$emit('update:visible', false)" appendToBody>
    <FunctionSetting ref="functionRfc" :targetDataType="dialogForm.dataType" :tableData="[dialogForm]" />
    <span slot="footer" class="dialog-footer">
      <el-button v-if="formDisabled" @click="$emit('update:visible', false)">关 闭</el-button>
      <el-button v-else @click="$emit('update:visible', false)">取 消</el-button>
      <el-button type="primary" @click="sure">确 定</el-button>

    </span>
  </el-dialog>
</template>

<script>
import { deepClone } from '@/utils'
import FunctionSetting from './index'

export default {
  name: 'FunctionSettingDialog',
  components: { FunctionSetting },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    id: {
      type: [String, Number],
      default: ''
    },
    dialogData: {
      type: [Object],
      default: function() {
        return { functionList: [] }
      }
    }
  },
  inject: ['formDisabled'],
  data() {
    return {
      dialogForm: {
        functionList: []
      }
    }
  },
  created() {
    this.dialogForm = deepClone(this.dialogData)
  },
  methods: {
    sure() {
      // 处理dialogForm参数
      // this.$refs.dialogForm.validate(valid => {
      //   if (valid) {
      //     this.dialogForm.functionList.forEach(item => {
      //       item.parameters = []
      //       item.parameters = item.parameterList.map(pi => { return pi.defaultValue })
      //     })
      //     this.$emit('finish', this.dialogForm)
      //   } else {
      //     this.$message.error('请完善表单信息')
      //   }
      // })
      console.log('sure')
      this.$emit('finish', this.dialogForm)
    }

  }

}
</script>
