export class Param {
  constructor() {
    this.rowKey = Date.now() + ''
    this.childrenList = []
    this.dataType = null // 参数类型
    this.description = null // 描述
    this.isRequired = null // 是否必填
    this.paramName = null // 参数key
    this.generic = null
    this.dataPosition = null
    this.value = null
    // this.paramCheck = new ParamCheck()
    // this.newBool = true
  }
}
