<template>
  <div style="">
    <el-row v-for="(formItem, index) in preConditionList" :key="index" type="flex" align="middle" style="margin-bottom: 8px;">
      <el-col :span="22">
        <el-divider contentPosition="left">c{{ index+1 }}：</el-divider>
        <el-form ref="form" :model="formItem" class="condition-form" labelWidth="65px" :disabled="formDisabled">
          <!-- 值1条件 -->
          <el-form-item required label="值1">
            <el-row :gutter="10">
              <!-- 引用 固定 -->
              <el-col :span="5">
                <el-select v-model="formItem.c1.type" placeholder="请选择参数类型" @change="typeChange($event, index, 'c1')">
                  <el-option v-for="item in ParamTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
                </el-select>
              </el-col>
              <!-- 数据类型 -->
              <el-col :span="6">
                <el-select v-model="formItem.c1.dataType" placeholder="请选择参数值类型" :disabled="formItem.c1.type === 1">
                  <el-option v-for="item in dataTypeList" :key="item.type" :label="item.desc" :value="item.type" />
                </el-select>
              </el-col>
              <!-- 值: 引用值、固定值、临时变量 -->
              <el-col :span="6">
                <!-- 固定值 -->
                <mc-input v-if="formItem.c1.type === 0" :dataType="formItem.c1.dataType" v-model="formItem.c1.value" :trim="false" placeholder="源字段或值" />
                <!-- 引用值 -->
                <el-input v-if="formItem.c1.type === 1" v-model="formItem.c1.value" placeholder="请输入内容" @focus="focusInput($event, formItem.c1)">
                  <el-button slot="append" icon="el-icon-setting" @click="showJsonTree(formItem.c1)" />
                </el-input>
                <!-- 临时变量 -->
                <el-select v-if="formItem.c1.type === 3" v-model="formItem.c1.value" placeholder="请选择变量" @change="variableChange($event, formItem.c1)">
                  <el-option v-for="option in variables" :key="option.variableName" :label="option.variableName" :value="option.variableName" />
                </el-select>
              </el-col>
              <!-- 引用值时显示所属节点 -->
              <el-col :span="5" v-if="formItem.c1.type === 1">
                <el-input :value="resolveNodeName(formItem.c1.nodeKey, nodeMap)" :disabled="true" />
              </el-col>
            </el-row>
          </el-form-item>
          <!-- 比较符 -->
          <el-form-item required label="比较符">
            <el-row :gutter="10">
              <el-col :span="8">
                <el-select v-model="formItem.compareSymbol" placeholder="请选择" @change="compareChange($event, formItem)">
                  <el-option v-for="item in compareTypeList" :key="item.type" :label="item.desc" :value="item.type" />
                </el-select>
              </el-col>
            </el-row>
          </el-form-item>
          <!-- 值2 -->
          <el-form-item required label="值2" v-if="includeList.includes(formItem.compareSymbol)">
            <el-row :gutter="10">
              <!-- 引用 固定 -->
              <el-col :span="5">
                <el-select v-model="formItem.c2.type" placeholder="请选择参数类型" @change="typeChange($event, index, 'c2')">
                  <el-option v-for="item in ParamTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
                </el-select>
              </el-col>
              <!-- 数据类型：为固定值或请求入参时需要制定数据类型 -->
              <el-col :span="6">
                <el-select v-model="formItem.c2.dataType" placeholder="请选择参数值类型" :disabled="formItem.c2.type === 1">
                  <el-option v-for="item in dataTypeList" :key="item.type" :label="item.desc" :value="item.type" />
                </el-select>
              </el-col>
              <!-- 值: 参数类型为固定类型时才可修改 -->
              <el-col :span="6">
                <!-- 固定值 -->
                <mc-input v-if="formItem.c2.type === 0" :dataType="formItem.c2.dataType" v-model="formItem.c2.value" :trim="false" placeholder="源字段或值" />
                <!-- 引用值 -->
                <el-input v-if="formItem.c2.type === 1" v-model="formItem.c2.value" placeholder="请输入内容" @focus="focusInput($event, formItem.c2)">
                  <el-button slot="append" icon="el-icon-setting" @click="showJsonTree(formItem.c2)" />
                </el-input>
                <!-- 临时变量 -->
                <el-select v-if="formItem.c2.type === 3" v-model="formItem.c2.value" placeholder="请选择变量" @change="variableChange($event, formItem.c2)">
                  <el-option v-for="option in variables" :key="option.variableName" :label="option.variableName" :value="option.variableName" />
                </el-select>
              </el-col>
              <!-- 引用值时显示所属节点 -->
              <el-col :span="5" v-if="formItem.c2.type === 1">
                <el-input :value="resolveNodeName(formItem.c2.nodeKey, nodeMap)" :disabled="true" />
              </el-col>
            </el-row>
          </el-form-item>
        </el-form>
      </el-col>
      <!-- 减少符号 -->
      <el-col style="text-align: center;" :span="2" v-if="!formDisabled">
        <i class="el-icon-remove-outline" @click="reduceCondition(index)" />
      </el-col>
    </el-row>
    <div style="margin-top: 12px;">
      <el-button class="table-add-btn" size="medium" type="dash" icon="el-icon-plus" @click="pushCondition" v-if="!formDisabled">
        添加
      </el-button>
    </div>

    <!-- 数据源json弹窗 -->
    <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px">
      <JsonTree title="源数据" :multipleNode="true" :selectNodeId.sync="selectNodeId" :data.sync="sourceData" @rightClick="rightClick" v-bind="$attrs" />
    </el-dialog>
  </div>
</template>

<script>
import { mapActions } from 'vuex'
import { PreCondition, C } from '@/components/easy-flow/model/model'
import JsonTree from '../jsonTree'
import mixinResolveNodeName from '../../..//mixins/resolveNodeName'

export default {
  components: { JsonTree },
  props: {
    preConditionList: {
      type: Array,
      default: () => []
    },
    referenceTypeEnum: { type: String, default: 'ParamReferenceTypeEnum' }
  },
  inject: ['formDisabled', 'nodeMap'],
  mixins: [mixinResolveNodeName],
  data() {
    return {
      includeList: [1, 2, 3, 4, 5, 6, 7, 8],
      // 参数类型枚举  引用 固定
      ParamTypeEnum: [],
      // 数据类型枚举
      dataTypeList: [],
      // 比较符枚举
      compareTypeList: [],
      jsonTreeDialogVisible: false,
      currentC: null,
      variableMap: new Map(),
      selectNodeId: null,
      sourceData: []
    }
  },
  watch: {
    referenceTypeEnum: {
      async handler(nV) {
        if (nV) {
          [this.ParamTypeEnum] = await this.getDicts([nV])
        }
      },
      immediate: true
    }
  },
  computed: {
    // variables() {
    //   const nodeParamsHandleDto = this.nodeParamsHandleDto
    //   if (!nodeParamsHandleDto) return []
    //   // 循环nodeOptionForm.nodeParamsHandleDto,找出所有variables合并
    //   const variables = []
    //   const structList = nodeParamsHandleDto.structList
    //   console.log('structList', structList)
    //   structList.forEach(struct => {
    //     const handleOptDto = struct.handleOptDto
    //     const handleConditionDtoList = struct.handleConditionDtoList
    //     if (handleOptDto) {
    //       variables.push(...handleOptDto.variables)
    //     } else if (handleConditionDtoList) {
    //       handleConditionDtoList.forEach(handleConditionDto => {
    //         const conditionOptList = handleConditionDto.handleOptList
    //         if (conditionOptList) {
    //           conditionOptList.forEach(conditionOptDto => {
    //             variables.push(...conditionOptDto.variables)
    //           })
    //         }
    //       })
    //     }
    //   })
    //   this.variableMap.clear()
    //   variables.forEach(item => {
    //     this.variableMap.set(item.variableName, item)
    //   })
    //   console.log('variables', variables)
    //   return variables
    // }
  },
  mounted() {
    this.getDict()
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    variableChange(v, formData) {
      console.log(v, formData)
      const variable = this.variableMap.get(v)
      if (!variable) return
      formData.dataType = variable.dataType
    },
    compareChange(v, formItem) {
      if (this.includeList.includes(v)) {
        formItem.c2 = new C('c2')
      } else {
        formItem.c2 = null
      }
    },
    showJsonTree(c) {
      if (c.type === undefined) return this.$message.warning('请先选择参数类型')
      if (c.type === 1) { // 引用值，显示弹窗
        this.jsonTreeDialogVisible = true
        this.currentC = c
      }
    },
    focusInput(_event, _c) {
    },
    rightClick(node, nodeId) {
      this.jsonTreeDialogVisible = false
      this.currentC.nodeKey = nodeId
      this.currentC.value = node.path
      this.currentC.dataType = node.dataType
    },
    typeChange(v, index, c) {
      this.$set(this.preConditionList[index][c], 'dataType', null)
      this.$set(this.preConditionList[index][c], 'value', null)
      this.$set(this.preConditionList[index][c], 'nodeKey', null)
    },
    // 获取数据字典
    async getDict() {
      const res = await this.getDicts(['DataTypeEnum', 'CompareSymbolEnum'])
      // const res = await this.getDicts(['DataTypeEnum', 'CompareSymbolEnum', 'ParamReferenceTypeEnum'])
      this.dataTypeList = res[0]
      this.compareTypeList = res[1]
      // this.ParamTypeEnum = res[2]
    },
    // 添加条件
    pushCondition() {
      this.preConditionList.push(new PreCondition())
    },
    // 删除条件
    reduceCondition(index) {
      if (this.formDisabled) return
      this.preConditionList.splice(index, 1)
    }
  }
}
</script>

<style lang="scss" scoped>
.condition-form {
  border: 1px dotted #ccc;
  padding-top: 8px;
  ::v-deep .el-form-item {
    margin-bottom: 8px;
    padding-left: 8px;
  }
}
.el-icon-remove-outline {
  color: red;
  font-size: 22px;
  cursor: pointer;
}
.btn {
  display: block;
  width: 92%;
  border-style: dotted;
}
</style>
