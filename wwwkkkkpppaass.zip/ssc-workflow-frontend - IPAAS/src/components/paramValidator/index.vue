<template>
  <el-dialog title="参数校验" :visible="visible" width="70%" @close="$emit('update:visible', false)" appendToBody v-if="visible">
    <mc-form ref="form" :model="formData" :rules="rules">
      <mc-form-item componentType="ElInputNumber" prop="maxLen" label="最大长度" />
      <mc-form-item componentType="ElInputNumber" prop="minLen" label="最小长度" />
      <mc-form-item componentType="ElSelect" prop="formatType" label="类型" dict="FieldRuleCheckEnum" />
      <mc-form-item componentType="ElInput" prop="regEx" label="正则表达式" />
      <mc-form-item componentType="ElCheckbox" prop="funCheckFlag" label="使用函数校验" :editProps="{trueLabel: 1, falseLabel: 0}" :span="24" @change="funCheckFlagChange" />
      <el-col class="form-wrap" :span="24">
        <mc-form ref="subform-func" :model="formData.flowFieldFunCheck" :rules="funRules" v-if="formData.funCheckFlag" :showTopBorder="false" :showBottomBorder="false">
          <mc-form-item prop="flowFieldFunCheck" label="函数校验" :span="24">
            <FunctionSetting :formItem="formData.flowFieldFunCheck" v-bind="$attrs" />
          </mc-form-item>
        </mc-form>
      </el-col>
      <mc-form-item componentType="ElCheckbox" prop="apiCheckFlag" label="使用API校验" :editProps="{trueLabel: 1, falseLabel: 0}" :span="24" />
      <!-- <mc-form-item label-width="0" :span="24"> -->
      <el-col class="form-wrap" :span="24">
        <mc-form ref="subform-api" :model="formData.flowFieldApiCheck" :rules="apiRules" v-if="formData.apiCheckFlag" :showTopBorder="false" :showBottomBorder="false">
          <mc-form-item componentType="McPopoverSelect" prop="definitionId" label="校验API" :editProps="{
            defaultValue: formData.flowFieldApiCheck.businessApiName,
            apiFunc: frontendApiListApiFunc,
            tableColumn: frontendApiTableColumn,
            queryList: frontendApiQueryList,
            labelKey: 'businessApiName',
            validateRowData: validateRowData,
            param: {status: 1}
          }" @changeRow="changeRow"
          />
          <mc-form-item componentType="ElSelect" prop="requestType" label="请求方式" :dict="MethodTypeEnum" :disabled="true" />
          <mc-form-item componentType="ElInput" prop="requestUrl" label="接口请求URL" :disabled="true" />
          <mc-form-item componentType="ElInput" prop="apiCacheTime" label="缓存时间(s)" :disabled="true" />
          <mc-form-item componentType="ElInput" prop="definitionReqList" label="入参校验" :span="24">
            <ReqParamList :tableList="formData.flowFieldApiCheck.definitionReqList" @eventLinstener="eventLinstener" v-bind="$attrs" />
          </mc-form-item>
          <mc-form-item componentType="ElInput" prop="resultScript" label="脚本校验" :span="24" :editProps="{
            type: 'textarea',
            autosize: { minRows: 2, maxRows: 6 },
            placeholder: '根据返回结果填写表达式'
          }"
          />
        </mc-form>
      </el-col>
      <!-- </mc-form-item> -->
    </mc-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="$emit('update:visible', false)">取 消</el-button>
      <el-button type="primary" @click="confirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { mapActions } from 'vuex'
import { validateFn, validateTableTreeData } from '@/utils/validator'
import ReqParamList from './req'
import { RowParam } from './model/model'
import arrangeApi from '@/api/arrange'
import { getTableColumn, getQueryList } from '@/config/popContentTableConfig/frontendApi.config'
import FunctionSetting from './functionSetting.vue'

export default {
  name: 'ValidatorDialog',
  components: { ReqParamList, FunctionSetting },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    id: {
      type: [String, Number],
      default: ''
    },
    formData: {
      type: [Object],
      default: () => {}
    },
    validateRowData: {
      type: Function,
      default: null
    },
    mode: { type: String, default: 'edit' }
  },
  data() {
    return {
      frontendApiListApiFunc: arrangeApi.listArrange,
      frontendApiTableColumn: getTableColumn(),
      frontendApiQueryList: [],
      MethodTypeEnum: [],
      rules: {
        maxLen: [
          { validator: validateFn.checkNum({ max: 32, isPositiveNumber: true, notNull: false }), trigger: 'blur' }
        ],
        minLen: [
          { validator: validateFn.checkNum({ max: 32, isPositiveNumber: true, notNull: false }), trigger: 'blur' },
          {
            validator: (rull, value, callback) => {
              if (value && this.formData.maxLen && value > this.formData.maxLen) {
                callback(new Error('最小长度不能大于最大长度'))
              } else {
                callback()
              }
            },
            trigger: 'blur'
          }
        ],
        regEx: [{ validator: validateFn.checkRegexp(), trigger: 'blur' }]
      },
      apiRules: {
        definitionId: [{ required: true, message: '请选择校验API', trigger: 'change' }],
        requestType: [{ required: true, message: '请选择请求方式', trigger: 'change' }],
        requestUrl: [{ required: true, message: '请输入接口请求URL', trigger: 'change' }],
        apiCacheTime: [{ required: true, message: '请输入缓存时间', trigger: 'change' }],
        resultScript: [{ required: true, message: '请输入脚本校验', trigger: 'change' }]
      },
      funRules: {}
    }
  },
  async created() {
    const [MethodTypeEnum] = await this.getDicts(['MethodTypeEnum', 'FieldRuleCheckEnum'])
    this.MethodTypeEnum = MethodTypeEnum
    this.frontendApiQueryList = getQueryList(MethodTypeEnum)
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    changeRow(row) {
      this.formData.flowFieldApiCheck.businessApiName = row.businessApiName // 接口名字
      this.formData.flowFieldApiCheck.apiCacheTime = row.apiCacheTime // 缓存时间
      this.formData.flowFieldApiCheck.requestType = row.requestType // 接口请求方式
      this.formData.flowFieldApiCheck.requestUrl = row.requestUrl // 接口请求URL
      this.formData.flowFieldApiCheck.definitionReqList = this.formatterRowParam(row.apiInParamPathList, 'destName') || [] // 接口请求参数列表
    },
    addRow(list, title) {
      list.push(new RowParam({ addByUser: true }))
    },
    eventLinstener({ type, title, list }) {
      switch (type) {
        case 'add':
          this.addRow(list, title)
      }
    },
    funCheckFlagChange(val) {
      this.formData.flowFieldFunCheck = {
        express: null, // 表达式
        parameters: [] // 参数
      }
    },
    confirm() {
      if (this.$refs['subform-api']) {
        this.$refs['subform-api'].validate()
          .then(valid => {
            if (valid) {
              const apiValid = this.validateTable(this.formData.flowFieldApiCheck.definitionReqList)
              if (!apiValid) return
              this.$emit('confirm', this.formData)
            } else {
              this.$message.error('请按照提示完善表单数据')
            }
          })
      } else {
        this.$emit('confirm', this.formData)
      }
    },
    validateTable(tableData) {
      const [valid, msg, rowIndex] = validateTableTreeData(tableData, this.validateTableRow)
      if (!valid) { this.$message.error(`请求参数-第${rowIndex}行：${msg}`) }
      if (valid) return true
    },
    validateTableRow(row, isTop) {
      if (!row.destName) {
        return [false, '参数名不能为空']
      }
      if (!row.dataType) {
        return [false, '请求参数类型不能为空']
      }
      if (row.referenceType === undefined || row.referenceType === null) {
        return [false, '赋值类型不能为空']
      }
      if (!row.dataPosition) {
        return [false, '参数位置不能为空']
      }
      if (!row.sourceName) {
        return [false, '取值参数名不能为空']
      }
      return [true]
    },
    formatterRowParam(list, key) {
      list = list || []
      return list.map(item => ({
        ...new RowParam({}), [key]: item.paramName, dataType: item.dataType, isRequired: item.isRequired, dataPosition: item.dataPosition
      }))
    }

  }

}

</script>

<style scoped lang="scss">
.form-wrap{
  margin-top: -10px;
}
</style>
