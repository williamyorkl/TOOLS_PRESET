// 字段映射列表
<template>
  <el-form class="table-form" ref="mappingForm" :model="formData" :rules="rules" labelWidth="0px" size="mini">
    <el-table ref="mappingTable" :data="formData.tableList" highlightCurrentRow @current-change="handleCurrentChange" style="width: 100%" maxHeight="300px">
      <el-table-column label="序号" type="index" align="left" width="60" />

      <el-table-column label="请求参数名称" width="200px">
        <template slot-scope="scope">
          <el-form-item>
            <el-input v-model.trim="scope.row.destName" placeholder="请输入内容" :readonly="!scope.row.addByUser" :disabled="!scope.row.addByUser" />
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="请求参数类型" width="160px">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.dataType" placeholder="请选择属性数据类型" :readonly="!scope.row.addByUser" :disabled="!scope.row.addByUser">
              <el-option v-for="item in DataTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="参数位置" align="left" width="150px">
        <template slot-scope="scope">
          <el-form-item>
            <!-- 只有引用值才要选择参数位置 -->
            <el-select v-model="scope.row.dataPosition" placeholder="请选择" :disabled="!scope.row.addByUser || scope.row.referenceType === 0">
              <el-option v-for="item in DataPosEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="赋值类型" align="left" width="150px">
        <template slot-scope="scope">
          <el-form-item>
            <el-select v-model="scope.row.referenceType" placeholder="请选择类型" @change="referenceTypeChange(scope.row.referenceType, scope.row)">
              <el-option v-for="item in ParamReferenceTypeEnum" :key="item.type" :label="item.desc" :value="item.type" />
            </el-select>
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="取值参数名" width="200px">
        <template slot-scope="scope">
          <el-form-item>
            <!-- 引用值 -->
            <el-input v-if="scope.row.referenceType === 1" v-model="scope.row.sourceName" placeholder="请选择" :readonly="true">
              <el-button slot="append" icon="el-icon-setting" @click="showJsonTree(scope.row)" />
            </el-input>
            <mc-input :dataType="scope.row.dataType" :trim="false" v-model="scope.row.sourceName" />
          </el-form-item>
        </template>
      </el-table-column>

      <el-table-column label="函数设置" width="140px" align="left">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="editFunction(scope.row,scope.$index)">函数{{ scope.row.functionList&&scope.row.functionList.length ? '('+scope.row.functionList.length+')':'' }}</el-button>
          <el-button type="text" size="mini" @click="editScript(scope.row,scope.$index)">脚本{{ scope.row.scriptData?'(1)':'' }}</el-button>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="80px" align="left" fixed="right">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="deleteRow(scope.$index)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="mt-10 mb-10">
      <el-button class="table-add-btn" @click="addRow" icon="el-icon-plus">添加</el-button>
    </div>
    <FunctionSettingDialog ref="functionRfc" v-show="functionDialogVisible" :dialogData="selectRow" :visible.sync="functionDialogVisible" @finish="(val)=>updateRow(val)" />
    <ScriptSetting :dialogForm="selectRow" v-show="scriptDialogVisible" :visible.sync="scriptDialogVisible" @finish="(val)=>updateRow(val)" />

    <!-- 数据源json弹窗 -->
    <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px">
      <JsonTree title="源数据" :data="[rowData]" @rightClick="rightClick" :multipleNode="true" />
    </el-dialog>
  </el-form>
</template>

<script>
import ScriptSetting from './dialog/scriptSetting'
import FunctionSettingDialog from '@/components/functionSetting/functionSettingDialog'
import { mapActions } from 'vuex'
import JsonTree from './jsonTree'
export default {
  components: { FunctionSettingDialog, ScriptSetting, JsonTree },
  props: {
    tableList: {
      default: () => [],
      type: Array
    },
    title: {
      default: 'inParamTable',
      type: String
    },
    rowData: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      formData: {
        tableList: this.tableList
      },
      rules: {},
      DataTypeEnum: [],
      ParamReferenceTypeEnum: [],
      DataPosEnum: [],
      selectRow: {},
      selectIndex: null,
      functionDialogVisible: false,
      scriptDialogVisible: false,
      jsonTreeDialogVisible: false,
      currentRow: {}
    }
  },
  watch: {
    tableList: {
      handler(nV) {
        if (nV) {
          this.formData.tableList = nV
          console.log(this.formData.tableList)
        }
      },
      immediate: true
    }
  },
  async created() {
    [this.DataTypeEnum, this.ParamReferenceTypeEnum, this.DataPosEnum] = await this.getDicts([
      'DataTypeEnum',
      'ParamReferenceTypeEnum',
      'DataPosEnum'
    ])
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    showJsonTree(row) {
      this.currentRow = row
      this.jsonTreeDialogVisible = true
    },
    rightClick(treeNode) {
      this.currentRow.sourceName = treeNode.path
      this.jsonTreeDialogVisible = false
    },
    handleCurrentChange(row) {
      this.$emit('eventLinstener', {
        type: 'currentChange',
        row: row,
        list: this.tableList,
        title: this.title
      })
    },
    addRow() {
      this.$emit('eventLinstener', {
        type: 'add',
        title: this.title,
        list: this.tableList
      })
    },
    editFunction(row, index) {
      this.functionDialogVisible = true
      if (!row.functionList) row.functionList = []
      this.selectRow = row
      this.selectIndex = index
    },
    // 编辑脚本
    editScript(row, index) {
      this.scriptDialogVisible = true
      this.selectRow = row
      this.selectIndex = index
    },
    updateRow(formData) {
      this.$set(this.formData.tableList, this.selectIndex, formData)
      this.scriptDialogVisible = false
      this.functionDialogVisible = false
    },
    deleteRow(index) {
      this.$confirm(
        '确定删除此行吗? 删除不会提交数据，请点击【保存】提交',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      ).then(() => {
        this.formData.tableList.splice(index, 1)
      })
    },
    referenceTypeChange(v, row) {
      row.sourcePos = null
    }
  }
}
</script>

<style scoped lang="scss">
table-add-btn {
  width: 100%;
}
</style>
