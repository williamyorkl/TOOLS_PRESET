<template>
  <el-table border :data="tableData" :spanMethod="collapseMethod">
    <el-table-column label="函数" :showOverflowTooltip="false">
      <!-- eslint-disable-next-line vue/no-unused-vars -->
      <template slot-scope="scope">
        <el-select v-model="formItem.express" clearable placeholder="请选择" filterable @change="setFuncInfo($event, formItem)">
          <el-option-group v-for="group in funcList" :key="group.label" :label="group.label">
            <el-option v-for="item in group.options" :key="item.id" :label="item.funcCode + ' | ' + item.funcName" :value="'#' + item.funcCode" />
          </el-option-group>
        </el-select>
      </template>
    </el-table-column>
    <template v-if="formItem.parameters.length > 0">
      <el-table-column label="函数入参">
        <template slot-scope="scope">
          {{ scope.row.paramName }}
        </template>
      </el-table-column>
      <el-table-column label="取值类型">
        <template slot-scope="scope">
          <el-select v-model="scope.row.referenceType" placeholder="请选择取值方式" @change="typeChange(scope.row)">
            <el-option v-for="item in typeList" :key="item.type" :label="item.desc" :value="item.type" />
          </el-select>
        </template>
      </el-table-column>

      <el-table-column label="源字段">
        <!-- eslint-disable-next-line vue/no-unused-vars -->
        <template slot="header" slot-scope="scope">
          源字段
          <el-tooltip content="若引用循环值，请在 &quot;[ ]&quot; 中声明对应下标或使用 &quot;[ i ]&quot; 表示循环索引" placement="top">
            <i class="pointer el-icon-info" />
          </el-tooltip>
        </template>
        <template slot-scope="scope">
          <!-- 引用值 -->
          <el-input v-if="scope.row.referenceType === 1" v-model="scope.row.sourceNodePath" placeholder="请选择" :readonly="true">
            <el-button slot="append" icon="el-icon-setting" @click="showJsonTree(scope.row)" />
          </el-input>
          <!-- 固定值 -->
          <el-input v-else v-model="scope.row.sourceNodePath" maxlength="32" placeholder="请输入内容" />
        </template>
      </el-table-column>
    </template>

    <!-- 数据源json弹窗 -->
    <el-dialog title="值详情" :visible.sync="jsonTreeDialogVisible" appendToBody width="700px">
      <JsonTree title="源数据" :data="[rowData]" @rightClick="rightClick" :multipleNode="true" />
    </el-dialog>
  </el-table>
</template>

<script>
import { mapActions } from 'vuex'
import funcApi from 'api/platformConfig/func'
import { Parameter, Variable } from '@/components/easy-flow/model/model'
import JsonTree from './jsonTree'
export default {
  components: { JsonTree },
  props: {
    formItem: {
      type: Object,
      default: () => new Variable()
    },
    rowData: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      funcList: [],
      funcMapping: null,
      jsonTreeDialogVisible: false,
      typeList: [],
      currentRow: {}
    }
  },
  created() {
    this.getDict()
    this.getFuncList()
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    showJsonTree(row) {
      this.currentRow = row
      this.jsonTreeDialogVisible = true
    },
    rightClick(treeNode) {
      this.currentRow.sourceNodePath = treeNode.path
      this.jsonTreeDialogVisible = false
    },
    typeChange(row) {
      row.sourceNodePath = null
      row.sourceNodeName = null
      row.sourceNodeKey = null
    },
    setFuncInfo(val, formItem) {
      formItem.parameters = []
      let funcCode = val
      if (funcCode.startsWith('#')) funcCode = funcCode.slice(1)
      const item = this.funcMapping.get(funcCode)
      if (!item) return
      let params = []
      try {
        params = JSON.parse(item.paramJson) || []
      } catch (e) {
        params = []
      }
      params.forEach((funcParam) => {
        formItem.parameters.push(new Parameter({ paramName: funcParam.name }))
      })
      // 带出函数的返回值类型作为变量的dataType
      formItem.dataType = item.responseType
    },
    // 调用函数接口加载数据
    async getFuncList() {
      const res = await funcApi.getFuncLevelTwoListAll()
      if (!this.funcMapping) this.funcMapping = new Map()
      this.funcList = res
      res.forEach((group) => {
        group.options.forEach((item) => {
          this.funcMapping.set(item.funcCode, item)
        })
      })
    },
    // 获取数据字典
    async getDict() {
      [this.typeList] =
        await this.getDicts([
          'ParamReferenceTypeEnum'
        ])
    },
    collapseMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        if (rowIndex === 0) {
          // 第一列，第一行，向后合并999行、一列
          return {
            rowspan: 999,
            colspan: 1
          }
        } else {
          // 第一列，其他行，变成0
          return {
            rowspan: 0,
            colspan: 0
          }
        }
      }
    }
  },
  computed: {
    tableData() {
      console.log('this.formItem', this.formItem)
      // 如果参数长度为0，渲染[formItem]，否则渲染parameters
      const paramLen = this.formItem.parameters.length
      let tableData = []
      if (paramLen === 0) {
        tableData = [this.formItem]
      } else {
        tableData = this.formItem.parameters
      }

      return tableData
    }
  }
}
</script>

<style>
</style>
