<template>
  <div class="jsontree-panel">
    <div class="card-title">
      <span class="title-text">{{ title }}(JSON)
        <el-tooltip class="item" effect="dark" content="右键选择数据" placement="top-start">
          <i class="el-icon-info" />
        </el-tooltip>
        &nbsp;
      </span>
      <div class="filter-input"><el-input v-model="filterText" placeholder="输入关键字进行检索" @input="filterTreeData" /></div>
    </div>

    <el-card class="box-card">
      <el-tree ref="tree" :data="treeData" :props="treeDataProps" nodeKey="key" defaultExpandAll checkOnClickNode @node-contextmenu="rightClick" :filterNodeMethod="filterNode" />
    </el-card>
  </div>
</template>

<script>
import { mapActions } from 'vuex'
import { _typeof, deepClone } from '@/utils'
import { formatterParamList } from '@/components/flow-node/biz_components/nodeOptionDialog/node-option-utils'
export default {
  props: {
    title: {
      type: String,
      default: '目标数据'
    },
    data: {
      type: [Array],
      default: () => []
    },
    treeDataProps: {
      type: Object,
      default: () => ({ children: 'childrenList' })
    },
    mode: {
      type: String,
      default: 'edit'
    }
  },
  data() {
    return {
      filterText: null,
      treeData: [],
      DataTypeEnum: []
    }
  },
  watch: {
    data: {
      async handler(nV) {
        if (!nV) {
          this.treeData = []
        } else if (_typeof(nV) === 'array') {
          [this.DataTypeEnum] = await this.getDicts(['DataTypeEnum'])
          this.treeData = formatterParamList(deepClone(nV), this.DataTypeEnum)
        }
      },
      immediate: true
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),

    // 筛选树数据
    filterTreeData(v) {
      this.$refs.tree.filter(v)
    },
    rightClick(event, treeNode, node, $node) {
      this.$emit('rightClick', treeNode)
    },
    onCopy(v, c, b, d) {
      console.log('copy', v, c, b, d)
    },
    onError(e) {
      console.log('err', e)
    },
    filterNode(value, data) {
      if (!value) return true
      const paramName = data.paramName || data.fieldName || data.label
      return paramName.indexOf(value) !== -1
    }
  }
}
</script>

<style lang="scss" scoped>
.box-card {
  height: 200px;
  overflow: auto;
  margin-top: 10px;
}
.node-select {
  width: 150px;
}

.card-title{
  display: flex;
  align-items: center;
  .title-text{
    padding-right: 10px;
  }
  .filter-input{
    width: 150px;
    margin-left: 10px;
  }
}
</style>
