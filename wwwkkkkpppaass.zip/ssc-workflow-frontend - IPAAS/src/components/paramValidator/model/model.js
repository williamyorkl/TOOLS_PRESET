// 行参数
export class RowParam {
  constructor({ addByUser = false }) {
    this.dataType = null // 数据类型
    this.destName = null // 目标字段
    this.funcData = [] // 函数
    this.referenceType = null // 赋值类型
    this.scriptData = null // 脚本
    this.sourceName = null // 取值参数路径名
    this.sourcePos = null // 取值位置
    this.addByUser = addByUser // 是否为用户手动添加
  }
}
