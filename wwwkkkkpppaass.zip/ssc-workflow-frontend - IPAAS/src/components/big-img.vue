<template>
    <!-- 过渡动画 -->
    <transition name="fade">
        <div class="img-view" @click="bigImg">
            <!-- 遮罩层 -->
            <div @touchmove.prevent class="img-layer"></div>
            <div class="img">
                <img :src="imgSrc">
            </div>
        </div>
    </transition>
</template>
<script>
export default {
  name: 'BigImg',
  props: ['imgSrc'],
  methods: {
    bigImg() {
      // 发送事件
      this.$emit('clickit')
    }
  }
}
</script>
<style scoped lang="scss">
/*动画*/
// .fade-enter-active,
// .fade-leave-active {
//     transition: all .2s linear;
//     transform: translate3D(0, 0, 0);
// }

// .fade-enter,
// .fade-leave-active {
//     transform: translate3D(100%, 0, 0);
// }

/* bigimg */

.img-view {
    position: relative;
    width: 100%;
}

/*遮罩层样式*/
.img-view .img-layer {
    position: fixed;
    z-index: 2005;
    top: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.7);
    width: 100%;
    height: 100%;
    overflow: hidden;
}

/*不限制图片大小，实现居中*/
.img-view .img {
  width: 100%;
  img {
    max-width: 100%;
    max-height: 100%;
    position: fixed;
    left: 0px;
    right: 0;
    top: 30px;
    bottom: 0;
    margin: auto;
    z-index: 2006;
  }
}
</style>
