// const FILE_URL = "http://at.alicdn.com/t/font_2489955_pbvl03mwoy.css"
const FILE_URL = 'http://at.alicdn.com/t/font_1050521_8fdb0x8mwm4.css'
const xhr = new XMLHttpRequest()
let icons = []
xhr.open('GET', FILE_URL)
xhr.onreadystatechange = function () {
  if (xhr.readyState === 4 && xhr.status === 200) {
    console.log(xhr.responseText)
    icons = getExecStrs(xhr.responseText).sort()
  }
}
xhr.send()

function getExecStrs(str) {
  const reg = /icon\-(.+?)\:/g
  const list = []
  let result = null
  do {
    result = reg.exec(str)
    result && list.push(result[1])
  } while (result)
  return list
}

export default icons
