// 1：每分 2：每时  3：每天 4：每周 5：每月 6：每年 7：cron
function geneDay() {
  const arr = []
  for (let i = 0; i < 31; i++) {
    arr.push({ value: i + 1, label: i + 1 > 9 ? i + 1 : '0' + (i + 1) })
  }
  return arr
}

function geneHour() {
  const arr = []
  for (let i = 0; i < 24; i++) {
    arr.push({ value: i, label: i > 9 ? i : '0' + i })
  }
  return arr
}

function geneMinute() {
  const arr = []
  for (let i = 0; i < 60; i++) {
    arr.push({ value: i, label: i > 9 ? i : '0' + i })
  }
  return arr
}

export const options = {
  month: [
    { value: 1, label: '1' },
    { value: 2, label: '2' },
    { value: 3, label: '3' },
    { value: 4, label: '4' },
    { value: 5, label: '5' },
    { value: 6, label: '6' },
    { value: 7, label: '7' },
    { value: 8, label: '8' },
    { value: 9, label: '8' },
    { value: 10, label: '10' },
    { value: 11, label: '11' },
    { value: 12, label: '12' }
  ],
  day: geneDay(),
  hour: geneHour(),
  weekDay: [
    { value: 1, label: '一' },
    { value: 2, label: '二' },
    { value: 3, label: '三' },
    { value: 4, label: '四' },
    { value: 5, label: '五' },
    { value: 6, label: '六' },
    { value: 7, label: '日' }
  ],
  minute: geneMinute()
}
