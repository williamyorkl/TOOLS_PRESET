<template>
  <el-row :gutter="10">
    <!-- type: 1-7 -->
    <template v-if="type > 1 && type < 7">
      <!-- type === 6： 年 -->
      <template v-if="type >= 6">
        <el-col :span="4">
          <el-form-item label="" prop="basicTaskDto.executeTimeMap.month" labelWidth="0">
            <el-select v-model="timeMap.month" :disabled="cpDisabled">
              <el-option v-for="item in options.month" :key="item.value" :value="item.value" :label="item.label" />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="1">月</el-col>
      </template>
      <!-- type === 5： 月 -->
      <template v-if="type >= 5">
        <el-col :span="4" v-if="type >= 5">
          <el-form-item label="" prop="basicTaskDto.executeTimeMap.day" labelWidth="0">
            <el-select v-model="timeMap.day" :disabled="cpDisabled">
              <el-option v-for="item in options.day" :key="item.value" :value="item.value" :label="item.label" />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="1">日</el-col>
      </template>
      <!-- type === 4： 周 -->
      <template v-if="type === 4">
        <el-col :span="1">周</el-col>
        <el-col :span="4" v-if="type === 4">
          <el-form-item label="" prop="basicTaskDto.executeTimeMap.week" labelWidth="0">
            <el-select v-model="timeMap.week" :disabled="cpDisabled">
              <el-option v-for="item in options.weekDay" :key="item.value" :value="item.value" :label="item.label" />
            </el-select>
          </el-form-item>
        </el-col>
      </template>
      <template v-if="type >= 3">
        <el-col :span="4" v-if="type >= 3">
          <el-form-item label="" prop="basicTaskDto.executeTimeMap.hour" labelWidth="0">
            <el-select v-model="timeMap.hour" :disabled="cpDisabled">
              <el-option v-for="item in options.hour" :key="item.value" :value="item.value" :label="item.label" />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="1">时</el-col>
      </template>
      <template v-if="type >= 2">
        <el-col :span="4" v-if="type >= 2">
          <el-form-item label="" prop="basicTaskDto.executeTimeMap.minute" labelWidth="0">
            <el-select v-model="timeMap.minute" :disabled="cpDisabled">
              <el-option v-for="item in options.minute" :key="item.value" :value="item.value" :label="item.label" />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="1">分</el-col>
      </template>
    </template>
  </el-row>
</template>

<script>
import { options } from './option'
export default {
  name: 'McTime',
  props: {
    type: {
      type: Number,
      validator: (value) => [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].indexOf(value) !== -1,
      default: null
    },
    timeMap: {
      default: () => ({}),
      type: Object
    },
    formData: {
      type: Object,
      required: true
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  watch: {
    timeMap(nV) {
      console.log('change', nV)
    }
  },
  computed: {
    cpDisabled() {
      return this.disabled
    }
  },
  data() {
    return {
      options
    }
  }
}
</script>

<style>
</style>
