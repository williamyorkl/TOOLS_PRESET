
<template>
  <el-button @click="handleExport()">导出</el-button>
</template>
<script>
import Export from 'api/export'
import ExportDialog from './exportDialog'
export default {
  name: 'EcExportBtn',
  props: {
    getDataUrl: {
      type: [String],
      default: ''
    },
    hasData: {
      type: [Number],
      default: ''
    },
    query: {
      type: [Object],
      default: ''
    },
    methodWay: {
      type: [String],
      default: 'GET'
    },
    taskType: {
      type: [String],
      default: ''
    }
  },
  data() {
    return {

    }
  },
  methods: {
    handleExport() {
      console.log(this.query)
      if (!this.hasData) {
        this.$message.error('当前查询条件下没有数据，请更改查询条件后再进行导出')
        return
      }
      const url = this.getDataUrl
      console.log(url)
      if (this.query.pageIndex != undefined) delete this.query.pageIndex
      if (this.query.pageSize != undefined) delete this.query.pageSize
      const param = {
        taskType: this.taskType,
        query: this.query
      }
      Export.begin(param, url, this.methodWay).then(res => {
        if (res.success) {
          // 打开导出进度弹窗
          this.$simpleModalService.push({
            title: '导出',
            width: '30%',
            body: ExportDialog,
            props: {
              taskId: res.data
            },
            callback: function () {

            }
          })
        } else {
          this.$message.warning(res.errorMSG || res.errMsg)
        }
      })
    }
  }
}
</script>
<style>

</style>
