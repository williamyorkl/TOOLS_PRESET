<template>
    <div class="dialog-container">
      <div >
        <p>{{title}}</p>
        <el-progress :text-inside="true" :stroke-width="18" :percentage="percentage"></el-progress>
      </div>
    <div class="btnWrap" >
      <el-button type="primary" :disabled="!success" @click="handleDownFile">下载</el-button>
    </div>
  </div>
</template>
<script>
import Export from 'api/export'
export default {
  props: ['props'],
  data() {
    return {
      title: '',
      taskId: '',
      percentage: 0,
      idMap: {},
      success: false,
      exportUrl: '',
      id: ''
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    handleDownFile() {
      // 点击下载
      const a = document.createElement('a')
      const href = ('/dataexporter-server/MainController/download/' + this.id)
      a.href = href
      a.click()
    },
    init() {
      if (this.props && this.props.taskId) {
        this.taskId = this.props.taskId
        this.getFileDealStatus(this.taskId, result => {
          if (result.data.status === 2) {
            this.title = '导出成功'
            this.exportUrl = result.data.fileUrl
            this.id = result.data.id
            return this.success = true
          } else {
            // 异常的处理
            this.$message.warning(result.errorMsg || '导出异常')
            return this.$simpleModalService.pop()
          }
        })
      }
    },
    getFileDealStatus(id, callback) {
      if (!this.idMap[id]) {
        this.idMap[id] = {}
      }
      Export.getExportStatus(id).then(res => {
        const _this = this
        if (!res.success) {
          this.$message.warning(res.errorMsg || res.errMsg)
          return
        }
        if (!res.data) {
          return this.$message.warning('后端返回格式异常')
        }
        switch (res.data.status) {
          case 0:
            this.title = '正在导出'
            this.percentage += ~~(2 * Math.random())
            if (this.percentage > 80) {
              this.percentage = 80
            }
            return this.idMap[id].timer = setTimeout(function() {
              return _this.getFileDealStatus(id, callback)
            }, 1000)
          case 1:
            this.title = '正在处理'
            this.percentage += ~~(10 * Math.random())
            if (this.percentage > 80) {
              this.percentage = 80
            }
            return this.idMap[id].timer = setTimeout(function() {
              return _this.getFileDealStatus(id, callback)
            }, 1000)
          case 2:
            this.percentage = 100
            return callback && callback(res)
          case -1:
            this.percentage += ~~(10 * Math.random())
            if (this.percentage > 80) {
              this.percentage = 80
            }
            return this.idMap[id].timer = setTimeout(function() {
              _this.getFileDealStatus(id, callback)
            }, 1000)
          case -2:
            return callback && callback(res)
          case -3:
            return callback && callback(res)
        }
      })
    },
    cancel() {
      this.$simpleModalService.pop()
    }
  }
}
</script>
<style></style>
