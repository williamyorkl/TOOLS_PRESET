<template>
  <span>{{label}}</span>
</template>
<script>
import ddModel from 'api/base/dd'
export default {
  name: 'ecDdLabel',
  data() {
    return {
      label: ''
    }
  },
  props: ['dictKey', 'value'],
  mounted() {
    this.getLabel()
  },
  methods: {
    getLabel() {
      this.$nextTick(() => {
        ddModel.getValueLabel(this.dictKey, this.value).then((res) => {
          this.label = res
        })
      })
    }
  },
  watch: {
    value() {
      this.getLabel()
    }
  }
}
</script>
