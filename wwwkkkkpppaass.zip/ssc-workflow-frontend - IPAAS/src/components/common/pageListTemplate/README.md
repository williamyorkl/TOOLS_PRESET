## 列表模板生成使用说明


### 注意事项
此组件已经全局注册，<page-list-template></page-list-template>

### props

option: {
  type: Object,
  default() {
    return {
      queryBar: {    // querybar配置，具体查看全局组件querybar
        labelWidth: 80,
        defaultQuery: {},
        list: [
          {
            label: "时间范围",
            queryType: "dateRange",
            list: [
              {
                key: "payTimeStart",
                type: "datetime"
              },
              {
                key: "payTimeEnd",
                type: "datetime"
              }
            ]
          },
          {
            label: '地区',
            queryType: 'areaCascader',
            areaCascaderKeys: ['receiverProvince', 'receiverCity'],
            clearable: true
          },
          {
            label: '平台/店铺',
            queryType: 'platformAndShop',
            list: [
              {
                key: 'platformId',
              },
              {
                key: 'shopId',
              },
            ]
          },
          {
            key: "skuId",
            label: "商品编码",
            queryType: "input"
          },
        ],
        query(query) {
          console.log('query', query)
        },
        reset() {
          console.log('reset')
        }
      },
      commonBtn: [  // 操作的按钮列表，eg：导出 导入等功能
        {
          type: 'primary',
          text: 'btn',
          click() {
            console.log('click')
          }
        },
        {
          type: 'default',
          text: 'btn',
          click() {
            console.log('click')
          }
        }
      ],
      tableOption: {   // 表格配置
        maxHeight: 600,
        loading: false,
        tableData: [
          {
            platformName: 'pingtai',
            shopName: 'shop',
            contactName: 'contactName',
            skuName: 'skuName'
          }
        ],
        columns: [  // 表格列配置  render函数参数h代渲染函数 具体用法参照 vue渲染函数
          {
            prop: 'platformName',
            label: '平台',
            align: 'center',
          },
          {
            prop: 'shopName',
            label: '店铺',
            align: 'center',
            render(h, scope){
              console.log(scope)
              return h('span', null, scope.row.shopName)
            },
          },
          {
            prop: 'contactName',
            label: '联系人',
            align: 'center',
          },
          {
            prop: 'skuName',
            label: '商品名',
            align: 'center',
          },
        ]
      },
      pagination: {  //  分页的相关配置
        handleSizeChange(size) {},
        handleCurrentChange(page) {},
        pageSizes: [10, 30, 50, 100],
        pageSize: 30,
        pageIndex: 2,
        recordCount: 200,
        layout: 'total, sizes, prev, pager, next, jumper'
      }
    }
  }
}
