
<script>
import EcQuerybar from '../querybar'
export default {
  name: 'pageListTemplate',
  components: { EcQuerybar },
  props: {
    option: {
      type: Object,
      default() {
        return {
          queryBar: {
            labelWidth: 80,
            defaultQuery: {},
            list: [
              {
                label: '时间范围',
                queryType: 'dateRange',
                list: [
                  {
                    key: 'payTimeStart',
                    type: 'datetime'
                  },
                  {
                    key: 'payTimeEnd',
                    type: 'datetime'
                  }
                ]
              },
              {
                label: '地区',
                queryType: 'areaCascader',
                areaCascaderKeys: ['receiverProvince', 'receiverCity'],
                clearable: true
              },
              {
                label: '平台/店铺',
                queryType: 'platformAndShop',
                list: [
                  {
                    key: 'platformId'
                  },
                  {
                    key: 'shopId'
                  }
                ]
              },
              {
                key: 'skuId',
                label: '商品编码',
                queryType: 'input'
              }
            ],
            query(query) {
              console.log('query', query)
            },
            reset() {

            }
          },
          commonBtn: [
            {
              type: 'primary',
              text: 'btn',
              click() {
                console.log('click')
              }
            },
            {
              type: 'default',
              text: 'btn',
              click() {
                console.log('click')
              }
            }
          ],
          tableOption: {
            maxHeight: 600,
            loading: false,
            tableData: [
              {
                platformName: 'pingtai',
                shopName: 'shop',
                contactName: 'contactName',
                skuName: 'skuName'
              }
            ],
            columns: [
              {
                prop: 'platformName',
                label: '平台',
                align: 'center'
              },
              {
                prop: 'shopName',
                label: '店铺',
                align: 'center',
                render(h, scope) {
                  return h('span', null, scope.row.shopName)
                }
              },
              {
                prop: 'contactName',
                label: '联系人',
                align: 'center'
              },
              {
                prop: 'skuName',
                label: '商品名',
                align: 'center'
              }
            ]
          },
          pagination: {
            handleSizeChange(size) {},
            handleCurrentChange(page) {},
            pageSizes: [10, 30, 50, 100],
            pageSize: 30,
            pageIndex: 2,
            recordCount: 200,
            layout: 'total, sizes, prev, pager, next, jumper'
          }
        }
      }
    }
  },
  data() {
    return {}
  },
  render(h) {
    const { queryBar, commonBtn, tableOption, pagination } = this.option
    return (
      <div class="common-container">
        <div class="apply-content">
          <mc-query query-list={queryBar.list} defaultQuery={queryBar.defaultQuery} onQuery={queryBar.query} onReset={queryBar.reset} labelWidth={queryBar.labelWidth}></mc-query>
          <div class="common-btns-container">
            {
              commonBtn.map(btn => (
                <el-button type={btn.type} onClick={btn.click}>{btn.text}</el-button>
              ))
            }
          </div>
          <div class="common-table-container">
            <el-table data={tableOption.tableData} style="width:100%" border max-height={tableOption.maxHeight} v-loading={tableOption.loading}>
              {tableOption.columns.map(col => {
                return (
                  <el-table-column type={col.type} align={col.align || 'left'} label={col.label} prop={col.prop} formatter={ col.render ? (row, column, cell) => col.render(h, { row, column, cell }) : null}></el-table-column>
                )
              })}
            </el-table>
          </div>
          <div class="pagination-container">
            <el-pagination on-size-change={pagination.handleSizeChange} on-current-change={pagination.handleCurrentChange}
              currentPage={pagination.pageIndex} pageSizes={pagination.pageSizes} pageSize={pagination.pageSize}
              layout={pagination.layout} total={pagination.recordCount} background>
            </el-pagination>
          </div>
        </div>
      </div>
    )
  }
}
</script>
