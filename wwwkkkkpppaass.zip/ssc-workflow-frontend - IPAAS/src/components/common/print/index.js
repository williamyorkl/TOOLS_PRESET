
export default {
  methods: {
    /**
     * @description 打印方法
     * @param {document} target  要打印的iframe
     * @param {String} template  要打印的模板
     */
    publishPrint (target, template) {
      var doc = target.contentWindow.document
      doc.body.innerText = ''// 清空之前保存内容
      doc.write(template)
      doc.close()
      target.contentWindow.focus()
      target.contentWindow.print()
    },
    listenPrint(yes, no) {
      if (window.matchMedia) {
        var mediaQueryList = window.matchMedia('print')
        mediaQueryList.addListener(function(mql) {
          if (mql.matches) {
            if (typeof yes == 'function') {
              yes()
            }
          } else {
            if (typeof yes == 'function') {
              no()
            }
          }
        })
      } else {
        console.log('浏览器不支持监听')
      }
    }
  }
}
