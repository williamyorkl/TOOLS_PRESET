
export default {
  methods: {
    /**
     * @description 获取当前表单数量字段总额
     * @param {Number} total 计算总数
     * @param {Object} item  当前项目
     * @returns total
     */
    getAllCnt (total, item) {
      return total + item.itemCnt
    },
    /**
     * @description 绘制拣货表单
     * @param {Array} arr 拣货数据数组
     * @returns  {String} template:返回模板
     */
    pickPatting (arr) {
      var fragment_subTitle = '<h2 style="text-align: center">' + '拣货单' + '</h2>'
      var fragment_line = '<hr/>'
      var template = ''
      var allPage = this.findPage(arr)
      var allCnt = this.deepFlatten(arr).reduce(this.getAllCnt, 0)
      var currentPage = 0
      for (const key1 in arr) {
        for (const key2 in arr[key1].contents) {
          ++currentPage
          var fragment_title = '<div style="display:block;' + (currentPage !== allPage ? 'page-break-after:always' : '') + '"><h2 style="text-align: center">' + '有限公司' + '</h2>'
          const infos = arr[key1].contents[key2].data.pickDetailInfos
          var pickTime = arr[key1].contents[key2].data.pickTime// 制表时间
          var currentCnt = arr[key1].contents[key2].data.pickExtInfo.totalItemCnt
          var fragment_option = '<div style="padding:20px 0 ;width:100%"><span style="display:inline-block;width:50%;text-align:left">拣货单单号：' +
            this.currentPrintTarget.pickId + '</span><span style="padding-right:20px">制单时间：' +
            new Date(pickTime).format('yyyy-MM-dd hh:mm:ss') + '</span></div>'
          var fragement_table_header = '<table  style="text-align: center;width:100%;border-collapse: collapse;margin-top:20px" border="1"><thead><tr><th>商品编码</th><th>商品名称</th><th>数量</th><th>体积（dm3）</th><th>重量（kg）</th><th>实际拣货量</th></thead>'
          var fragement_table_body = '<tbody>'
          var fragment_footer = '<div style="padding:20px 0 ;width:100%"><span style="display:inline-block;width:33%;text-align:left">页面：' + currentPage + '/' + allPage + '</span><span style="display:inline-block;width:33%;text-align:left">本页合计：' + currentCnt + '</span><span style="display:inline-block;width:33%;text-align:left">总计：' + allCnt + '</span></div></div>'
          infos.forEach(v => { v.weight = v.itemCnt * v.grossWeight; v.allVolume = v.itemCnt * v.volume })
          for (const key3 in infos) {
            var fragement_table_body = fragement_table_body + '<tr><td>' + infos[key3].itemId + '</td><td>' + infos[key3].itemName + '</td><td>' + infos[key3].itemCnt + '</td><td>' + infos[key3].allVolume + '</td><td>' + infos[key3].weight + '</td><td></td><tr>'
          }
          fragement_table_body = fragement_table_body + '</tbody></table>'
          template = template + fragment_title + fragment_subTitle + fragment_line + fragment_option + fragement_table_header + fragement_table_body + fragment_footer
          fragement_table_body = '<tbody>'
        }
      }
      return template
    },
    /**
     * @description 绘制配货表单
     * @param {Array} arr 配货数据数组
     * @returns  {String} template:返回模板
     */
    packPatting (arr) {
      var fragment_subTitle = '<h2 style="text-align: center">' + '配货清单' + '</h2>'
      var fragment_line = '<hr/>'
      var template = ''
      var allPage = this.findPage(arr)
      var allCnt = this.deepFlatten(arr).reduce(this.getAllCnt, 0)
      var currentPage = 0
      for (const key1 in arr) {
        for (const key2 in arr[key1].contents) {
          ++currentPage
          var fragment_title = '<div style="display:block;' + (currentPage !== allPage ? 'page-break-after:always' : '') + ' "><h2 style="text-align: center">' + '有限公司' + '</h2>'
          const infos = arr[key1].contents[key2].data.pickDetailInfos
          var pickTime = arr[key1].contents[key2].data.pickTime// 制表时间
          var currentCnt = arr[key1].contents[key2].data.pickExtInfo.totalItemCnt
          var fragment_option = '<div style="padding:10px 0 ;width:100%"><span style="display:inline-block;width:50%;text-align:left;">配货主单号：' +
            infos[0].packingId + '</span><span style="width:50%;padding-right:20px">关联订单号：' +
            arr[key1].contents[key2].data.pickExtInfo.sourceOrderId + '</span></div><div style="padding:10px 0"><span style="width:50%;padding-right:30px">拣货单号：' +
            arr[key1].contents[key2].data.pickId + '</span><span style="width:50%;padding-left:80px">收货人：' +
            arr[key1].contents[key2].data.pickExtInfo.receiverName + '</span></div><div style="padding:10px 0"><span style="width:50%;padding-right:20px">收货地址：' +
            arr[key1].contents[key2].data.pickExtInfo.receiverAddrDetail + '</span></div>'
          var fragement_table_header = '<table  style="text-align: center;width:100%;border-collapse: collapse;" border="1"><thead><tr><th>配货单号</th><th>商品编号</th><th>商品名称</th><th>数量</th><th>体积（dm3）</th><th>重量（kg）</th><th>实际拣货量</th></thead>'
          var fragement_table_body = '<tbody>'
          var fragment_footer = '<div style="padding:20px 0 ;width:100%"><span style="display:inline-block;width:33%;text-align:left">页面：' +
            currentPage + '/' + allPage + '</span><span style="display:inline-block;width:33%;text-align:left">本页合计：' +
            currentCnt + '</span><span style="display:inline-block;width:33%;text-align:left">总计：' +
            allCnt + '</span></div></div>'
          infos.forEach(v => { v.weight = v.itemCnt * v.grossWeight; v.allVolume = v.itemCnt * v.volume })
          for (const key3 in infos) {
            var fragement_table_body = fragement_table_body + '<tr><td>' +
              infos[0].packingId + '</td><td>' +
              infos[key3].itemId + '</td><td>' +
              infos[key3].itemName + '</td><td>' +
              infos[key3].itemCnt + '</td><td>' +
              infos[key3].allVolume + '</td><td>' +
              infos[key3].weight + '</td><td></td><tr>'
          }
          fragement_table_body = fragement_table_body + '</tbody></table>'
          template = template +
            fragment_title +
            fragment_subTitle +
            fragment_line +
            fragment_option +
            fragement_table_header +
            fragement_table_body +
            fragment_footer
          fragement_table_body = '<tbody>'
        }
      }
      return template
    },
    /**
     * @description 把电子面单嵌入文档并且打印
     * @param {document} iframe 绘制容器
     * @param {Object} data 绘制数据 {imageUrl}
     */
    expressPatting (iframe, data) {
      var that = this
      var arr = []
      data.forEach(item => { arr.push(this.addPromise(item.imageUrl)) })
      var template = ''
      Promise.all(arr).then(reslove => {
        for (let i = 0; i < reslove.length; i++) {
          template = template + '<div style="page-break-before:always;page-break-after:always"><img src="' + reslove[i] + '" style="width:340.3px;height:431.01px" /></div>'
        }
        that.publishPrint(iframe, template)
      })
    },
    /**
     * @description 给每个图片加载添加onload监听
     * @param {String} url 图片路径
     * @returns Promise
     */
    addPromise (url) {
      return new Promise((reslove, reject) => {
        const img = new Image()
        img.src = url
        img.onload = () => {
          reslove(url)
        }
      })
    },
    /**
     *
     * @description 查找要打印数据的页数，一个data对象数据表示一页
     * @param {Array} arr 数据数组
     * @returns {Number} 返回页数
     */
    findPage (arr) {
      return [].concat(...arr.map(v => v.contents)).length
    },
    /**
     *
     * @description 将多层的打印数组降为所有item行单维数组
     * @param {Array} arr 数据数组
     * @returns 所有item行数据数组
     */
    deepFlatten (arr) {
      return [].concat(...arr.map(v => {
        if (Array.isArray(v.contents) || !!v.data) {
          return Array.isArray(v.contents) ? this.deepFlatten(v.contents) : this.deepFlatten(v.data.pickDetailInfos)
        } else {
          return v
        }
      }))
    }
  }
}
