<template>
  <div class="">
    <el-dialog class="xt-modal-dialog modal1" :visible.sync="dialogVisible" ref="dialog" :title="title" :width="width"
      :size="size || 'small'" @close="closeCallback" @open="openCallaback" :close-on-click-modal=false
      :custom-class="customClass">
      <div class="el-dialog__headerbtn" @click="cancelHandler">
        <i class="el-dialog__close el-icon el-icon-close"></i>
      </div>
      <body-page :props="props" :modal="_modalService" ref="body" />
      <span slot="footer" class="dialog-footer" v-if="cancel || confirm">
        <el-button @click="cancelHandler" v-if="cancel && cancel.length">{{cancel && cancel.length && cancel[0]}}
        </el-button>
        <el-button type="primary" @click="confirmHandler" v-if="confirm && confirm.length">
          {{confirm && confirm.length && confirm[0]}}</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<style>
/* .xt-modal-dialog .el-dialog__footer{
      padding: 0 0 20px;
    } */
.xt-modal-dialog .el-dialog--middle {
  width: 76%;
  min-width: 900px;
}

.xt-modal-dialog .el-dialog__body {
  padding-top: 0px;
  padding-bottom: 0px;
  overflow-y: auto;
}

.xt-modal-dialog .el-dialog__header {
  padding: 20px 10px 10px;
  min-height: 40px;
}

.xt-modal-dialog .el-dialog__headerbtn,
.el-pagination__rightwrapper {
  float: right;
  position: absolute;
  right: 10px;
  top: 10px;
}

.xt-modal-dialog.modal1 .el-dialog__header .el-dialog__headerbtn {
  display: none !important;
}
</style>

<script>
export default {
  name: 'xt-modal',
  props: {
    title: String,
    size: [String],
    width: String,
    cancel: Array,
    close: [Function],
    callback: [Function],
    customClass: [String],
    props: [Object],
    confirm: Array,
    _modalService: [Function, Object]
  },
  data: function () {
    return {
      isClickHeaderClose: true,
      dialogVisible: false
    }
  },
  computed: {
  },
  created() {
    console.log(this.width)
    console.log(this.title)
  },
  methods: {
    show: function () {
      this.dialogVisible = true
      this.$refs.dialog.open()
    },
    dismiss: function () {
      this.dialogVisible = false
      this.$refs.dialog.close()
      this.$el.remove()
      this.$destroy()
      if (this.callback) this.callback(this._modalService, this.$refs.body)
    },
    cancelHandler: function () {
      if (!this.cancel) {
        this.dismiss()
        if (this.close) this.close(this._modalService, this.$refs.body)
        return
      }
      this.isClickHeaderClose = false
      const cancelFn = (this.cancel && this.cancel.length && this.cancel[1])
      if (cancelFn) cancelFn(this._modalService, this.$refs.body)
    },
    confirmHandler: function () {
      this.isClickHeaderClose = false
      const confirmFn = (this.confirm && this.confirm.length && this.confirm[1])
      console.log(this.$refs)
      if (confirmFn) confirmFn(this._modalService, this.$refs.body)
    },
    closeCallback: function () {
      if (!this.isClickHeaderClose) return
      this.cancelHandler(this._modalService, this.$refs.body)
      if (this.close) {
        this.close(this._modalService, this.$refs.body)
      }
    },
    openCallaback: function () { }
  }
}

</script>
