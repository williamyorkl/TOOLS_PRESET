import Modal from './Modal'
import Vue from 'vue'
import ElementUI from 'element-ui'

Vue.use(ElementUI)

const ModalConstructor = Vue.extend(Modal)

const instances = []

class ModalService {
  static push(options, container) {
    const modal = new ModalConstructor({
      propsData: {
        title: options.title || '',
        width: options.width || '50%',
        cancel: options.cancel || undefined,
        props: options.props,
        close: options.close || undefined,
        callback: options.callback || undefined,
        size: options.size || undefined,
        confirm: options.confirm || undefined,
        _modalService: ModalService,
        customClass: options.customClass || undefined
      },
      components: {
        'body-page': options.body || null
      }
    })
    const modalVm = modal.$mount()
    if (!container) {
      container = document.body
    }
    container.appendChild(modalVm.$el)
    modalVm.show()

    instances.push(modalVm)
  }

  static pop() {
    if (instances.length) {
      const modelVm = instances.pop()
      modelVm.dismiss()
    }
  }
}

export default ModalService
