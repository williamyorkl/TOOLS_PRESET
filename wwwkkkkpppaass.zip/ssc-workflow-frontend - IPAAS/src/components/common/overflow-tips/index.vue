/*
示例：<overflow-tips :content="contentText" :line="2"></overflow-tips>
content：文本内容
line：显示行数，默认1
 */
<template>
  <el-tooltip :content="content" placement="top" :disabled="!flag">
    <div ref="container" :class="['overflow-container', 'ellipsis' + line]">
      <span ref="content">{{content}}</span>
    </div>
  </el-tooltip>
</template>

<script>
export default {
  name: 'overflow-tips',
  data () {
    return {
      flag: false
    }
  },
  mounted () {
    this.checkOverflow()
  },
  updated () {
    this.checkOverflow()
  },
  methods: {
    checkOverflow () {
      if (!this.noTips) {
        if (this.line === 1) {
          if (this.$refs.container.offsetWidth < this.$refs.content.offsetWidth) {
            this.flag = true
          }
        } else {
          if (this.$refs.container.offsetHeight < this.$refs.content.offsetHeight) {
            this.flag = true
          }
        }
      }
    }
  },
  props: {
    line: {
      type: Number,
      default: 1
    },
    content: {
      type: String,
      default: ''
    },
    noTips: {
      type: Boolean,
      default: false
    }
  }
}
</script>

<style lang="scss" scoped>
  .overflow-container {
    &.ellipsis1{
      overflow: hidden;
      text-overflow: ellipsis; //文本溢出显示省略号
      white-space: nowrap; //文本不会换行
    }
    &.ellipsis2{
      min-height: 16.8px;
      overflow: hidden;
      word-break: break-all;
      text-overflow:ellipsis; //文本溢出显示省略号
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
    }
    &.ellipsis3{
      min-height: 16.8px;
      overflow: hidden;
      word-break: break-all;
      text-overflow:ellipsis; //文本溢出显示省略号
      display: -webkit-box;
      -webkit-line-clamp: 3;
      -webkit-box-orient: vertical;
    }
  }
</style>
