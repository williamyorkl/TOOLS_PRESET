<template>
  <el-select v-model="currentVal" :placeholder="p" :filterable="filterable" :clearable="clearable" :disabled="disabled" :multiple="multiple" :collapse-tags="collapseTags" :popper-class="popperClass" :size="size" @focus="focus" @clear="clear" @change="change" @blur="blur">
    <el-option v-for="(item,index) in selectList" :key="index" :label="labelAddValue ? ((item.value || item[valueKey]) + '-' + (item.name || item[labelKey])) : (item.name || item[labelKey])" :value="item[valueKey] || item.value" @click.native="handleOptionClick(item)"></el-option>
  </el-select>
</template>
<script>
import ddModel from 'api/base/dd'

import {

  _getAllProvince

} from 'api/common/map'
import { mapState } from 'vuex'
export default {
  name: 'EcSelector',
  data() {
    return {
      currentVal: this.value,
      list: [],
      listMap: {}
    }
  },
  props: {
    value: {},
    departmentCode: {
      type: [Number, String],
      default: ''
    },
    midCategory: {
      type: [Number, String],
      default: ''
    },
    minCategory: {
      type: [Number, String],
      default: ''
    },
    placeholder: {
      type: String
    },
    options: {
      type: Array,
      default() {
        return []
      }
    },
    multiple: {
      type: Boolean,
      default: false
    },
    collapseTags: {
      type: Boolean,
      default: false
    },
    popperClass: {
      type: String
    },
    dictType: {
      type: String
    },
    valueKey: {
      type: String,
      default: 'value'
    },
    labelKey: {
      type: String,
      default: 'name'
    },
    clearable: {
      type: Boolean,
      default: true
    },
    filterable: {
      type: Boolean,
      default: true
    },
    disabled: {
      type: Boolean,
      default: false
    },
    async: {
      type: Boolean,
      default: false
    },
    labelAddValue: {
      // 显示为id-name
      type: Boolean,
      default: false
    },
    deleteList: {
      type: Array,
      default() {
        return []
      }
    },
    extendParams: {
      type: Object,
      default() {
        return {}
      }
    },
    size: {
      type: String,
      default: 'small'
    },
    defaultFirst: {
      // 默认值，第一个
      type: Boolean,
      default: false
    }
  },
  created() {
    if (this.dictType !== 'midCategory' && this.dictType !== 'minCategory') {
      !this.async && this.getDdValues()
    }
  },
  methods: {
    handleOptionClick(option) {
      this.$emit('option-click', option)
      this.$emit('optionClick', option)
    },
    focus(e) {
      if (
        this.dictType === 'office' ||
        this.dictType === 'midCategory_assembly' ||
        this.dictType === 'midCusCategory'
      ) {
        this.getDdValues()
      } else {
        this.async && this.getDdValues()
      }
      this.$emit('focus', e)
    },
    blur(e) {
      this.$emit('blur', e)
    },
    clear() {
      this.$emit('clear', this.dictType)
    },
    change(val) {
      this.$emit('input', val)
      this.$emit(
        'change',
        {
          value: val,
          key: this.dictType,
          item: this.listMap[val]
        },
        this.extendParams
      )
    },
    getDdValues() {
      if (this.dictType) {
        const key = this.dictType
        let promiseFun
        switch (key) {
          case 'allProvince':
            promiseFun = _getAllProvince(1, 'province')
            break

          default:
            promiseFun = ddModel.getValues(key)
        }
        promiseFun.then(res => {
          if (res === 'loading') {
            setTimeout(() => {
              this.getDdValues()
            }, 1000)
          } else {
            this.list = res
            if (this.defaultFirst) {
              this.currentVal = this.list && this.list.length && this.list[0][this.valueKey]
              this.change(this.currentVal)
            }
          }
        })
      }
    }
  },
  computed: {

    selectList() {
      const selectList = this.options.length ? this.options : this.list
      const deleteList = this.deleteList.map(i => i + '')
      return selectList.filter(i => {
        this.listMap[i[this.valueKey]] = i
        return deleteList.indexOf(i[this.valueKey]) === -1
      })
    },
    p() {
      let placeholder = ''
      if (this.list.length) {
        placeholder = '请选择' + (this.list[0].desc || '')
      }
      return this.placeholder || placeholder || '请选择'
    }
  },
  watch: {
    value(value) {
      this.currentVal = value
    },
    currentVal(value) {
      this.$emit('input', value)
    },
    dictType(val) {
      if (val) {
        this.getDdValues()
      }
    }
  }
}
</script>
