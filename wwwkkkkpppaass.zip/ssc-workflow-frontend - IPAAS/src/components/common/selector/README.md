## selector组件使用说明
### 注意事项
这个组件已经全局注册
### Attributes

参数 | 说明 | 类型 | 可选值 | 默认值
--- | --- | --- | --- | ---
v-model | value值 | String | — | -
options | 不用数据字典时的下拉列表 | Array | - | []
placeholder | 输入提示 | String | - | 请选择(数据字典不用传)
clearable | 是否可以清除 | Boolean | true  elementUI select原属性
multiple | 多选 | Boolean | false  elementUI select原属性
collapse-tags | 多选时候文字显示 | Boolean | - | true  elementUI select原属性
async | 数据字典是否点击才加载列表 | Boolean | - | true
value-key | 下拉获取值的字段 | String | - | value
label-key | 下拉显示值的字段 | String | - | name
dict-type | 数据字典的key | String | - | -
delete-list | 不显示出来的value值 | Array | - | []
### Events

事件名称 | 说明 | 回调参数
---|--- | --- |
change | 选择内容改变时触发 | 对象 - 当前值，数据字典的key，当前对象
option-click | 选项点击事件触发 | option

### 使用示例 

```vue
<template>
  <div>
    <ec-selector v-model="value" dict-type="shop"></ec-selector>
    <ec-selector v-model="value1" options="list" label-key="label"></ec-selector>
  </div>
</template>
<script>

  export default {
    name: 'ec-selector-demo',
    data () {
      return {
        value: '',
        value1: '',
        list: [
          {
            value: 1,
            label: '测试'
          }
        ]
      }
    }
  }
</script>

```
