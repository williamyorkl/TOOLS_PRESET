<script>
import { TableColumn } from 'element-ui'

// renderCell 函数，类型可扩展
const renderCell = {
  slots: function (h, data) {
    // 接受传入的renderCell函数
    const renderCell = () => {
      return this.renderCell ? this.renderCell(data, h) : ''
    }
    return this.showOverflowTooltip || this.showTooltipWhenOverflow
      ? <div class="cell el-tooltip" style={{ width: (data.column.realWidth || data.column.width) + 'px' }}>{ renderCell(h, data) }</div>
      : <div class="cell">{ renderCell(h, data) }</div>
  }
}

export default {
  name: 'EcColumn',
  extends: TableColumn, // 继承TableColumn
  props: {
    cellType: {
      type: String
    },
    renderCell: {
      type: Function
    }
  },
  created () {
    if (renderCell[this.cellType]) { // 替换el-table-column的渲染方法
      this.columnConfig.renderCell = renderCell[this.cellType].bind(this)
    }
  }
}
</script>
