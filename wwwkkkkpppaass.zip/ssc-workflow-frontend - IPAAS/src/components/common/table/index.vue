<template lang="html">
  <div >
    <el-table :data="tableData" v-on="tableEvents" >
      <slot name="prepend"></slot>
      <ec-column
        v-for="(item, key) in staticColumns"
        v-if="item.hideColumn != true"
        :key="key + '_'"
        v-bind="item.props">
      </ec-column>
      <ec-column
        v-for="(item, key) in configColumns"
        v-if="columnValues.indexOf(item.props.termCode) > -1 && item.hideColumn != true"
        :key="key"
        v-bind="item.props">
      </ec-column>
      <slot></slot>
      <el-table-column width="40" :render-header="renderHeadIcon" fixed="right">
      </el-table-column>
    </el-table>

    <el-dialog
      width="630px"
      :visible.sync="dialogVisible"
      title="表格展示内容配置">

      <el-transfer
        filterable
        :titles="['待展示内容', '表格展示内容']"
        filter-placeholder="请输入名称"
        v-model="dialogColumnValues"
        :props="{
          key: 'key',
          label: 'label'
        }"
        :format="{
          noChecked: '${total}',
          hasChecked: '${checked}/${total}'
        }"
        :data="configColumns | getLabelAndCode">
      </el-transfer>

      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="saveConfig">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import EcColumn from './column'
import tableConfig from '@/api/common/tableConfig'
export default {
  name: 'EcTable',
  components: { EcColumn },
  data () {
    return {
      dialogVisible: false,
      dialogColumnValues: [], // 穿梭框勾选值
      columnValues: [], // 展示的列
      configColumns: [], // 可修改配置列
      staticColumns: [], // 固定配置列
      userName: window.localStorage.getItem('userName'), // 当前登录用户，作为缓存标识
      orginItemList: [] // 缓存服务器返回的
      // isLoadingData: false,
    }
  },
  filters: {
    getLabel (value) {
      return value.map(obj => {
        return {
          label: obj.props.label
        }
      })
    },
    getLabelAndCode(value) {
      return value.map(obj => {
        return {
          label: obj.props.label,
          key: obj.props.termCode
        }
      })
    }

  },
  props: {
    tableData: {
      type: Array
    }, // table数据
    tableEvents: {
      type: Object
    }, // table事件
    columnsConfig: {
      type: Array
    }, // 所有列数据
    tableType: {
      type: String
    } // table类型，用于缓存本地配置
  },
  computed: {
  },
  created () {
    this.getDefaultColumns()
  },
  methods: {
    emitLoadingStatus(type) {
      this.$emit('changeLoadStatus', type)
    },
    getDefaultColumns(callblack) {
      let temp = []
      const setDefaultFromConfig = (list) => {
        this.columnsConfig.map(obj => {
          if (obj.defaultColumn) {
            list.push(obj.props.termCode)
          }
        })
        this.columnValues = list.concat()
        this.emitLoadingStatus(false)
      }
      this.emitLoadingStatus(true)
      tableConfig.tempResultItemList(this.tableType).then(r => {
        const data = r.content
        if (data && data.resultItemVos && data.resultItemVos.length) {
          this.orginItemList = data.resultItemVos
          const enableList = data.resultItemVos.filter((item) => {
            return item.enable
          })
          temp = enableList.map((item) => {
            this.columnsConfig.map(obj => {
              if (item.termCode == obj.props.termCode) {
                // 使用数据库的字段名称
                obj.props.label = item.termName
              }
            })
            return item.termCode
          })
          this.columnValues = temp.concat()
          this.emitLoadingStatus(false)
        } else {
          setDefaultFromConfig(temp)
        }
      }).catch(r => {
        setDefaultFromConfig(temp)
      })
      this.columnsConfig.map(obj => {
        if (obj.staticColumn) {
          this.staticColumns.push(obj)
        } else {
          this.configColumns.push(obj)
        }
      })
    },
    renderHeadIcon (h, obj) { // 显示配置按钮
      return <el-button onClick={this.showConfig} style={{ fontSize: '16px', padding: '2px 0' }} size="mini" type="text" icon="el-icon-setting"></el-button>
    },
    saveConfig () { // 保存配置
      if (this.dialogColumnValues.length === 0) {
        this.$message.error('请至少选择一个展示内容')
        return false
      }
      this.columnValues = this.dialogColumnValues
      const paramList = []
      this.orginItemList.forEach(item => {
        if (this.columnValues.indexOf(item.termCode) > -1) {
          paramList.push(item.id)
        }
      })

      // console.log(this.orginItemList, this.dialogColumnValues)
      // let paramList = this.orginItemList.concat(this.dialogColumnValues).map((list) =>  list.id)
      // console.log(this.orginItemList, this.dialogColumnValues)
      //
      const params = {
        ids: paramList.join(',')
      }
      
      tableConfig.checkTempResultItemList(this.tableType, params).then(r => {
        this.dialogVisible = false
      })

      // window.localStorage.setItem('configTableColumns_' + this.tableType + this.userName, this.columnValues)
    },
    showConfig () { // 字段配置弹窗
      this.dialogVisible = true
      this.dialogColumnValues = this.columnValues.concat()
    }
  }
}
</script>

<style lang="css" scoped>
</style>
