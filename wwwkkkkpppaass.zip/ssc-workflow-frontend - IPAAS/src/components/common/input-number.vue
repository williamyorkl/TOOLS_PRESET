<template>
	<div class="el-input el-input--small">
		<input
			class="el-input__inner"
			v-model="currentValue"
      ref="input"
      @input="handleInput"
      @focus="handleFocus"
      @blur="handleBlur"
      @change="handleChange"
      v-bind="$props"
		/>
	</div>
</template>

<script>
import emitter from 'mixins/emitter.js'
export default {
  name: 'InputNumber',
  mixins: [emitter],
  data() {
    return {
      currentValue: this.value,
      focused: false
    }
  },
  props: {
    width: {
      type: String,
      default: '150px'
    },
    value: {

    },
    bit: {
      type: Number,
      default: 10
    },
    decimal: {
      type: Number,
      default: 2
    },
    type: {
	    type: String,
	    default: 'text'
	  },
	  placeholder: {
      type: String,
      default: '请输入'
	  },
	  validateEvent: {
    	type: Boolean,
    	default: true
    },
    disabled: {
		  type: Boolean,
      default: false
    },
  	name: {
  		type: String
  	}
  },
  methods: {
    handleChange(event) {
      this.$emit('change', event.target.value)
    },
    setCurrentValue(value) {
    	if (value === this.currentValue) return

	    this.currentValue = value
	    if (this.validateEvent) {
        this.dispatch('ElFormItem', 'el.form.change', [value])
      }
    },
    handleFocus(event) {
      this.focused = true
	    this.$emit('focus', event)
	  },
	  handleInput(event) {
      let value = event.target.value
      let val = +event.target.value
      if (typeof val === 'number' && val === val && val !== 0) {
        const numRe = /\d*\.\d{2}/
        const str = val + ''
        const match = str.match(numRe)
        val = match ? match[0] : value
        if (this.decimal === 0) {
          val = (+val).toFixed(0)
        }
        value = val
      }
      this.setCurrentValue(value)
      this.$emit('input', value)
	  },
    handleBlur(event) {
      this.focused = false
      this.$emit('blur', event)
      if (isNaN(this.value) && this.value !== '') {
      	this.$emit('input', '')
      }
      if (this.validateEvent) {
      	this.dispatch('ElFormItem', 'el.form.blur', [this.currentValue])
    	}
    }
  },
  watch: {
  	value(val, oldValue) {
    	this.setCurrentValue(val)
  	}
  }
}
</script>
