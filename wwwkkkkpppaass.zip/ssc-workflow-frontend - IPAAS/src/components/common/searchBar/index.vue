<template>
  <div class="search-bar">
    <el-form class="dynamic-form" onkeypress="return event.keyCode != 13;" :inline="config.inline" :model="value" :label-position="config.labelPosition" :label-width="config.labelWidth" :size='config.size' :status-icon="config.statusIcon">
      <el-row :gutter="20">
        <el-col :span="12" v-for="item in config.formItemList" :key="item.key">
          <search-item :item="item" :value="value[item.key]" @input="handleInput($event, item.key)" />
        </el-col>
      </el-row>
      <el-form-item>
        <div>
          <slot name="button"></slot>
        </div>
      </el-form-item>
    </el-form>

  </div>
</template>

<script>
import searchItem from './searchItem'
export default {
  name: 'SearchBar',
  components: {
    searchItem
  },
  props: {
    config: {
      type: Object,
      required: true
    },
    value: {
      type: Object,
      required: true
    }
  },

  data() {
    return {
      form: {}
    }
  },
  mounted() {
    this.setDefaultValue()
  },
  methods: {
    handleInput(val, key) {
      console.log(val, key, 9999)
      // 这里element-ui没有上报event，直接就是value了
      this.$emit('input', { ...this.value, [key]: val })
    },
    setDefaultValue() {
      const formData = { ...this.value }
      // 设置默认值
      this.config.formItemList.forEach((item) => {
        // 显示两个数组 在 key值不存在 而且在 type === date
        if (!item.key && item.type === 'date') {
          item.options.forEach(option => {
            formData[option.key] = option.value
          })
        }
        if (item.key && (formData[item.key] === undefined || formData[item.key] === null)) {
          formData[item.key] = item.value
        }
      })
      this.$emit('input', formData)
    }
  }
}
</script>

<style>
.dynamic-form {
  padding: 20px 0;
  border-bottom: 1px solid #ccc;
  margin-bottom: 10px;
}
</style>
