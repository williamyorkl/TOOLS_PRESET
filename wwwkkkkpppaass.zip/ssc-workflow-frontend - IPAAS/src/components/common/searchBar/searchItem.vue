<template>
  <!-- <el-row :gutter="20">
    <el-col :span="12"> -->
  <el-form-item :rules="item.Rules" :label="item.label" :prop="item.key">
    <el-input v-if="item.type==='input'" v-bind="$attrs" v-on="$listeners" :type="item.subtype"
      :placeholder="item.placeholder" :disabled="item.disable" :readonly="item.readonly" :autosize="item.autosize" :clearable="item.clearable">
    </el-input>
    <el-select v-else-if="item.type==='select'" v-bind="$attrs" :filterable="item.filterable" v-on="$listeners"
      :multiple="item.multiple" :disabled="item.disabled" :multiple-limit="item.multipleLimit" :clearable="item.clearable">
      <el-option v-for="o in item.options" :key="o.value" :label="o.label" :value="o.value" :disabled="o.disabled">
      </el-option>
    </el-select>
    <ec-selector style="width: 100%"  v-else-if="item.type==='dictSelect'" v-on="$listeners" :dict-type = "item.dictType" v-bind="$attrs"></ec-selector>         
    <el-date-picker v-else-if="item.type==='daterange'" v-bind="$attrs" v-on="$listeners" :disabled="item.disable"
      style="width: 100%" :picker-options="item.pickerOptions" type="daterange" :value-format="item.format"
      :format="item.showFormat" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" :clearable="item.clearable">
    </el-date-picker>
    <el-date-picker v-else-if="item.type==='datetimerange'" v-bind="$attrs" v-on="$listeners" :disabled="item.disable"
      style="width: 100%" :picker-options="item.pickerOptions" type="datetimerange" :value-format="item.format"
      :format="item.showFormat" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" :clearable="item.clearable">
    </el-date-picker>
    <div v-else-if="item.type ==='date'" class="single-date-picker">
      <el-date-picker type="date" class="flex1" v-bind="$attrs" v-on="$listeners" :disabled="item.disable"
        :value-format="item.format" :format="item.showFormat" placeholder="选择日期" :clearable="item.clearable">
      </el-date-picker>
      <span style="width: 30px; text-align: center">至</span>
      <el-date-picker type="date" class="flex1" v-bind="$attrs" v-on="$listeners" :disabled="item.disable"
        :value-format="item.format" :format="item.showFormat" placeholder="选择日期" :clearable="item.clearable">
      </el-date-picker>
        
    </div>
    <span v-else>未知控件类型</span>
  </el-form-item>

  <!-- </el-col>
  </el-row> -->
</template>
<script>

export default {
  props: {
    item: {
      type: Object,
      required: true
    }
  }
}
</script>

<style lang="scss" scoped>
.single-date-picker {
  display: flex;
  // justify-content: center;
}
</style>
