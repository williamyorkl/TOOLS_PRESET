import { TemplateCategoryEnum } from '@/config/enum'
export default {
  data() {
    return {
      templateInfo: {
        id: null,
        templateName: null,
        description: null
      },
      tplDialogVisible: false
    }
  },
  methods: {
    createTpl(row) {
      this.templateInfo.id = row.id
      this.templateInfo.templateName = null
      this.templateInfo.description = null
      this.tplDialogVisible = true
    },
    geneTpl(templateInfo) {
      const routeName = this.$route.name
      templateInfo.templateCategory = TemplateCategoryEnum[routeName]
      this.tplDialogVisible = false
      this.$router.push({ name: 'ArrangeTplSet', query: templateInfo })
    }
  }
}
