<template>
  <el-dialog title="生成模板" :visible.sync="visible" :beforeClose="handleCancel" width="500px">
    <mc-form ref="form" :model="formData" :rules="rules">
      <mc-form-item componentType="ElInput" prop="templateName" label="模板名称" :span="24" :editProps="{ maxlength: 128}" />
      <mc-form-item componentType="ElInput" prop="description" label="描述" :span="24" :editProps="{
        type: 'textarea',
        autosize: { minRows: 2, maxRows: 6 }
      }"
      />
    </mc-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleCancel">取 消</el-button>
      <el-button type="primary" @click="handleConfirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
export default {
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    formData: {
      type: Object,
      default: () => ({
        templateName: null,
        description: null,
        id: null
      })
    }
  },
  data() {
    return {
      rules: {
        templateName: [
          { required: true, message: '请输入模板名称', trigger: 'blur' }
        ],
        description: [
          { required: true, message: '请输入描述', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    handleConfirm() {
      this.$refs.form.validate().then(async valid => {
        if (valid) {
          this.$emit('confirm', this.formData)
        } else {
          this.$message.error('请按照提示完善表单数据')
        }
      })
    },

    handleCancel() {
      this.$emit('update:visible', false)
    }
  }
}
</script>

<style scoped lang="scss">
.condition-box ::v-deep .el-form-item__content {
  display: flex;
  .text1 {
    display: block;
    min-width: 135px;
  }
  .text2 {
    display: block;
    min-width: 90px;
  }
}
</style>
