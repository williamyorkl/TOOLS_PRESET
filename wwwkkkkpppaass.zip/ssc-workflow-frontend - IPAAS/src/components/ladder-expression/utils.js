// ladder表达式转对象
export function decodeLadderExpression(str) {
  if (!str) {
    return []
  }
  const resultArr = []
  const strr = 'const a = ' + str + '; return a'
  // eslint-disable-next-line no-new-func
  const fn = new Function(strr)
  const obj = fn()
  const reg = /([0-9]{1,3})([s|h|m|d])/
  // eslint-disable-next-line no-unused-vars
  for (const k in obj) {
    const result = k.match(reg)
    if (result) {
      resultArr.push({ timelen: result[1], count: obj[k], timeUnit: result[2] })
    }
  }
  return resultArr
}

// 对象转ladder表达式
export function encodeLadderExpression(arr) {
  let str = '{'
  arr.forEach((item, index) => {
    if (item.timelen !== null && item.count !== null && item.timeUnit !== null) {
      str += `'${item.timelen + item.timeUnit}':${item.count}`
      if ((index + 1) < arr.length) {
        str += ','
      }
    }
  })
  str += '}'
  return str
}
