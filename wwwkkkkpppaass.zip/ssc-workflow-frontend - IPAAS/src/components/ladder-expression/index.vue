<template>
  <el-form class="ladder" ref="form" :model="formData" labelWidth="0">
    <mc-list :list="ladderData" @handleAdd="handleLadderAdd" :limit="1">
      <template slot-scope="scope">
        <el-form-item class="ladder-item" label="" :prop="'ladderData.' + scope.index" :rules="rules.rowData">
          <el-input class="timelen" placeholder="间隔" v-model.number="scope.item.timelen" type="number" v-input-number="{min: 1, max: 999, int: true, precision: 0}">
            <el-select v-model="scope.item.timeUnit" slot="append" placeholder="单位">
              <el-option label="秒" value="s" :disabled="uniqe && optionDisabled.includes('s')" />
              <el-option label="分" value="m" :disabled="uniqe && optionDisabled.includes('m')" />
              <el-option label="时" value="h" :disabled="uniqe && optionDisabled.includes('h')" />
              <el-option label="天" value="d" :disabled="uniqe && optionDisabled.includes('d')" />
            </el-select>
          </el-input>
          <el-select class="count" v-model="scope.item.count" placeholder="">
            <el-option
              v-for="item in 5"
              :key="item"
              :label="item"
              :value="item"
            />
          </el-select> 次
        </el-form-item>
      </template>
    </mc-list>
  </el-form>
</template>

<script>
import { decodeLadderExpression, encodeLadderExpression } from './utils'
import '@/directives/input-number'
export default {
  name: 'LadderExpression',
  props: {
    data: {
      type: String,
      default: ''
    },
    uniqe: {
      type: Boolean,
      default: false
    }
  },
  directives: {
    // inputNumber
  },
  data() {
    return {
      input3: null,
      select: null,
      ladderData: [],
      rules: {
        rowData: [
          {
            required: true,
            validator: function(rule, value, callback) {
              console.log(value)
              if (!value.timeUnit || !value.timelen || !value.count) {
                callback(new Error('请完善重试阶梯表达式数据'))
              } else {
                callback()
              }
            }
          }
        ]
      }
    }
  },
  computed: {
    formData() {
      return {
        ladderData: this.ladderData
      }
    },
    optionDisabled() {
      // 时分秒天各自只能选中一次
      const result = []
      this.ladderData.forEach(item => {
        result.push(item.timeUnit)
      })
      return result
    }
  },
  watch: {
    data: {
      handler(val) {
        this.ladderData = decodeLadderExpression(val)
        console.log(this.ladderData)
      },
      immediate: true
    },
    ladderData: {
      handler(nV) {
        let flag = true
        if (nV) {
          for (let i = 0; i < nV.length; i++) {
            if (!nV[i].timelen || !nV[i].timeUnit || !nV[i].count) {
              flag = false
              break
            }
          }
        }
        if (flag) {
          this.$emit('update:data', encodeLadderExpression(nV))
        }
      },
      deep: true
    }
  },
  methods: {
    handleLadderAdd(list) {
      list.push({ timelen: null, count: null, timeUnit: null })
    },
    validateForm() {
      return new Promise(resolve => {
        this.$refs.form.validate(valid => {
          resolve(valid)
        })
      })
    }
  }

}
</script>

<style scoped lang="scss">
.ladder {
  .ladder-item{
    margin-bottom: 16px;
  }
  ::v-deep .el-form-item__error{
    top: auto;
  }
  .timelen{
    width: 150px;
  }
  .timelen ::v-deep .el-input-group__append {
    background: #fff;
  }
  .count{
    width: 60px;
  }
}
// 影响prepare和append图标的位置
.ladder ::v-deep .el-input .el-select {
  width: 80px;
}
</style>
