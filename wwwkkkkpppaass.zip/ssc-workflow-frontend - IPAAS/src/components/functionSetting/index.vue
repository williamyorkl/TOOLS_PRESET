<template>
  <!-- 接收函数列表,直接就该列表进行增删改操作 -->
  <div>
    <el-form ref="formData" :model="formData" label-width="120px" size="mini" label-position="top">
      <el-table :data="formData.functionList" style="width: 100%" border>
        <el-table-column label="序号" type="index" align="left" width="60" />
        <el-table-column prop="express" label="函数名称" align="left" :show-overflow-tooltip="false" width="250px">
          <template slot-scope="scope">
            <el-form-item :prop="'functionList.' + scope.$index + '.express'" :rules="{ required: true, message: '请选择函数类型', trigger: 'change' }">
              <el-select v-model="scope.row.express" clearable placeholder="请选择" filterable @change="setFuncInfo($event,scope.$index,scope.row, scope)" :disabled="disabled">
                <el-option-group v-for="group in funcList" :key="group.label" :label="group.label">
                  <el-option v-for="item in group.options" :key="item.id" :label="item.funcCode + ' | ' + item.funcName" :value="'#' + item.funcCode" />
                </el-option-group>
              </el-select>
            </el-form-item>
          </template>
        </el-table-column>
        <el-table-column prop="funcParaCount" label="参数个数" align="left" :show-overflow-tooltip="false" width="80px">
          <template slot-scope="scope">
            {{ Object.keys(scope.row.parameterMap).length }}
          </template>
        </el-table-column>
        <el-table-column prop="" label="参数" align="left" :show-overflow-tooltip="false" width="200px">
          <template slot-scope="scope">
            <template v-if="scope.row.parameterMap">
              <el-row class="mb-5" :gutter="10" v-for="(val, key) in scope.row.parameterMap" :key="key">
                <el-col :span="8">{{ key }}</el-col>
                <el-col :span="16"><el-input type="text" v-model="scope.row.parameterMap[key]" maxlength="128" :disabled="disabled" /></el-col>
              </el-row>
            </template>
          </template>
        </el-table-column>

        <el-table-column prop="remarks" label="参数说明" align="left" :show-overflow-tooltip="false" min-width="150px" />

        <el-table-column label="操作" align="left" fixed="right" v-if="!disabled">
          <template slot-scope="scope">
            <el-button type="text" size="mini" @click="deleteRow(scope.$index)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="rigth mt-10 mb-10" v-if="!disabled">
        <el-button style="width: 100%" size="medium" type="dash" @click="addRow" icon="el-icon-plus">添加</el-button>
      </div>
    </el-form>
    <div class="tips-normal">提示：参数支持参数列表中的变量以及$fun_i几种参数，其中$fun_i表示前面第（i+1）个函数的返回值（自上而下，i从0开始）</div>
  </div>
</template>

<script>
import funcApi from 'api/platformConfig/func'
import { FunctionDTO } from './options/model'

export default {
  name: 'FunctionSetting',
  props: {
    tableData: {
      type: [Array],
      default: () => []
    },
    mode: { type: String, default: 'edit' },
    funcType: {
      default: null,
      type: [String, Number]
    }
  },

  data() {
    return {
      funcList: [],
      funcMapping: null,
      formData: {
        functionList: []
      }

    }
  },
  computed: {
    disabled() { return this.mode === 'view' }
  },
  watch: {
    tableData: {
      async handler(nV) {
        if (nV) {
          this.formData.functionList = await this.transformParameter(nV)
        }
      },
      immediate: true
    },
    'formData.functionList': {
      handler(nV) {
        let responseType = null
        if (nV) {
          const length = nV.length
          if (length) {
            const funcMapping = this.funcMapping
            const lastFunc = funcMapping.get(this.spliceExpress(nV[length - 1].express))
            if (lastFunc) {
              responseType = lastFunc.responseType
            }
          }
        }
        this.$emit('updateResponseType', responseType)
      },
      immediate: true,
      deep: true
    }
  },
  created() {
    this.getFuncList()
  },
  methods: {
    async transformParameter(tableData) {
      if (!this.funcMapping) await this.getFuncList()
      tableData.forEach(item => {
        if (item.parameters) {
          const parameterMap = {}
          const express = this.spliceExpress(item.express)
          const func = this.funcMapping.get(express)
          let params = null
          if (func.paramJson) {
            params = JSON.parse(func.paramJson)
            params.forEach((param, index) => {
              parameterMap[param.name] = item.parameters[index]
            })
          }
          this.$set(item, 'parameterMap', parameterMap)
          delete item.parameters
        }
        if (!item.parameters && !item.parameterMap) {
          this.$set(item, 'parameterMap', {})
        }
      })
      return tableData
    },
    spliceExpress(express) {
      if (!express) return null
      if (express.startsWith('#')) {
        express = express.slice(1)
      }
      return express
    },
    setFuncInfo(val, rowIndex, row, scope) {
      if (!val) {
        row.parameterMap = []
      } else {
        let funcCode = val
        if (funcCode.startsWith('#')) funcCode = funcCode.slice(1)
        const item = this.funcMapping.get(funcCode)
        row.remarks = item.remarks
        row.scope = item.scope
        this.$set(row, 'parameterMap', {})
        if (!item.paramJson) return
        JSON.parse(item.paramJson).forEach(item => {
          // 不显示defaultValue
          this.$set(row.parameterMap, item.name, null)
        })
      }
    },
    // 调用函数接口加载数据
    async getFuncList() {
      const res = await funcApi.getFuncLevelTwoListAll({ type: this.funcType })
      if (!this.funcMapping) this.funcMapping = new Map()
      this.funcList = res
      res.forEach(group => {
        group.options.forEach(item => {
          this.funcMapping.set(item.funcCode, item)
        })
      })
    },
    addRow() {
      this.formData.functionList.push(new FunctionDTO())
    },
    // 删除，不请求后台
    deleteRow(index) {
      this.formData.functionList.splice(index, 1)
    },
    sure() {
      // 处理formData参数
      this.$refs.formData.validate(valid => {
        if (valid) {
          this.formData.functionList.forEach(item => {
            item.parameters = []
            item.parameters = item.parameterList.map(pi => { return pi.defaultValue })
          })
          this.$emit('finish', this.formData)
        } else {
          this.$message.error('请完善表单信息')
        }
      })
    },
    // 暴露给外部调用的表单校验方法
    validFormData() {
      return new Promise(resolve => {
        this.$refs.formData.validate(valid => {
          resolve(valid)
        })
      })
    }

  }

}
</script>
