<template>

  <el-dialog title="函数设置" :visible="visible" width="70%" @close="$emit('update:visible', false)" append-to-body>
    <FunctionSetting ref='functionRfc' :tableData="dialogForm.functionList" :mode="mode"></FunctionSetting>
    <span slot="footer" class="dialog-footer">
      <el-button @click="$emit('update:visible', false)">取 消</el-button>
      <el-button type="primary" @click="sure">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { deepClone } from '@/utils'
import FunctionSetting from '@/components/functionSetting'

export default {
  name: 'FunctionSettingDialog',
  components: { FunctionSetting },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    id: {
      type: [String, Number],
      default: ''
    },
    dialogData: {
      type: [Object],
      default: function () {
        return { functionList: [] }
      }
    },
    mode: { type: String, default: 'edit' }
  },
  watch: {
    visible(val) {
      if (val) {
        this.dialogForm = deepClone(this.dialogData)
      }
    }
  },

  data() {
    return {
      dialogForm: {
        functionList: []
      }

    }
  },

  methods: {
    sure() {
      // 处理dialogForm参数
      // this.$refs.dialogForm.validate(valid => {
      //   if (valid) {
      //     this.dialogForm.functionList.forEach(item => {
      //       item.parameters = []
      //       item.parameters = item.parameterList.map(pi => { return pi.defaultValue })
      //     })
      //     this.$emit('finish', this.dialogForm)
      //   } else {
      //     this.$message.error('请完善表单信息')
      //   }
      // })
      this.$emit('finish', this.dialogForm)
    }

  }

}
</script>
