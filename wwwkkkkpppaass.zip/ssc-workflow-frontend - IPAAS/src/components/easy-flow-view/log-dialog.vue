<template>
  <el-dialog :title="title" :visible.sync="visible" :width="width" :beforeClose="handleClose">
    <Mc-form v-if="nodeData" labelWidth="110px">
      <Mc-form-item label="节点名称:">{{ nodeData.nodeName }}</Mc-form-item>
      <Mc-form-item label="节点ID:">{{ nodeData.nodeId }}</Mc-form-item>
      <Mc-form-item label="错误类型:">{{ nodeData.errorCodeInfo }}</Mc-form-item>
      <Mc-form-item label="状态:">{{ code2Text(nodeData.status, LogNodeStateEnum) }}</Mc-form-item>
      <Mc-form-item label="总耗时(ms):">{{ nodeData.timeCost }}</Mc-form-item>
      <Mc-form-item label="错误信息:" v-if="nodeData.status !== 0">
        <div class="form-item-content">{{ nodeData.errorMsg }}</div>
      </Mc-form-item>
      <Mc-form-item label="错误堆栈:" v-if="nodeData.status !== 0">
        <div class="form-item-content">{{ nodeData.errorStack }}</div>
      </Mc-form-item>
      <Mc-form-item label="开始时间:">{{ nodeData.startTime }}</Mc-form-item>
      <Mc-form-item label="结束时间:">{{ nodeData.endTime }}</Mc-form-item>
      <template v-if="nodeData.type === NodeTypeEnum.PROCESS">
        <Mc-form-item label="服务声明名称:">{{ nodeData.serviceApiName }}</Mc-form-item>
        <Mc-form-item label="后端服务ID:">{{ nodeData.serviceApiId }}</Mc-form-item>
        <Mc-form-item label="后端服务名称:">{{ nodeData.serviceApiDesc }}</Mc-form-item>
        <Mc-form-item label="后端服务版本号:">{{ nodeData.serviceApiVersion }}</Mc-form-item>
      </template>
      <Mc-form-item label="入参快照:" :span="24">
        <codemirror :value="prettyJson(nodeData.paramIn)" :options="codeMirrorOptions" class="code-container" />
      </Mc-form-item>
      <Mc-form-item label="出参快照:" :span="24">
        <codemirror :value="prettyJson(nodeData.paramOut)" :options="codeMirrorOptions" class="code-container" />
      </Mc-form-item>
      <Mc-form-item label="运行明细:" :span="24">{{ nodeData.detailInfo }}</Mc-form-item>
    </Mc-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">关闭</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { mapActions } from 'vuex'
import { code2Text } from '@/utils'
import { NodeTypeEnum } from '@/config/enum'

import 'codemirror/lib/codemirror.css'
import { codemirror } from 'vue-codemirror'

require('codemirror/mode/javascript/javascript.js')

export default {
  name: 'EditDialog',
  components: {
    codemirror
  },
  props: {
    visible: {
      default: false,
      type: Boolean
    },
    title: {
      default: '新增',
      type: String
    },
    width: {
      default: '30%',
      type: String
    },
    nodeData: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      NodeTypeEnum,
      code2Text,
      LogNodeStateEnum: [],
      codeMirrorOptions: {
        mode: { name: 'javascript', json: true },
        lineNumbers: true,
        readOnly: true
      }
    }
  },
  async created() {
    this.LogNodeStateEnum = await this.getDicts('LogNodeStateEnum')
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    handleClose() {
      this.$emit('update:visible', false)
    },
    prettyJson(data) {
      let res = null
      try {
        res = JSON.stringify(JSON.parse(data), null, 2)
      } catch (e) {
        res = data
      }
      return res
    }
  }
}
</script>

<style lang="scss" scoped>
.code-container {
  font-size: 12px;
  box-shadow: 4px 4px 4px #efefef;
  line-height: 20px;
  max-height: 150px;
  overflow: auto;

  ::v-deep .CodeMirror{
    height: 150px;
  }
}
.form-item-content {
  background: #fafafa;
  max-height: 200px;
  overflow: auto;
}
</style>
