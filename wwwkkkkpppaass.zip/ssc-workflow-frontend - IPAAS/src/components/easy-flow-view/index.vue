
<template>
  <div class="arrange-container-wrapper">
    <div class="arrange-container">
      <jsplumbCanvas @setting="setting" ref="jsplumb-canvas" canvasId="arrange-container" :canvasData="{nodeList, lineList}" />

      <LogDialog :nodeData.sync="nodeData" :visible.sync="logDialogVisible" :title="logDialogTitle" width="1000px" />
    </div>
  </div>
</template>

<script>
import '@/components/flow-node/index.scss'
// import '@/components/easy-flow/utils/jsplumb'
import '@/components/easy-flow/index.css'
import { easyFlowMixin } from '@/components/easy-flow/utils/mixins'
import LogDialog from './log-dialog'
import jsplumbCanvas from '@/components/flow-node/components/jsplumb-canvas'

export default {
  components: { LogDialog, jsplumbCanvas },
  props: {
    nodeList: {
      default: () => [],
      type: Array
    },
    lineList: {
      default: () => [],
      type: Array
    },
    // eslint-disable-next-line vue/require-prop-types
    nodeLogMap: {
      default: () => new Map()
    }
  },
  mixins: [easyFlowMixin],
  data() {
    return {
      logDialogVisible: false,
      logDialogTitle: '节点日志',
      activeElement: {},
      nodeMap: new Map(),
      nodeOptionDialogVisible: false,
      nodeData: {}
    }
  },
  // 这几个provide属性在此处无意义，仅为了避免节点连线内部报错
  provide() {
    return {
      // activeElement通过inject配合mixin: ../mixins/activeElement.js传递
      getActiveElement: () => {
        return this.activeElement
      },
      setActiveElement: (activeElement) => {
        this.activeElement = activeElement
      },
      nodeMap: new Map(),
      isLog: true,
      nodeLogMap: this.nodeLogMap,
      formDisabled: true
    }
  },
  mounted() {
  },
  methods: {
    setting(e) {
      console.log('setting', e)
      const nodeId = e.data.nodeId
      const nodeData = this.nodeLogMap.get(nodeId)
      if (!nodeData) {
        return this.$message.error('没有查询到节点日志信息')
      } else {
        this.nodeData = { ...nodeData, type: e.data.type }
        this.logDialogVisible = true
        this.logDialogTitle = this.nodeData.nodeName
      }
    }
  }
}
</script>

<style scoped lang="scss">

.arrange-container-wrapper{
  height: 100%;
  display: flex;
  flex-direction: column;
  .toolbar{
    height: $toolbarHeight;
    box-sizing: border-box;
    border-bottom: 1px solid rgb(207, 205, 205);
    box-shadow: 0px 3px 0px 0px rgba(0, 0, 0, 0.05);
  }
  .arrange-container {
    height: calc(100% - #{$toolbarHeight});
    display: flex;
    flex-grow: 1;
    .menu-container{
      flex-shrink: 0;
      max-height: 100%;
      overflow-x: hidden;
      overflow-y: auto;
      width: 220px;
      border-right: 1px solid #dce3e8;
    }
  }
}
</style>
