<template>
  <div
    ref="node"
    :style="nodeContainerStyle"
    @dblclick.stop="dblclickNode"
    @click.stop="clickNode"
    @mouseup="changeNodeSite"
    @contextmenu="contextmenu"
    :class="nodeContainerClass"
  >
    <!-- 最左侧的那条竖线 -->
    <div class="ef-node-left" />
    <!-- 节点类型的图标 -->
    <div class="ef-node-left-ico flow-node-drag">
      <i v-if="isOldIcon" class="iconfont" :class="nodeIcon" />
      <mc-svg-icon v-else :class="nodeIcon" :icon="node.ico" iconClass="iconfont" />
    </div>
    <!-- 节点名称 -->
    <div class="ef-node-text" :show-overflow-tooltip="true" :title="node.name">
      {{ node.name }}
    </div>
    <!-- 节点状态图标 -->
    <div class="ef-node-right-ico">
      <i class="el-icon-circle-check el-node-state-success" v-show="node.state === 'success'" />
      <i class="el-icon-circle-close el-node-state-error" v-show="node.state === 'error'" />
      <i class="el-icon-warning-outline el-node-state-warning" v-show="node.state === 'warning'" />
      <i class="el-icon-loading el-node-state-error" v-show="node.state === 'error'" />
    </div>
  </div>
</template>

<script>
export default {
  props: {
    node: {
      default: () => ({}),
      type: Object
    },
    activeElement: {
      default: () => ({}),
      type: Object
    }
  },
  data() {
    return {}
  },
  computed: {
    nodeContainerClass() {
      return {
        'ef-node-container': true,
        'ef-node-active': this.activeElement.type === 'node' ? this.activeElement.nodeId === this.node.id : false
      }
    },
    // 节点容器样式
    nodeContainerStyle() {
      return {
        top: this.node.top,
        left: this.node.left
      }
    },
    nodeIcon() {
      const nodeIcon = {}
      nodeIcon[this.node.ico] = true
      // 添加该class可以推拽连线出来，viewOnly 可以控制节点是否运行编辑
      nodeIcon['flow-node-drag'] = !this.node.viewOnly
      return nodeIcon
    }
  },
  methods: {
    clickNode() {
      this.$emit('clickNode', this.node.id, this.node)
    },
    // 点击节点
    dblclickNode() {
      this.$emit('dblclickNode', this.node.id, this.node)
    },
    contextmenu(ev) {
      this.$emit('contextmenu', ev, this.node)
    },
    // 鼠标移动后抬起
    changeNodeSite() {
      // 避免抖动
      if (this.node.left === this.$refs.node.style.left && this.node.top === this.$refs.node.style.top) {
        return
      }
      this.$emit('changeNodeSite', {
        nodeId: this.node.id,
        left: this.$refs.node.style.left,
        top: this.$refs.node.style.top
      })
    }
  }
}
</script>
