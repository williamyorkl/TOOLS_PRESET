import {
  genID
} from '@/utils'

// 文件扩展名提取
export function fileType(fileName) {
  return fileName.substring(fileName.lastIndexOf('.') + 1)
}

/**
 * oss路径定义
 * @param file
 */
export function ossPath(file) {
  const folder = moment().format('YYYY-MM-DD')
  if (file.name) {
    return `admin/${folder}/${fileType(file.name)}/${file.name}`
  } else {
    return `admin/${folder}/html/${moment().format('YYYY-MM-DD-HH-mm-ss')}.html`
  }
}

export function ossUpload(file) {
  const name = file.name
  const uid = genID()
  try {
    let resp = await this.OSS_STORE.put(`imgs/${uid}${name}`, file)
    return resp

  } catch (error) {
    console.log(error)
  }
}
