<template>
  <el-dialog :title="title" :visible.sync="visible" :width="width" :beforeClose="handleClose" appendToBody>
    <el-form labelWidth="100px">
      <el-form-item label="填充类型">
        <el-select v-model="inputType" @change="inputTypeChange">
          <el-option label="json" value="json" />
          <el-option label="text" value="text" />
          <el-option label="节点间复制" value="copy" v-if="allowCopy" />
        </el-select>
      </el-form-item>
    </el-form>
    <el-form labelWidth="100px" v-if="inputType === 'json'">
      <!-- eslint-disable-next-line vue/no-unused-vars -->
      <mc-list :list="paramList" slot-scope="scope" @handleAdd="handleAdd" :disabled="!needPos || type === 'apiOutParamList'">
        <template slot-scope="scope">
          <!-- 禁止用户手动设置path参数；如果是get请求，禁止设置body参数 -->
          <el-form-item prop="" label="参数位置" v-if="type !== 'apiOutParamList' && needPos">
            <el-select v-model="scope.item.type">
              <el-option v-for="item in DataPosEnum" :key="item.type" :label="item.desc" :value="item.type" :disabled="posDisable(item) " />
            </el-select>
          </el-form-item>
          <el-form-item prop="" label="参数">
            <codemirror ref="codemirror" v-model="scope.item.jsonStr" :options="options" class="code-container" />
          </el-form-item>
        </template>
      </mc-list>
    </el-form>
    <el-form labelWidth="100px" :model="textFormData" ref="textForm" :rules="rules" v-else-if="inputType === 'text' || inputType === 'copy'">
      <el-form-item prop="dataPosition" label="参数位置" v-if="type !== 'apiOutParamList' && needPos">
        <el-select v-model="textFormData.dataPosition">
          <el-option v-for="item in DataPosEnum" :key="item.type" :label="item.desc" :value="item.type" :disabled="posDisable(item) " />
        </el-select>
      </el-form-item>
      <el-form-item label="结构位置" prop="path" :rules="hasWrapper ? [
        {required: true, trigger: 'change', message: '请选择结构位置'}
      ] : []"
      >
        <el-input v-model="textFormData.path" disabled />
      </el-form-item>
      <JsonTree title="目标数据" :data="originalParamList" :allowEdit="false" :multipleNode="false" @rightClick="targetRightClick" />
      <template v-if="inputType === 'text'">
        <el-form-item label="是否小写驼峰" prop="isCamelCase">
          <el-switch v-model="textFormData.isCamelCase" activeColor="#13ce66" inactiveColor="#ff4949" />
        </el-form-item>
        <el-row :gutter="10">
          <el-col :span="8">
            <el-form-item prop="paramStr" label="参数名">
              <codemirror ref="codemirror1" v-model="textFormData.paramStr" :options="options" class="code-container" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item prop="dataTypeStr" label="参数类型">
              <codemirror ref="codemirror2" v-model="textFormData.dataTypeStr" :options="options" class="code-container" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item prop="descriptionStr" label="参数描述">
              <codemirror ref="codemirror3" v-model="textFormData.descriptionStr" :options="options" class="code-container" />
            </el-form-item>
          </el-col>
        </el-row>
      </template>
      <template v-else>
        <el-form-item class="sourcePath" label="节点字段" prop="sourcePath">
          <el-input v-model="textFormData.sourcePath" disabled />
        </el-form-item>
        <!-- 复制模式：结构位置、当前结构的json树；  选择复制数据的来源节点、所选节点的json树、选中的字段 -->
        <JsonTree title="源数据" :multipleNode="true" :selectNodeId.sync="selectNodeId" :data.sync="sourceData" @rightClick="sourceRightClick" v-bind="$attrs" :selectAllNode="true" />
      </template>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" @click="confirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { mapActions } from 'vuex'
// import JsonTree from '@/components/flow-node/biz_components/components/jsonTree'
import { jsonObj2Array } from '@/utils'
import { TextFormData, CopyFormData } from './model'
import { resolveText, resolveCopy, recursivelyAddAttr } from '@/utils/resolve-data'
import { codemirror } from 'vue-codemirror'
import 'codemirror/lib/codemirror.css'
import 'codemirror/theme/base16-dark.css'

require('codemirror/mode/javascript/javascript.js')
export default {
  name: 'JsonDialog',
  components: {
    codemirror,
    JsonTree: () => import('@/components/flow-node/biz_components/components/jsonTree')
  },
  props: {
    visible: {
      default: false,
      type: Boolean,
      required: true
    },
    wrapStr: {
      type: String,
      default: null
    },
    title: {
      default: '参数填充',
      type: String
    },
    width: {
      default: '30%',
      type: String
    },
    requestType: {
      type: Number,
      required: false,
      default: null
    },
    type: {
      type: String,
      default: null
    },
    needPos: {
      default: true,
      type: Boolean
    },
    originalParamList: {
      type: Array,
      default: () => []
    },
    // eslint-disable-next-line vue/prop-name-casing
    RowParam: {
      type: Function,
      default: null
    },
    allowCopy: {
      default: false,
      type: Boolean
    }
  },
  data() {
    return {
      DataPosEnum: [],
      paramList: [],
      options: {
        mode: { name: 'javascript', json: true },
        theme: 'base16-dark',
        lineNumbers: true
      },
      inputType: 'json',
      textFormData: new TextFormData(),
      rules: {
        dataPosition: [
          { required: true, message: '请选择参数位置', trigger: 'change' }
        ],
        paramStr: [
          { required: true, message: '请输入参数名', trigger: 'change' }
        ],
        dataTypeStr: [
          { required: true, message: '请输入参数类型', trigger: 'change' }
        ],
        sourcePath: [
          // { required: true, trigger: 'change', message: '请选择节点字段' }
        ]
      },
      sourceData: [],
      selectNodeId: null,
      targetData: [],
      sourceTreeNode: null
    }
  },
  watch: {
    visible: {
      handler(nV) {
        if (nV) {
          if (this.$refs.codemirror) {
            this.$refs.codemirror.codemirror.setValue(null)
          }
          this.paramList = [{ jsonStr: null, paramPos: null }]
        }
      },
      immediate: true
    },
    selectNodeId: {
      handler() {
        this.textFormData.sourcePath = null
      }
    }
  },
  async created() {
    [this.DataPosEnum] = await this.getDicts(['DataPosEnum'])
  },
  computed: {
    hasWrapper() {
      return ['mapper', 'mq'].includes(this.wrapStr)
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    targetRightClick(treeNode) {
      const dataType = treeNode.dataType
      if (![7, 8].includes(dataType)) {
        return this.$message.error('请选择【数组、对象】类型数据')
      }
      this.textFormData.path = treeNode.path
    },
    sourceRightClick(treeNode) {
      // targetArr用于解析copy到的数据，加入到target数据
      this.textFormData.sourceData = treeNode
      this.textFormData.sourcePath = treeNode.path
    },
    handleAdd() {
      this.paramList.push({ jsonStr: '', type: null })
    },
    handleClose() {
      this.$emit('update:visible', false)
    },
    posDisable(item) {
      if (item.type === 1) return true
      if ((this.requestType && this.requestType === 1) && item.type === 4) return true
      if (!this.reqestType) return false
    },
    inputTypeChange(v) {
      switch (v) {
        case 'text':
          this.textFormData = new TextFormData()
          break
        case 'copy':
          this.textFormData = new CopyFormData()
          break
      }
    },
    confirm() {
      if (this.inputType === 'json') {
        // 解析json数据，转化为列表数据
        const list = []
        this.paramList.forEach((item, index) => {
          try {
            let jsonStr = JSON.parse(item.jsonStr)
            if (this.hasWrapper) {
              jsonStr = {
                [this.wrapStr]: jsonStr
              }
            }
            const data = jsonObj2Array(jsonStr, [], item.type, this.RowParam)
            list.push(...data)
          } catch (e) {
            this.$message.error(`第${index + 1}组：JSON解析出错`)
          }
        })
        this.$emit('confirm', list)
      } else if (this.inputType === 'text') {
        this.$refs.textForm.validate(valid => {
          if (valid) {
            const paramList = resolveText(this.originalParamList, this.textFormData, this.RowParam)
            this.$emit('confirm', paramList)
          } else {
            this.$message.error('请完善表单数据')
          }
        })
      } else if (this.inputType === 'copy') {
        // debugger
        this.$refs.textForm.validate(valid => {
          if (valid) {
            // 如果没有选择节点字段，那么sourceData是整体数据，此时是数组，需要区分一下
            if (!this.textFormData.sourcePath) {
              this.textFormData.sourceData = this.sourceData
            }
            const paramList = resolveCopy({ originalParamList: this.originalParamList, formData: this.textFormData, RowParam: this.RowParam })
            const paramListWithKey = recursivelyAddAttr(paramList)
            this.$emit('confirm', paramListWithKey)
          }
        })
      }
    }
  }
}
</script>

<style scoped lang="scss">
.sourcePath{
  margin-top: 16px;
}
</style>
