export default {
  data() {
    return {
      jsonDialogVisible: false,
      currentJsonKey: null,
      activeName: 'params'
    }
  },
  methods: {
    // confirmJsonData(data) {
    //   this.formData[this.currentJsonKey] = data
    //   this.jsonDialogVisible = false
    // },
    showJsonVisible(key) {
      if (this.mode && this.mode === 'view') {
        this.isView = true
      }
      if (this.isView === undefined) {
        this.isView = false
      }
      if (this.isView) return
      this.currentJsonKey = key
      this.jsonDialogVisible = true
    }
  }
}
