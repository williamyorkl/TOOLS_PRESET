// 基础form，可用于copy模式
export class FormData {
  constructor() {
    // copy、text共用
    this.path = ''
    this.dataPosition = 2 // 参数位置
  }
}

export class TextFormData extends FormData {
  constructor() {
    super()
    this.isCamelCase = true
    this.paramStr = ''
    this.dataTypeStr = ''
    this.descriptionStr = ''
  }
}

export class CopyFormData extends FormData {
  constructor() {
    super()
    this.sourceData = null
    this.sourcePath = null
  }
}
