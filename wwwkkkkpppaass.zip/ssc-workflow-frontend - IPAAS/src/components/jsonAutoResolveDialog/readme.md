# 
用户录入n组json数据和参数位置,自动解析为级联列表数据并通过confirm导出

```js
props: {
  visible: {
      default: false,
      type: Boolean,
      required: true
    },
    title: {
      default: '参数填充',
      type: String
    },
    width: {
      default: '30%',
      type: String
    },
    paramList: {
      default: () => [],
      type: Array
    }
}

event: {
  confirm: list => {

  }
}

```