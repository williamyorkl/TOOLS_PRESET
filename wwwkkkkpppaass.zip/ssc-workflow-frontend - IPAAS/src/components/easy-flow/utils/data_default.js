import { Node, Workflow } from '@/components/easy-flow/model/model.js'
const nodeList = [
  new Node({
    id: 'startNode',
    name: '编排开始',
    type: 'start',
    left: '26px',
    top: '161px',
    ico: 'el-icon-caret-right',
    state: 'success'
  }),
  new Node({
    id: 'nodeB',
    name: '默认流程-节点B',
    type: 'process',
    left: '340px',
    top: '161px',
    ico: 'icon-APIguanli',
    state: 'success'
  }),
  new Node({
    id: 'endNode',
    name: '编排结束',
    type: 'end',
    left: '739px',
    top: '161px',
    ico: 'icon-jieshu',
    state: 'success'
  })
]

const lineList = [
  {
    from: 'startNode',
    to: 'nodeB'
  },
  {
    from: 'nodeB',
    to: 'endNode'
  }
]

const dataDefault = new Workflow({ name: '默认流程' })
dataDefault.nodeList = nodeList
dataDefault.lineList = lineList

export function getDataDefault() {
  return dataDefault
}
