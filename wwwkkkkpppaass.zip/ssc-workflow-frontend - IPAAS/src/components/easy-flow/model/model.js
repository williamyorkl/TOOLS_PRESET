// import { PolicyData } from '@/views/arrange/serviceArrange/options/model'
import { getUUID } from '@/utils/index'

// 流程完整数据
export class Workflow {
  constructor() {
    this.businessApiName = null // 用户接口名称
    this.developer = null // 开发人员
    this.id = null // 流程id
    this.remark = null // 描述
    this.requestTimeout = 6000 // 超时时间
    this.requestType = null // 请求方式 (字典)
    this.requestUrl = null // 请求url
    this.lineList = [] // 连线
    this.nodeList = [] // 节点
  }
}

export class Line {
  constructor() {
    this.from = null
    this.to = null
  }
}
// 入参/出参配置数据
export class Param {
  constructor() {
    this.mappingList = []
    this.sourceMessageList = []
    this.targetMessage = null
    this.sourceMessage = null
    this.targetType = 'JSON'
  }
}
// 条件控制值
export class C {
  constructor(attrName = 'c1', type = null, dataType = null, value = null) {
    this.attrName = attrName // 字段名称：前端生成一个本条件列表中唯一的名称
    this.type = type // 类型（固定-0 | 引用-1）
    this.dataType = dataType // 数据类型
    this.nodeKey = null // 目标节点的key，前端的id
    this.value = value // 值：固定类型-直接填值，引用类型-选择其他节点的出参path
  }
}

// 一组条件控制
export class PreCondition {
  constructor() {
    this.c1 = new C('c1')
    this.c2 = new C('c2')
    this.compareSymbol = null
  }
}

// 过滤条件
export class FilterCondition {
  constructor() {
    this.c1 = new C(null, 0, null, 'morenzhi') // c1不需要value，为了兼容后端的非空验证，此处放一个默认值
    this.c2 = new C('c2')
    this.compareSymbol = null
  }
}

// 循环配置
export class WorkflowNodeLoopDto {
  constructor() {
    this.isLoop = false
    this.type = 1 // 类型（固定-0 | 引用-1）
    this.nodeName = null
    this.nodeKey = null
    this.value = null
  }
}

// 接口URL参数,/user/{id}
export class UrlParam {
  constructor({ fieldName }) {
    this.dataType = null
    this.type = 1 // 类型（固定-0 | 引用-1）
    this.fieldName = fieldName
    this.nodeKey = null
    this.value = null
  }
}

export class NodeParams {
  constructor(type) {
    this.apiId = null // 微服务接口id
    // this.apiOutParamMessage = null // 接口出参，其他节点的入参可从此处选择
    this.inputParamList = [] // 入参列表
    this.outputParamList = [] // 出参列表
    this.mappingList = []
    this.serviceName = null // 服务名
    this.apiRequestTimeout = null // 微服务接口请求超时时间(ms)
    this.fallBack = null // 异常返回OR继续 枚举:stop | continue
    this.group = null // 分组(新增可不填)
    this.inputParamType = null // 接口入参类型(新增可不填)
    this.interfaceType = null // 接口类型 0-dubbo,1-http
    if (type === 'end') {
      this.interfaceType = 0 // 参数类型：json
    }
    this.methodName = null // 方法名(新增可不填)
    this.serviceInstance = null // wsldUrl(soap专有)
    this.namespace = null // 命名空间 (soap专有)
    this.serviceName = null // 服务声明名称(新增可不填)
    this.version = null // 版本
    // this.outParam = new Param() // 微服务接口id
    if (type === 'process') { // 中间节点才有前置条件
      this.preConditionList = [] // 前置条件: 默认有一组空的前置条件
      this.usedCondLogicExp = true
      this.condLogicExp = null // 逻辑关系字符串
      this.workflowNodeLoopDto = new WorkflowNodeLoopDto() // 循环配置
      this.forwardHeader = null
      this.forwardCookie = null
      this.filterForwardHeaderParams = ''
      this.forwardHeaderParams = ''
    }
    this.apiRequestUrlParam = [] // api路径参数 : 根据url参数解析
    this.serviceDesc = null // 服务描述
    this.apiRequestContentType = null // 接口请求内容类型(编辑回显字段,新增不传值)
    this.apiRequestProtocol = null // 接口请求协议(编辑回显字段,新增不传值)
    this.apiDesc = null // 方法描述（编辑回显字段，新增不传值）
    this.apiRequestMethod = null // 接口请求方式(编辑回显字段,新增不传值)
    this.apiRequestUrl = null // 接口请求URL(编辑回显字段,新增不传值)
  }
}

// db类型节点的一些属性类
// DB:分页字段
export class PageField {
  constructor() {
    this.dataType = 1
    this.fieldName = null
    this.logicalOperator = ''
    this.nodeKey = ''
    this.nodeKey1 = ''
    this.operator = null
    this.type = null
    this.type1 = null
    this.value = ''
    this.value1 = ''
  }
}

// DB: 查询字段
export class SelectField {
  constructor({ fieldName, dataType }) {
    this.dataType = dataType
    this.fieldName = fieldName
  }
}

// DB:排序字段
export class SortField {
  constructor() {
    this.direction = null
    this.field = null
  }
}

// DB:update字段
export class UpdateField {
  constructor() {
    this.dataType = null
    this.fieldName = ''
    this.logicalOperator = ''
    this.nodeKey = ''
    this.nodeKey1 = ''
    this.operator = null
    this.type = null
    this.value = ''
    this.isCheckKey = null
    this.isUpdateKey = null
    this.isInsertKey = null
  }
}

// DB:where字段
export class WhereField {
  constructor() {
    this.dataType = null
    this.fieldName = ''
    this.logicalOperator = ''
    this.nodeKey = ''
    this.nodeKey1 = ''
    this.operator = null
    this.type = null
    this.type1 = null
    this.value = ''
    this.value1 = ''
    this.rowKey = getUUID()
    this.groups = []
  }
}

// DB:referenceField
export class ReferenceField {
  constructor() {
    this.dataType = null
    this.fieldName = ''
    this.nodeKey = ''
    this.type = null
    this.value = ''
  }
}

// DB节点配置
export class DbParams {
  constructor() {
    this.dbId = null
    this.tableName = null // 数据库名称
    this.sqlList = [new SqlParams()] // 放多个sql配置
  }
}

// DB数据库节点多sql配置
export class SqlParams {
  constructor() {
    this.isInputSql = 0
    this.sqlMethod = null
    this.timeOut = 5
    this.textSql = null

    this.collectionName = null // 集合对象
    this.collectionNodeKey = null // 节点key
    this.mainKeyName = null // 主键
    this.mainKeyNameNodeKey = null // 主键节点key

    this.queryCount = false // 是否查询记录总数

    this.selectFieldList = [] // select 参数列表
    this.pageFieldList = []
    this.sortFieldList = []
    this.updateFieldList = []
    this.whereFieldList = []
    this.referenceFieldList = []
  }
}

export class Mapping {
  constructor() {
    this.dataType = null // 入参数据类型 对应paramList数据类型
    this.functionList = [] // 函数列表
    this.referenceType = 1 // 入参类型( 固定-0 | 引用-1 | 请求参数-2)
    this.scriptData = null // 脚本
    this.sorted = 0 // 排序
    this.sourceNodeKey = null // 源字段节点key(id: 前端生成的id)
    this.sourceNodeName = null // 源字段节点名称
    this.sourceNodePath = null // 源字段节点路径
    this.targetNodePath = null // 目标节点路径 对应paramListpath
    this.bizDictMapId = null
    this.dataPosition = null // 参数位置 对应paramList  dataPosition
    this.isRequired = null // 是否必传 对应paramList  isRequired
    this.id = null
    this.nodeId = null
  }
}

// MQ.mappingParam
export class MappingParam {
  constructor() {
    this.mappingList = []
    this.sourceMessageList = []
    this.targetMessage = null
    this.targetType = null
  }
}

// functionList
export class Func {
  constructor() {
    this.express = null
    this.parameters = []
    this.scope = null
  }
}

// functionList
export class SourceMessage {
  constructor() {
    this.sourceMessage = ''
    this.sourceNodeKey = ''
    this.sourceType = ''
  }
}

// MQ
export class MqParams {
  constructor() {
    this.keyPrefix = null
    this.mappingList = []
    this.targetMessage = null // 用于存储用户输入的json对象
    this.mqServerId = null
    this.mqType = null
    this.topic = null
    this.tags = null
  }
}

// 逻辑处理节点出参
export class HandleOutputParam {
  constructor() {
    this.rowKey = Date.now() + Math.random().toString().slice(2, 4)
    this.childrenList = []
    this.dataType = null // 参数类型
    this.description = null // 描述
    this.isRequired = null // 是否必填
    this.paramName = null // 参数key
    this.generic = null
    this.dataPosition = null
    this.value = null
  }
}
// 逻辑处理节点参数类
export class HandleParams {
  constructor() {
    this.structList = []
    this.targetMessage = null
    this.outputParamList = []
  }
}

export class Parameter {
  constructor({ paramName }) {
    this.paramName = paramName
    this.dataType = null
    this.referenceType = null
    this.sourceNodeKey = null
    this.sourceNodePath = null
    this.sourceNodeName = null
  }
}

export class Variable {
  constructor() {
    this.dataType = null
    this.express = null
    this.parameters = []
    this.referenceType = null
    this.scope = null
    this.sourceNodeKey = null
    this.sourceNodeName = null
    this.sourceNodePath = null
    this.variableName = null
  }
}

// filter组件数据原型
export class OptFilter {
  constructor() {
    this.condLogicExp = null // 条件表达式
    this.condLogicRpn = null // 条件RPN表达式
    this.conditionList = [] // 条件列表
    this.nodeKey = null
    this.outputParamList = [] // 输出参数列表
    this.value = null // 引用类型-引用节点对应出参path(数据集)
  }
}
// mapper组件数据原型
export class OptMapper {
  constructor() {
    this.id = null
    this.inputList = [] // 记录输入信息
    this.mappingList = [] // 记录映射信息
    this.outputList = [] // 记录输出信息
    this.targetMessage = null // json字符串
  }
}
// group组件数据原型
export class OptGroup {
  constructor() {
    this.nodeKey = null
    this.outputParamList = [] // 输出参数列表
    this.value = null // 引用类型-引用节点对应出参path(数据集)
    this.groupKey = null
  }
}

// groovy入参
export class GroovyInputParam {
  constructor() {
    this.className = null
    this.nodeKey = null
    this.nodeName = null
    this.desc = null
  }
}

// groovy出参
export class GroovyOutputParam {
  constructor() {
    this.paramName = null
    this.dataType = null
    this.generic = null
    this.value = null
    this.desc = null
    this.rowKey = Date.now() + Math.random().toFixed(4)
    this.childrenList = []
  }
}

// group组件数据原型
export class OptGroovy {
  constructor() {
    this.outputParamList = [] // 输出参数列表
    this.inputParamList = [] // 输出参数列表
    this.groovyScript = null // 脚本
  }
}

// Combine组件数据原型
export class OptCombine {
  constructor() {
    this.fieldName = null
    this.listFlag = 0
    this.mappingList = []
    this.nodeKeyList = [{
      dataType: null,
      nodeKey: null,
      value: null
    }, {
      dataType: null,
      nodeKey: null,
      value: null
    }]
  }
}

export class HandleOptDto {
  constructor({ optType }) {
    this.errorId = null
    this.errorInfo = {}
    this.mappingList = []
    this.optType = optType
    this.order = null
    this.variables = []
    this.targetMessage = null
    if (optType === 4) {
      this.filter = new OptFilter()
    }
    if (optType === 5) {
      this.mapper = new OptMapper()
    }
    if (optType === 6) {
      this.group = new OptGroup()
    }
    if (optType === 7) {
      this.groovy = new OptGroovy()
    }
    if (optType === 8) {
      this.combine = new OptCombine()
    }
  }
}

export class HandleConditionDto {
  constructor({ conditionType }) {
    this.condLogicExp = null
    this.condLogicRpn = null
    this.conditionList = [] // 前缀条件，和if含义不一样
    this.conditionType = conditionType
    this.handleOptList = []
  }
}

export class HandleStruct {
  constructor({ type = null, optType }) {
    if (type === 1) { // 条件
      this.handleConditionDtoList = []
    }
    if (type === 2) { // 操作
      this.handleOptDto = new HandleOptDto({ optType })
    }
    this.order = null
    this.type = type
  }
}

export class ForwardParams {
  constructor() {
    this.completeUrl = null // 用户接口路径
    this.routeId = null // 服务id
    this.srvName = null // 后端服务名
    this.reqPathPrefix = null // 后端API路径
    this.timeOut = null // 超时时间
    this.registryName = null // 注册中心名称
  }
}

export class Node {
  constructor({ ico = 'el-icon-goods', name = '节点', id = 'node', nodeId = null, left = '300px', top = '300px', state = 'success', type = 'process' }) {
    this.ico = ico // 节点图标
    this.name = name // 节点名称
    if (id) {
      this.id = id // 前端生成的节点id
    } else {
      this.id = 'node' + Date.now()
    }
    this.nodeId = nodeId // 后端生成的节点id
    this.nodeKey = this.id
    this.left = left // 节点的左边距
    this.top = top // 节点的上边距
    this.state = state // 节点状态
    this.type = type // 节点类型（枚举：start | process | end）
    if (type === 'db') {
      this.retryPolicy = ''
      this.nodeParamsDbDto = new DbParams()
    } else if (type === 'mq') {
      this.nodeParamsMqDto = new MqParams()
    } else if (type === 'handle') {
      this.nodeParamsHandleDto = new HandleParams()
    } else if (type === 'forward') {
      this.nodeParamsForwardDto = new ForwardParams()
    } else {
      this.retryPolicy = ''
      this.nodeParams = new NodeParams(type) // 生成开始节点和process节点的数据
    }
  }
}
