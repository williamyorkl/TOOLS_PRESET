/**
 * @description mc-form-installer
 * @author Adonis.Lau(liuwj24@meicloud.com)
 */

import $http from '@/api/fetch'
import 'mc-form/dist/assets/index.css'
import McForm, { setDefaultConfigs } from 'mc-form'

export default function install(Vue) {
  setDefaultConfigs({
    request: $http,

    ui: {
      size: 'small'
    },

    selector: {
      size: void 0
    },

    picker: {
      // 2.0.11版本不支持timestamp 默认回Date对象
      valueFormat: void 0
    }
  })

  Vue.component(McForm.name, McForm)
}
