<template>
  <div>
    <mc-form-item label="" label-width="0" :span="24">
      <mc-list :list="formData.frontList" @handleAdd="handleAdd">
        <template slot-scope="scope">
          <mc-form-item label="系统应用">
            <el-select v-model="scope.item.beGrantSysAppId" filterable>
              <el-option v-for="item in appList" :key="item.id" :label="item.appName" :value="item.id"></el-option>
            </el-select>
          </mc-form-item>
          <mc-form-item label="网关应用">
            <el-select v-model="scope.item.beGrantGateAppId">
              <el-option v-for="item in gateWayAppList" :key="item.appId" :label="item.appName" :value="item.id"></el-option>
            </el-select>
          </mc-form-item>
        </template>
      </mc-list>
    </mc-form-item>
    <mc-form-item label-width="0">
      <span class="text">暂不支持JWT认证和自定义认证</span>
    </mc-form-item>
  </div>
</template>

<script>
import { Front } from './model'
export default {
  props: {
    formData: {
      type: Object,
      default: () => ({})
    },
    appList: {
      type: Array,
      default: () => []
    },
    gateWayAppList: {
      type: Array,
      default: () => []
    }
  },
  methods: {
    handleAdd() {
      this.formData.frontList.push(new Front())
    }
  }
}
</script>

<style scoped lang="scss">
.text{
  color: $--color-info;
}
</style>
