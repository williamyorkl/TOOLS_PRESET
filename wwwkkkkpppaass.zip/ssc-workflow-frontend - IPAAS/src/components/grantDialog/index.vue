<template>
  <el-dialog :title="title" :visible.sync="visible" :width="width" :before-close="handleClose" v-if="visible">
    <mc-form ref="form" :model="formData" :rules="rules">
      <!-- 接口名 -->
      <mc-form-item componentType="ElInput" prop="apiName" :label="apiTypeName" :disabled="true" :span="24"></mc-form-item>
      <!-- 接口类型 -->
      <mc-form-item componentType="ElSelect" prop="beGrantType" label="接口类型" :dict="ApiTypeEnum" :disabled="true" :span="24"></mc-form-item>
      <component :is="currentComponent" :formData="formData" :appList="appList" :gateWayAppList="gateWayAppList" />
    </mc-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose">取 消</el-button>
      <el-button type="primary" @click="confirm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import Constant from '@/config/constant'
import { mapActions } from 'vuex'
import FrontGrant from './front-grant'
import BackGrant from './back-grant'
import appApi from '@/api/app/app'
import grantApi from '@/api/serviceStatement/grant'
import gatewayApp from '@/api/application'
import { regExpRules, validateFn, validateTableTreeData } from '@/utils/validator'

export default {
  name: 'EditDialog',
  components: { FrontGrant, BackGrant },
  props: {
    visible: {
      default: false,
      type: Boolean
    },
    title: {
      default: '新增',
      type: String
    },
    width: {
      default: '600px',
      type: String
    },
    formData: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      appList: [],
      gateWayAppList: [],
      rules: {},
      ApiTypeEnum: []
    }
  },
  watch: {
    visible: {
      async handler(nV) {
        if (nV) {
          if (this.$refs.form) {
            this.$refs.form.clearValidate()
          }
          [this.ApiTypeEnum] = await this.getDicts(['ApiTypeEnum'])
          // 获取两个选项列表
          this.getAppAll()
          this.getGatewayAppList()
        }
      },
      immediate: true
    }
  },
  computed: {
    apiTypeName() {
      return this.formData.beGrantType === 1 ? '用户接口名称' : '后端服务名称'
    },
    currentComponent() {
      return this.formData.beGrantType === 1 ? 'FrontGrant' : 'BackGrant'
    }
  },
  methods: {
    ...mapActions('new_dict', ['getDicts']),
    // 获取App列表，获取选中列表
    async getAppAll() {
      const { beGrantId, beGrantType } = this.formData
      const resp = await appApi.listApp({ beGrantId, beGrantType })
      this.appList = resp || []
    },
    // 获取网关应用列表
    async getGatewayAppList() {
      const resp = await gatewayApp.getAppAll({ authMethodList: [3, 4] })
      this.gateWayAppList = resp
    },
    handleClose(done) {
      this.$emit('update:visible', false)
    },
    confirm() {
      this.$refs.form.validate().then(async (valid) => {
        if (valid) {
          if (this.currentComponent === 'FrontGrant') {
            const validList = this.validateTreeTable(this.formData)
            if (!validList) return
          }
          await grantApi.apiGrant(this.formData)
          this.$message.success('授权完成')
          this.$emit('update:visible', false)
        } else {
          this.$message.error('请按照提示完善表单数据')
        }
      })
    },
    validateAppList(row, isTop) {
      if (!row.beGrantSysAppId) {
        return [false, '系统应用不能为空']
      }
      if (!row.beGrantGateAppId) {
        return [false, '网关应用不能为空']
      }
      return [true]
    },
    validateTreeTable(formData) {
      console.log(formData)
      const [valid, msg, rowIndex] = validateTableTreeData(formData.frontList, this.validateAppList)
      if (!valid) { this.$message.error(`请求参数-第${rowIndex}行：${msg}`) }
      if (valid) { return true }
    }
  }
}
</script>
