<template>
  <div>
    <mc-form-item componentType="ElSelect" prop="backList" label="系统应用" :dict="appList" valueKey="id" labelKey="appName" :editProps="{
        multiple: true,
        filterable: true
      }" :span="24"></mc-form-item>
  </div>
</template>

<script>
export default {
  props: {
    formData: {
      type: Object,
      default: () => ({})
    },
    appList: {
      type: Array,
      default: () => []
    }
  }
}
</script>

<style>
</style>
