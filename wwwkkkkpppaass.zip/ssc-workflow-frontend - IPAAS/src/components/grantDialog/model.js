export class Front {
  constructor() {
    this.beGrantSysAppId = null // 系统应用
    this.beGrantGateAppId = null // 网关应用
  }
}
