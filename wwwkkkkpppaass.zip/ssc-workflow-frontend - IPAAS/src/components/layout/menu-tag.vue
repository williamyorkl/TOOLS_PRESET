<template>
  <div>
    <div class="tab-box" ref="tabBox">
      <el-tag
        class="tab-item"
        ref="tab"
        :title="tab.label"
        v-for="(tab) in tabList"
        :key="tab.name + tab.query.id"
        :closable="tab.name !== 'home'"
        :type="currenTab.label == tab.label ? '' : 'info'"
        :id="tab.name"
        @close="handleClose(tab)"
        @click.native="handleClick(tab)"
        @contextmenu.prevent.native="openMenu(tab,$event)"
        :draggable="tab.name !== 'home'"
        @dragstart.native="handleDrag(tab, $event)"
        @drop.native="handleDrop(tab, $event)"
        @dragover.prevent.native
      >
        {{ ellipsisText(tab.label) }}
      </el-tag>
    </div>

    <ul class="contextmenu" v-show="visible" :style="{left:left+'px',top:top+'px'}">
      <li @click="closeSelectedTag(selectedTag)">关闭当前</li>
      <li @click="closeOthersTags(selectedTag)">关闭其他</li>
      <li @click="closeAllTags">关闭所有</li>
    </ul>
  </div>
</template>
<script>
/* eslint-disable */
export default {
  name: 'menutag',
  data() {
    return {
      breadList: [],
      currenTab: {},
      visible: false,  //右键弹框可见
      top: 0,  //弹框位置
      left: 0,
      selectedTag: {}, //当前选中弹框
    }
  },
  created() {
    // this.getBread()
    this.setTab()
  },
  methods: {
    ellipsisText(text, len = 15) {
      if (text.length > len) {
        return text.substr(0, len) + '...'
      } else {
        return text
      }
    },
    setTab() {
      if(this.$route.name === '登录' || this.$route.name === 'Page404') return
      const tab = {
        name: this.$route.name,
        meta: this.$route.meta,
        label: this.$route.meta.label,
        path: this.$route.path,
        query: this.$route.query,
        params: this.$route.params,
        fullPath: this.$route.fullPath
      }
      tab.label = tab.query.id ? (tab.label + '-' + tab.query.id) : tab.label // label使用名称和id拼接，在跳转详情页时要求必须使用id传参
      this.currenTab = tab
      const tabSourceIndex = this.tabList.findIndex(t => (t.fullPath == tab.fullPath))
      const tabSource = this.tabList[tabSourceIndex]
      if (!tabSource) {
        if (tab.name === 'home') {
          this.$store.commit('menutag/unshiftTab', tab)
        } else if(tab.name){
          this.$store.commit('menutag/pushTab', tab)
        }
      } else {
        // this.$store.commit('menutag/spliceAddTab', { tabSourceIndex, num: 1, tab })
          // this.$store.commit('menutag/pushTab', tab)
      }
      this.$nextTick(() => {
        if (tab.name) {
          this.scrollTab(tab.name)
        }

      })
    },
    scrollTab(name) {
      setTimeout(() => {
        document.getElementById(name).scrollIntoView({
          behavior: 'smooth',
          block: 'end',
          inline: 'nearest'
        })
      }, 500)
    },
    handleClose(tab) {
      if (tab.name === 'home') return
      const tabIndex = this.tabList.findIndex(t => ( t.fullPath == tab.fullPath))
      this.$store.commit('menutag/spliceTab', { tabIndex, num: 1 })
      this.$store.commit('SPLICE_KEEP_ALIVE_NAME', { name: tab.name })
      if (tab.name === this.$route.name) {
        this.navigatorPage(this.tabList[tabIndex - 1], true)
      }
    },
    handleClick(tab) {
      if (tab.fullPath === this.$route.fullPath) return
      this.navigatorPage(tab)
    },
    navigatorPage(tab) {
      const { path, query, params, name } = tab
      let meta = Object.assign({}, tab.meta)
      if (Object.keys(params).length) {
        this.$router.replace({
          name,
          meta,
          params,
          path
        })
      } else {
        this.$router.replace({
          name,
          meta,
          query,
          path
        })
      }
    },
    closeSelectedTag(view) {
      this.handleClose(view)
    },
    closeOthersTags(tab) {
      this.$store.commit('menutag/delOthersViews', tab)
      this.$router.push({path:tab.fullPath})
    },
    closeAllTags() {
      this.$store.commit('menutag/delAllViews')
      this.$router.push('/')
    },
    openMenu(tag, e) {
      const {pageX} = e // 相对于浏览器左上角的距离，减去左侧菜单的宽度
      const {width: leftMenuWidth} = document.querySelector('.sidebar').getBoundingClientRect() // 左侧菜单的宽度
      const {width: topbarWidth} = document.querySelector('.topbar').getBoundingClientRect()
      const menuWidth = 88 // 右键菜单的宽度;
      this.visible = true
      this.selectedTag = tag
      this.top = e.clientY
      this.left = pageX - leftMenuWidth + 18
      if(this.left > topbarWidth - menuWidth) {
        this.left = topbarWidth - menuWidth
      }
    },
    closeMenu() {
      this.visible = false
    },
    //可拖拽
    // 拖拽
    handleDrag(nav, event) {
      // const nav = this.tabList[index];
      if (nav) {
        event.dataTransfer.setData('tab-name', nav.name)
      }
    },
    handleDrop(nav, event) {
      // const nav = this.tabList[index];
      if (nav) {
        const dragName = event.dataTransfer.getData('tab-name')
        event.preventDefault()

        let navNames = this.tabList.map(item => item.name)
        const a = parseInt(navNames.findIndex(item => item === dragName))
        const b = parseInt(navNames.findIndex(item => item === nav.name))

        // navNames.splice(b, 1, ...navNames.splice(a, 1 , navNames[b]));
        // this.$emit('on-drag-drop', dragDrop')
        const params = {
          sIndex: a,
          eIndex: b
        }
        this.$store.commit('menutag/dragDrop', params)
      }
    }
  },
  computed: {
    tabList() {
      // console.log(this.$store.state.menutag.tabList)
      return this.$store.state.menutag.tabList
    }
  },
  watch: {
    $route(val) {
      this.setTab()
    },
    visible(value) {
      if (value) {
        document.body.addEventListener('click', this.closeMenu)
      } else {
        document.body.removeEventListener('click', this.closeMenu)
      }
    }
  },
}
</script>

<style lang="scss" scoped>
.tab-box {
  width: max-content;
  .tab-item {
    margin-right: 5px;
    cursor: pointer;
    // max-width: 120px;
    overflow: hidden;
    vertical-align: middle;
  }
}
.contextmenu {
  width: 88px;
  margin: 0;
  background: #fff;
  z-index: 999;
  position: absolute;
  list-style-type: none;
  padding: 5px 0;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 400;
  color: #333;
  box-shadow: 2px 2px 3px 0 rgba(0, 0, 0, 0.3);
  li {
    margin: 0;
    padding: 0 20px;
    line-height: 40px;
    cursor: pointer;
    &:hover {
      background: #eee;
    }
  }
}
</style>
