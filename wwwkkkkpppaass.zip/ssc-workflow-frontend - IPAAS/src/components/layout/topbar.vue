<template>
  <div class="topbar">
    <div class="top-info">
      <bread-crumb class="top-bread-crumb"></bread-crumb>
      <div class="top-app-name">{{appName}}</div>
      <!-- paas模式不显示用户名和退出 -->
      <template v-if="mode !== '__paas__' || mode === '__container__'">
        <el-dropdown @command="dropMenuClick">
          <span class="el-dropdown-link">
            {{userName}}<i class="el-icon-arrow-down el-icon--right"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item command="toggleApp">切换应用</el-dropdown-item>
            <el-dropdown-item command="logout">退出登录</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </template>
    </div>
    <div class="menu-tag">
      <menutag class="top-menu-tag"></menutag>
    </div>

  </div>
</template>
<script>
// import userModel from 'api/user/index.js'

import { getLocal } from 'utils/cache'
import menutag from './menu-tag'
import BreadCrumb from './breadcrumb'
import { mapState, mapMutations } from 'vuex'

const mode = process.env.VUE_APP_MODE
export default {
  name: 'topbar',
  data() {
    return {
      mode
    }
  },
  components: { menutag, BreadCrumb },
  computed: {
    appName: {
      get() {
        return this.$store.state.user.app.appName
      }
    },
    userName: {
      get() {
        let userName = ''
        const userInfo = this.$store.state.user.userInfo || {}
        if (userInfo && userInfo.jwtInfo) userName = userInfo.jwtInfo.userName || ''
        return userName
      }
    },
    platform: {
      get() {
        return {
          platformId: this.platformId,
          platformName: this.platformName
        }
      },
      set(data) {
        this.platformId = data.platformId
        this.platformName = data.platformName
      }
    }
  },

  mounted() {},
  methods: {
    ...mapMutations('common', ['SET_SALON_TOP']),
    dropMenuClick(command) {
      console.log(command)
      switch (command) {
        case 'logout':
          this.logoutHandle()
          break
        case 'toggleApp':
          this.toggleAppHandle()
          break
      }
    },
    showExport() {
      // 显示导出队列
      this.$store.commit('exportList/showExportList')
      this.$store.commit('exportList/setLoadingExportCount', 0)
    },
    beforeEnter(el) {
      const rect = document.getElementById('exportBtn').getBoundingClientRect()
      document.getElementById('exportBall').style.left =
        document.getElementById('exportBtn').getBoundingClientRect().left +
        'px'
      const x = document.body.clientWidth / 2 - rect.left + 130
      const y = document.body.clientHeight / 2 - rect.top + 50
      el.style.display = ''
      el.style.webkitTransform = `translate3d(0, ${y}px, 0)`
      el.style.transform = `translate3d(0, ${y}px, 0)`

      const inner = el.getElementsByClassName('inner')[0]
      inner.style.webkitTransform = `translate3d(${x}px, 0, 0)`
      inner.style.transform = `translate3d(${x}px, 0, 0)`
    },
    enter(el) {
      /* eslint-disable no-unused-vars */
      const rf = el.offsetHeight // 触发重绘才能有动画效果
      this.$nextTick(() => {
        el.style.webkitTransform = 'translate3d(0, 0, 0)'
        el.style.transform = 'translate3d(0, 0, 0)'

        const inner = el.getElementsByClassName('inner')[0]
        inner.style.webkitTransform = 'translate3d(0, 0, 0)'
        inner.style.transform = 'translate3d(0, 0, 0)'
      })
    },
    afterEnter(el) {
      this.$store.commit('exportList/endAnimation')
    },
    toggleAppHandle() {
      this.$store.commit('menutag/delAllViews')
      this.$router.push({ name: 'appList' })
    },
    logoutHandle() {
      this.$store.dispatch('user/logout')
      // 退出登录
      // userModel.logout({ userAccount: this.userName }).then(response => {
      //   this.$store.commit('menutag/delAllViews')
      //   this.$message({
      //     type: 'success',
      //     message: '退出成功',
      //     duration: 2000
      //   })
      //   this.$logout()
      // })
    }
  }
}
</script>
<style>
.topbar .export-box .el-badge__content {
  min-width: 6px;
}
</style>
<style lang="scss" scoped>
@import "../../styles/element-variables";
.topbar {
  position: -webkit-sticky;
  position: sticky;
  top: 0;
  // padding-left: 15px;
  // height: 56px;
  line-height: 56px;
  font-size: $--font-size-big;
  // border-bottom: 1px solid $--border-color-base;
  // background: $--color-white;
  z-index: 97;
  .el-dropdown-link{
    cursor: pointer;
  }
  .top-info {
    display: flex;
    box-shadow: 0px 2px 5px $--border-color-base;
    background-color: #fff;
    padding: 0 16px;
    z-index: 100;
    position: relative;
  }
  .menu-tag {
    box-shadow: 0px 2px 5px $--border-color-base;
    background-color: $--background-color-body;
    padding: 0 16px;
  }
  .top-bread-crumb {
    flex-grow: 1;
    flex-shrink: 1;
    line-height: 56px;
  }
  .top-app-name {
    margin-right: 20px;
    vertical-align: baseline;
  }
  .top-menu-tag {
    line-height: 46px;
    height: 48px;
    flex-grow: 1;
    flex-shrink: 1;
    overflow-x: auto;
    overflow-y: hidden;
    &::-webkit-scrollbar {
      height: 5x;
    }
  }
  .export-box {
    margin-left: 16px;
    width: 48px;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    .export-btn {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      position: relative;
      background: $--color-primary;
      overflow: hidden;
      transition: all 0.5s;
      img {
        width: 18px;
        position: relative;
        z-index: 2;
      }
      .download-animate {
        position: absolute;
        width: 100%;
        height: 100%;
        z-index: 1;
      }
      &.is-download {
        background: $--color-primary-light-7;
        .download-animate {
          background: $--color-primary-light-1;
          animation: download 2s infinite;
          animation-delay: 0.6s;
        }
      }
      &:hover {
        background: $--color-primary-light-3;
      }
    }
  }
  .platform-info {
    // width: 130px;
    padding-left: $--padding-base;
    flex-shrink: 0;
    font-size: $--font-size-big;
    color: $--color-text-regular;
    text-align: right;
  }
  .logInfo {
    // width: 250px;
    flex-shrink: 0;
    font-size: $--font-size-big;
    color: $--color-text-regular;
    .username{
      text-decoration: underline;
    }
    .line {
      margin: 0 15px;
    }
    .logout {
      color: $--color-text-regular;
      font-size: $--font-size-big;
    }
  }
}
.export-ball {
  position: fixed;
  z-index: 99;
  top: 12px;
  right: 232px;
  .inner {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: $--color-primary;
    transition: all 0.6s linear;
    display: flex;
    align-items: center;
    justify-content: center;
    img {
      width: 20px;
    }
  }
  &.drop-enter-active {
    /* 可以在上面的工具里跳出自己想要的曲线，调整参数 */
    transition: all 0.6s cubic-bezier(0, 1.18, 0.93, 1.08);
  }
}
.shop-name {
  // float: right;
  margin-left: 10px;
  display: flex;
  align-items: center;
  // height: 100%;
  .inner {
    background: $--color-primary;
    border-radius: 50%;
    width: 32px;
    height: 32px;
    display: flex;
    justify-content: center;
    color: #fff;
    align-items: center;
    cursor: pointer;
    img {
      width: 20px;
      height: 20px;
    }
  }
}
@keyframes download {
  from {
    transform: translateY(100%);
  }
  to {
    transform: translateY(0);
  }
}

.title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 30px;
  .title-right {
    display: flex;
    align-items: center;
    .el-input {
      width: 200px;
    }
    .el-button {
      height: 24px;
    }
  }
}
</style>
