<template>
  <div class="export-bar">
    <transition name="fade">
      <div class="export-bar-mask" v-show="showExportList" @click="hideExport"></div>
    </transition>
    <transition name="slide">
      <div class="export-bar-list" v-show="showExportList">
        <div class="list-container">
          <el-scrollbar style="height: 100%;" :native="false">
            <div class="list-head">
              <span>导出队列</span>
              <i class="el-icon-close" @click="hideExport"></i>
            </div>
            <div class="list-content">
              <export-item v-for="(item, index) in exportData" :key="index" :index="index" :export-data="item"></export-item>
            </div>
          </el-scrollbar>
        </div>
      </div>
    </transition>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import userModel from '@/api/user/index.js'
import ExportItem from './exportItem'

export default {
  name: 'exportbar',
  data () {
    return {
    }
  },
  components: { ExportItem },
  computed: {
    ...mapState({
      exportData: state => state.exportList.exportData,
      showExportList: state => state.exportList.showExportList
    })
  },
  created () {
    // userModel.logPass().then(response => {
    //   if (response.engDesc !== 'invalid-session') {
    //     this.$store.dispatch('exportList/getExportList')
    //   }
    // })
  },
  methods: {
    hideExport () {
      this.$store.commit('exportList/hideExportList')
    }
  }
}
</script>

<style>
  .export-bar-list .el-scrollbar__wrap {
    overflow-x: hidden;
  }
</style>
<style lang="scss" scoped>
  @import "../../styles/element-variables";
  .fade-enter-active, .fade-leave-active {
    transition: opacity .5s;
  }
  .fade-enter, .fade-leave-to {
    opacity: 0;
  }

  .slide-enter-active, .slide-leave-active {
    transition: transform .5s;
  }
  .slide-enter, .slide-leave-to {
    transform: translateX(100%);
  }

  .export-bar {
    position: relative;
    z-index: 98;
  }
  .export-bar-mask {
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.2);
  }
  .export-bar-list {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    background: #ffffff;
    width: 380px;
    .list-container {
      height: 100%;
      overflow: hidden;
      .list-head {
        line-height: 55px;
        font-size: $--font-size-biger;
        padding: 0 $--padding-base;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid $--border-color-light;
        i {
          cursor: pointer;
        }
      }
    }
  }
</style>
