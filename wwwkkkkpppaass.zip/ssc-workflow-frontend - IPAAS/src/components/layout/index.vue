<template>
  <div class="layout">
    <sidebar class="sidebar"></sidebar>
    <div class="main-content">
      <topbar></topbar>
      <router-view class="router-view"></router-view>
    </div>
    <div class="toggle-app" v-if="showToggleBtn">
      <i class="el-icon-menu" @click="handleToggleApp" title="切换应用"></i>
    </div>
  </div>
</template>
<script>
import Sidebar from './sideMenu/sidebar'
import Topbar from './topbar'
import { TENANT_ADMIN_MODE, LOGIN_MODE } from '@/config/enum'

export default {
  name: 'layout',
  data() {
    return {
      timer: null
    }
  },
  components: { Sidebar, Topbar },
  computed: {
    showToggleBtn() {
      return TENANT_ADMIN_MODE.includes(this.$store.state.user.userInfo.handlerName) && this.$store.state.user.backEndType === LOGIN_MODE.WEB_ADMIN
    }
  },
  methods: {
    handleToggleApp() {
      this.$store.commit('menutag/delAllViews')
      this.$router.push({ name: 'appList' })
    }
  }
}
</script>

<style lang="scss" scoped>
.layout {
  // position: relative;
  display: flex;
  .sidebar {
    flex-shrink: 0;
    // width: 240px;
    height: 100vh;
  }
  .main-content {
    flex-grow: 1;
    height: 100vh;
    overflow: auto;
    display: flex;
    flex-direction: column;
    .router-view{
      flex-grow: 1;
      height: calc(100vh - 104px);
    }
  }
  .toggle-app{
    position: fixed;
    bottom: 3px;
    right: 3px;
    z-index: 3000;
    &:hover{
      .el-icon-menu{
        color: $--color-success;
      }
    }
    .el-icon-menu{
      font-size: 30px;
      color: $--color-text-primary;
      cursor: pointer;
    }
  }

}
</style>
