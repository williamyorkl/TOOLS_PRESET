<template>
  <div class="sidebar" :class="{open: !isCollapse, close: isCollapse}" disabled>
    <div class="logo-block">
      <img v-if="
        NODE_ENV != 'beta' && NODE_ENV != 'development' && NODE_ENV != 'uat'
      " src="@/assets/platform-logo/sscMC.png" class="logo"
      >
      <img v-else src="@/assets/platform-logo/sscMC.png" class="logo">
    </div>
    <div class="menus">
      <!-- unique-opened -->
      <el-menu router :defaultOpeneds="openeds" :defaultActive="active" :collapse="isCollapse" class="el-menu-vertical-demo" :class="{isCollapse: isCollapse}">
        <ec-menu-item v-for="route in routes" :key="route.url" :route="route" parentPath="" />
      </el-menu>
    </div>
    <a class="doc-link" :href="docLink" target="_blank">
      <i class="link-icon iconfont icon-bangzhuwendang" /><span v-if="!isCollapse"> 使用文档 <i class="link-icon el-icon-top-right" /></span>
    </a>
    <div class="collapse" @click="toggleIsCollapse">
      <i :class="{ 'el-icon-arrow-left': !isCollapse , 'el-icon-arrow-right': isCollapse }" />
    </div>
  </div>
</template>
<script>
import EcMenuItem from './menu-item'
import { constantRoutes } from 'router/index'
import adminRoutes from 'router/routes.admin'
import baseRoutes from 'router/routes.base'
import { LOGIN_MODE } from '@/config/enum'

export default {
  name: 'Sidebar',
  data() {
    return {
      docLink: process.env.VUE_APP_DOC_LINK,
      menus: [],
      active: '',
      isCollapse: false,
      NODE_ENV: process.env.NODE_ENV,
      openeds: ['home'] // 菜单展开index
    }
  },
  components: { EcMenuItem },
  computed: {
    routes() {
      const backEndType = this.$store.state.user.backEndType
      let routes = backEndType === LOGIN_MODE.TENANT_ADMIN ? adminRoutes : constantRoutes
      routes = [...baseRoutes, ...routes]
      routes = routes.filter(route => !route.meta.hidden)
      return routes
    }
  },
  watch: {
    $route: {
      handler(nV) {
        const matched = nV.matched
        const len = matched.length
        this.openeds = nV.matched.map(item => item.name)
        if (matched && matched.length === 3) {
          // TODO - keepalive缓存三级菜单，目前只支持3级菜单，>3级菜单均不支持
          this.active = (matched[len - 2] || {}).name // 三级路由菜单的matched顺序有调整
        } else {
          this.active = (matched[len - 1] || {}).name
        }
      },
      immediate: true
    }
  },
  methods: {
    toggleIsCollapse() {
      this.isCollapse = !this.isCollapse
    }
  }
}
</script>
<style lang="scss" scoped>
@import "styles/element-variables";
.sidebar {
  display: flex;
  flex-direction: column;
  background: $--background-color-menu;
  position: relative;
  &.open {

    width: 240px;
  }
  &.close {
    width: 50px;
  }
  .isCollapse {
    ::v-deep span {
      display: none;
    }
  }
  .collapse {
    cursor: pointer;
    position: absolute;
    background: #c0c0c0;
    height: 50px;
    width: 10px;
    color: #fff;
    right: -10px;
    border-radius: 0 10px 10px 0;
    bottom: 50%;
    z-index: 0;
    i {
      font-size: 14px;
      font-weight: bold;
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      left: -2px;
    }
  }
  .logo {
    width: 80%;
  }
  .logo-block {
    text-align: center;
    line-height: 80px;
    flex-grow: 0;
  }
  .menus {
    width: 100%;
    flex-grow: 1;
    overflow-x: hidden;
    overflow-y: auto;
  }
}

.el-menu-vertical-demo:not(.el-menu--collapse) {
  min-height: 400px;
  width: 240px;
}
</style>
<style lang="scss">
@import "styles/element-variables";
.sidebar .el-menu {
  border-right: none;
  background: $--background-color-menu !important;
  .el-menu .el-submenu__title {
    font-size: $--font-size-base;
    height: 40px;
    line-height: 40px;
  }
}

.el-menu.el-menu-vertical-demo,
.el-submenu .el-menu-item {
  height: 40px;
  line-height: 40px;
  padding: 0;
  .checked-style {
    display: inline-block;
    span {
      font-weight: bold;
    }
  }
  .circle-dot {
    display: inline-block;
    width: 2px;
    height: 2px;
    margin: 10px 5px 10px 0;
  }
}

.el-menu-item {
  color: $--color-white !important;
  font-size: $--font-size-big !important;
}

.el-menu--popup{
  background: $--background-color-menu;
}

.el-menu-item.is-active {
  color: $--color-primary !important;
  background: inherit !important;
  .checked-style {
    display: inline-block;
    height: 100%;

  }
  span {
    font-weight: bold;
  }
}

.el-menu-item{
  i{
    margin-right: $--padding-small;
  }
}

.el-submenu__title {
  height: 48px;
  line-height: 48px;
  background: $--background-color-menu !important;
  color: $--color-white !important;
  font-size: $--font-size-big;
  // padding-left: 0 !important;
  i {
    margin-right: $--padding-small;
  }
}

.doc-link{
  display: inline-block;
  padding-left: 24px;
  line-height: 30px;
  color: #fff;
  font-size: 14px;
  cursor: pointer;
  i{
    color: #909399;
  }
  .link-icon{
    color: #fff;
  }
}
</style>
