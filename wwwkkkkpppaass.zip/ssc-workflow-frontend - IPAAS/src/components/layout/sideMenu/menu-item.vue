<template>
  <el-menu-item v-if="!hasChildren" :route="currentRoutePath" :key="route.actionName" :index="route.name">
    <i v-if="route.meta.icon" class="iconfont el-icon-icon" :class="route.meta.icon"></i>
    <span slot="title">{{route.meta.label}}</span>
  </el-menu-item>

  <el-submenu v-else :index="route.name" :key="route.path+route.actionName">
    <template slot="title">
      <i v-if="route.meta.icon" class="iconfont" :class="route.meta.icon"></i>
      <span slot="title">{{route.meta.label}}</span>
    </template>

    <ec-menu-item v-for="child in visibleChildren" :route="child" :parentPath="route.path" :key="child.path+child.actionName"></ec-menu-item>
  </el-submenu>

</template>

<script>
export default {
  name: 'ec-menu-item', // name：用来进行递归调用的组件名
  props: ['route', 'parentPath'],
  computed: {
    hasChildren() {
      return this.route.children && this.route.children.length > 0
    },
    visibleChildren() {
      if (!this.hasChildren) return []
      const visibleChildren = this.route.children.filter(route => !route.meta.hidden)
      return visibleChildren
    },
    currentRoutePath() {
      if (!this.parentPath) {
        return this.route.path
      } else if (this.route.path.startsWith('/')) {
        return this.route.path
      } else {
        return this.parentPath + '/' + this.route.path
      }
    }
  }
}
</script>

<style scoped lang="scss">
@import "styles/element-variables";
</style>
