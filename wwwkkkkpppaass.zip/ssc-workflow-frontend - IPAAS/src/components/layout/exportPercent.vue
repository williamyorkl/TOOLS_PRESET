<template>
  <el-progress type="circle" :percentage="percent || 0" :width="40" :stroke-width="3"></el-progress>
</template>

<script>
import exportModal from '@/api/common/export'

export default {
  name: 'export-percent',
  data () {
    return {
      percent: 0
    }
  },
  props: ['exportId', 'index'],
  created () {
    this.addPercent()
    this.checkStatus()
  },
  methods: {
    addPercent () { // 进度
      const percentInterval = setInterval(() => {
        this.percent = this.percent + 1
        if (this.percent >= 99) {
          clearInterval(percentInterval)
        }
      }, 80)
    },
    checkStatus () { // 导出任务状态
      exportModal.exportDetail(this.exportId).then(res => {
        if (res.data.status === 2 || res.data.status === -2) {
          this.$emit('export-finish')
          this.$store.commit('exportList/setExportData', { // 导出结束修改导出任务状态
            index: this.index,
            data: res.data
          })
          this.$store.commit('exportList/addExportCount') // 更新头部图标显示数量
          if (res.data.status === -2) {
            this.$message.error(res.errorMsg)
          }
        } else {
          setTimeout(() => {
            this.checkStatus()
          }, 1000)
        }
      })
    }
  }
}
</script>
