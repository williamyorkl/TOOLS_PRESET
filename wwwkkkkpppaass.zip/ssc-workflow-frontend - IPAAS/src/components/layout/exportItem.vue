<template>
  <div class="export-item">
    <div class="item-icon">
      <img src="../../assets/excel.png" alt="">
    </div>
    <div class="item-info">
      <p class="item-name">{{exportData.fileUrl || exportData.title}}</p>
      <p class="item-time">{{exportData.gmtCreate | formatTime}}<span v-if="exportData.status === -2" class="text-danger">&nbsp;&nbsp;&nbsp;&nbsp;导出失败</span></p>
    </div>
    <div class="item-status">
      <export-percent v-if="exportData.status === 1 || exportData.status === 0 || exportData.status === -1" :export-id="exportData.id" :index="index" @export-finish="exportFinish"></export-percent>
      <el-badge is-dot :hidden="!showDot" v-else-if="exportData.status === 2">
        <el-button type="primary" round @click="download(exportData.id)">下载</el-button>
      </el-badge>
      <el-badge is-dot :hidden="!showDot" v-else-if="exportData.status === -2">
        <el-button type="danger" round @click="reExport">重新导出</el-button>
      </el-badge>
    </div>
  </div>
</template>

<script>
import ExportPercent from './exportPercent'
import exportModal from '@/api/common/export'
import { formatTime } from '@/utils/filters'
export default {
  name: 'export-item',
  data () {
    return {
      percent: 0,
      showDot: false // 新完成的任务显示红点，点击下载或重新导出后隐藏
    }
  },
  filters: {
    formatTime
  },
  components: { ExportPercent },
  props: ['exportData', 'index'],
  created () {
  },
  methods: {
    exportFinish () {
      this.showDot = true
    },
    download (id) {
      this.showDot = false
      window.location.href = '/dataexporter-server/MainController/download/' + id
    },
    reExport () { // 重新导出
      this.showDot = false
      const params = {
        taskType: this.exportData.taskType,
        query: JSON.parse(this.exportData.params.split(';loginToken:')[0].split('query:')[1])
      }
      if (params.query.pageIndex != undefined) delete params.query.pageIndex
      if (params.query.pageSize != undefined) delete params.query.pageSize
      exportModal.begin(params).then(res => { // 传参taskType和query条件
        if (res.success) {
          const taskId = res.data
          this.$store.dispatch('exportList/addExport', {
            id: taskId
          })
        } else {
          Message.error(res.errorMSG || res.errMsg)
        }
      })
    }
  }
}
</script>

<style scoped lang="scss">
  @import "../../styles/element-variables";
  .export-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: $--padding-base;
    border-bottom: 1px solid $--border-color-light;
    .item-icon {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: $--color-success;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-right: $--padding-base;
      flex-shrink: 0;
      img {
        width: 24px;
      }
    }
    .item-info {
      flex: 1;
      .item-name {
        margin-bottom: 4px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .item-time {
        color: $--color-text-secondary;
      }
    }
    .item-status {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 82px;
      .el-button {
        width: 82px;
      }
    }
  }
</style>
