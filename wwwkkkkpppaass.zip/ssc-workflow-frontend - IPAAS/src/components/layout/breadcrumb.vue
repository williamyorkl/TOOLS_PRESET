
<template>
  <el-breadcrumb
    class="app-breadcrumb"
    separator="/"
  >
    <transition-group name="breadcrumb">
      <el-breadcrumb-item
        v-for="(item,index) in levelList"
        :key="item.path + index"
      >
        <span
          v-if="item.redirect===&quot;noredirect&quot;||index==levelList.length-1"
          class="no-redirect"
        >{{ item.meta.label }}</span>
        <router-link
          class="redirect"
          v-else
          :to="item.redirect||item.path"
        >
          {{ item.meta.label }}
        </router-link>
      </el-breadcrumb-item>
    </transition-group>
  </el-breadcrumb>
</template>

<script>
export default {
  created() {
    this.getBreadcrumb()
  },
  data() {
    return {
      levelList: null
    }
  },
  watch: {
    $route() {
      this.getBreadcrumb()
    }
  },
  methods: {
    // generateTitle,
    getBreadcrumb() {
      let matched = this.$route.matched.filter(item => {
        return item.meta.label
      })

      const len = matched.length
      if (len <= 0) return

      // TODO - keepalive缓存三级菜单，目前只支持3级菜单，>3级菜单均不支持
      if (len === 3) {
        this.levelList = [{ path: '/', meta: { label: 'iPaaS平台' } }].concat(matched[len - 2].meta.breadcrumbs)
        return
      }

      if (matched[len - 1].meta.breadcrumbs) {
        this.levelList = [{ path: '/', meta: { label: 'iPaaS平台' } }].concat(matched[len - 1].meta.breadcrumbs)
      } else {
        const first = matched[0]
        if (first && first.meta.label !== 'iPaaS平台') {
          matched = [{ path: '/', meta: { label: 'iPaaS平台' } }].concat(
            matched
          )
        }
        this.levelList = matched
      }
    }
  }
}
</script>

<style type="text/scss" lang="scss" scoped>
@import "../../styles/element-variables";
.app-breadcrumb.el-breadcrumb {
  // display: inline-block;
  // font-size: 14px;
  // margin-left: 10px;
  .redirect {
    font-weight: normal;
    color: $--color-text-regular;
  }

  .no-redirect {
    color: $--color-text-secondary;
    cursor: text;
  }
}
</style>
