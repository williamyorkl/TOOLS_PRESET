<template>
  <div id="app">
    <layout v-if="!isLevelTop && $route.name"></layout>
    <router-view v-if="isLevelTop" />
  </div>
</template>

<script>
import layout from 'components/layout'
import checkVersion from '@/utils/checkVersion'

export default {
  name: 'App',
  components: {
    layout
  },
  created() {
    // console.log(this.$route)
  },
  watch: {
    $route: {
      handler(val) {
        console.log(val)
      },
      immediate: true
    }
  },
  mounted() {
    if (process.env.NODE_ENV === 'production') {
      checkVersion()
    }
  },
  computed: {
    isLevelTop() {
      return this.$route.meta.isLevelTop
    }
  }
}

</script>

<style>
</style>
