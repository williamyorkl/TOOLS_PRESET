/* Layout */
// import Layout from '@/components/layout'
import ViewRouter from 'views/common/viewRouter.vue'
// import EmptyPage from '@/base_components/empty-page/emptyPage.vue'

const Page404 = () => import('views/common/error/404')

export default [
  {
    path: '/applist',
    name: 'appList',
    component: () => import('@/views/applist/applist'),
    meta: {
      label: '应用列表',
      hidden: true,
      keepAlive: false,
      icon: 'el-icon-s-home',
      isLevelTop: true
    }
  },
  {
    path: '/gateway',
    name: 'gateway',
    component: ViewRouter,
    meta: {
      label: '网关管理',
      hidden: false,
      keepAlive: true,
      icon: 'icon-wangguan',
      renderSubMenu: true
    },
    redirect: {
      name: 'ForwardArrangeList'
    },
    children: [
      {
        path: 'forwardArrangeList',
        name: 'ForwardArrangeList',
        component: () => import('views/gateway/forwardArrange/forwardArrange.vue'),
        meta: {
          label: '路由管理',
          keepAlive: true
        }
      },
      {
        path: 'application',
        name: 'Application',
        component: () => import('views/gateway/application/application.vue'),
        meta: {
          label: '网关应用',
          keepAlive: true
        }
      },
      {
        path: 'gatewayLog',
        name: 'GatewayLog',
        component: () => import('views/gateway/log/index.vue'),
        meta: {
          label: '运行日志',
          keepAlive: true
        }
      },
      {
        path: 'nodeLog',
        name: 'NodeLog',
        component: () => import('views/gateway/log/components/nodeLog'),
        meta: {
          label: '日志信息',
          keepAlive: true,
          hidden: true,
          breadcrumbs: [
            { path: 'forwardArrangeList', meta: { label: '网关管理' } },
            { path: 'gatewayLog', meta: { label: '运行日志' } },
            { path: 'nodeLog', meta: { label: '日志信息' } }
          ]
        }
      },
      {
        path: 'warnLog',
        name: 'WarnLog',
        component: () => import('views/gateway/warn/index.vue'),
        meta: {
          label: '异常统计',
          keepAlive: true
        }
      },
      {
        path: 'chainList',
        name: 'ChainList',
        component: () => import('views/gateway/warn/chain/index.vue'),
        meta: {
          label: '节点异常日志',
          keepAlive: true,
          hidden: true,
          breadcrumbs: [
            { path: 'forwardArrangeList', meta: { label: '网关管理' } },
            { path: 'warnLog', meta: { label: '异常监控' } },
            { path: 'chainList', meta: { label: '节点异常日志' } }
          ]
        }
      },
      {
        path: 'errNodeLog',
        name: 'ErrNodeLog',
        component: () => import('views/gateway/log/components/nodeLog'),
        meta: {
          label: '异常日志信息',
          keepAlive: true,
          hidden: true,
          breadcrumbs: [
            { path: 'forwardArrangeList', meta: { label: '网关管理' } },
            { path: 'warnLog', meta: { label: '异常监控' } },
            { path: 'chainList', meta: { label: '节点异常日志' } },
            { path: 'errNodeLog', meta: { label: '异常日志信息' } }
          ]
        }
      },
      {
        path: 'monitor',
        name: 'Monitor',
        component: () => import('views/gateway/monitor/monitor.vue'),
        meta: {
          label: '告警设置',
          keepAlive: true
        }
      },
      {
        path: 'inspect',
        name: 'Inspect',
        component: () => import('views/gateway/inspect/inspect.vue'),
        meta: {
          label: '巡检任务',
          keepAlive: true
        }
      },
      {
        path: 'debug1',
        name: 'GlobalDebug',
        component: () => import('views/gateway/debug/index.vue'),
        meta: {
          label: 'debug调试',
          keepAlive: true,
          hidden: true
        }
      }
    ]
  },
  {
    path: '/arrange',
    name: 'Arrange',
    component: ViewRouter,
    meta: {
      label: '编排管理',
      hidden: false,
      keepAlive: true,
      renderSubMenu: true,
      icon: 'icon-fuwubianpai-chunsezi'
    },
    redirect: {
      name: 'ServiceArrangeList'
    },
    children: [
      {
        path: 'serviceArrangeDetail',
        name: 'ServiceArrangeDetail',
        // component: () => import('views/arrange/serviceArrange/detail/index.vue'),
        component: () => import('views/arrange/arrangeDetail/index.vue'),
        meta: {
          label: '服务编排配置',
          keepAlive: true,
          hidden: true,
          breadcrumbs: [
            { path: 'serviceArrangeList', meta: { label: '编排管理' } },
            { path: 'serviceArrangeList', meta: { label: '服务编排' } },
            { path: 'serviceArrangeDetail', meta: { label: '服务编排配置' } }
          ]
        }
      },
      {
        path: 'serviceArrangeList',
        name: 'ServiceArrangeList',
        component: () => import('views/arrange/serviceArrange/serviceArrange.vue'),
        meta: {
          label: '服务编排',
          keepAlive: true
        }
      },
      {
        path: 'serviceGroup',
        name: 'ServiceGroup',
        component: () => import('views/arrange/serviceGroup/serviceGroup.vue'),
        meta: {
          label: '服务分组',
          keepAlive: true
        }
      },
      {
        path: 'breakPoint',
        name: 'BreakPoint',
        component: () => import('views/arrange/breakPoint/breakPoint.vue'),
        meta: {
          label: '重试任务',
          keepAlive: true
        }
      },
      {
        path: 'arrangeLog',
        name: 'ArrangeLog',
        component: () => import('views/arrange/arrangeLog/arrangeLog.vue'),
        meta: {
          label: '编排日志',
          keepAlive: true,
          hidden: true
        }
      },
      {
        path: 'arrangeSnapshot',
        name: 'ArrangeSnapshot',
        component: () => import('views/arrange/arrangeSnapshot/arrangeSnapshot.vue'),
        meta: {
          label: '编排快照',
          keepAlive: true,
          hidden: true
        }
      },
      {
        path: 'arrangeDetail',
        name: 'ArrangeDetail',
        component: () => import('views/arrange/arrangeSnapshot/arrangeSnapshot.vue'),
        meta: {
          label: '编排详情',
          keepAlive: true,
          hidden: true
        }
      },
      {
        path: 'notice',
        name: 'Notice',
        component: () => import('views/arrange/notice/notice.vue'),
        meta: {
          label: '服务变动通知',
          keepAlive: true
        }
      },
      {
        path: 'debug',
        name: 'Debug',
        component: () => import('views/arrange/serviceArrange/debug/index.vue'),
        meta: {
          label: 'debug调试',
          keepAlive: true,
          hidden: true
        }
      }
    ]
  },

  {
    path: '/integrate',
    name: 'Integrate',
    component: ViewRouter,
    meta: {
      label: '集成管理',
      hidden: false,
      keepAlive: true,
      renderSubMenu: true,
      icon: 'icon-shujujicheng'
    },
    redirect: {
      name: 'IntegrationApp'
    },
    children: [
      {
        path: 'integrationApp',
        name: 'IntegrationApp',
        component: () => import('views/logicArrange/integrationApp/index.vue'),
        meta: {
          label: '集成应用',
          keepAlive: true
        }
      },
      {
        path: 'data',
        name: 'Data',
        component: ViewRouter,
        redirect: {
          name: 'DispatchArrangeList'
        },
        meta: {
          label: '数据集成',
          keepAlive: true
        },
        children: [
          {
            path: '/integrate/data/dispatchArrangeList',
            name: 'DispatchArrangeList',
            component: () => import('views/logicArrange/dispatchArrangeList/index.vue'),
            meta: {
              label: '定时集成',
              keepAlive: true,
              breadcrumbs: [
                { path: 'integrate', meta: { label: '集成管理' } },
                { path: 'data', meta: { label: '数据集成' } },
                { path: 'DispatchArrangeList', meta: { label: '定时集成' } }
              ]
            }
          },
          {
            path: '/integrate/data/cdcArrangeList',
            name: 'CdcArrangeList',
            component: () => import('views/logicArrange/cdcArrangeList/index.vue'),
            meta: {
              label: '实时集成',
              keepAlive: true,
              breadcrumbs: [
                { path: 'integrate', meta: { label: '集成管理' } },
                { path: 'data', meta: { label: '数据集成' } },
                { path: 'DispatchArrangeList', meta: { label: '定时集成' } }
              ]
            }
          }
        ]
      },
      {
        path: 'mqArrangeList',
        name: 'MqArrangeList',
        component: () => import('views/logicArrange/mqArrangeList/index.vue'),
        meta: {
          label: '消息集成',
          keepAlive: true
        }
      },

      {
        path: 'arrange-tpl',
        name: 'ArrangeTpl',
        component: () => import('views/platformConfig/arrange-tpl/index.vue'),
        meta: {
          label: '模板管理',
          keepAlive: true
        }
      },
      {
        path: 'CDCList',
        name: 'CDCList',
        component: () => import('views/datasource/CDC/cdc.vue'),
        meta: {
          label: 'CDC配置',
          keepAlive: true
        }
      }
    ]
  },

  {
    path: '/serviceRegister',
    name: 'serviceRegister',
    component: ViewRouter,
    meta: {
      label: '服务注册',
      hidden: false,
      keepAlive: true,
      renderSubMenu: true,
      icon: 'icon-rpc'
    },
    redirect: {
      name: 'RegistryCenter'
    },
    children: [
      {
        path: 'registryCenter',
        name: 'RegistryCenter',
        component: () => import('views/serviceRegister/registryCenter/registryCenter.vue'),
        meta: {
          label: '注册中心',
          keepAlive: true
        }
      },
      {
        path: 'serviceStatementList',
        name: 'ServiceStatementList',
        component: () => import('views/serviceRegister/serviceStatement/index.vue'),
        meta: {
          label: '服务声明',
          keepAlive: true
        }
      },
      {
        path: 'interfaceManageList',
        name: 'InterfaceManageList',
        component: () => import('views/serviceRegister/interfaceManage/index.vue'),
        meta: {
          label: '后端服务',
          keepAlive: true
        }
      },
      {
        path: 'apiGrant',
        name: 'ApiGrant',
        component: () => import('views/serviceRegister/apiGrant/index.vue'),
        meta: {
          label: '授权接口',
          keepAlive: true
        }
      },
      {
        path: 'auth',
        name: 'Auth',
        component: () => import('views/serviceRegister/auth/index.vue'),
        meta: {
          label: '全局认证',
          keepAlive: true
        }
      }
    ]
  },
  {
    path: '/model',
    name: 'Model',
    component: ViewRouter,
    meta: {
      label: '技术模型',
      hidden: false,
      keepAlive: true,
      renderSubMenu: true,
      icon: 'icon-moxingguanli-02'
    },
    redirect: {
      name: 'FieldModel'
    },
    children: [
      {
        path: 'field-model',
        name: 'FieldModel',
        component: () => import('views/model/field-model/index.vue'),
        meta: {
          label: '数据模型',
          keepAlive: true
        }
      },
      {
        path: 'domain-model',
        name: 'DomainModel',
        component: () => import('views/model/domain-model/index.vue'),
        meta: {
          label: '领域模型',
          keepAlive: true
        }
      }
    ]
  },
  {
    path: '/datasource',
    name: 'Datasource',
    component: ViewRouter,
    meta: {
      label: '数据源管理',
      hidden: false,
      keepAlive: true,
      renderSubMenu: true,
      icon: 'icon-shujuyuanguanli'
    },
    redirect: {
      name: 'Database'
    },
    children: [
      {
        path: 'database',
        name: 'Database',
        component: () => import('views/datasource/database/database.vue'),
        meta: {
          label: 'DB数据源',
          keepAlive: true
        }
      },
      {
        path: 'mq',
        name: 'Mq',
        component: () => import('views/datasource/mq/mq.vue'),
        meta: {
          label: 'MQ数据源',
          keepAlive: true
        }
      },
      {
        path: 'cachedDatabase',
        name: 'CachedDatabase',
        component: () => import('views/datasource/cached-database/cached-database.vue'),
        meta: {
          label: '缓存数据源',
          keepAlive: true
        }
      },
      {
        path: 'mappingDict',
        name: 'MappingDict',
        component: () => import('views/datasource/mappingDict/mappingDict.vue'),
        meta: {
          label: '字段映射管理',
          keepAlive: true
        }
      }
    ]
  },
  // {
  //   path: '/model',
  //   name: 'Model',
  //   component: ViewRouter,
  //   meta: {
  //     label: '模型管理',
  //     hidden: false,
  //     keepAlive: true,
  //     renderSubMenu: true,
  //     icon: 'icon-chanpinmoxing'
  //   },
  //   redirect: {
  //     name: 'DataModel'
  //   },
  //   children: [
  //     {
  //       path: 'dataModel',
  //       name: 'DataModel',
  //       component: EmptyPage,
  //       meta: {
  //         label: '数据模型',
  //         keepAlive: true
  //       }
  //     },
  //     {
  //       path: 'businessModel',
  //       name: 'BusinessModel',
  //       component: EmptyPage,
  //       meta: {
  //         label: '业务模型',
  //         keepAlive: true
  //       }
  //     }
  //   ]
  // },
  {
    path: '/statistical',
    name: 'Statistical',
    component: ViewRouter,
    meta: {
      label: '统计报表',
      hidden: false,
      keepAlive: true,
      icon: 'icon-baobiao',
      renderSubMenu: true
    },
    redirect: {
      name: 'BusinessApi'
    },
    children: [
      {
        path: 'statistic-api',
        name: 'BusinessApi',
        component: () => import('views/statistics/businessApi/businessApi.vue'),
        meta: {
          label: '集成流报表',
          keepAlive: true
        }
      }, {
        path: 'statistic-api1',
        name: 'ServiceApi',
        component: () => import('views/statistics/serviceApi/serviceApi.vue'),
        meta: {
          label: '后端服务报表',
          keepAlive: true
        }
      }
    ]
  },
  {
    path: '/platformConfig',
    name: 'PlatformConfig',
    component: ViewRouter,
    meta: {
      label: '平台配置',
      hidden: false,
      keepAlive: true,
      renderSubMenu: true,
      icon: 'icon-peizhi'
    },
    redirect: {
      name: 'GlobalConfig'
    },
    children: [
      {
        path: 'globalConfig',
        name: 'GlobalConfig',
        component: () => import('views/platformConfig/globalConfig/globalConfig.vue'),
        meta: {
          label: '全局配置',
          keepAlive: true
        }
      },
      {
        path: 'global-variables',
        name: 'GlobalVariables',
        component: () => import('views/platformConfig/global-variables/global-variables.vue'),
        meta: {
          label: '全局变量',
          keepAlive: true
        }
      },
      {
        path: 'func',
        name: 'Func',
        component: () => import('views/platformConfig/func/func.vue'),
        // component: () => import('views/arrange/func/func.vue'),
        meta: {
          label: '函数库',
          keepAlive: true
        }
      },
      {
        path: 'contact',
        name: 'Contact',
        component: () => import('views/platformConfig/contact/contact.vue'),
        meta: {
          label: '联系人管理',
          keepAlive: true
        }
      },
      {
        path: 'resStruct',
        name: 'ResStruct',
        component: () => import('views/platformConfig/resStruct/resStruct.vue'),
        meta: {
          label: '响应码结构',
          keepAlive: true
        }
      },
      {
        path: 'resInfo',
        name: 'ResInfo',
        component: () => import('views/platformConfig/resInfo/resInfo.vue'),
        meta: {
          label: '响应码信息',
          keepAlive: true
        }
      },
      // {
      //   path: 'resTranslate',
      //   name: 'ResTranslate',
      //   component: () => import('views/platformConfig/resTranslate/resTranslate.vue'),
      //   meta: {
      //     label: '响应码翻译',
      //     keepAlive: true
      //   }
      // },
      {
        path: 'migrate',
        name: 'Migrate',
        component: () => import('views/platformConfig/migrate/migrate.vue'),
        meta: {
          label: '环境迁移',
          keepAlive: true
        }
      },
      {
        path: 'arrange-tpl-set',
        name: 'ArrangeTplSet',
        component: () => import('views/platformConfig/arrange-tpl-set/index.vue'),
        meta: {
          label: '模板设置',
          keepAlive: true,
          hidden: true
        }
      },
      {
        path: 'arrange-tpl-tour',
        name: 'ArrangeTplTour',
        component: () => import('views/platformConfig/arrange-tpl-tour/index.vue'),
        meta: {
          label: '生成编排',
          keepAlive: true,
          hidden: true
        }
      }
      // 屏蔽发号器功能
      // {
      //   path: 'pk',
      //   name: 'Pk',
      //   component: () => import('views/platformConfig/pk/index.vue'),
      //   meta: {
      //     label: '发号器',
      //     keepAlive: true,
      //     hidden: false
      //   }
      // }
    ]
  },
  {
    path: '/test',
    name: 'Test',
    component: ViewRouter,
    meta: {
      label: '测试',
      hidden: true,
      keepAlive: false,
      icon: 'icon-'
    },
    redirect: {
      name: 'Test1'
    },
    children: [
      {
        path: 'test1',
        name: 'Test1',
        component: () => import('views/test/table/table.vue'),
        meta: {
          label: '测试table连线'
        }
      }
    ]
  },
  {
    path: '/template',
    name: 'Template1',
    component: ViewRouter,
    meta: {
      label: '模板',
      hidden: true,
      keepAlive: true,
      icon: 'icon-ziduanyingshe'
    },
    redirect: {
      name: 'Template1'
    },
    children: [
      {
        path: 'template1',
        name: 'Template1',
        component: () => import('views/template/template1/template1.vue'),
        meta: {
          label: '模板1',
          keepAlive: true
        }
      }, {
        path: 'template2',
        name: 'Template2',
        component: () => import('views/template/template2/template2.vue'),
        meta: {
          label: '模板1',
          keepAlive: true
        }
      }, {
        path: 'template-u-table-original',
        name: 'template-u-table-original',
        component: () => import('views/template/template-u-table-original/index.vue'),
        meta: {
          label: 'utable虚拟表格-original',
          keepAlive: true
        }
      }, {
        path: 'template-u-table',
        name: 'template-u-table',
        component: () => import('views/template/template-u-table/index.vue'),
        meta: {
          label: 'mc-table虚拟表格',
          keepAlive: true
        }
      }, {
        path: 'page',
        name: 'Page',
        component: () => import('views/template/template-page/index.vue'),
        meta: {
          label: '页面模板',
          keepAlive: true
        }
      }, {
        path: 'node',
        name: 'Node',
        component: () => import('views/arrange/arrangeDetail/index.vue'),
        meta: {
          label: '流程1',
          keepAlive: true
        }
      }
    ]
  },
  {
    path: '*',
    component: Page404,
    name: 'Page404',
    meta: {
      label: 'Error 404',
      hidden: true,
      keepAlive: true,
      icon: 'el-icon-location'
    }
  }
]
