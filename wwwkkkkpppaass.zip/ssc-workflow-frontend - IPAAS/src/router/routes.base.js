export default [
  {
    path: '/',
    name: 'home',
    component: () => import('@/views/home/home'),
    meta: {
      label: 'iPaaS平台',
      hidden: false,
      keepAlive: true,
      icon: 'el-icon-s-home'
    }
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/login/login'),
    meta: {
      label: '登录',
      hidden: true,
      keepAlive: false,
      icon: 'el-icon-s-home',
      isLevelTop: true
    }
  }
]
