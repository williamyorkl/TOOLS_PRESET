import Vue from 'vue'
import Router from 'vue-router'
import Message from 'element-ui'
import { regExpRules } from '@/utils/validator'

import totalRoutes from './routes.total'
// import srmRoutes from './routes.srm'
import adminRoutes from './routes.admin'
import baseRoutes from './routes.base'

const originalPush = Router.prototype.push

Router.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}

Vue.use(Router)

// export const constantRoutes = process.env.VUE_APP_IS_SRM ? srmRoutes : totalRoutes
export const constantRoutes = totalRoutes
const routes = [...baseRoutes, ...adminRoutes, ...constantRoutes]

const router = new Router({
  mode: 'hash',
  routes
})
console.log(routes)

// 捕获加载js失败
router.onError(error => {
  const isChunkLoadFailed = error.message.match(regExpRules.chunkLoadError)
  if (isChunkLoadFailed) {
    Message.warning('版本发生变化，请刷新页面！')
  }
})

export default router
