##keepAlive
>#####功能说明：从列表页进入详情页，返回上一页时需保留之前的页面状态

####使用方法

1. **<keep-alive>** 组件中，使用 **include** 参数对组件进行缓存，并且设置最大缓存数为 10；

``` html
<!-- /src/components/layout/index.vue -->
<keep-alive max="10" :include="keepAliveNames">
  <router-view/>
</keep-alive>
```

2. 在 **route** 配置内增加 **keepAlive** 自定义字段；

``` javascript
// /src/router/index.js
{
  path: 'orderList',
  name: 'orderList',
  component: OrderList,
  meta: {
    label: '订单列表',
    hidden: false,
    keepAlive: true
  }
}
```

3. 注意，组件内的组件名 **name** 字段的值，需要与路由中定义的路由名相同，因为 **<keep-alive>** 的 **include** 参数取的是组件名；

``` javascript
// /src/views/order/order-list.vue
export default {
  name: 'orderList',
  ···
  ···
}
```

4. 有时候需要在当前页面组件跳转其他页面前删除当前页面的缓存，可在跳转前执行以下代码即可删除当前页面的缓存；

``` javascript
const tabObj= this.tabList.find(t => t.name === this.$route.name)
if(!!tabObj) {
  this.$store.commit('SPLICE_KEEP_ALIVE_NAME', { name: tabObj.name })
}
```

  只要调用 **SPLICE_KEEP_ALIVE_NAME** mutation，就可以删除任何页面的 <keep-alive> 缓存。

##breadCrumb
>#####功能说明：根据页面层级设置面包屑。由于router配置无法保证是根据实际页面层级来配置的，所以不能直接通过$route.matched来获取面包屑。此方法根据router配置中的自定义route层级，来存储用户的访问记录，展示面包屑

####使用方法
1. 首页route设置breadNumber为0
2. 根据实际页面层级设置对应route的breadNumber（不设置默认为1）

#####示例
``` json
{
	path: '/shop',
	name: 'shop',
	component: Layout,
	meta: {
		label: '店铺管理'
	},
	children: [{
		path: 'my-shop',
		name: 'myShop',
		component: MyShop,
		meta: {
			label: '我的店铺'
		}
	},{
		path: 'my-shop/detail/:shopId',
		name: 'myShopDetail',
		component: MyShopDetail,
		meta: {
			breadNumber: 2,
			label: '店铺详情'
		}
	}]
}
```

####详细实现
1. store添加breadCrumb模块。为避免刷新页面数据丢失，需要使用sessionStorage。

   ``` javascript
	const state = {
	  breadListState: [{
	    name: '首页',
	    path: '/'
	  }]
	};

	const mutations = {
	  breadListMutations (getters, list) {
	    getters.breadListState = list;
	    sessionStorage.setItem('breadListStorage', list);
	  }
	};

	const actions = {
	};

	const getters = {
	  breadListState: state => {
	    return JSON.parse(sessionStorage.getItem('breadListStorage')) || state.breadListState.concat();
	  }
	};

	export default {
	  namespaced: true,
	  getters,
	  state,
	  mutations,
	  actions
	};
   ```

2. router配置内对应页面添加需要的层级配置breadNumber。
3. 添加breadCrumb组件，内使用el-breadcrumb组件
   1. getBread
      - 获取当前route的breadNumber
      - 根据route.fullPath和label创建新的面包屑
      - store.getters获取已有面包屑
      - 使用splice根据breadNumber替换新的面包屑
      - store.commit保存面包屑
      - 给组件得面包屑数据赋值最新值
   2. 监听$route调用getBread
   3. created调用getBread

   ``` vue
	<template>
	  <el-breadcrumb>
	    <el-breadcrumb-item
	      v-for="(item, index) in breadList"
	      :key="item.id"
	      separator="/"
	      :to="{ path: item.path }">{{item.name}}</el-breadcrumb-item>
	  </el-breadcrumb>
	</template>
	<script>
	  export default {
	    name: 'BreadCrumb',
	    data () {
	      return {
	        breadList: []
	      }
	    },
	    created () {
	      this.getBread()
	    },
	    methods:{
	      getBread () {
	        var breadNumber= typeof(this.$route.meta.breadNumber) != 'undefined' ? this.$route.meta.breadNumber : 1 //默认为1
	        var newBread= {
	          name: this.$route.meta.label,
	          path: this.$route.fullPath
	        } // 当前页面的
	        var breadList = this.$store.getters['breadCrumb/breadListState'] // 获取breadList数组

	        breadList.splice(breadNumber, breadList.length - breadNumber, newBread)
	        var breadList = JSON.stringify(breadList)
	        this.$store.commit('breadCrumb/breadListMutations',breadList)
	        this.breadList = this.$store.getters['breadCrumb/breadListState']
	      }
	    },
	    watch:{
	      $route () {
	        this.getBread()
	      }
	    }
	  }
	</script>
	```
