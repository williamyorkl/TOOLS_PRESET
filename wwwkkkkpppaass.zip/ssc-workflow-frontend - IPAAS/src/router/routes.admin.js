export default [
  {
    path: '/admin/system-app',
    name: 'adminSysApp',
    component: () => import('@/views/admin/app'),
    meta: {
      label: '系统应用',
      hidden: false,
      keepAlive: true,
      icon: 'el-icon-menu'
    }
  },
  {
    path: '/admin/user',
    name: 'adminUser',
    component: () => import('@/views/admin/user'),
    meta: {
      label: '用户管理',
      hidden: false,
      keepAlive: true,
      icon: 'el-icon-user-solid'
    }
  }
]
