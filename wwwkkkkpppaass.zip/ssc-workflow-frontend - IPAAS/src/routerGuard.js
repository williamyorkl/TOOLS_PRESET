import qs from 'qs'
import router from './router'
import store from 'store'
import { getLocal, removeLocal } from '@/utils/cache'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import adminRoute from '@/router/routes.admin'
import { LOGIN_MODE, TENANT_ADMIN_MODE } from '@/config/enum'

import { Message } from 'element-ui'
import cookiejs from './utils/cookie'

const queryObj = qs.parse(location.search, { ignoreQueryPrefix: true })
const redirectUrl = window.location.origin + process.env.VUE_APP_PUBLIC_PATH

const adminRouteNames = adminRoute.map(item => item.name)
// let token = ''
// if (window.top && window.top.getCloudToken) {
//   token = top.getCloudToken()
// }

// 显示跳转进度条
router.beforeEach((to, from, next) => {
  if (premissionRoute(to.name)) {
    NProgress.start()
    next()
  } else {
    router.push({ name: 'home' })
  }
})

router.beforeEach((to, from, next) => {
  const isLogining = getLocal('logining')
  /* 路由发生变化修改页面title */
  if (to.meta.label) {
    document.title = 'iPaaS平台—' + to.meta.label
  }
  if (process.env.VUE_APP_MODE === 'private') {
    const envMap = store.state.user.envMap
    // 判断是否要去登录页
    const userInfo = store.state.user.userInfo
    handleRedirect({ envMap, to, router, next, isLogining, userInfo })
  } else if (process.env.VUE_APP_MODE === '__container__') {
    const storeKey = 'X-IDaas-Resource'
    if (queryObj.ticket) {
      store.dispatch('user/fetchToken', { service: redirectUrl, ticket: queryObj.ticket }).then(_res => {
        location.href = location.origin + location.pathname
      }).catch(e => {
        Message.error(e.message)
        location.href = location.origin + location.pathname
      }).finally(() => {
        next()
      })
    } else {
      const token = cookiejs.getCookie(storeKey)
      if (!token) {
        store.dispatch('user/logout').then(() => {
          next()
        })
      } else {
        next()
      }
    }
  }
})

// 添加页面缓存
router.beforeEach((to, from, next) => {
  // TODO - keepalive缓存三级菜单，目前只支持3级菜单，>3级菜单均不支持
  if (to.matched && to.matched.length === 3) {
    const blackRouteObj = to.matched.splice(1, 1)
    to.matched.push(...blackRouteObj)
  }

  store.commit('PUSH_KEEP_ALIVE_NAME', {
    name: to.name,
    keepAlive: to.meta.keepAlive
  })
  next()
})

// 关闭进度条
router.afterEach((_to, _from) => {
  NProgress.done()
})

// 处理跳转
async function handleRedirect({ envMap, to, router, isLogining, next, userInfo }) {
  // 多个环境，需要
  const needAuth = envMap && envMap.length > 0
  // -1.判断是否其他系统重定向回来，查找对应系统重定向的参数是否在queryObj中
  const params = Object.keys(queryObj)
  const backEndType = store.state.user.backEndType
  if (isLogining && params && params.length) { // 识别为 由第三方登录页返回
    handleThirdRedirect(next)
  } else if (!needAuth && (to.name === 'login' || to.name === 'adminLogin')) {
  // 1. 不需要登录,阻止访问login页面
    removeLocal('logining')
    router.replace({ name: 'home' })
  } else if (needAuth) {
    // 2. 需要登录
    if (userInfo.jwt) { // 已登录
      removeLocal('loginging')
      const currentApp = store.state.user.app
      if (TENANT_ADMIN_MODE.includes(userInfo.handlerName) && backEndType === LOGIN_MODE.WEB_ADMIN) { // 需要选择应用
        if (!currentApp.appName && to.name !== 'appList') { // 未选择应用
          router.replace({ name: 'appList' })
        }
      } else if (to.name === 'login') { // 不需要选择应用
        router.replace({ name: 'home' })
      }
    } else { // 未登录
      store.commit('menutag/delAllViews')
      if (to.name !== 'login') router.replace({ name: 'login' })
    }
    next()
  }
}

async function handleThirdRedirect() {
  const handlerName = getLocal('handlerName')
  const href = getLocal('href')
  const backEndType = LOGIN_MODE.WEB_ADMIN
  removeLocal('logining')
  removeLocal('handlerName')
  removeLocal('href')
  const queryObj = qs.parse(location.search, { ignoreQueryPrefix: true })
  try {
    const params = {
      callbackData: queryObj || {},
      handlerName,
      backEndType,
      redirectUrl: location.origin + location.pathname
    }
    await store.dispatch('user/login', params)
    store.commit('menutag/delAllViews')
    if (handlerName === 'iam') { // iam选择app
      location.href = href + '#/applist'
    } else {
      location.href = href + '#/'
    }
  } catch (e) {
    location.href = href + '#/login'
  }
}

// 拦截处理一下，如果是tenantAdmin，只允许访问首页、系统应用、用户管理；如果是webAdmin，不允许访问系统应用、用户管理
function premissionRoute(name) {
  const backEndType = store.state.user.backEndType

  if (backEndType === LOGIN_MODE.WEB_ADMIN && adminRouteNames.includes(name)) {
    return false
  } else if (backEndType === LOGIN_MODE.TENANT_ADMIN && ![...adminRouteNames, 'home'].includes(name)) {
    return false
  }
  return true
}
