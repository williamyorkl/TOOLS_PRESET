# css使用

##统一主题
###font-size、color、background-color、padding、margin、border-corlor、border-radius不允许使用色号和大小，统一使用 element-variables.scss 内变量。请勿使用w200，mr20这类class来设置宽度或者边距。

###常用变量
######需使用其他变量自行查看 element-variables.scss
变量 | 说明 | 取值
--- | --- | ---
$--color-white | 白色 | #fff
$--color-black | 黑色 | #000
$--color-primary | 主题色 | #3388ff
$--color-success | 成功（绿） | #67C23A
$--color-warning | 警告（黄） | #F7B418
$--color-danger | 错误（红） | #F56C6C
$--color-info | 常规 | #F56C6C
$--border-color-base | 边界1 | #DCDFE6
$--border-color-light | 边界2 | #E4E7ED
$--border-color-lighter | 边界3 | #EBEEF5
$--border-color-extra-light | 边界4 | #F2F6FC
$--border-radius-base | 圆角 | 4px
$--border-radius-small | 圆角小 | 2px
$--color-text-primary | 主要文字 | #303133
$--color-text-regular | 常规文字 | #606266
$--color-text-secondary | 次要文字 | #909399
$--color-text-placeholder | 占位文字 | #c0c4cc
$--background-color-base | 背景色（表头、标题等） | #f5f7fa
$--background-color-body | body颜色 | #f9f9f9
$--background-color-menu | 菜单颜色 | #2c3340
$--font-size-base | 基础字号 | 12px
$--font-size-big | 标题字号 | 14px
$--font-size-large | 特大字号（dialog标题等） | 18px
$--padding-base | 间距 | 16px
$--padding-small | 间距小 | 8px
$--padding-big | 间距大 | 32px
$--table-striped-background | 表格斑马纹背景色 | #FAFBFC
$--color-primary-hover | primary按钮hover颜色，非button需要增加hover颜色时使用
$--color-primary-active | primary按钮active颜色，非button需要增加active颜色时使用

##统一布局

###样式在var.scss内，所有页面均按此规则布局

###所有页面
class | 说明
--- | ---
.common-container | 最外层class，左内边距8、宽100%、最大宽度1200、大屏居中
.page-container | 已删除。common-container已经包含他的样式
.apply-content | 左右下内边距16、下外边距16

###列表
class | 说明
--- | ---
el-tabs | 见element-ui tab组件。上外边距16
mc-query | 见mc-query组件。
.common-btns-container | 列表按钮（如新增、导入导出等）。上外边距16
.common-table-container | 内包含表格，列表加载loading放在此div上。上外边距16
el-table | 见element-ui table组件。非特殊要求，不使用border、size、stripe等属性，方便统一配置
.pagination-container | 内包含分页器。flex布局内容居中、上外边距16
el-pagination | 见element-ui pagination组件
el-button | 列表操作按钮size使用mini
.table-product-img | 商品图片，高64、宽自适应

#####示例

``` html
<div class="common-container">
	<el-tabs type="card" class="common-list-tabs">
		<el-tab-pane label="" name=""></el-tab-pane>
		<el-tab-pane label="" name=""></el-tab-pane>
	</el-tabs>
	<div class="apply-content">
		<mc-query></mc-query>
    	<div class="common-btns-container">
    		<el-button></el-button>
    		<el-button></el-button>
  		</div>
  		<div class="common-table-container" v-loading="isLoading">
			<el-table>
				<el-table-column label="商品名称" min-width="300" align="left">
        		<template slot-scope="scope">
      				<img class="table-product-img" :src="scope.row.skuPicUrl"></div>
        		</template>
          	</el-table-column>
				<el-table-column label="操作" fixed="right">
            		<template slot-scope="scope">
              		<el-button type="text" size="mini">详情</el-button>
            		</template>
          	</el-table-column>
			</el-table>
  		</div>
		<div class="pagination-container">
      		<el-pagination></el-pagination>
		</div>
	</div>
</div>

```
###详情页
待定
