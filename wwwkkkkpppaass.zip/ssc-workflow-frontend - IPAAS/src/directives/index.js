import Vue from 'vue'
import inputNumber from './input-number'

function install(Vue) {
  inputNumber(Vue)
}

Vue.use(install)
