## 自定义指令
### clipboard
使用vue-clipboard2插件，参考https://www.npmjs.com/package/vue-clipboard2

```javascript
<el-button
	v-clipboard:copy="order.main.outerOrderId"
	v-clipboard:success="onCopy"
	v-clipboard:error="onError">
	复制</el-button>
```

### hoverClipboard
自定义指令，鼠标悬浮时显示复制按钮。默认有复制成功和失败的文字提示，需要额外的回调操作可用v-clipboard:success和v-clipboard:error

```javascript
<el-button
	v-hover-clipboard="order.main.outerOrderId"
	v-clipboard:success="onCopy"
	v-clipboard:error="onError">
	{{order.main.outerOrderId}}</el-button>
```

### hasPermission
根据配置的按钮权限，显示按钮

```javascript
<el-button v-has-permission="'/order/testButton'">按钮权限</el-button>
```

### apiPermission
根据配置的按钮权限，禁用点击功能

```javascript
<el-button v-api-permission:api="'/order/testButton'" v-api-permission:success="handleClick" :data-id="order.id">按钮权限</el-button>

handleClick (el) {
	console.log(el.dataset.id)
}
```
> success回调传参为指令所绑定的元素，如果传递额外参数（例如table内每行的操作按钮），可以通过dataset获取按钮上的data数据（请注意data参数名会被自动转成小写）。由于vue指令的内部逻辑原因，如果在有v-if的元素上使用此指令，当按钮销毁时事件会绑定到其他元素上，使用v-show代替v-if可解决。参考https://cn.vuejs.org/v2/guide/custom-directive.html
