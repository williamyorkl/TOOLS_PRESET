// <el-input v-model.number="scope.item.timelen" type="number" v-input-number="{min: 1, max: 999, int: true, precision: 0}">
export default function(Vue) {
  Vue.directive('input-number', {
    update(el, binding, vnode) {
      const defaultOptions = {
        int: true, min: 0, max: 100, precision: 0
      }
      const options = { ...defaultOptions, ...binding.value }

      let val = parseFloat(vnode.componentInstance.value) // 转数值
      if (options.int) {
        val = parseInt(val)
      } else {
        val = val.toFixed(options.precision) // 小数位数
      }
      val = val < options.min ? options.min : val // 大小范围
      val = val > options.max ? options.max : val

      vnode.componentInstance.$emit('input', val)
    }
  })
}
