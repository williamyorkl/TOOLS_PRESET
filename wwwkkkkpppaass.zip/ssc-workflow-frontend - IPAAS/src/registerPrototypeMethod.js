import Vue from 'vue'
import exportConfirm from 'utils/export'
import Moment from 'moment'
import getUrlKey from './utils/getUrlKey'
import { PROCESS_ENV } from '@/config/process_env'

Moment.locale('en', {
  week: {
    dow: 1, // 星期一是一周的第一天。
    doy: 4 // 用于判断一年中的第一周。
  }
})

Vue.prototype.$export = exportConfirm
Vue.prototype.$moment = Moment

// 回到登录页
Vue.prototype.$logout = () => {
  var localStorage = window.localStorage
  localStorage.clear()
  var sessionStorage = window.sessionStorage
  sessionStorage.clear()
}

Vue.prototype.getUrlKeyUtils = getUrlKey

Vue.prototype.$PROCESS_ENV = PROCESS_ENV
console.log(PROCESS_ENV)
// eslint-disable-next-line no-extend-native
Date.prototype.format = function (fmt) { // author: meizz
  var o = {
    'M+': this.getMonth() + 1, // 月份
    'd+': this.getDate(), // 日
    'h+': this.getHours(), // 小时
    'm+': this.getMinutes(), // 分
    's+': this.getSeconds(), // 秒
    'q+': Math.floor((this.getMonth() + 3) / 3), // 季度
    S: this.getMilliseconds() // 毫秒
  }
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length))
  for (var k in o) { if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length))) }
  return fmt
}
