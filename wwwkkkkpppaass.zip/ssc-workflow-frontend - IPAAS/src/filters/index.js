import { code2Text } from '@/utils'
import { formatTime } from '@/utils/filters'
// 注册全局过滤
const filters = {
  toFixed2(value) {
    return value.toFixed(2)
  },
  code2Text,
  formatTime
}

export const filterLoad = (Vue) => {
  // eslint-disable-next-line no-unused-vars
  for (const key in filters) {
    if (filters.hasOwnProperty(key)) {
      Vue.filter(key, filters[key])
    }
  }
}
