import StoreModel from 'api/common/store'
export const LogisticsDialogMixin = {
  data() {
    return {
      logisticsInfo: {
        data: [], // 物流信息
        logisticsNo: '',
        logisticsComCodeName: ''
      },
      dialogLogisticsVisible: false,
      dialogLoading: false
    }
  },
  methods: {
    // 显示弹窗
    viewLogisticsDetail(val) {
      this.dialogLogisticsVisible = true
      this.dialogLoading = true
      // this.logsPageIndex = 1
      this.logisticsInfo.data = []
      this.logisticsInfo.logisticsComCodeName = val.logisticsComCodeName
      this.logisticsInfo.logisticsNo = val.logisticsNo
      this.getLogisticsDetail(val)
    },
    // 查询物流信息
    getLogisticsDetail(val) {
      const params = {
        // orderId: this.orderId,
        com: val.logisticsComCode || 'JD',
        num: val.logisticsNo || 'JD0003485242555',
        phone: this.orderDetail.orderAddr.receiverMobile
      }

      StoreModel.queryLogisticsInfo(params)
        .then(response => {
          this.dialogLoading = false
          if (response.code === 200) {
            this.logisticsInfo.data = response.content.data || []
            // this.logsRecordCount = response.totalRecord
          } else {
            this.$message.error(response.chnDesc)
          }
        })
        .catch(e => {
          this.dialogLoading = false
        })
    }
  }
}
