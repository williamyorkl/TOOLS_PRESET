
/**
 * 此处增加对数据字典的处理
 * this.$store.dispatch(`DICT/${GET}`, key) 获取单个数据字典并储存于vuex，相同的key全局只获取一次；
 * $options.dictauto将自动触发获取
 * -------------------------------------------------------------------
 * beforeCreate会做以下操作
 * $options.dictmaps: 增加数据字典 { value: label } 的映射到computed，如 ['sex'] -> computed: { sexMap : {} }
 * $options.dictlists: 增加数据字典列表到computed
 * ------------------------------------------------------------------------
 * PS: 每个数据字典的列表和映射的相对应字段由后端的返回决定，映射字段列表字段加上后缀Map
 * ------------------------------------------------------------------------
 * 示例:
 * export default {
 *   dictmaps: ['sex', 'memberLevel'],
 *   dictlists: ['rightType']
 * }
 * 处理为:
 * {
 *   computed: {
 *     sexMap() {},
 *     memberLevelMap() {},
 *     rightType() {}
 *   }
 * }
 */

import { isArray, noop } from '@/utils/modules'
import { GET, DELETE } from '@/store/modules/dict'

const emptyObject = {}
const emptyArray = []

export default {
  /**
   * 增加数据字典到computed
   */
  beforeCreate() {
    const options = this.$options

    if (!isArray(options.dictmaps) && !isArray(options.dictlists)) {
      return
    }

    options.dictauto = true

    const computed = options.computed || (options.computed = {})

    if (isArray(options.dictmaps)) {
      options.dictmaps.forEach(key => {
        computed[key + 'Map'] = function() {
          return this.$store.state.DICT.dict[key + 'Map'] || emptyObject
        }
      })
    }

    if (isArray(options.dictlists)) {
      options.dictlists.forEach(key => {
        computed[key] = function() {
          return this.$store.state.DICT.dict[key] || emptyArray
        }
      })
    }
  },

  created() {
    const options = this.$options

    if (options.dictauto) {
      const keys = [].concat(options.dictlists || [], options.dictmaps || [])

      keys.forEach(key => {
        this.fetchDict(key).catch(noop)
      })
    }
  },

  methods: {
    fetchDict(key) {
      return this.$store.dispatch(`DICT/${GET}`, key)
    },

    removeDicts() {
      this.$store.commit(`DICT/${DELETE}`)
    },

    hasPermission() {
      return true
    }
  }
}
