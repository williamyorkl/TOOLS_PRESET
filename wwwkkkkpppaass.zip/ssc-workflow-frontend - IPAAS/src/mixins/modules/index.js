import dict from './dict'

export default function install(Vue) {
  Vue.mixin(dict)
}
