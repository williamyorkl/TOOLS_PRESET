import axios from 'axios'
import { Message } from 'element-ui'
import { TIMEOUT_MILLISECONDS, WHITE_LIST, NO_AUTH_API_LIST } from 'config/api'
import cookiejs from 'utils/cookie'
import store from 'store'
import { TENANT_ADMIN_MODE, LOGIN_MODE } from '@/config/enum'
import { _typeof } from '@/utils'
import { LoadingConfig } from './LoadingConfig'

const baseURL = process.env.VUE_APP_BASE_URL + process.env.VUE_APP_BASE_URL_PATCH

const instance = axios.create({
  baseURL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
    authorize: true,
    'X-Requested-With': 'XMLHttpRequest'
  }
})

instance.interceptors.request.use((config) => {
  const loading = new LoadingConfig(config)
  loading.loading() // 触发loading
  if (process.env.VUE_APP_MODE === '__paas__') {
    config.headers['IDaas-Auth-Token'] = cookiejs.getCookie('IDaaSAuthToken')
  }
  if (process.env.VUE_APP_MODE === '__container__') {
    config.headers['X-IDaas-Resource'] = cookiejs.getCookie('X-IDaas-Resource')
  }
  if (process.env.VUE_APP_MODE === 'private' && NO_AUTH_API_LIST.includes(config.url) !== -1) {
    const userInfo = store.state.user.userInfo
    config.headers['ipaas-token'] = userInfo.jwt
    if (userInfo && TENANT_ADMIN_MODE.includes(userInfo.handlerName) && store.state.user.backEndType === LOGIN_MODE.WEB_ADMIN) {
      config.headers['ipaas-tenant'] = store.state.user.app.id
    }
  }
  if (config.apiDebug) {
    config.metadata = {}
    config.metadata.startTime = Date.now()
  }
  if (process.env.mode === 'production') {
    console.log('req', config)
  }
  return config
})

instance.interceptors.response.use(
  response => {
    const loading = new LoadingConfig(response.config)
    loading.apiEnd() // 触发接口结束
    if (process.env.mode === 'production') {
      console.log('resp', response)
    }
    let isInWhiteList = false
    WHITE_LIST.forEach(i => {
      if (location.href.indexOf(i) > -1) {
        isInWhiteList = true
      }
    })
    if (response.config.noErrorToast) { // 默认提示接口返回的错误信息，不提示在调用时传入noErrorToast: true
      return response.data
    }
    if (response.config.apiDebug) { // 用于api调试，json格式处理
      response.config.metadata.endTime = Date.now()
      response.duration = response.config.metadata.endTime - response.config.metadata.startTime
      return response
    }
    if (response.data) { // 符合统一格式的接口根据status提示
      if (response.data.code === 200 || response.data.code === 0) { // 请求token的接口status返回的0
        return response.data.data
      } else if (response.data.code) {
        const code = response.data.code
        switch (code) {
          case 303:
            store.dispatch('user/clearUserInfo', response.data)
            Message.warning(response.data.msg || '操作失败')
            break
          case 403:
            store.dispatch('user/clearUserInfo', response.data)
            store.commit('codeBox/SAVE_CODE', { code: response.data.code, msg: response.data.msg })
            break
          default:
            Message.error(response.data.msg || '操作失败')
        }
        return Promise.reject(response.data)
      } else if (_typeof(response.data) === 'blob') { // 文件导出的直接返回response
        // blob类型需要先检测response.data.type的类型，如果是'application/json',默认出错，使用FileReader处理结果并提示报错
        if (response.data.type === 'application/json') {
          var reader = new FileReader()
          reader.onload = e => {
            const result = JSON.parse(e.target.result)
            Message({
              type: 'error',
              message: result.msg || '导出出错'
            })
          }
          reader.readAsText(response.data, 'utf-8')
          return Promise.reject(response.data)
        } else {
          return response
        }
      } else if (response.data.code) {
        Message({
          type: 'error',
          message: response.data.msg || '接口异常~'
        })
        return Promise.reject(response.data)
      } else {
        return response.data
      }
    } else {
      return response.data
    }
  }, err => {
    const loading = new LoadingConfig(err.config)
    loading.apiEnd() // 触发接口结束
    if (err.toString().includes('timeout')) {
      Message.error('请求超时')
      return Promise.reject(err)
    }
    if (err.response.config.noErrorToast) { // 默认提示接口返回的错误信息，不提示在调用时传入noErrorToast: true
      return Promise.reject(err)
    } else if (err.response.config.apiDebug) {
      err.response.config.metadata.endTime = Date.now()
      err.response.duration = err.response.config.metadata.endTime - err.response.config.metadata.startTime
      return Promise.reject(err)
    } else {
      if (err.response) {
        const { status, data } = err.response
        switch (status) {
          case 404:
            Message.error('错误：404 ,请求的服务未找到')
            break
          case 400:
            Message.error('错误：服务400')
            break
          case 403:
            Message.error('权限不足')
            store.dispatch('user/logout')
            break
          default:
            if (status >= 500) {
              if (data.message) {
                const msg = /[\u4e00-\u9fa5]+?.*[\u4e00-\u9fa5]+?/.exec(data.message)
                if (msg && msg[0]) {
                  Message.error('错误！服务器' + status)
                }
              } else {
                Message.error('服务器异常')
              }
            }
        }
        return Promise.reject(err)
      } else {
        if (err.message === `timeout of ${TIMEOUT_MILLISECONDS}ms exceeded`) {
          Message({
            type: 'error',
            message: '网络异常'
          })
        }
        return Promise.reject(err)
      }
    }
  })
export default instance
