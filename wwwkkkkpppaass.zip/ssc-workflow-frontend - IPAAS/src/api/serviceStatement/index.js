import fetch from '../fetch.js'
import { objToFormData } from '@/utils'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

model.getServiceStatementList = function (params) {
  return fetch({
    url: modelName + 'service_declare/pageList',
    method: 'post',
    data: params
  })
}

model.deleteServiceStatement = function (params) {
  return fetch({
    url: modelName + `service_declare/${params.id}`,
    method: 'DELETE',
    data: {}
  })
}

model.refreshServiceStatement = function (params) {
  return fetch({
    url: modelName + `service_declare/refresh/${params.id}`,
    method: 'GET',
    needLoading: true,
    needLoading: true
  })
}

model.postServiceStatement = function (params) {
  return fetch({
    url: modelName + 'service_declare',
    method: 'post',
    data: params,
    needLoading: true
  })
}

// 批量同步
model.batchSyncServiceStatement = function (params) {
  return fetch({
    url: modelName + 'service_declare/sync/dubbo/declare',
    method: 'post',
    data: params,
    needLoading: true
  })
}

// 批量同步：new
model.batchSyncServiceStatement2 = function(params) {
  return fetch({
    url: modelName + 'flow_registry_center/pullSvcDeclaration',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 导入
model.importService = function(params) {
  const formData = objToFormData(params)
  return fetch({
    url: modelName + 'service_declare/import',
    method: 'POST',
    data: formData,
    fileUpload: true,
    timeout: 20000,
    needLoading: true,
    needLoading: true
  })
}

export default model
