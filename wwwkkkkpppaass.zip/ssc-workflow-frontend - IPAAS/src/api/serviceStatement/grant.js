import fetch from '../fetch.js'
import { objToFormData } from '@/utils'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 接口授权
model.apiGrant = function (params) {
  return fetch({
    url: modelName + 'flow_grant',
    method: 'post',
    data: params
  })
}

// 被授权列表
model.listBeGrant = function (params) {
  return fetch({
    url: modelName + 'flow_grant/beGrantPage',
    method: 'POST',
    data: params
  })
}

// 授权列表
model.listGrant = function (params) {
  return fetch({
    url: modelName + 'flow_grant/grantPage',
    method: 'POST',
    data: params
  })
}

// 应用列表
model.listApp = function (params) {
  return fetch({
    url: modelName + 'flow_grant/beGrantAppList',
    method: 'POST',
    data: params
  })
}

// 删除
model.deleteGrant = function (params) {
  return fetch({
    url: modelName + `flow_grant/${params.id}`,
    method: 'DELETE'
  })
}

export default model
