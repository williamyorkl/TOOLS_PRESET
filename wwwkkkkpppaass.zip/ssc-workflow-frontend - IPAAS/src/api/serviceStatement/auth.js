import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 认证信息列表
model.listAuth = function (params) {
  return fetch({
    url: modelName + 'flow_auth/pageList',
    method: 'POST',
    data: params
  })
}

// 新增/更新认证信息
model.saveOrUpdateAuth = function (params) {
  return fetch({
    url: modelName + 'flow_auth/saveOrUpdate',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 删除认证信息
model.deleteAuth = function (params) {
  return fetch({
    url: modelName + `flow_auth/${params.id}`,
    method: 'DELETE',
    data: params
  })
}

export default model
