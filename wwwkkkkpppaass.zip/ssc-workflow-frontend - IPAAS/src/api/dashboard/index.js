import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// api按自定义参数统计
model.api = function(params) {
  return fetch({
    url: modelName + 'flow_analysis/api',
    // url: modelName + 'flow_analysis/api/flow',
    method: 'POST',
    data: params
  })
}

// 实时api统计
model.apiRealTime = function() {
  return fetch({
    // url: modelName + 'flow_analysis/api/current',
    url: modelName + 'flow_analysis/api/flow/current',
    method: 'POST'
  })
}

// api排名统计
model.apiTop = function(params) {
  return fetch({
    url: modelName + 'flow_analysis/api/top',
    method: 'POST',
    data: params
  })
}

// api按固定时间维度统计
model.apiType = function(params) {
  return fetch({
    // url: modelName + `flow_analysis/api/${params.type}`,
    url: modelName + `flow_analysis/api/flow/${params.type}`,
    method: 'POST',
    data: params
  })
}

export default model
