import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

model.getServiceApiList = function (params) {
  return fetch({
    url: modelName + 'service_api/pageList',
    method: 'POST',
    data: params
  })
}

model.genDefinitionDocByApiId = function (params) {
  return fetch({
    url: modelName + 'service_api/genDefinitionDocReq',
    method: 'GET',
    params
  })
}

export default model
