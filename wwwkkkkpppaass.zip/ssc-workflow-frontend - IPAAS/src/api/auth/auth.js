import fetch from '../fetch.js'

const modelName = ''
const model = {}

// 登录方式
model.loginMethod = function (params) {
  return fetch({
    url: modelName + 'auth/loginMethod',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 登录
model.login = function(params) {
  return fetch({
    url: modelName + 'auth/login',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 登出
model.logout = function(params) {
  return fetch({
    url: modelName + 'auth/logout',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 转发
model.forward = function(params) {
  return fetch({
    url: modelName + 'auth/forward',
    method: 'POST',
    data: params,
    responseType: params.responseType
  })
}

export default model
