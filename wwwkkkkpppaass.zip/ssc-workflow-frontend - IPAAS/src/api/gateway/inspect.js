import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 获取巡检任务列表接口
model.getInspectList = function (params) {
  return fetch({
    url: modelName + 'flow_inspect_task/pageList',
    method: 'GET',
    params
  })
}

// 巡检任务-新增
model.saveInspect = function (params) {
  return fetch({
    url: modelName + 'flow_inspect_task',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 巡检任务-删除
model.deleteInspect = function (params) {
  return fetch({
    url: modelName + `flow_inspect_task/${params.id}`,
    method: 'DELETE'
  })
}

// 巡检任务-详情
model.detailInspect = function (params) {
  return fetch({
    url: modelName + `flow_inspect_task/${params.id}`,
    method: 'GET'
  })
}

// 巡检任务-启动
model.startInspect = function (params) {
  return fetch({
    url: modelName + `flow_inspect_task/start/${params.id}`,
    method: 'GET',
    needLoading: true
  })
}

// 巡检任务-暂停
model.pauseInspect = function (params) {
  return fetch({
    url: modelName + `flow_inspect_task/pause/${params.id}`,
    method: 'GET',
    needLoading: true
  })
}

// 巡检任务-失败日志
model.getLogList = function (params) {
  return fetch({
    url: modelName + 'flow_inspect_task/fail/pageList',
    method: 'POST',
    data: params
  })
}

export default model
