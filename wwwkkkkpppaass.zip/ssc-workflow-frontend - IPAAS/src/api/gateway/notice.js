import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 列表
model.getChangeNoticeList = function (params) {
  return fetch({
    url: modelName + 'flow_change_notification/pageList',
    method: 'POST',
    data: params
  })
}

// 处理
model.handleNoticeById = function(params) {
  return fetch({
    url: modelName + `flow_change_notification/handle/${params.id}`,
    method: 'GET',
    needLoading: true
  })
}

export default model
