import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 获取网关日志列表接口
model.getLogList = function(params) {
  return fetch({
    url: modelName + 'flow_chain_log/pageList',
    method: 'POST',
    data: params
  })
}

// 网关日志-节点日志
model.getNodeLists = function(params) {
  return fetch({
    url: modelName + 'flow_node_log/pageList',
    method: 'POST',
    data: params
  })
}

// 获取节点日志列表接口
model.getNodeList = function(params) {
  return fetch({
    url: modelName + `flow_node_log/listByTraceId/${params.traceId}`,
    method: 'GET'
  })
}

// 获取节点日志列表接口
model.getNodeList1 = function(params) {
  return fetch({
    url: modelName + `flow_node_log/listById/${params.id}`,
    method: 'GET'
  })
}

// 通过sessionId获取
model.getNodeListBySessionId = function(params) {
  return fetch({
    url: modelName + `flow_node_log/listBySessionId/${params.id}`,
    method: 'GET'
  })
}

// 查询用户接口名称数据
model.getUserLists = function(params) {
  return fetch({
    url: modelName + 'definition/allPageList',
    method: 'POST',
    data: params
  })
}

model.retryFlow = function(params) {
  return fetch({
    url: modelName + 'flow_chain_log/retryFlowDefinition',
    method: 'POST',
    data: params,
    needLoading: true
  })
}
export default model
