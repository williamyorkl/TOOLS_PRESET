import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 路由管理
// 列表
model.listForwardArrange = function (params) {
  return fetch({
    url: modelName + 'forward/definition/pageList',
    method: 'POST',
    data: params
  })
}

// 详情
model.detailForwardArrange = function(params) {
  return fetch({
    url: modelName + `forward/definition/${params.id}`,
    method: 'GET'
  })
}

// 新增
model.saveForwardArrange = function(params) {
  return fetch({
    url: modelName + 'forward/definition/add',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 修改
model.updateForwardArrange = function(params) {
  return fetch({
    url: modelName + 'forward/definition/edit',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 删除
model.deleteForwardArrange = function(params) {
  return fetch({
    url: modelName + `forward/definition/${params.id}`,
    method: 'DELETE'
  })
}

export default model
