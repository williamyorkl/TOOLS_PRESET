import fetch from '../fetch.js'
import cookiejs from 'utils/cookie'
export const getList = function (params) {
  const token = cookiejs.parse(document.cookie).loginToken
  return fetch({
    noErrorToast: true,
    url: '/dataexporter-server/MainController/task/list',
    method: 'GET',
    params: {
      pageIndex: 0,
      pageSize: 500,
      loginToken: token
    }
  })
}

export const begin = function (params) {
  const url = '/ecu-admin/dataExporter/export/' + params.taskType
  delete params.taskType
  return fetch({
    url: url,
    method: 'GET',
    params: params
  })
  // return fetch({
  //   url: '/ecu-admin/dataExporter/export',
  //   method: 'GET',
  //   params: params
  // })
}

export const exportDetail = function (id) {
  return fetch({
    url: '/dataexporter-server/MainController/task/' + id,
    method: 'GET'
  })
}

export default {
  getList,
  exportDetail,
  begin
}
