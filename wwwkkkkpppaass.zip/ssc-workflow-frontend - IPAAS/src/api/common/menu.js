import fetch from '../fetch.js'
var modelName = '/menu'
var menu = {}
menu.showAction = function (params) {
  return fetch({
    url: '/ecu-admin/permission/action/showAction',
    method: 'GET',
    params: params
  })
}
menu.addAction = function (params) {
  return fetch({
    url: '/ecu-admin/permission/action/addAction',
    method: 'POST',
    data: params
  })
}
menu.updateAction = function (params) {
  return fetch({
    url: '/ecu-admin/permission/action/updateAction',
    method: 'POST',
    data: params
  })
}
menu.deleteAction = function (params) {
  return fetch({
    url: '/ecu-admin/permission/action/deleteAction',
    method: 'DELETE',
    data: params
  })
}
export default menu
