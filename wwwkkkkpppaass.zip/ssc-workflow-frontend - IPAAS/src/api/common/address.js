async getProvince ({commit}, {type, parentCode}) {
  const { content } =
  if (type === 'province') {
    commit('SET_PROVINCE', content)
  } else if (type === 'city') {
    commit('SET_CITY', content)
  } else if (type === 'area') {
    commit('SET_AREA', content)
  }

  const queryAddress = (parentCode) => {
    await area.getList({
      parentCode
    })
  }
