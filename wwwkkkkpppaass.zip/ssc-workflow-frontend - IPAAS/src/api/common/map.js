
import areaModel from '../area'

export const _getAllProvince = areaModel.getAllProvince // 获取所有省份

export default {
 
  _getAllProvince
 
}
