import fetch from '../fetch.js'
const modelName = '/ecu-admin/grid'

export const tempResultItemList = function (moduleType) {
  return fetch({
    url: modelName + '/tempResultItemList/' + moduleType,
    method: 'GET'
  })
}

export const checkTempResultItemList = function (moduleType, params) {
  return fetch({
    url: modelName + '/checkTempResultItemList/' + moduleType,
    method: 'POST',
    data: params
  })
}

export default {
  tempResultItemList,
  checkTempResultItemList
}
