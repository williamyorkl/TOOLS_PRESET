import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const dict = {}

dict.getDict = function (params) {
  return fetch({
    url: `dictionary/${params}`,
    method: 'GET'
  })
}

dict.getFuncList = function () {
  return fetch({
    url: modelName + 'func/list',
    method: 'GET'
  })
}

export default dict
