import fetch from '../fetch.js'
var modelName = '/role'
var role = {}
role.getList = function (params) {
  return fetch({
    url: '/ecu-admin/permission/role/showRoleByPage',
    method: 'GET',
    params: params
  })
}
role.forbidRole = function (params) {
  return fetch({
    url: '/ecu-admin/permission/role/disableRole',
    method: 'POST',
    data: params
  })
}
role.startRole = function (params) {
  return fetch({
    url: '/ecu-admin/permission/role/enableRole',
    method: 'POST',
    data: params
  })
}
role.addRole = function (params) {
  return fetch({
    url: '/ecu-admin/permission/role/addRole',
    method: 'POST',
    data: params
  })
}
role.roleAuthList = function (params) {
  return fetch({
    url: '/ecu-admin/permission/roleAction/showMenuAction',
    method: 'GET',
    params: params
  })
}
role.setRoleAuthList = function (params) {
  return fetch({
    url: '/ecu-admin/permission/roleAction/maintain',
    method: 'POST',
    data: params
  })
}
role.deleteRole = function (params) {
  return fetch({
    url: '/ecu-admin/permission/role/deleteRole',
    method: 'POST',
    data: params
  })
}
role.getListPlatformIds = function (params) {
  return fetch({
    url: '/ecu-admin/permission/role/listPlatformIds',
    method: 'GET',
    params: params
  })
}

export default role
