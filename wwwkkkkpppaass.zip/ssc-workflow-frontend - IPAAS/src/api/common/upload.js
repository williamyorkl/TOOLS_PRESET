import axios from 'axios'
const productBackMall = '/ecu-admin'
const Upload = {}
// 上传图片
Upload.uploadPic = function (params) {
  const config = {
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  }
  return axios.post(productBackMall + '/upload', params, config)
}
export default Upload
