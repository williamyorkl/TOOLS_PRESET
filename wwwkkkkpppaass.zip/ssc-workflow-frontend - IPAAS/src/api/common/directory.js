import fetch from '../fetch.js'
var modelName = '/directory'
var directory = {}
var baseURL = '/ecu-admin'
directory.getDirectoryList = function (params) {
  return fetch({
    url: baseURL + '/dd/getDDList',
    method: 'POST',
    data: params
  })
}
directory.getDirectoryChildList = function (params) {
  return fetch({
    url: baseURL + '/dd/getDDValueList',
    method: 'GET',
    params: params
  })
}
directory.updateParentDetail = function (params) {
  return fetch({
    url: baseURL + '/dd/updateDD?id=' + params.id,
    method: 'POST',
    data: params
  })
}
directory.updateChildDetail = function (params) {
  return fetch({
    url: baseURL + '/dd/value/updateDDValue',
    method: 'POST',
    data: params
  })
}
directory.saveDirectory = function (params) {
  return fetch({
    url: baseURL + '/dd/addDD',
    method: 'POST',
    data: params
  })
}
directory.saveKey = function (params) {
  return fetch({
    url: baseURL + '/dd/value/addDDValue',
    method: 'POST',
    data: params
  })
}
// 获取数据字典外部映射
directory.getOuterList = function (params) {
  return fetch({
    url: baseURL + '/dd/value/getOuterDetailList',
    method: 'GET',
    params: params
  })
}
// 添加数据字典值
directory.saveOuterDetail = function (params) {
  return fetch({
    url: baseURL + '/dd/value/saveOuterDetail',
    method: 'POST',
    data: params
  })
}
directory.updateOuterDetail = function (params) {
  return fetch({
    url: baseURL + '/dd/value/updateOuterDetail',
    method: 'POST',
    data: params
  })
}
// 删除外部映射
directory.deleteOuterDetail = function (params) {
  return fetch({
    url: baseURL + '/dd/value/delOuterDetail',
    method: 'GET',
    params: params
  })
}
// 获取平台列表
directory.getPlatformList = function (params) {
  return fetch({
    url: baseURL + '/platform/listPlatformOption',
    method: 'GET',
    params: params
  })
}
directory.getOneTypeList = function (params) {
  return fetch({
    url: '/ecu-admin/md/getList',
    method: 'GET',
    params: params
  })
}
// 店铺评级
directory.getShopGrade = function (params) {
  return fetch({
    url: '/dd/value/shopGrade',
    method: 'GET',
    params: params
  })
}

directory.getDDValueListByKey = function (ddKey) {
  return fetch.get(baseURL + '/dd/getDDValueListByKey', { params: { ddKey } })
}

export default directory
