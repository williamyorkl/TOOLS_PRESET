import fetch from '../fetch.js'
var modelName = '/user'
var user = {}

// 查询用户数据权限
// typeCode: 数据权限类型,shop_id(店铺） store_id（仓库）
// userId: 用户ID,不传时查询当前登录用户
user.getResource = function (params) {
  return fetch({
    url: '/ecu-admin/permission/auth/resource/getResource',
    method: 'GET',
    params: params
  })
}

// 设置用户数据权限
// typeCode: 数据权限类型,shop_id(店铺） store_id（仓库）
// userId
// resources: 数据实体ID的array，传[]时则为清楚用户所有权限，不能为null
user.setResource = function (params) {
  return fetch({
    url: '/ecu-admin/permission/auth/resource/setResource',
    method: 'POST',
    data: params
  })
}

user.getList = function (params) {
  return fetch({
    url: '/ecu-admin/user/list',
    method: 'GET',
    params: params
  })
}
user.getRoleList = function (params) {
  return fetch({
    url: '/ecu-admin/permission/userRole/getRoleTree',
    method: 'GET',
    params: params
  })
}
user.roleAuth = function (params) {
  return fetch({
    url: '/ecu-admin/permission/userRole/setRole',
    method: 'POST',
    data: params
  })
}
user.statusEdit = function (params) {
  return fetch({
    url: '/ecu-admin/user/editStatus',
    method: 'GET',
    params: params
  })
}
user.createUser = function (params) {
  return fetch({
    url: '/ecu-admin/user/create',
    method: 'POST',
    data: params
  })
}
user.editUserInfo = function (params) {
  return fetch({
    url: '/ecu-admin/user/edit',
    method: 'POST',
    data: params
  })
}
user.getDepartmentList = function (params) {
  return fetch({
    url: '/ecu-admin/department/list',
    method: 'GET',
    params: params
  })
}
user.updatePwd = function (params) {
  return fetch({
    url: '/ecu-admin/user/changePwd',
    method: 'POST',
    data: params
  })
}
user.updatePwdAdmin = function (params) {
  return fetch({
    url: '/ecu-admin/user/forceChangePwd',
    method: 'POST',
    data: params
  })
}
// 获取分公司列表-无参数
user.getCompanyList = function (params) {
  return fetch({
    url: '/ecu-admin/customer/company',
    method: 'GET',
    params: params
  })
}
// 获取供应商列表-无参数
user.getSupplierList = function (params) {
  return fetch({
    url: '/ecu-admin/supplier/list',
    method: 'GET',
    params: params
  })
}
export default user
