import fetch from '../fetch.js'
var modelName = '/company'
var company = {}
company.getList = function (params) {
  return fetch({
    url: '/ecu-admin/company/list',
    method: 'GET',
    params: params
  })
}
// 修改
company.editCompany = function (params) {
  return fetch({
    url: '/ecu-admin/company/edit',
    method: 'POST',
    data: params
  })
}
// 新增分公司
company.addCompany = function (params) {
  return fetch({
    url: '/ecu-admin/company/add',
    method: 'POST',
    data: params
  })
}
// 删除分公司
company.delCompany = function (params) {
  return fetch({
    url: '/ecu-admin/company/sweep',
    method: 'GET',
    params: params
  })
}
// 查看分公司区域
company.viewArea = function (params) {
  return fetch({
    url: '/ecu-admin/company/view',
    method: 'GET',
    params: params
  })
}

export default company
