import fetch from '../fetch.js'

const modelName = 'tenant-admin/'
const model = {}

// 应用：列表
model.listApp = function(params) {
  return fetch({
    url: modelName + 'flow_sys_app/page',
    method: 'POST',
    data: params
  })
}

// 应用：新增
model.saveApp = function(params) {
  return fetch({
    url: modelName + 'flow_sys_app/save',
    method: 'POST',
    data: params
  })
}

// 应用：更新
model.updateApp = function(params) {
  return fetch({
    url: modelName + 'flow_sys_app/update',
    method: 'POST',
    data: params
  })
}

// 应用：详情
model.detailApp = function(params) {
  return fetch({
    url: modelName + `flow_sys_app/${params.id}`,
    method: 'GET',
    params
  })
}

// 应用：删除
model.deleteApp = function(params) {
  return fetch({
    url: modelName + `flow_sys_app/${params.id}`,
    method: 'DELETE'
  })
}

// 应用：根据userId查询应用列表
model.GrantApp = function(params) {
  return fetch({
    url: modelName + 'flow_sys_app/getByUserId',
    method: 'POST',
    data: params
  })
}

// 全部应用
model.listAppAll = function (params = {}) {
  return fetch({
    url: modelName + 'flow_sys_app/list',
    method: 'POST',
    data: params
  })
}

export default model
