import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 列表
model.getMonitorList = function (params) {
  return fetch({
    url: modelName + 'flow_monitor/page',
    method: 'POST',
    data: params
  })
}

// 列表
model.getMonitorAll = function (params) {
  return fetch({
    url: modelName + 'flow_monitor/list',
    method: 'POST',
    data: params
  })
}

// 删除
model.deleteMonitor = function(params) {
  return fetch({
    url: modelName + `flow_monitor/${params.id}`,
    method: 'DELETE'
  })
}

// 基础信息：详情
model.detailMonitor = function(params) {
  return fetch({
    url: modelName + 'flow_monitor/get',
    method: 'POST',
    data: params
  })
}

// 基础信息：新增
model.addMonitor = function(params) {
  return fetch({
    url: modelName + 'flow_monitor/save',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 基础信息：修改
model.updateMonitor = function(params) {
  return fetch({
    url: modelName + 'flow_monitor/update',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 启用/禁用
model.updateStatus = function(params) {
  return fetch({
    url: modelName + 'flow_monitor/updateStatus',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

export default model
