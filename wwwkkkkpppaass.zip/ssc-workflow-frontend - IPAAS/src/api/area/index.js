import fetch from '../fetch.js'
import { getSession, setSession } from 'utils/cache'

// 获取省市区
export const getAllProvince = (parentCode, type) => {
  if (type === 'province') {
    const value = getSession('allProvince')
    if (value && value.length > 0) {
      return Promise.resolve(value)
    }
  }
  let data = []
  return fetch({
    url: '/ecu-admin/area/getList',
    method: 'get',
    params: { parentCode }
  }).then(res => {
    if (res.code == 200) {
      data = res.content.map(item => ({
        name: item.areaName,
        value: item.areaCode
      }))
      if (type === 'province') {
        setSession('allProvince', data)
      }
      return data
    }
  })
}

export default {
  getList(params) {
    const value = getSession('allAreaList')
    return fetch({
      url: '/ecu-admin/area/getList',
      method: 'get',
      params: params
    })
  },
  getAllProvince
}
