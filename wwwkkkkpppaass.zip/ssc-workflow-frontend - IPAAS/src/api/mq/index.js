import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 列表
model.getMqList = function (params) {
  return fetch({
    url: modelName + 'flow_mq_config/pageList',
    method: 'POST',
    data: params
  })
}

// 列表
model.getMqAll = function (params) {
  return fetch({
    url: modelName + 'flow_mq_config/list',
    method: 'POST',
    data: params
  })
}

// 删除
model.deleteMq = function(params) {
  return fetch({
    url: modelName + `flow_data_base/${params.id}`,
    method: 'DELETE'
  })
}

// 基础信息：详情
model.detailMq = function(params) {
  return fetch({
    url: modelName + `flow_mq_config/${params.id}`,
    method: 'GET'
  })
}

// 基础信息：新增
model.createMq = function(params) {
  return fetch({
    url: modelName + 'flow_mq_config/add',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 基础信息：修改
model.updateMq = function(params) {
  return fetch({
    url: modelName + 'flow_mq_config/edit',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 测试连接
model.checkMqLink = function(params) {
  return fetch({
    url: modelName + 'flow_mq_config/test/connect',
    method: 'POST',
    data: params,
    needLoading: true
  })
}
export default model
