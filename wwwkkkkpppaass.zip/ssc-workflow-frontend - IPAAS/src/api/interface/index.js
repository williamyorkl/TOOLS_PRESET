import fetch from '../fetch.js'
import { objToFormData } from '@/utils'
const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

model.getInterfaceList = function (params) {
  return fetch({
    url: modelName + 'service_api/pageList',
    method: 'post',
    data: params
  })
}

model.interfaceAdd = function (params) {
  return fetch({
    url: modelName + 'service_api',
    method: 'post',
    data: params,
    needLoading: true
  })
}

model.interfaceDetail = function(params) {
  return fetch({
    url: modelName + 'service_api/getAllOne',
    method: 'POST',
    data: params
  })
}

model.interfaceDelete = function (params) {
  return fetch({
    url: modelName + `service_api/${params.id}`,
    method: 'DELETE'
  })
}

// 更新/新增
model.interfaceUpdate = function (params) {
  return fetch({
    url: modelName + 'service_api',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 导入swagger，需添加fileUpload配置，跳过请求拦截中的参数处理
model.interfaceImportSw = function(file, params) {
  const formData = objToFormData(file)
  return fetch({
    url: modelName + 'service_api/import',
    method: 'POST',
    data: formData,
    params,
    // fileUpload: true,
    timeout: 30000,
    needLoading: true
  })
}

// 批量编排
model.bathGenDocs = function(params) {
  return fetch({
    url: modelName + 'service_api/bathGenDocs',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 更新接口
model.interfaceRefresh = function(params) {
  return fetch({
    url: modelName + `service_api/refresh/${params.id}`,
    method: 'GET',
    needLoading: true
  })
}

// 获取回滚配置
model.detailRollback = function(params) {
  return fetch({
    url: modelName + 'flow_consistency_rollback_api/get',
    method: 'GET',
    params
  })
}

// 新增/更新回滚配置
model.updateRollback = function(params) {
  return fetch({
    url: modelName + 'flow_consistency_rollback_api',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

export default model
