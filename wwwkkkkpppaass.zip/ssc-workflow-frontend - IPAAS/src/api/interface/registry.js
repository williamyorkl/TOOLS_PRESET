import fetch from '../fetch.js'
import { objToFormData } from '@/utils'
const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

model.getRegistryList = function (params) {
  return fetch({
    url: modelName + 'flow_registry_center/pageList',
    method: 'GET',
    params
  })
}

model.detailRegistry = function(params) {
  return fetch({
    url: modelName + `flow_registry_center/${params.id}`,
    method: 'GET'
  })
}

model.deleteRegistry = function(params) {
  return fetch({
    url: modelName + `flow_registry_center/${params.id}`,
    method: 'DELETE'
  })
}

model.updateRegistry = function(params) {
  return fetch({
    url: modelName + 'flow_registry_center',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

model.serviceList = function(params) {
  return fetch({
    url: modelName + 'flow_registry_center/service/list',
    method: 'GET',
    params
  })
}

// 应用列表
model.appList = function(params) {
  return fetch({
    url: modelName + 'flow_registry_center/fetchApps',
    method: 'POST',
    data: params
  })
}

export default model
