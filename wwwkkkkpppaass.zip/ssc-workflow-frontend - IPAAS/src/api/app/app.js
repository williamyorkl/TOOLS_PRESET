import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 列表: 所有应用
model.listApp = function (params = {}) {
  return fetch({
    url: modelName + 'flow_sys_app/list',
    method: 'POST',
    data: params
  })
}

// 列表: 当前用户的所有应用
model.listAppByUserId = function (params = {}) {
  return fetch({
    url: modelName + 'flow_sys_app/getByUserId',
    method: 'POST',
    data: params
  })
}

export default model
