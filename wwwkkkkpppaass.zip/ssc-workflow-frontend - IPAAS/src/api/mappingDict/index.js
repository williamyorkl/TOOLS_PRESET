import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 列表
model.getMappingDictList = function (params) {
  return fetch({
    url: modelName + 'flow_biz_dict_map/pageList',
    method: 'POST',
    data: params
  })
}

// 列表
model.getMappingDictAll = function (params = {}) {
  return fetch({
    url: modelName + 'flow_biz_dict_map/list',
    method: 'POST',
    data: params
  })
}

// 删除
model.deleteMappingDict = function(params) {
  return fetch({
    url: modelName + `flow_biz_dict_map/${params.id}`,
    method: 'DELETE'
  })
}

// 测试字典映射
model.checkMappingDict = function(params) {
  return fetch({
    url: modelName + 'flow_biz_dict_map/mapping/test',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 基础信息：详情
model.detailMappingDict = function(params) {
  return fetch({
    url: modelName + `flow_biz_dict_map/${params.id}`,
    method: 'GET'
  })
}

// 基础信息：新增/修改
model.updateMappingDict = function(params) {
  return fetch({
    url: modelName + 'flow_biz_dict_map',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

export default model
