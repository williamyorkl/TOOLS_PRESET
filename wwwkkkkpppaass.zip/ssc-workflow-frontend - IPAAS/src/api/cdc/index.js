import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 列表
model.getCDCList = function (params) {
  return fetch({
    url: modelName + 'flow_cdc_config/pageList',
    method: 'POST',
    data: params
  })
}

// 删除
model.deleteCDC = function(params) {
  return fetch({
    url: modelName + `flow_cdc_config/${params.id}`,
    method: 'DELETE'
  })
}

// 基础信息：详情
model.detailCDC = function(params) {
  return fetch({
    url: modelName + `flow_cdc_config/${params.id}`,
    method: 'GET'
  })
}

// 基础信息：新增/修改
model.updateCDC = function(params) {
  return fetch({
    url: modelName + 'flow_cdc_config',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 根据CDCId查表列表
model.getAllTable = function(params) {
  return fetch({
    url: modelName + `flow_cdc_config/listTable/${params.id}`,
    method: 'GET'
  })
}

// 根据CDCId和CdcTable查记录
model.getInputParam = function(params) {
  return fetch({
    url: modelName + 'flow_cdc_config/getInputParam',
    method: 'GET',
    params
  })
}
export default model
