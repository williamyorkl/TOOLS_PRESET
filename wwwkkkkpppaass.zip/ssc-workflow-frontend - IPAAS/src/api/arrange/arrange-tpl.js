import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 模板
// 列表
model.getTplList = function(params) {
  return fetch({
    url: modelName + 'flow_template_info/page/list',
    method: 'POST',
    data: params
  })
}

// 详情
model.getTplDetail = function(params) {
  return fetch({
    url: modelName + `flow_template_info/${params.id}`,
    method: 'GET',
    data: params
  })
}

// 新增/更新模板
model.updateTpl = function(params) {
  return fetch({
    url: modelName + 'flow_template_info',
    method: 'POST',
    data: params
  })
}

// 根据ID删除模板
model.deleteTpl = function(params) {
  return fetch({
    url: modelName + `flow_template_info/${params.id}`,
    method: 'DELETE'
  })
}

// 根据模板生成编排
model.createArrange = function(params) {
  return fetch({
    url: modelName + 'flow_template_info/save/definition',
    method: 'POST',
    data: params
  })
}

export default model
