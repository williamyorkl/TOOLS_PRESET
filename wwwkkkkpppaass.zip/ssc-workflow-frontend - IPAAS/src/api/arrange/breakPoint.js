import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 断点续跑
// 列表
model.listbreakPoint = function(params) {
  return fetch({
    url: modelName + 'flow_consistency_ladder_task',
    method: 'GET',
    params
  })
}

// 重试
model.retryBreakPoint = function(params) {
  return fetch({
    url: modelName + 'flow_consistency_ladder_task/exec',
    method: 'GET',
    params,
    needLoading: true
  })
}

// 作废
model.discardBreakPoint = function(params) {
  return fetch({
    url: modelName + 'flow_consistency_ladder_task/discard',
    method: 'GET',
    params,
    needLoading: true
  })
}

// 日志
model.logsBreakPoint = function(params) {
  return fetch({
    url: modelName + 'flow_operate_log/pageList',
    method: 'POST',
    data: params
  })
}

export default model
