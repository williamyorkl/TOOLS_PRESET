import fetch from '../fetch.js'

// import qs from 'qs'
import { objToFormData } from '@/utils'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 服务分组管理
// 列表
model.listGroup = function(params) {
  return fetch({
    url: modelName + 'flow_workflow_definition_group/pageList',
    method: 'GET',
    params
  })
}

// 列表(不分页)
model.listGroupCtrl = function(params) {
  return fetch({
    url: modelName + 'flow_workflow_definition_group/list',
    method: 'GET',
    params
  })
}

// 删除
model.deleteGroup = function(params) {
  return fetch({
    url: modelName + `flow_workflow_definition_group/${params.id}`,
    method: 'DELETE'
  })
}

// 基础信息：详情
model.detailGroup = function(params) {
  return fetch({
    url: modelName + `flow_workflow_definition_group/${params.id}`,
    method: 'GET'
  })
}

// 基础信息：新增/修改
model.updateGroup = function(params) {
  return fetch({
    url: modelName + 'flow_workflow_definition_group',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 编排信息
// 列表
model.listArrange = function(params) {
  return fetch({
    url: modelName + 'definition/pageList',
    method: 'POST',
    data: params
  })
}

// // 删除
// model.deleteArrange = function(params) {
//   return fetch({
//     url: modelName + 'definition/delete',
//     method: 'GET',
//     params
//   })
// }

// 导入，需添加fileUpload配置，跳过请求拦截中的参数处理
model.importArrange = function(params) {
  const formData = objToFormData(params)
  return fetch({
    url: modelName + 'shift/in',
    method: 'POST',
    data: formData,
    fileUpload: true,
    needLoading: true
  })
}

// 导出，需添加responseType: 'blob'表明接收数据的类型
model.exportArrange = function(params) {
  return fetch({
    url: modelName + 'shift/out',
    method: 'POST',
    data: params,
    responseType: 'blob',
    needLoading: true
  })
}

// 导入swagger，需添加fileUpload配置，跳过请求拦截中的参数处理
model.importSwArrange = function(params) {
  const formData = objToFormData(params)
  return fetch({
    url: modelName + 'definition/import',
    method: 'POST',
    data: formData,
    // fileUpload: true,
    timeout: 30000,
    needLoading: true
  })
}
// 基础信息：详情
model.detailArrangeHead = function(params) {
  return fetch({
    url: modelName + 'definition/get/doc/detail',
    method: 'GET',
    params
  })
}

// 基础信息：新增/修改
model.updateArrangeHead = function(params) {
  return fetch({
    url: modelName + 'definition/doc',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 编排：详情
model.detailArrange = function(params) {
  return fetch({
    url: modelName + 'definition/get/detail',
    method: 'GET',
    params
  })
}

// 编排：新增/修改
model.updateArrange = function(params) {
  return fetch({
    url: modelName + 'definition/addOrEdit',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 编排：同步接口
model.syncController = function(params) {
  return fetch({
    url: modelName + 'definition/sync/controller',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 限流: 新增/更新
model.limitArrange = function(params) {
  return fetch({
    url: modelName + 'flow_limit',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 限流
model.limitArrangeDetail = function(params) {
  return fetch({
    url: modelName + 'flow_limit/get',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 状态变更: 待发布-0；已上线-1；已下线-2  待发布 => 已上线 => 已下线 => 已上线
model.publishArrange = function(params) {
  return fetch({
    url: modelName + 'definition/publish',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// sql语句解析
model.parseSql = function(params) {
  return fetch({
    url: modelName + 'flow_data_base/sql/parser',
    method: 'POST',
    data: params
  })
}

// 调试：构造数据
model.mockDebuggerData = function(params) {
  return fetch({
    url: modelName + 'definition/mock/inparam',
    method: 'GET',
    params
  })
}

// 熔断：查详情
model.detailDegrade = function(params) {
  return fetch({
    url: modelName + 'flow_degrade/get',
    method: 'GET',
    params
  })
}

// 熔断：更新
model.updateDegrade = function(params) {
  return fetch({
    url: modelName + 'flow_degrade',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 数据一致性：详情
model.detailConsistency = function(params) {
  return fetch({
    url: modelName + 'flow_consistency_policy/get',
    method: 'GET',
    params
  })
}

// 数据一致性：更新/新增
model.updateConsistency = function(params) {
  return fetch({
    url: modelName + 'flow_consistency_policy',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// groovy刷新结构
model.getGroovyCode = function(params) {
  return fetch({
    url: modelName + 'definition/getGroovyCode',
    method: 'POST',
    data: params
  })
}

// 线程池设置：保存
model.saveThreadPoolSetting = function(params) {
  return fetch({
    url: modelName + 'flow_thread_pool/save',
    method: 'POST',
    data: params
  })
}

// 线程池设置：获取下来列表
model.getThreadPoolSetting = function(params) {
  return fetch({
    url: modelName + 'flow_thread_pool/list',
    method: 'POST',
    data: params
  })
}

export default model
