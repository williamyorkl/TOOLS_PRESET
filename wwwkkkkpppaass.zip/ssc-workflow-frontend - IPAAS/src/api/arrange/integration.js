import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 集成应用
// 列表
model.listIntergrationApp = function (params) {
  return fetch({
    url: modelName + 'flow_integration_app/pageList',
    method: 'POST',
    data: params
  })
}

// 详情
model.detailIntergrationApp = function (params) {
  return fetch({
    url: modelName + `flow_integration_app/${params.id}`,
    method: 'GET',
    params
  })
}

// 新增/保存
model.saveIntergrationApp = function (params) {
  return fetch({
    url: modelName + 'flow_integration_app',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

export default model
