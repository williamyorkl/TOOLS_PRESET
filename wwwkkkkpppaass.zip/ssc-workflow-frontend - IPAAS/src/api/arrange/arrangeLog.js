import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 编排日志
// 列表
model.listArrangeLog = function (params) {
  return fetch({
    url: modelName + 'flow_api_operation_log/pageList',
    method: 'POST',
    data: params
  })
}

// 根据日志id查询快照
model.detailArrangeSnapshot = function(params) {
  return fetch({
    url: modelName + `flow_api_operation_log/${params.id}`,
    method: 'GET'
  })
}

export default model
