import { Loading } from 'element-ui'

export class LoadingConfig {
  constructor({ needLoading = false, needError = false, needSuccess = false, loadingMsg = '加载中' }) {
    this.needLoading = needLoading
  }

  // 初始化
  loading = () => {
    // 不需要loading
    if (!this.needLoading) {
      return
    }

    // 需要loading，要先查看是否有loading实例，如果有，则不需要重新创建，给计数器加1
    if (!Loading.loading) {
      LoadingConfig.loading = Loading.service({
        lock: true,
        text: 'loading...',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const close = LoadingConfig.loading.close
      LoadingConfig.loading.close = (...args) => {
        this.closeLoading()
        return close.apply(LoadingConfig.loading, args)
      }
    }

    // 记录目前开启的请求数量
    LoadingConfig.loading._count ? (LoadingConfig.loading._count += 1) : (LoadingConfig.loading._count = 1)
  }

  // 在接口返回数据后，计数器减1
  apiEnd = (msg) => {
    if (!this.needLoading) {
      return
    }
    if (!LoadingConfig.loading) {
      return
    }
    LoadingConfig.loading._count--

    if (LoadingConfig.loading && LoadingConfig.loading._count <= 0) {
      LoadingConfig.loading.close()
    }
  }

  closeLoading = () => {
    if (!LoadingConfig.loading) {
      return
    }
    LoadingConfig.loading._count = 0
  }
}
