# api使用

##调用
1. 各模块应用对应api js
2. 公用map api在common/map内包装了一次，方便统一查看和调用。方法名前面加了_，区分和原有方法名
3. 公用map api使用场景：例如在订单详情页需要根据店铺id查询店铺详情。

	common/map.js
	
	```javascript
	import { getAllShopList, getShopList, getShopDetail } from '../shops';
	import { getAllPlatformList, getPlatformList, getPlatformDetail } from '../platform';
	export const _getAllShopList = getAllShopList; // 所有店铺列表
	export const _getShopList = getShopList; // 店铺分页列表
	export const _getShopDetail = getShopDetail; // 店铺详情
	
	export const _getAllPlatformList = getAllPlatformList; // 所有平台列表
	export const _getPlatformList = getPlatformList; // 平台分页列表
	export const _getPlatformDetail = getPlatformDetail; // 平台详情
	
	export default {
	  _getAllShopList,
	  _getShopList,
	  _getShopDetail,
	  _getAllPlatformList,
	  _getPlatformList,
	  _getPlatformDetail
	}
	```
	引用
	
	``` javascript
	import { _getAllShopList, _getAllPlatformList } from 'api/common/map';
	
	```

##封装
###post
通过data传参

``` javascript
return fetch({
	url: modelName + '/shopAutoAudit/disable',
	method: 'POST',
	data: params
})
```
###get
通过params传参

``` javascript
return fetch({
	url: modelName + '/getShop',
	method: 'GET',
	params: params
})
```
###export
1. 每个接口都export const
2. 所有接口合并export default

``` javascript
import fetch from '../fetch.js'
const modelName = '/ecu-admin/platform';

export const getPlatformList = function (params) {
  return fetch({
    url: modelName + '/listPlatformPage',
    method: 'GET',
    params: params
  })
}

export const getPlatformDetail = function (params) {
  return fetch({
    url: modelName + '/getPlatform',
    method: 'GET',
    params: params
  })
}

export default {
  getPlatformList,
  getPlatformDetail
};
```

##错误处理
###接口调用失败
fetch.js内

status | 提示 | 
--- | --- 
timeout | error，网络异常
>= 500 | error，服务器异常
404 | error，错误：404 ,请求的服务未找到
400 | error，错误：服务400
401 | 跳转系统默认页
403 | 跳转登录

###接口调用成功
>符合接口返回数据规范的data.code === 200表示成功，返回resolve；否则提示data.chnDesc，返回reject。如不需要错误提示，如数据字典接口，在对应api封装内传参noErrorToast: true

``` javascript
return fetch({
	noErrorToast: true,
	url: modelName + '/getShop',
	method: 'GET',
	params: params
})
```