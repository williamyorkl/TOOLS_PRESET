import { TIMEOUT_MILLISECONDS, WHITE_LIST } from 'config/api'
import { Message } from 'element-ui'
import store from 'store'

export const catchError = (err) => {
  console.log(err)
  if (err.response.config.noErrorToast) { // 默认提示接口返回的错误信息，不提示在调用时传入noErrorToast: true
    return Promise.reject(err)
  } else if (err.config.apiDebug) { // api调试结果全返回，时间计算
    err.config.metadata.endTime = Date.now()
    err.response.duration = err.config.metadata.endTime - err.config.metadata.startTime
    return Promise.reject(err.response)
  } else {
    if (err.response) {
      const { code, data } = err.response
      if (code >= 500) {
        if (data.message) {
          const msg = /[\u4e00-\u9fa5]+?.*[\u4e00-\u9fa5]+?/.exec(data.message)
          if (msg && msg[0]) {
            Message({
              type: 'error',
              message: '错误！服务器' + code
            })
          }
        } else {
          Message({
            type: 'error',
            message: '服务器异常'
          })
        }
      }
      if (code == 404) {
        Message({
          type: 'error',
          message: '错误：404 ,请求的服务未找到'
        })
      }
      if (code == 400) {
        Message({
          type: 'error',
          message: '错误：服务400'
        })
      }
      if (code === 403 || code === 403) {
        store.dispatch('user/logout')
      }
      return Promise.reject(err)
    } else {
      if (err.message === `timeout of ${TIMEOUT_MILLISECONDS}ms exceeded`) {
        Message({
          type: 'error',
          message: '网络异常'
        })
      }
      return Promise.reject(err)
    }
  }
}
