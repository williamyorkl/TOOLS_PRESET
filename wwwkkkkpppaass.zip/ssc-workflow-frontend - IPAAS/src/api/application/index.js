import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 列表
model.getAppList = function (params) {
  return fetch({
    url: modelName + 'flow_app/pageList',
    method: 'POST',
    data: params
  })
}

// 列表: 全部
model.getAppAll = function (params) {
  return fetch({
    url: modelName + 'flow_app/list',
    method: 'POST',
    data: params
  })
}

// 删除
model.deleteApp = function(params) {
  return fetch({
    url: modelName + `flow_app/${params.id}`,
    method: 'DELETE'
  })
}

// 详情
model.detailApp = function(params) {
  return fetch({
    url: modelName + `flow_app/${params.id}`,
    method: 'GET'
  })
}

// 新增/修改
model.updateApp = function(params) {
  return fetch({
    url: modelName + 'flow_app',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 关联接口
// 根据Appid获取app关联的接口列表
model.getBusinessApiList = function (params) {
  return fetch({
    url: modelName + 'flow_app_define_rela/list',
    method: 'POST',
    data: params
  })
}

// 根据Appid获取可用于新增的接口列表
model.getAllBusinessList = function (params) {
  return fetch({
    url: modelName + 'flow_app_define_rela/pageList',
    method: 'POST',
    data: params
  })
}

// 根据应用id和接口id查询应用接口的流控信息
model.getLimitByAppApiId = function(params) {
  return fetch({
    url: modelName + '',
    method: 'POST',
    data: params
  })
}

// 根据Appid获取doc
model.getDocById = function (params) {
  return fetch({
    responseType: 'blob',
    url: modelName + 'flow_app/getDocById',
    method: 'POST',
    data: params
  })
}

// 根据Appid获取SDK
model.getSdkById = function (params) {
  return fetch({
    responseType: 'blob',
    url: modelName + 'flow_app/getSdkById',
    method: 'POST',
    data: params
  })
}

export default model
