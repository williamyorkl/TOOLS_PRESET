import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 列表
model.getTableList = function(params) {
  return fetch({
    url: modelName + 'flow_low_table_field/pageList',
    method: 'POST',
    data: params
  })
}

// 详情
model.getTableDetail = function(params) {
  return fetch({
    url: modelName + 'flow_low_table_field/getDetail',
    method: 'POST',
    data: params
  })
}

// 新增
model.saveTable = function(params) {
  return fetch({
    url: modelName + 'flow_low_table_field/save',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 编辑
model.updateTable = function(params) {
  return fetch({
    url: modelName + 'flow_low_table_field/update',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 详情：索引管理
model.getTableIndexDetail = function(params) {
  return fetch({
    url: modelName + 'flow_low_table_field/getDetailIndex',
    method: 'POST',
    data: params
  })
}

// 编辑：索引管理
model.updateTableIndex = function(params) {
  return fetch({
    url: modelName + 'flow_low_table_field/updateIndex',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 查询数据表字段
model.getTableListPage = function(params) {
  return fetch({
    url: modelName + 'flow_low_table_field/pageTableList',
    method: 'POST',
    data: params
  })
}

export default model
