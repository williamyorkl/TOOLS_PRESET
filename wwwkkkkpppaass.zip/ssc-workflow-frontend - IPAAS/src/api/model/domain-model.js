import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 列表
model.getDomainList = function(params) {
  return fetch({
    url: modelName + 'flow_low_model/pageList',
    method: 'POST',
    data: params
  })
}

// 详情
model.getDomainDetail = function(params) {
  return fetch({
    url: modelName + `flow_low_model/${params.id}`,
    method: 'GET',
    data: params
  })
}

// 详情：领域服务
model.getServiceList = function(params) {
  return fetch({
    url: modelName + 'service_api/list',
    method: 'POST',
    data: params
  })
}

// 新增
model.saveDomain = function(params) {
  return fetch({
    url: modelName + 'flow_low_model/saveOrUpdate',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 修改
model.updateDomain = function(params) {
  return fetch({
    url: modelName + 'flow_low_model/saveOrUpdate',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 删除
model.deleteDomain = function(params) {
  return fetch({
    url: modelName + `flow_low_model/${params.id}`,
    method: 'DELETE'
  })
}

export default model
