import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 列表
model.getDatabaseList = function(params) {
  return fetch({
    url: modelName + 'flow_data_base/pageList',
    method: 'POST',
    data: params
  })
}

// 列表
model.getDatabaseAll = function(params) {
  return fetch({
    url: modelName + 'flow_data_base',
    method: 'GET',
    params
  })
}

// 删除
model.deleteDatabase = function(params) {
  return fetch({
    url: modelName + `flow_data_base/${params.id}`,
    method: 'DELETE'
  })
}

// 测试连接
model.checkDatabase = function(params) {
  return fetch({
    url: modelName + 'flow_data_base/check',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 基础信息：详情
model.detailDatabase = function(params) {
  return fetch({
    url: modelName + `flow_data_base/${params.id}`,
    method: 'GET'
  })
}

// 基础信息：新增/修改
model.updateDatabase = function(params) {
  return fetch({
    url: modelName + 'flow_data_base',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 根据数据库id查询所有的表和表字段
model.getTablesColumnsByDbId = function(params) {
  return fetch({
    url: modelName + `flow_data_base/tables/${params.id}`,
    method: 'GET'
  })
}

// 根据数据库id查表(分页)
model.getTablesColumnsByDbIdPage = function(params) {
  return fetch({
    url: modelName + 'flow_data_base/tables/pageList',
    method: 'POST',
    data: params
  })
}

// 根据表名查字段
model.getFields = function(params) {
  return fetch({
    url: modelName + 'flow_data_base/tables/columnList',
    method: 'GET',
    params
  })
}

export default model
