import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 列表查詢
model.getDatabaseList = function(params) {
  return fetch({
    url: modelName + 'flow_cache_source/pageList',
    method: 'POST',
    data: params
  })
}

// 列表
model.getDatabaseAll = function(params) {
  return fetch({
    url: modelName + 'flow_cache_source',
    method: 'GET',
    params
  })
}

// 删除
model.deleteDatabase = function(params) {
  return fetch({
    url: modelName + `flow_cache_source/${params.id}`,
    method: 'DELETE'
  })
}

// 测试连接
model.checkDatabase = function(params) {
  return fetch({
    url: modelName + 'flow_cache_source/check',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 基础信息：详情
model.detailDatabase = function(params) {
  return fetch({
    url: modelName + `flow_cache_source/${params.id}`,
    method: 'GET'
  })
}

// 基础信息：新增/修改
model.updateDatabase = function(params) {
  return fetch({
    url: modelName + 'flow_cache_source',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 根据数据库id查表(分页)
model.getTablesColumnsByDbIdPage = function(params) {
  return fetch({
    url: modelName + 'flow_cache_source/tables/pageList',
    method: 'POST',
    data: params
  })
}

// 操作参数类型推断
model.getInfetenceByType = function(params) {
  return fetch({
    url: modelName + `flow_cache_source/inference/${params.type}`,
    method: 'GET'
  })
}

export default model
