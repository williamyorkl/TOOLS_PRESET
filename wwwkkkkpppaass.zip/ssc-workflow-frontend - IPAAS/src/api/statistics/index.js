import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 后端服务报表
model.getServiceApiList = function (params) {
  return fetch({
    url: modelName + 'flow_stat_srv_api',
    method: 'GET',
    params
  })
}

// 用户接口报表
model.getBusinessApiList = function (params) {
  return fetch({
    url: modelName + 'flow_stat_biz_api',
    method: 'GET',
    params
  })
}

export default model
