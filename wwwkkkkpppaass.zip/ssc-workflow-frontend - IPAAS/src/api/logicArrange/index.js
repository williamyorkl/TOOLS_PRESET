import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 列表
model.getArrangeList = function (params) {
  return fetch({
    url: modelName + 'logic/definition/pageList',
    method: 'POST',
    data: params
  })
}

// 删除
model.deleteArrange = function(params) {
  return fetch({
    url: modelName + `logic/definition/${params.id}`,
    method: 'DELETE'
  })
}

// 基础信息：详情
model.detailArrange = function(params) {
  return fetch({
    url: modelName + `logic/definition/${params.id}`,
    method: 'GET'
  })
}

// 基础信息：新增
model.createArrange = function(params) {
  return fetch({
    url: modelName + 'logic/definition/add',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 基础信息：修改
model.updateArrange = function(params) {
  return fetch({
    url: modelName + 'logic/definition/edit',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 逻辑编排：上线/发布
model.releaseLogicArrange = function(params) {
  return fetch({
    url: modelName + `logic/definition/release/${params.id}`,
    method: 'GET',
    needLoading: true
  })
}

// 逻辑编排：下线
model.downLogicArrange = function(params) {
  return fetch({
    url: modelName + `logic/definition/down/${params.id}`,
    method: 'GET',
    needLoading: true
  })
}

// 触发任务执行
model.trigger = function (params) {
  return fetch({
    url: modelName + `logic/definition/trigger/${params.id}`,
    method: 'GET',
    needLoading: true
  })
}
export default model
