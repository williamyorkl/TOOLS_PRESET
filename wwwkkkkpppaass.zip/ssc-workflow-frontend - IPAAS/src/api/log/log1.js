import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

model.getNodeList = function(params) {
  return fetch({
    url: modelName + `flow_node_log/listByTraceId/${params.traceId}`,
    method: 'GET'
  })
}

model.testError = function(params) {
  return fetch({
    url: modelName + 'testError',
    method: 'POST',
    data: params
  })
}

// 节点列表 {definitionId}
model.getNodeIdList = function(params) {
  return fetch({
    url: modelName + 'definition/getNodeIdList',
    method: 'POST',
    data: params
  })
}

// 错误下拉 {}
model.getAllErrorType = function(params) {
  return fetch({
    url: modelName + 'flow_warn_msg/getAllErrorType',
    method: 'POST',
    data: params
  })
}

/* 异常统计一级页面 {
  "errorType" : 1,
  "errorCode" : 500005,
  "integrationAppId": null,
  "nodeId" : 3124
}
*/
model.getWarnList = function(params) {
  return fetch({
    url: modelName + 'flow_warn_msg/pageList',
    method: 'POST',
    data: params
  })
}

/* 异常统计二级页面 {
  "warnMsgId" : 1644
}
*/
model.getNodeLogs = function(params) {
  return fetch({
    url: modelName + 'flow_warn_msg/nodeLogs',
    method: 'POST',
    data: params
  })
}

export default model
