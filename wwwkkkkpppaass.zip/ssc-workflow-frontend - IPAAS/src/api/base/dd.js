import fetch from '../fetch.js'
import { getSession, setSession } from 'utils/cache'
const ddModel = {}
const ctrlName = '/ecu-admin'; const modelName = '/dd'
ddModel.getValues = (key) => {
  const value = getSession(key)
  // if(value === 'pending') {
  // 	return Promise.resolve([])
  // }
  if (value) {
    return Promise.resolve(value)
  }
  // else{
  // 	setSession(key, 'pending')
  // }
  return fetch({
    // url: '/dd/key/getDetail',
    url: ctrlName + '/dd/getDDValueListByKey',
    method: 'get',
    params: { ddKey: key }
  }).then(res => {
    if (res.content && res.content.length > 0) {
      let list = []
      list = res.content.map(i => ({
        name: i.label,
        value: i.value
        // desc: res.content.ddName
      }))
      setSession(key, list)
      return list
    }
    return []
  })
}
ddModel.getValueLabel = (key, value) => {
  return ddModel.getValues(key).then(result => {
    var dd, ref

    if (value === void 0) {
      return ''
    }
    if (result) {
      for (const i of result) {
      	if (i.value == value) {
          return i.name
      	}
      }
    }
    return ''
  })
}
export default ddModel
