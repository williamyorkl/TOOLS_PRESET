import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 用户：列表
model.listUser = function(params) {
  return fetch({
    url: modelName + 'flow_sys_user/page',
    method: 'POST',
    data: params
  })
}

// 用户：新增
model.saveUser = function(params) {
  return fetch({
    url: modelName + 'flow_sys_user/save',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 用户：更新
model.updateUser = function(params) {
  return fetch({
    url: modelName + 'flow_sys_user/update',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 用户：详情
model.detailUser = function(params) {
  return fetch({
    url: modelName + `flow_sys_user/${params.id}`,
    method: 'GET',
    params
  })
}

// 用户：删除
model.deleteUser = function(params) {
  return fetch({
    url: modelName + `flow_sys_user/${params.id}`,
    method: 'DELETE'
  })
}

export default model
