import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 列表
model.getContactList = function (params) {
  return fetch({
    url: modelName + 'flow_contact/page',
    method: 'POST',
    data: params
  })
}

// 列表
model.getContactAll = function (params) {
  return fetch({
    url: modelName + 'flow_contact/list',
    method: 'POST',
    data: params
  })
}

// 删除
model.deleteContact = function(params) {
  return fetch({
    url: modelName + `flow_contact/${params.id}`,
    method: 'DELETE'
  })
}

// 基础信息：详情
model.detailContact = function(params) {
  return fetch({
    url: modelName + `flow_contact/${params.id}`,
    method: 'GET'
  })
}

// 基础信息：新增/修改
model.saveContact = function(params) {
  return fetch({
    url: modelName + 'flow_contact',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 填充dingtalk信息
model.fillDingTalkById = function(params) {
  return fetch({
    url: modelName + 'flow_contact/fillDingTalkById',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 填充微信信息
model.fillWxById = function(params) {
  return fetch({
    url: modelName + 'flow_contact/fillWeChatById',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

export default model
