import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 获取错误码结构
model.getErrorStruct = function(params) {
  return fetch({
    url: modelName + 'flow_error_struct/list',
    method: 'POST',
    data: params
  })
}

// 新增 错误码字段
model.saveErrStruct = function(params) {
  return fetch({
    url: modelName + 'flow_error_struct/save',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 新增/更新 错误码字段
model.updateErrStruct = function(params) {
  return fetch({
    url: modelName + 'flow_error_struct/update',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 根据id查错误码字段
model.detailErrStruct = function(params) {
  return fetch({
    url: modelName + `flow_error_struct/${params.id}`,
    method: 'GET'
  })
}

// 根据id删除错误码字段
model.deleteErrStruct = function(params) {
  return fetch({
    url: modelName + `flow_error_struct/${params.id}`,
    method: 'DELETE'
  })
}

// 获取错误码信息列表
model.getErrByPage = function(params) {
  return fetch({
    url: modelName + 'flow_error_info/page2Map',
    method: 'POST',
    data: params
  })
}

// 获取错误码信息列表
model.getErrStructByPage = function(params) {
  return fetch({
    url: modelName + 'flow_error_struct/page',
    method: 'POST',
    data: params
  })
}

// 新增 错误码信息
model.saveErrInfo = function(params) {
  return fetch({
    url: modelName + 'flow_error_info/save',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 更新 错误码信息
model.updateErrInfo = function(params) {
  return fetch({
    url: modelName + 'flow_error_info/update',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 根据id查错误码信息
model.detailErrInfo = function(params) {
  return fetch({
    url: modelName + `flow_error_info/${params.id}`,
    method: 'GET'
  })
}

// 根据id删除错误码信息
model.deleteErrInfo = function(params) {
  return fetch({
    url: modelName + `flow_error_info/${params.id}`,
    method: 'DELETE'
  })
}

export default model
