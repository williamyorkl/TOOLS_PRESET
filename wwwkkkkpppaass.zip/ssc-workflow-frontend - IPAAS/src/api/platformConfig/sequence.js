import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 列表
model.getSequenceList = function(params) {
  return fetch({
    url: modelName + 'sequence/list',
    method: 'POST',
    data: params
  })
}

// 删除
model.deleteSequence = function(params) {
  return fetch({
    url: modelName + `sequence/delete/${params.id}`,
    method: 'DELETE'
  })
}

// 基础信息：详情
model.detailSequence = function(params) {
  return fetch({
    url: modelName + `sequence/detail/${params.id}`,
    method: 'GET'
  })
}

// 基础信息：新增
model.saveSequence = function(params) {
  return fetch({
    url: modelName + 'sequence/add',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 基础信息：修改
model.updateSequence = function(params) {
  return fetch({
    url: modelName + 'sequence/edit',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 发布
model.publishSequence = function(params) {
  return fetch({
    url: modelName + `sequence/publish/${params.id}`,
    method: 'POST',
    data: params,
    needLoading: true
  })
}

export default model
