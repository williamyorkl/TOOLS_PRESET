import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 错误码结构主表（分页）
model.listResStruct = function(params) {
  return fetch({
    url: modelName + 'flow_error_struct_head/pageList',
    method: 'POST',
    data: params
  })
}

// 错误码结构详情
model.detailResStruct = function(params) {
  return fetch({
    url: modelName + `flow_error_struct_head/${params.id}`,
    method: 'GET'
  })
}

// 新增错误码结构
model.saveResStruct = function(params) {
  return fetch({
    url: modelName + 'flow_error_struct_head/save',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 更新错误码结构
model.updateResStruct = function(params) {
  return fetch({
    url: modelName + 'flow_error_struct_head/update',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 删除错误码结构
model.deleteResStruct = function(params) {
  return fetch({
    url: modelName + `flow_error_struct_head/${params.id}`,
    method: 'DELETE'
  })
}

// 获取默认结构
model.getDefaultStruct = function(params = {}) {
  return fetch({
    url: modelName + 'flow_error_struct_head/getDefaultStruct',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

export default model
