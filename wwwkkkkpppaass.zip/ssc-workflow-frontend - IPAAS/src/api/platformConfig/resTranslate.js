import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 错误码翻译主表（分页）
model.listResTranslate = function(params) {
  return fetch({
    url: modelName + 'flow_error_translate/pageList',
    method: 'POST',
    data: params
  })
}

// 错误码翻译详情
model.detailResTranslate = function(params) {
  return fetch({
    url: modelName + `flow_error_translate/${params.id}`,
    method: 'GET'
  })
}

// 新增错误码翻译
model.saveResTranslate = function(params) {
  return fetch({
    url: modelName + 'flow_error_translate/save',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 更新错误码翻译
model.updateResTranslate = function(params) {
  return fetch({
    url: modelName + 'flow_error_translate/update',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 删除错误码翻译
model.deleteResTranslate = function(params) {
  return fetch({
    url: modelName + `flow_error_translate/${params.id}`,
    method: 'DELETE'
  })
}

export default model
