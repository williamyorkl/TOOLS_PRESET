import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 列表
model.getVariableList = function(params) {
  return fetch({
    url: modelName + 'flow_global_key_val/page',
    method: 'POST',
    data: params
  })
}

// 删除
model.deleteVariable = function(params) {
  return fetch({
    url: modelName + 'flow_global_key_val/delete',
    method: 'DELETE',
    data: params
  })
}

// 基础信息：详情
model.detailVariable = function(params) {
  return fetch({
    url: modelName + 'flow_global_key_val/get',
    method: 'GET',
    params
  })
}

// 基础信息：新增
model.saveVariable = function(params) {
  return fetch({
    url: modelName + 'flow_global_key_val/save',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 基础信息：修改
model.updateVariable = function(params) {
  return fetch({
    url: modelName + 'flow_global_key_val/update',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

export default model
