import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 基础信息：详情
model.detailConfig = function(params) {
  return fetch({
    url: modelName + 'flow_global_config/getByTenant',
    method: 'POST'
  })
}

// 基础信息：新增
model.saveConfig = function(params) {
  return fetch({
    url: modelName + 'flow_global_config/save',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 基础信息：修改
model.updateConfig = function(params) {
  return fetch({
    url: modelName + 'flow_global_config/update',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

export default model
