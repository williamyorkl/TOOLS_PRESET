import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 错误码信息（分页）
model.listResInfo = function(params) {
  return fetch({
    url: modelName + 'flow_error_info/page',
    method: 'POST',
    data: params
  })
}

// 错误码信息详情
model.detailResInfo = function(params) {
  return fetch({
    url: modelName + `flow_error_info/${params.id}`,
    method: 'GET'
  })
}

// 新增错误码信息
model.saveResInfo = function(params) {
  return fetch({
    url: modelName + 'flow_error_info/save',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 更新错误码信息
model.updateResInfo = function(params) {
  return fetch({
    url: modelName + 'flow_error_info/update',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 删除错误码信息
model.deleteResInfo = function(params) {
  return fetch({
    url: modelName + `flow_error_info/${params.id}`,
    method: 'DELETE'
  })
}

export default model
