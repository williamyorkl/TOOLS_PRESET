import fetch from '../fetch.js'
import { objToFormData } from '@/utils'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 环境迁移：列表
model.listMigrate = function(params) {
  return fetch({
    url: modelName + 'flow_migrate/pageList',
    method: 'POST',
    data: params
  })
}

// 环境迁移：新增
model.saveMigrate = function(params) {
  return fetch({
    url: modelName + 'flow_migrate',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 环境迁移：详情
model.detailMigrate = function(params) {
  return fetch({
    url: modelName + `flow_migrate/${params.id}`,
    method: 'GET',
    params
  })
}

// 导入，需添加fileUpload配置，跳过请求拦截中的参数处理
model.importMigrate = function(params) {
  const formData = objToFormData(params)
  return fetch({
    url: modelName + 'flow_migrate/import',
    method: 'POST',
    data: formData,
    fileUpload: true,
    needLoading: true
  })
}

// 导出，需添加responseType: 'blob'表明接收数据的类型
model.exportMigrate = function(params) {
  return fetch({
    url: modelName + 'flow_migrate/export',
    method: 'POST',
    data: params,
    responseType: 'blob',
    timeout: 20000,
    needLoading: true
  })
}

export default model
