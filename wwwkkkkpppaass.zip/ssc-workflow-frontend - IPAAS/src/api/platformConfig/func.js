import fetch from '../fetch.js'

const modelName = process.env.VUE_APP_AUTH_PREFIX
const model = {}

// 列表
model.getFuncList = function(params) {
  return fetch({
    url: modelName + 'func/pageList',
    method: 'GET',
    params
  })
}

// 列表
model.getFuncListAll = function(params) {
  return fetch({
    url: modelName + 'func/list',
    method: 'GET',
    params
  })
}

// 二级列表
model.getFuncLevelTwoListAll = function(params) {
  return fetch({
    url: modelName + 'func/levelTwoList',
    method: 'GET',
    params
  })
}

// 删除
model.deleteFunc = function(params) {
  return fetch({
    url: modelName + 'func/delete',
    method: 'DELETE',
    params
  })
}

// 函数：详情
model.detailFunc = function(params) {
  return fetch({
    url: modelName + 'func/get',
    method: 'GET',
    params
  })
}

// 函数：新增/修改
model.saveFunc = function(params) {
  return fetch({
    url: modelName + 'func/save',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

// 函数：转换参数
model.transParams = function(params) {
  return fetch({
    url: modelName + 'func/inference',
    method: 'POST',
    data: params,
    needLoading: true
  })
}

model.checkScript = function(params) {
  return fetch({
    url: modelName + 'func/check/ql/script',
    method: 'POST',
    data: params
  })
}

export default model
