# baseline-admin-web

### 初始化：
```
git submodule init
git submodule update
npm install / yarn install
```
### 开发环境：连后端本地
```
npm run dev:private
```
### 其他环境待定
```
# 包含多种权限
npm run build:private
# 155测试环境，旧的登录
npm run build:container
# srm特供版：支持通过修改`src/router/routes.srm.js`后打包来控制菜单项
npm run build:private-srm
```
## 约定与规范

### 样式

* 使用sass预处理
* vue文件下的样式统一加上`scoped`作用域
* 需要覆盖全局的样式写在styles文件夹下, 并在index.scss中引入（如：element.scss覆盖element-ui的样式）

### js规范

使用standard标准， 建议在编辑器中安装eslint插件
如果有特殊情况要使用第三方的js，可允许添加上 /* eslint-disable */

### 异步流

使用`Promise`处理异步流


### 联调

与后端人员联调时，由于每人连的IP都不一样，为了避免频繁的冲突，~~每个人都需要在本地修改/config/dev.env.js文件中的PROXY_TABLE~~,修改后不用上传到SVN

## 目录结构
```shell
├── src                        // 源代码
│   ├── api                    // 所有请求
│   ├── assets                 // 主题 字体等静态资源
│   ├── components             // 全局公用组件
│   │   ├── common             // 通用组件
│   │   ├── layout             // 布局相关
│   ├── directives             // 全局指令
│   ├── filters                // 全局filter
│   ├── styles                 // 全局样式
│   ├── utils                  // 全局公用方法
│   ├── views                  // 页面


```

## 公共样式说明
```shell
├── styles                     // 样式文件
│   ├── commom.scss            // 主题相关公共样式
│   ├── element.scss           // 改写elementUI组件样式
│   ├── index.scss             // 样式入口文件
│   ├── mixin.scss             // 混合样式@minxin
│   ├── public.scss            // 公共样式
│   ├── reset.scss             // css初始化文件
│   ├── vars.scss              // 主题变量文件
```
