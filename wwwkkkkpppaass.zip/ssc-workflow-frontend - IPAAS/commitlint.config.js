module.exports = {
  extends: [
    '@commitlint/config-conventional'
  ],
  rules: {
    'type-enum': [2, 'always', [
      'feat', // 新功能
      'fix', // 修复
      'refactor', // 重构
      'docs', // 文档
      'chore', // 构建工具、辅助工具、配置
      'style', // 结构、格式（不影响代码运行的变动）
      'revert', // 回退
      'test' // 测试
    ]],
    'scope-empty': [2, 'never']
  }
}
